-- MANCING MANIA v2: suka, komentar, kiriman spot/ikan baru (aman dijalankan ulang)
create table if not exists public.likes (
  catch_id uuid not null references public.catches(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (catch_id, user_id)
);
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  catch_id uuid not null references public.catches(id) on delete cascade,
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 300),
  created_at timestamptz not null default now()
);
create index if not exists comments_catch_idx on public.comments (catch_id, created_at);
create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind text not null check (kind in ('spot','fish')),
  name text not null check (char_length(trim(name)) between 2 and 60),
  region text check (region in ('ID','AU')),
  area text check (area is null or char_length(area) <= 80),
  lat double precision, lon double precision,
  fish text check (fish is null or char_length(fish) <= 40),
  status text not null default 'baru' check (status in ('baru','setuju','tolak')),
  created_at timestamptz not null default now()
);
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.submissions enable row level security;

drop policy if exists "suka dibaca" on public.likes;
create policy "suka dibaca" on public.likes for select using (true);
drop policy if exists "suka sendiri" on public.likes;
create policy "suka sendiri" on public.likes for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "batal suka" on public.likes;
create policy "batal suka" on public.likes for delete to authenticated using (user_id = auth.uid());

drop policy if exists "komentar dibaca" on public.comments;
create policy "komentar dibaca" on public.comments for select using (true);
drop policy if exists "komentar ditulis" on public.comments;
create policy "komentar ditulis" on public.comments for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "komentar dihapus" on public.comments;
create policy "komentar dihapus" on public.comments for delete to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists "kiriman dibaca" on public.submissions;
create policy "kiriman dibaca" on public.submissions for select using (status = 'setuju' or user_id = auth.uid() or public.is_admin());
drop policy if exists "kiriman dibuat" on public.submissions;
create policy "kiriman dibuat" on public.submissions for insert to authenticated with check (user_id = auth.uid() and status = 'baru');
drop policy if exists "kiriman dinilai admin" on public.submissions;
create policy "kiriman dinilai admin" on public.submissions for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "kiriman dihapus" on public.submissions;
create policy "kiriman dihapus" on public.submissions for delete to authenticated using (user_id = auth.uid() or public.is_admin());

grant select on public.likes, public.comments, public.submissions to anon, authenticated;
grant insert, delete on public.likes, public.comments to authenticated;
grant insert, update, delete on public.submissions to authenticated;
