package com.mancingmania.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
