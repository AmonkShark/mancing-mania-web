-- MANCING MANIA v8: tab Komunitas (postingan, komentar, reaksi, laporan, ikuti, blokir admin). Aman dijalankan ulang.
create table if not exists public.banned_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  reason text, created_at timestamptz not null default now()
);
create or replace function public.is_banned() returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.banned_users where user_id = auth.uid())
$$;

create table if not exists public.cposts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  kind text not null default 'tangkapan' check (kind in ('tangkapan','tanya','info','jual')),
  body text not null check (char_length(trim(body)) between 1 and 2000),
  photos text[] not null default '{}' check (cardinality(photos) <= 4),
  grp text check (grp is null or char_length(grp) <= 40),
  region text check (region in ('ID','AU')),
  spot_id text, spot_name text check (spot_name is null or char_length(spot_name) <= 60),
  fish text check (fish is null or char_length(fish) <= 40),
  length_cm int check (length_cm is null or length_cm between 1 and 400),
  answered boolean not null default false,
  hidden boolean not null default false,
  report_count int not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists cposts_time_idx on public.cposts (created_at desc);
create index if not exists cposts_grp_idx on public.cposts (grp, created_at desc);

create table if not exists public.ccomments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.cposts(id) on delete cascade,
  parent_id uuid references public.ccomments(id) on delete cascade,
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 1000),
  hidden boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists ccomments_post_idx on public.ccomments (post_id, created_at);

create table if not exists public.creactions (
  post_id uuid not null references public.cposts(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  emoji text not null default 'like' check (emoji in ('like','love','fire')),
  primary key (post_id, user_id)
);

create table if not exists public.creports (
  post_id uuid not null references public.cposts(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  reason text check (reason is null or char_length(reason) <= 200),
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.follows (
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind text not null check (kind in ('user','spot','fish')),
  target text not null check (char_length(target) between 1 and 80),
  created_at timestamptz not null default now(),
  primary key (user_id, kind, target)
);

-- saringan kata kasar / negatif (server), batas spam
create or replace function public.bad_text(t text) returns boolean language sql immutable as $$
  select coalesce(lower(t),'') ~ '(^|[^a-z])(anjing|anjg|ajg|bangsat|bgst|kontol|kntl|memek|mmk|ngentot|ngntt|jembut|pepek|perek|pelacur|lonte|bokep|porno|sange|coli|goblok|tolol|kafir|babi lu|cina lo|judi online|judol|slot gacor|togel|pinjol|pinjaman online|fuck|fucking|shit|bitch|cunt|dick|pussy|porn|nude|nudes|xxx|nigger|faggot|onlyfans)([^a-z]|$)'
$$;
create or replace function public.cposts_guard() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.is_banned() then raise exception 'Akun diblokir dari komunitas'; end if;
  if public.bad_text(new.body) then raise exception 'Postingan mengandung kata yang tidak diizinkan'; end if;
  if tg_op = 'INSERT' and (select count(*) from public.cposts where user_id = new.user_id and created_at > now() - interval '1 hour') >= 6 then
    raise exception 'Terlalu banyak postingan, coba lagi nanti'; end if;
  if tg_op = 'UPDATE' and not public.is_admin() then new.hidden := old.hidden; new.report_count := old.report_count; end if;
  return new;
end $$;
drop trigger if exists cposts_guard on public.cposts;
create trigger cposts_guard before insert or update on public.cposts for each row execute function public.cposts_guard();

create or replace function public.ccomments_guard() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.is_banned() then raise exception 'Akun diblokir dari komunitas'; end if;
  if public.bad_text(new.body) then raise exception 'Komentar mengandung kata yang tidak diizinkan'; end if;
  if (select count(*) from public.ccomments where user_id = new.user_id and created_at > now() - interval '1 hour') >= 40 then
    raise exception 'Terlalu banyak komentar, coba lagi nanti'; end if;
  return new;
end $$;
drop trigger if exists ccomments_guard on public.ccomments;
create trigger ccomments_guard before insert on public.ccomments for each row execute function public.ccomments_guard();

-- 3 laporan = disembunyikan otomatis
create or replace function public.creports_after() returns trigger language plpgsql security definer set search_path = public as $$
declare n int;
begin
  select count(*) into n from public.creports where post_id = new.post_id;
  update public.cposts set report_count = n, hidden = (hidden or n >= 3) where id = new.post_id;
  return new;
end $$;
drop trigger if exists creports_after on public.creports;
create trigger creports_after after insert on public.creports for each row execute function public.creports_after();

alter table public.cposts enable row level security;
alter table public.ccomments enable row level security;
alter table public.creactions enable row level security;
alter table public.creports enable row level security;
alter table public.follows enable row level security;
alter table public.banned_users enable row level security;

drop policy if exists "cp baca" on public.cposts;
create policy "cp baca" on public.cposts for select using (not hidden or user_id = auth.uid() or public.is_admin());
drop policy if exists "cp buat" on public.cposts;
create policy "cp buat" on public.cposts for insert to authenticated with check (user_id = auth.uid() and not hidden and report_count = 0);
drop policy if exists "cp ubah" on public.cposts;
create policy "cp ubah" on public.cposts for update to authenticated using (user_id = auth.uid() or public.is_admin()) with check (user_id = auth.uid() or public.is_admin());
drop policy if exists "cp hapus" on public.cposts;
create policy "cp hapus" on public.cposts for delete to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists "cc baca" on public.ccomments;
create policy "cc baca" on public.ccomments for select using (not hidden or user_id = auth.uid() or public.is_admin());
drop policy if exists "cc buat" on public.ccomments;
create policy "cc buat" on public.ccomments for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "cc hapus" on public.ccomments;
create policy "cc hapus" on public.ccomments for delete to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists "cr baca" on public.creactions;
create policy "cr baca" on public.creactions for select using (true);
drop policy if exists "cr buat" on public.creactions;
create policy "cr buat" on public.creactions for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "cr ubah" on public.creactions;
create policy "cr ubah" on public.creactions for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "cr hapus" on public.creactions;
create policy "cr hapus" on public.creactions for delete to authenticated using (user_id = auth.uid());

drop policy if exists "lap buat" on public.creports;
create policy "lap buat" on public.creports for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "lap baca" on public.creports;
create policy "lap baca" on public.creports for select to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists "ikut baca" on public.follows;
create policy "ikut baca" on public.follows for select using (true);
drop policy if exists "ikut buat" on public.follows;
create policy "ikut buat" on public.follows for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "ikut hapus" on public.follows;
create policy "ikut hapus" on public.follows for delete to authenticated using (user_id = auth.uid());

drop policy if exists "ban admin" on public.banned_users;
create policy "ban admin" on public.banned_users for all to authenticated using (public.is_admin()) with check (public.is_admin());

grant select on public.cposts, public.ccomments, public.creactions, public.follows to anon, authenticated;
grant insert, update, delete on public.cposts, public.ccomments, public.creactions, public.follows to authenticated;
grant select, insert on public.creports to authenticated;
grant select, insert, delete on public.banned_users to authenticated;
