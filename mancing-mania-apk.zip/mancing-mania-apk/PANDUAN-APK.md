# Membuat APK Mancing Mania (gratis, tanpa install apa pun di komputer)

Folder ini adalah **proyek Android** Mancing Mania. Kamu tidak perlu memasang Android Studio. **GitHub** (gratis) yang akan merakit file `.apk` untukmu di server mereka.

Hasil akhirnya:
- **APK debug**: bisa langsung di-install di HP Android-mu dan HP teman, untuk dicoba dan dibagikan.
- **APK + AAB rilis bertanda tangan** (opsional): untuk dirilis di Google Play Store.

Waktu yang dibutuhkan sekitar 20 menit untuk pertama kali. Setelah itu, setiap perubahan otomatis dirakit ulang.

---

## Langkah 1 — Buat akun & repository GitHub

1. Daftar gratis di **https://github.com/signup**.
2. Klik **+** (kanan atas) → **New repository**:
   - Repository name: `mancing-mania`
   - Pilih **Private** (hanya kamu yang bisa melihat kodenya).
   - Klik **Create repository**.

## Langkah 2 — Upload isi folder ini

1. Di halaman repository yang baru, klik link **uploading an existing file**.
2. Buka folder `mancing-mania-apk` di komputermu, **pilih semua isinya** (bukan foldernya), lalu seret ke halaman GitHub.
   - Pastikan folder **`.github`** ikut terupload. Di Mac, folder berawalan titik tersembunyi: tekan **Cmd + Shift + .** di Finder untuk menampilkannya. Di Windows biasanya sudah terlihat.
   - Folder `node_modules` (kalau ada) **tidak perlu** diupload.
3. Tulis pesan "Upload pertama", lalu klik **Commit changes**.

## Langkah 3 — Masukkan kunci Supabase (agar komunitas aktif)

Kalau kamu sudah membuat Supabase (lihat PANDUAN.md di paket web):

1. Di repository: **Settings → Secrets and variables → Actions → New repository secret**.
2. Tambahkan dua secret:
   - `SUPABASE_URL`, contoh `https://abcdxyz.supabase.co`
   - `SUPABASE_ANON_KEY`, isinya kunci anon/publishable

Kalau belum punya Supabase, lewati langkah ini. APK tetap jalan, hanya fitur komunitas (tangkapan bersama, saran & laporan) yang belum aktif.

## Langkah 4 — Rakit APK

1. Buka tab **Actions**. Kalau diminta, klik **I understand my workflows, go ahead and enable them**.
2. Pilih **Build APK** di kiri → **Run workflow** → **Run workflow**.
3. Tunggu ±5–10 menit sampai muncul tanda ✅ hijau.
4. Klik proses itu. Di bagian bawah **Artifacts**, unduh **MancingMania-debug-apk**. Hasilnya file zip berisi `app-debug.apk`.

> Setiap kali kamu mengubah file di repository (misalnya `www/config.js` atau data spot di `www/app.js`), GitHub otomatis merakit APK baru.

## Langkah 5 — Install di HP Android

1. Pindahkan `app-debug.apk` ke HP, lewat WhatsApp ke diri sendiri, Google Drive, atau kabel USB.
2. Ketuk file itu di HP. Kalau muncul peringatan, izinkan **Instal aplikasi tidak dikenal** untuk aplikasi yang kamu pakai membuka file (misalnya Files/Chrome/WhatsApp).
3. Buka **Mancing Mania**. Izinkan **lokasi** untuk GPS dan **kamera** untuk foto tangkapan saat diminta.

Login di aplikasi memakai **kode 6 digit dari email**. Pastikan template email Supabase sudah diubah sesuai PANDUAN.md (bagian Magic Link).

---

## Opsional — Rilis ke Google Play Store

Play Store butuh aplikasi yang **ditandatangani dengan kunci rilis milikmu**.

**A. Buat kunci rilis (sekali seumur aplikasi)**
1. **Actions → Buat kunci rilis → Run workflow**. Isi kata sandi (min. 6 karakter) dan namamu.
2. Setelah selesai, unduh artifact **kunci-rilis**. Isinya `mancing-mania.jks`, `KEYSTORE_BASE64.txt`, dan `PETUNJUK.txt`.
3. ⚠️ **Simpan `mancing-mania.jks` dan kata sandinya di tempat aman** (Google Drive pribadi plus flashdisk). Kalau hilang, kamu tidak bisa memperbarui aplikasi di Play Store.
4. Hapus run "Buat kunci rilis" itu dari GitHub (klik ⋯ → Delete workflow run).

**B. Simpan kunci sebagai Secrets** (Settings → Secrets and variables → Actions):
- `KEYSTORE_BASE64`: seluruh isi file `KEYSTORE_BASE64.txt`
- `KEYSTORE_PASSWORD`: kata sandi tadi
- `KEY_ALIAS`: `mancingmania`
- `KEY_PASSWORD`: kata sandi tadi

**C. Jalankan lagi "Build APK".** Sekarang ada artifact tambahan **MancingMania-rilis** berisi:
- `app-release.aab`: diupload ke **Google Play Console** (akun developer US$25, sekali bayar).
- `app-release.apk`: versi rilis bertanda tangan, untuk dibagikan langsung.

**D. Sebelum upload versi baru ke Play Store**, naikkan nomor versi di `android/app/build.gradle`: `versionCode 1` → `2` (wajib naik setiap rilis), dan `versionName "1.0"` → `"1.1"`.

Untuk listing Play Store, siapkan juga:
- Ikon 512×512: `www/icons/icon-512.png`
- Banner 1024×500: `www/icons/feature-graphic.png`
- Link kebijakan privasi dan hapus akun: halaman `privacy.html` dan `hapus-akun.html` yang sudah online (misalnya di Netlify, lihat PANDUAN.md)
- Formulir *Data safety*: aplikasi mengumpulkan email, nama panggilan, foto, lokasi spot (dibulatkan), dan isi saran/laporan.

---

## Cara lain (kalau punya komputer dengan Android Studio)

```bash
npm install
npx cap sync android
npx cap open android      # lalu di Android Studio: Build → Build APK(s)
```

## Isi folder

```
www/                       aplikasi Mancing Mania (sama dengan versi web)
www/config.js              kunci Supabase & video (bisa juga lewat Secrets)
android/                   proyek Android (ikon marlin, splash, izin GPS & kamera)
capacitor.config.json      nama & ID aplikasi: com.mancingmania.app
.github/workflows/         pabrik APK otomatis di GitHub
package.json               daftar komponen Capacitor
```

**ID aplikasi** `com.mancingmania.app` tidak bisa diganti setelah terbit di Play Store. Kalau ingin ID lain, ganti dulu di `capacitor.config.json` dan `android/app/build.gradle` (applicationId) sebelum rilis pertama.
