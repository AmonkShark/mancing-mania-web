-- MANCING MANIA v6: penghitung pengunjung (termasuk tanpa login), aman dijalankan ulang
create table if not exists public.visits (
  day date not null,
  device text not null check (char_length(device) between 8 and 64),
  region text check (region in ('ID','AU')),
  platform text check (platform in ('web','pwa','apk')),
  primary key (day, device)
);
alter table public.visits enable row level security;
revoke all on public.visits from anon, authenticated;

create or replace function public.record_visit(p_device text, p_region text, p_platform text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_device is null or char_length(p_device) < 8 or char_length(p_device) > 64 then return; end if;
  insert into public.visits(day, device, region, platform)
  values ((now() at time zone 'Asia/Makassar')::date, p_device,
          case when p_region in ('ID','AU') then p_region end,
          case when p_platform in ('web','pwa','apk') then p_platform end)
  on conflict (day, device) do update set region = excluded.region, platform = excluded.platform;
end $$;
grant execute on function public.record_visit(text, text, text) to anon, authenticated;

create or replace function public.visit_stats()
returns json language plpgsql security definer set search_path = public as $$
declare t date := (now() at time zone 'Asia/Makassar')::date; r json;
begin
  if not public.is_admin() then raise exception 'khusus admin'; end if;
  select json_build_object(
    'today', (select count(*) from visits where day = t),
    'd7', (select count(distinct device) from visits where day > t - 7),
    'd30', (select count(distinct device) from visits where day > t - 30),
    'all', (select count(distinct device) from visits),
    'id7', (select count(distinct device) from visits where day > t - 7 and region = 'ID'),
    'au7', (select count(distinct device) from visits where day > t - 7 and region = 'AU'),
    'apk7', (select count(distinct device) from visits where day > t - 7 and platform = 'apk'),
    'days', (select coalesce(json_agg(json_build_object('d', d, 'n', n) order by d), '[]'::json)
             from (select day d, count(*) n from visits where day > t - 14 group by day) x)
  ) into r;
  return r;
end $$;
grant execute on function public.visit_stats() to authenticated;
