
/* ================= DATA ================= */
const LOC=[
 {id:"balmoral",n:"Balmoral",a:"Middle Harbour",lat:-33.827,lon:151.252,type:"Pantai & dermaga",fish:["Bream","Whiting","Flathead","Tarwhine","Squid"],
  spots:"Ujung dermaga untuk squid saat subuh; pasir depan rotunda untuk whiting; karang Rocky Point untuk bream.",
  bait:{"Udang mentah":["Bream","Whiting","Tarwhine"],"Cacing laut":["Whiting"],"Squid jig":["Squid"],"Soft plastic kecil":["Flathead","Bream"]},tide:"Pasang naik, pagi atau senja."},
 {id:"watsons",n:"Watsons Bay",a:"South Head",lat:-33.843,lon:151.282,type:"Dermaga",fish:["Yellowtail","Squid","Bream","Trevally","Luderick"],
  spots:"Sisi dalam dermaga untuk yellowtail & squid; tiang dermaga untuk bream.",
  bait:{"Roti":["Yellowtail","Luderick"],"Udang mentah":["Bream","Trevally"],"Squid jig":["Squid"],"Rumput laut hijau":["Luderick"]},tide:"Pasang tinggi & air jernih."},
 {id:"spit",n:"The Spit Bridge",a:"Middle Harbour",lat:-33.804,lon:151.246,type:"Tepi & jembatan",fish:["Kingfish","Bream","Flathead","Squid","Tailor"],
  spots:"Tiang jembatan & marina untuk kingfish dan bream; pasir arah Clontarf untuk flathead.",
  bait:{"Squid hidup":["Kingfish"],"Soft plastic besar":["Kingfish","Flathead"],"Udang mentah":["Bream"],"Metal lure":["Tailor"]},tide:"Arus kuat saat pasang perbani."},
 {id:"cabarita",n:"Cabarita",a:"Parramatta River",lat:-33.840,lon:151.116,type:"Taman & dermaga",fish:["Bream","Flathead","Mulloway","Estuary Perch","Luderick"],
  spots:"Dermaga dan taman Cabarita; tepi berbatu untuk bream; malam hari untuk mulloway.",
  bait:{"Udang mentah":["Bream"],"Potongan cumi":["Mulloway","Flathead"],"Soft plastic kecil":["Bream","Flathead","Estuary Perch"],"Squid hidup":["Mulloway"]},tide:"Malam + pasang tinggi. Ada peringatan konsumsi ikan di sungai ini, cek NSW DPI."},
 {id:"bareisland",n:"Bare Island",a:"La Perouse",lat:-33.991,lon:151.231,type:"Batu & jembatan",fish:["Luderick","Drummer","Bream","Yellowtail","Squid"],
  spots:"Sekitar jembatan untuk luderick & squid; batu sisi timur untuk drummer.",
  bait:{"Rumput laut hijau":["Luderick"],"Roti":["Drummer","Yellowtail"],"Udang mentah":["Bream","Yellowtail"],"Squid jig":["Squid"]},tide:"Pasang turun di sekitar jembatan."},
 {id:"kurnell",n:"Kurnell",a:"Botany Bay",lat:-34.008,lon:151.207,type:"Batu & pantai",fish:["Flathead","Bream","Trevally","Salmon Australia","Tailor","Snapper"],
  spots:"Silver Beach untuk flathead & whiting; Inscription Point untuk salmon, tailor & snapper (hati-hati ombak).",
  bait:{"Pilchard utuh":["Tailor","Salmon Australia","Snapper"],"Soft plastic besar":["Flathead","Snapper"],"Udang mentah":["Bream","Trevally"],"Metal lure":["Salmon Australia","Tailor"]},tide:"Pergantian arus; tailor saat senja."},
 {id:"bundeena",n:"Bundeena",a:"Port Hacking",lat:-34.084,lon:151.151,type:"Dermaga & flat",fish:["Whiting","Flathead","Bream","Squid","Luderick"],
  spots:"Flat pasir Gunnamatta & Bundeena untuk whiting dan flathead; dermaga untuk squid.",
  bait:{"Cacing laut":["Whiting"],"Udang mentah":["Whiting","Bream"],"Soft plastic kecil":["Flathead"],"Squid jig":["Squid"],"Rumput laut hijau":["Luderick"]},tide:"Pasang naik di atas flat pasir."},
 {id:"longreef",n:"Long Reef",a:"Northern Beaches",lat:-33.741,lon:151.310,type:"Batu & pantai",fish:["Salmon Australia","Tailor","Drummer","Bream","Whiting"],
  spots:"Pantai Collaroy–Long Reef untuk whiting & salmon; batu tanjung untuk drummer dan tailor.",
  bait:{"Pilchard utuh":["Tailor","Salmon Australia"],"Cacing laut":["Whiting"],"Roti":["Drummer"],"Metal lure":["Salmon Australia","Tailor"]},tide:"Pagi buta & senja; batu hanya saat laut tenang."},
 {id:"brooklyn",n:"Brooklyn",a:"Hawkesbury River",lat:-33.548,lon:151.226,type:"Sungai & dermaga",fish:["Mulloway","Flathead","Bream","Estuary Perch","Squid"],
  spots:"Dermaga Brooklyn; tiang jembatan kereta untuk mulloway; teluk bakau untuk bream & perch.",
  bait:{"Squid hidup":["Mulloway"],"Potongan cumi":["Mulloway","Flathead"],"Soft plastic kecil":["Bream","Estuary Perch","Flathead"],"Udang mentah":["Bream"]},tide:"Saat arus berhenti (slack) untuk mulloway."}
];
/* Spesies: ilustrasi (warna badan/punggung, bentuk, pola) + aturan + ciri pengenal */
const SP={
 "Bream":{b:"#c9cfc8",d:"#6f7a6a",fin:"#e3c24a",h:.42,pat:"",min:27,lim:"min. 27 cm, maks 20",ciri:"Badan tinggi pipih, perak kehijauan, sirip perut & dubur kuning (yellowfin bream).",lat:"Acanthopagrus australis"},
 "Flathead":{b:"#b59a72",d:"#7d6544",fin:"#c9a16a",h:.22,flat:1,pat:"spots",min:36,lim:"36–70 cm, maks 10",ciri:"Kepala gepeng lebar, badan pipih memanjang, bintik cokelat; ekor ada bercak biru-hitam (dusky).",lat:"Platycephalus fuscus"},
 "Whiting":{b:"#e8dcc0",d:"#b8a682",fin:"#d8c79f",h:.24,pat:"",min:27,lim:"min. 27 cm",ciri:"Ramping, moncong runcing, warna pasir keemasan, bintik hitam di pangkal sirip dada.",lat:"Sillago ciliata"},
 "Squid":{squid:1,b:"#e9c9c9",d:"#b07b88",min:0,lim:"maks 20",ciri:"Badan tabung bening-kemerahan, sirip lebar di sepanjang badan (southern calamari).",lat:"Sepioteuthis australis"},
 "Kingfish":{b:"#dfe7ea",d:"#4f6e86",fin:"#e8c33a",h:.28,pat:"stripe",min:65,lim:"min. 65 cm, maks 5",ciri:"Torpedo, punggung biru-hijau, garis kuning dari mata ke ekor, ekor kuning bercabang.",lat:"Seriola lalandi"},
 "Mulloway":{b:"#c8ccd2",d:"#7b8590",fin:"#a7a9a5",h:.3,pat:"",min:70,lim:"min. 70 cm, maks 2",ciri:"Perak-perunggu, besar, garis lateral bertitik terang, ekor membulat lurus.",lat:"Argyrosomus japonicus"},
 "Snapper":{b:"#e6a59a",d:"#c06d63",fin:"#e7a39a",h:.42,pat:"bluespots",min:30,lim:"min. 30 cm, maks 10",ciri:"Merah-merah muda dengan bintik biru terang, dahi menonjol pada ikan besar.",lat:"Chrysophrys auratus"},
 "Tailor":{b:"#d4dde0",d:"#5f7f87",fin:"#b8c6c6",h:.28,pat:"",min:30,lim:"min. 30 cm, maks 20",ciri:"Perak kebiruan, gigi tajam, sirip ekor gelap bercabang.",lat:"Pomatomus saltatrix"},
 "Luderick":{b:"#8f9a86",d:"#4b5446",fin:"#636c5a",h:.38,pat:"bars",min:27,lim:"min. 27 cm, maks 10",ciri:"Hijau keabu gelap dengan garis-garis vertikal tipis, mulut kecil (blackfish).",lat:"Girella tricuspidata"},
 "Drummer":{b:"#4d5552",d:"#2e3432",fin:"#3a403e",h:.42,pat:"",min:30,lim:"min. 30 cm",ciri:"Hitam pekat, badan tebal & tinggi, sangat kuat di karang (rock blackfish).",lat:"Girella elevata"},
 "Salmon Australia":{b:"#d9dfd6",d:"#4f6a6e",fin:"#9fb0a6",h:.28,pat:"spots",min:0,lim:"maks 5",ciri:"Torpedo, punggung hijau-biru dengan bintik gelap, perut perak.",lat:"Arripis trutta"},
 "Trevally":{b:"#dfe3e3",d:"#91a2a8",fin:"#e3cf6a",h:.4,pat:"",min:0,lim:"maks 20",ciri:"Perak, badan tinggi pipih, bercak hitam di tutup insang, garis lateral bersisik keras.",lat:"Pseudocaranx georgianus"},
 "Yellowtail":{b:"#d5dfe0",d:"#5c7f86",fin:"#e8c33a",h:.24,pat:"stripe",min:0,lim:"sering jadi umpan hidup",ciri:"Kecil ramping, ekor kuning, garis lateral bersisik (yellowtail scad).",lat:"Trachurus novaezelandiae"},
 "Tarwhine":{b:"#d7d8cc",d:"#9aa08c",fin:"#e3c24a",h:.42,pat:"lines",min:23,lim:"min. 23 cm",ciri:"Mirip bream tapi ada garis-garis keemasan horizontal di badan.",lat:"Rhabdosargus sarba"},
 "Estuary Perch":{b:"#b9b9a3",d:"#6b6d58",fin:"#8e8c74",h:.36,pat:"",min:0,lim:"maks 2",ciri:"Perunggu-zaitun, dahi cekung, duri sirip punggung tajam.",lat:"Percalates colonorum"}
};
const BAITINFO={"Udang mentah":"Umpan paling universal. Pasang dari ekor sampai mata kail tertutup.","Cacing laut":"Beachworm / bloodworm, terbaik untuk whiting.","Squid jig":"Umpan tiruan udang khusus cumi, ukuran 2.5–3.0.","Soft plastic kecil":"Grub/minnow 2–3 inci di jighead 1/8 oz.","Soft plastic besar":"Jerkbait 4–5 inci di jighead 1/4–3/8 oz.","Roti":"Murah; untuk berley dan umpan di kail kecil.","Rumput laut hijau":"Untuk luderick, pakai dengan float rig.","Squid hidup":"Umpan terbaik untuk kingfish & mulloway.","Potongan cumi":"Strip cumi awet di kail, untuk ikan dasar.","Pilchard utuh":"Ikan mati (mulie) di gang hook untuk tailor & salmon.","Metal lure":"Logam 20–40 g, lempar jauh & gulung cepat."};

/* Data pasang Fort Denison dari WillyWeather (13–19 Okt 2026), jam AEDT */
const TIDE_SRC="https://tides.willyweather.com.au/nsw/sydney/fort-denison.html";
const TIDES=[["2026-10-13",[["04:05",.47],["10:33",1.73],["17:03",.42],["23:00",1.34]]],["2026-10-14",[["04:35",.54],["11:09",1.70],["17:46",.47],["23:40",1.27]]],["2026-10-15",[["05:08",.61],["11:45",1.65],["18:30",.53]]],["2026-10-16",[["00:23",1.20],["05:45",.68],["12:27",1.58],["19:21",.59]]],["2026-10-17",[["01:13",1.15],["06:31",.73],["13:14",1.51],["20:19",.63]]],["2026-10-18",[["02:12",1.11],["07:30",.78],["14:12",1.46],["21:26",.64]]],["2026-10-19",[["03:25",1.12],["08:43",.80],["15:21",1.43],["22:30",.61]]]];

const $=s=>document.querySelector(s);
const store={get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}};
let mySpots=store.get("mm_spots",[]);
let curId=store.get("mm_cur","balmoral"),view="peta",dayOff=0,learn="animasi",fishSel=null;
const allSpots=()=>LOC.concat(mySpots).filter(s=>(s.region||regionOf(s.lat,s.lon))===region);const everySpot=()=>LOC.concat(mySpots);
const cur=()=>allSpots().find(s=>s.id===curId)||allSpots()[0];
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

/* ================= ILUSTRASI IKAN ================= */
function fishSVG(name,w){return `<span class="fishpic" data-sp="${esc(name)}">${fishSVG0(name,w)}</span>`}
function fishSVG0(name,w=200){
  const s=SP[name]||SP.Bream,H=100;
  if(s.squid){return `<svg viewBox="0 0 200 100" role="img" aria-label="${name}"><path d="M20 50 Q30 20 110 30 L140 50 L110 70 Q30 80 20 50Z" fill="${s.b}"/><path d="M28 50 Q40 18 110 32 Q80 50 110 68 Q40 82 28 50Z" fill="none" stroke="${s.d}" stroke-width="2" opacity=".6"/><g stroke="${s.d}" stroke-width="3" stroke-linecap="round"><path d="M140 46 Q165 40 190 36"/><path d="M140 50 Q168 50 192 50"/><path d="M140 54 Q165 60 190 64"/><path d="M138 44 Q160 30 178 26"/><path d="M138 56 Q160 70 178 74"/></g><circle cx="128" cy="44" r="5" fill="#222"/><circle cx="129" cy="43" r="1.5" fill="#fff"/></svg>`}
  const h=s.h*H*1.6, top=50-h/2, bot=50+h/2;
  const body=`M28 50 Q${s.flat?45:55} ${top} 110 ${top+2} Q150 ${top+4} 172 ${s.flat?48:46} Q176 50 172 ${s.flat?52:54} Q150 ${bot-2} 110 ${bot} Q55 ${bot} 28 50Z`;
  let pat="";
  if(s.pat==="spots")for(let i=0;i<14;i++)pat+=`<circle cx="${50+((i*37)%110)}" cy="${top+6+((i*13)%Math.max(6,h*.45))}" r="2.6" fill="${s.d}" opacity=".7"/>`;
  if(s.pat==="bluespots")for(let i=0;i<12;i++)pat+=`<circle cx="${60+((i*29)%100)}" cy="${top+8+((i*11)%Math.max(6,h*.5))}" r="1.8" fill="#4aa3e0"/>`;
  if(s.pat==="bars")for(let x=55;x<160;x+=11)pat+=`<line x1="${x}" y1="${top+4}" x2="${x-3}" y2="${bot-4}" stroke="${s.d}" stroke-width="2" opacity=".5"/>`;
  if(s.pat==="lines")for(let k=1;k<5;k++)pat+=`<path d="M45 ${top+k*h/5} Q110 ${top+k*h/5-3} 165 ${50+(k-2.5)*3}" stroke="${s.fin}" stroke-width="1.3" fill="none" opacity=".8"/>`;
  if(s.pat==="stripe")pat+=`<path d="M40 50 Q110 ${50-2} 172 50" stroke="${s.fin}" stroke-width="4" fill="none"/>`;
  return `<svg viewBox="0 0 200 100" role="img" aria-label="${name}">
   <path d="M30 50 L6 ${50-h*.45} Q14 50 6 ${50+h*.45}Z" fill="${s.fin||s.d}"/>
   <path d="M70 ${top+3} Q100 ${top-14} 135 ${top+4}Z" fill="${s.fin||s.d}" opacity=".9"/>
   <path d="M85 ${bot-2} Q100 ${bot+10} 115 ${bot-1}Z" fill="${s.fin||s.d}" opacity=".9"/>
   <path d="${body}" fill="${s.b}"/>
   <path d="M28 50 Q55 ${top} 110 ${top+2} Q150 ${top+4} 172 ${s.flat?48:46} Q120 ${50-h*.15} 28 50Z" fill="${s.d}" opacity=".75"/>
   ${pat}
   <path d="M150 ${top+8} Q144 50 150 ${bot-8}" stroke="${s.d}" stroke-width="1.5" fill="none" opacity=".6"/>
   <circle cx="160" cy="${48-h*.08}" r="4.5" fill="#fff"/><circle cx="161" cy="${48-h*.08}" r="2.6" fill="#1a1a1a"/>
   <path d="M120 54 Q132 62 140 56" fill="${s.fin||s.d}" opacity=".85"/></svg>`;
}
const fishMini=n=>`<span class="fishmini">${fishSVG(n)}${esc(n)}</span>`;

/* ================= PETA LEMPAR (skema lokal per spot) =================
   Kotak 300x190: air di atas, darat di bawah, pemancing di tepi. face = arah kompas air di depan pemancing. 1 unit ≈ 0.6 m */
const SCENE={
 balmoral:{face:90,shore:"Dermaga & pantai",me:[150,168],f:{sand:[150,105],weed:[60,80],rocks:[255,120],pylons:[95,140],deep:[175,35]}},
 watsons:{face:270,shore:"Ujung dermaga",me:[150,150],f:{pylons:[120,135],weed:[40,95],sand:[230,100],deep:[150,40],rocks:[270,140]}},
 spit:{face:0,shore:"Tepi selatan jembatan",me:[110,168],f:{pylons:[150,95],deep:[150,40],sand:[250,130],snags:[45,120],weed:[60,70]}},
 cabarita:{face:0,shore:"Dermaga taman",me:[150,165],f:{pylons:[175,140],rocks:[50,130],snags:[260,125],deep:[150,45],sand:[100,95]}},
 bareisland:{face:180,shore:"Jembatan Bare Island",me:[150,160],f:{pylons:[120,130],weed:[220,95],rocks:[45,110],whitewater:[260,40],deep:[150,45]}},
 kurnell:{face:0,shore:"Batu Inscription Point",me:[150,168],f:{whitewater:[85,95],reef:[200,60],deep:[150,25],sand:[255,140],rocks:[40,140]}},
 bundeena:{face:0,shore:"Pantai & dermaga",me:[150,168],f:{sand:[120,115],weed:[230,95],pylons:[260,145],deep:[150,35],rocks:[40,130]}},
 longreef:{face:90,shore:"Tepi batu tanjung",me:[150,168],f:{whitewater:[110,110],reef:[200,55],sand:[40,120],deep:[160,25],rocks:[250,130]}},
 brooklyn:{face:0,shore:"Dermaga Brooklyn",me:[150,165],f:{pylons:[210,110],deep:[150,40],snags:[45,120],weed:[90,90],sand:[260,135]}}
};
const FEAT={sand:"Pasir & drop-off",weed:"Rumput laut",rocks:"Karang/batu",pylons:"Tiang dermaga/jembatan",deep:"Alur dalam",whitewater:"Air berbuih",reef:"Karang dalam",snags:"Kayu tenggelam/bakau"};
const HABITAT={Kingfish:["pylons","deep","reef"],Bream:["pylons","rocks","snags"],Flathead:["sand"],Whiting:["sand"],Squid:["weed"],Luderick:["weed","rocks"],Drummer:["whitewater","rocks"],Tailor:["whitewater","deep"],"Salmon Australia":["whitewater","sand"],Mulloway:["deep","pylons"],Snapper:["reef","deep"],Trevally:["deep","pylons"],Yellowtail:["pylons","weed"],Tarwhine:["rocks","weed"],"Estuary Perch":["snags","rocks"]};
const HOWTO={Kingfish:"Lempar dan gulung cepat melewati tiang; tahan kuat agar ikan tidak lari ke tiang.",Bream:"Biarkan umpan jatuh pelan di dekat struktur, jangan terlalu banyak digerakkan.",Flathead:"Lempar melewati drop-off lalu seret/lompatkan kembali melintasi tepinya.",Whiting:"Lempar ke air dangkal berpasir, gulung sangat pelan.",Squid:"Lempar ke tepi rumput laut, biarkan jig tenggelam lalu sentak.",Luderick:"Hanyutkan float di sepanjang rumput laut mengikuti arus.",Drummer:"Pancing di buih tepat di depan batu, senar kuat, tanpa banyak pemberat.",Tailor:"Lempar jauh ke air berbuih saat senja, gulung cepat.","Salmon Australia":"Lempar metal lure ke buih atau parit pantai.",Mulloway:"Turunkan umpan hidup ke alur dalam saat arus melambat.",Snapper:"Pemberat ringan, biarkan umpan tenggelam pelan ke karang dalam.",Trevally:"Pakai berley, umpan di tengah kolom air.",Yellowtail:"Kail kecil + roti/udang dekat dermaga dengan berley.",Tarwhine:"Udang kecil di dekat karang dangkal.","Estuary Perch":"Lempar soft plastic ke dekat kayu, biarkan tenggelam."};
const compass=d=>["Utara","Timur Laut","Timur","Tenggara","Selatan","Barat Daya","Barat","Barat Laut"][Math.round(((d%360)+360)%360/45)%8];
function castMap(spotId,fish){
  const S=SCENE[spotId]||autoScene(everySpot().find(x=>x.id===spotId)||{});
  const feats=Object.entries(S.f),want=HABITAT[fish]||[];
  const tgtKey=want.find(k=>S.f[k]);if(!tgtKey)return `<p class="note">Habitat ${fish} tidak umum di spot ini.</p>`;
  const[tx,ty]=S.f[tgtKey],boat=mode==="perahu",[mx,my]=boat?[Math.min(270,Math.max(30,tx+(tx<150?55:-55))),Math.min(150,ty+40)]:S.me,dx=tx-mx,dy=ty-my;
  const dist=Math.round(Math.hypot(dx,dy)*.6/5)*5,ang=Math.atan2(dx,-dy)/rad,bear=(S.face+ang+360)%360;
  const shape=(k,[x,y],on)=>{const st=on?`stroke="var(--sand)" stroke-width="2.5"`:"";const op=on?1:.55;
    if(k==="sand")return `<ellipse cx="${x}" cy="${y}" rx="45" ry="18" fill="#e7d6a8" opacity="${op}" ${st}/>`;
    if(k==="weed")return `<g opacity="${op}">${[0,1,2,3,4].map(i=>`<path d="M${x-20+i*10} ${y+12} q-4 -12 0 -24" stroke="#3f8a4f" stroke-width="3" fill="none"/>`).join("")}${on?`<circle cx="${x}" cy="${y}" r="24" fill="none" ${st}/>`:""}</g>`;
    if(k==="rocks"||k==="reef")return `<g opacity="${op}">${[[-14,4],[0,-6],[14,5],[-4,10]].map(([a,b])=>`<circle cx="${x+a}" cy="${y+b}" r="${k==="reef"?9:8}" fill="${k==="reef"?"#8a6f6a":"#7d7a70"}"/>`).join("")}${on?`<circle cx="${x}" cy="${y}" r="24" fill="none" ${st}/>`:""}</g>`;
    if(k==="pylons")return `<g opacity="${op}">${[-20,-7,6,19].map(a=>`<rect x="${x+a-3}" y="${y-14}" width="6" height="28" fill="#6b5a45"/>`).join("")}${on?`<rect x="${x-28}" y="${y-20}" width="56" height="40" rx="6" fill="none" ${st}/>`:""}</g>`;
    if(k==="deep")return `<ellipse cx="${x}" cy="${y}" rx="70" ry="16" fill="var(--accent)" opacity="${on?.35:.18}" ${st}/>`;
    if(k==="whitewater")return `<g opacity="${op}">${[0,1,2].map(i=>`<path d="M${x-30} ${y-8+i*8} q10 -6 20 0 t20 0 t20 0" stroke="#fff" stroke-width="3" fill="none"/>`).join("")}${on?`<circle cx="${x}" cy="${y}" r="28" fill="none" ${st}/>`:""}</g>`;
    if(k==="snags")return `<g opacity="${op}"><path d="M${x-22} ${y+8} L${x+18} ${y-8} M${x-8} ${y+2} l-6 -14 M${x+6} ${y-3} l8 -12" stroke="#5b4630" stroke-width="4" fill="none"/>${on?`<circle cx="${x}" cy="${y}" r="24" fill="none" ${st}/>`:""}</g>`;
  };
  return `<div class="cast"><svg viewBox="0 0 300 200" role="img" aria-label="Peta lempar ${fish}" id="castSvg" data-a="${mx},${my},${(mx+tx)/2+dx*.15-20},${Math.min(my,ty)-30},${tx},${ty+6}" data-fish="${fish}">
    <defs><marker id="ah" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto"><path d="M0 0 L8 4 L0 8z" fill="var(--sand)"/></marker></defs>
    <rect width="300" height="200" fill="var(--sea)"/><path d="M0 175 Q80 165 150 172 T300 170 V200 H0Z" fill="var(--land)"/>
    ${feats.map(([k,p])=>shape(k,p,k===tgtKey)).join("")}
    <path d="M${mx} ${my} Q${(mx+tx)/2+dx*.15-20} ${Math.min(my,ty)-30} ${tx} ${ty+6}" fill="none" stroke="var(--sand)" stroke-width="2.5" stroke-dasharray="6 4" marker-end="url(#ah)" opacity=".45"/><g id="ca"><path id="caLine" fill="none" stroke="var(--fg)" stroke-width="1.2" opacity=".8"/><g id="caRings"></g><g id="caFish" opacity="0"><path d="M0 0 q-12 -8 -24 0 q12 8 24 0z M0 0 l8 -6 v12z" fill="var(--fg)" opacity=".75"/></g><circle id="caLure" r="4.5" fill="var(--sand)" stroke="var(--fg)" stroke-width="1.5" cx="-20" cy="-20"/></g>
    ${boat?`<path d="M${mx-14} ${my-2} h28 l-6 9 h-16z" fill="var(--fg)"/><rect x="${mx-4}" y="${my-10}" width="8" height="8" fill="var(--fg)"/><text x="${mx+16}" y="${my+4}" font-size="10" fill="var(--fg)">Perahu</text>`:`<circle cx="${mx}" cy="${my}" r="7" fill="var(--fg)"/><text x="${mx+10}" y="${my+4}" font-size="10" fill="var(--fg)">Kamu</text>`}
    <text x="${tx}" y="${ty-26}" font-size="10" text-anchor="middle" fill="var(--fg)" font-weight="600" paint-order="stroke" stroke="var(--sea)" stroke-width="3">${fish} di sini</text>
    <g transform="translate(276,22)"><circle r="14" fill="var(--surface)" stroke="var(--line)"/><path d="M0 -10 L4 2 L0 0 L-4 2Z" fill="var(--bad)" transform="rotate(${-S.face})"/><text y="-17" font-size="8" text-anchor="middle" fill="var(--muted)" transform="rotate(${-S.face})">U</text></g>
   </svg>
   <div class="row" style="margin-top:8px"><div class="kv"><span class="tag">Arah lempar</span><strong>${compass(bear)}</strong><span class="note">${Math.round(bear)}°</span></div><div class="kv"><span class="tag">Jarak ±</span><strong>${Math.max(5,dist)} m</strong></div><div class="kv"><span class="tag">Target</span><strong style="font-size:.95rem">${FEAT[tgtKey]}</strong></div></div>
   <p class="note">${boat?"Posisikan perahu di sisi atas arus, lalu biarkan hanyut (drift) melewati target. Jangan jangkar di atas karang hidup.":"Posisi berdiri: "+S.shore+"."} ${HOWTO[fish]||""}</p></div>`;
}


/* ================= INDONESIA ================= */
LOC.forEach(l=>l.region="AU");
LOC.push(
 {id:"ancol",region:"ID",n:"Pantai Ancol",a:"Jakarta",lat:-6.122,lon:106.84,type:"Dermaga & pemecah ombak",fish:["Kakap Putih","Baronang","Belanak","Cumi","Bawal"],
  spots:"Ujung pemecah ombak untuk kakap putih saat air pasang; batu berlumut untuk baronang & belanak; lampu dermaga malam hari untuk cumi.",
  bait:{"Udang hidup":["Kakap Putih","Bawal"],"Lumut":["Baronang","Belanak"],"Squid jig":["Cumi"],"Soft plastic kecil":["Kakap Putih"]},tide:"Pasang naik menjelang malam."},
 {id:"seribu",region:"ID",n:"Pulau Pramuka",a:"Kepulauan Seribu",lat:-5.745,lon:106.614,type:"Dermaga & karang",fish:["Kerapu","Kakap Merah","GT","Tongkol","Cumi","Baronang"],
  spots:"Tubir (tepi karang yang turun ke laut dalam) untuk kerapu & kakap merah; perairan terbuka untuk tongkol; dermaga malam untuk cumi.",
  bait:{"Potongan cumi":["Kerapu","Kakap Merah"],"Ikan umpan hidup":["GT","Kerapu"],"Jig logam":["Tongkol","GT"],"Squid jig":["Cumi"],"Lumut":["Baronang"]},tide:"Arus mulai bergerak, pagi atau sore."},
 {id:"anyer",region:"ID",n:"Anyer",a:"Banten",lat:-6.06,lon:105.88,type:"Pantai batu & dermaga",fish:["Kakap Merah","Kerapu","Barakuda","Baronang","Cumi"],
  spots:"Batu karang di sepanjang pantai untuk kerapu & baronang; ujung dermaga untuk barakuda dan cumi.",
  bait:{"Potongan cumi":["Kakap Merah","Kerapu"],"Ikan umpan hidup":["Barakuda","Kerapu"],"Lumut":["Baronang"],"Squid jig":["Cumi"]},tide:"Pasang naik, laut tenang."},
 {id:"pelabuhanratu",region:"ID",n:"Pelabuhan Ratu",a:"Sukabumi",lat:-7.0,lon:106.53,type:"Pantai & batu karang",fish:["GT","Tenggiri","Barakuda","Kakap Merah","Tongkol"],
  spots:"Batu karang dan buih ombak untuk GT; muara dan perairan terbuka untuk tenggiri & tongkol. Ombak Samudra Hindia besar, waspada.",
  bait:{"Popper":["GT"],"Jig logam":["Tenggiri","Tongkol","Barakuda"],"Ikan umpan hidup":["Tenggiri","Barakuda"],"Potongan cumi":["Kakap Merah"]},tide:"Subuh, saat ombak kecil."},
 {id:"karimunjawa",region:"ID",n:"Karimunjawa",a:"Jawa Tengah",lat:-5.86,lon:110.43,type:"Pulau & karang",fish:["Kerapu","Kakap Merah","GT","Tenggiri","Baronang"],
  spots:"Gosong karang dan tubir untuk kerapu & kakap merah; tanjung berarus untuk GT dan tenggiri. Sebagian area taman nasional, cek zona.",
  bait:{"Potongan cumi":["Kerapu","Kakap Merah"],"Popper":["GT"],"Jig logam":["Tenggiri","GT"],"Lumut":["Baronang"]},tide:"Arus kuat sekitar bulan baru & purnama."},
 {id:"serangan",region:"ID",n:"Serangan",a:"Bali",lat:-8.73,lon:115.24,type:"Pantai & perahu",fish:["GT","Kakap Merah","Barakuda","Tongkol","Cumi"],
  spots:"Mulut selat dan rumpon dengan perahu untuk GT & tongkol; karang dalam untuk kakap merah; pinggir pantai malam untuk cumi.",
  bait:{"Popper":["GT"],"Jig logam":["Tongkol","Barakuda","GT"],"Potongan cumi":["Kakap Merah"],"Squid jig":["Cumi"]},tide:"Pergantian arus di selat."},
 {id:"sekotong",region:"ID",n:"Sekotong",a:"Lombok",lat:-8.75,lon:115.98,type:"Pulau-pulau kecil (Gili)",fish:["GT","Kerapu","Kakap Merah","Barakuda","Cumi"],
  spots:"Sekitar Gili Nanggu & Gili Sudak: tubir untuk kerapu, tanjung berarus untuk GT.",
  bait:{"Popper":["GT"],"Ikan umpan hidup":["Kerapu","Barakuda"],"Potongan cumi":["Kakap Merah","Kerapu"],"Squid jig":["Cumi"]},tide:"Pagi hari, arus sedang."},
 {id:"labuanbajo",region:"ID",n:"Labuan Bajo",a:"Flores, NTT",lat:-8.49,lon:119.88,type:"Perahu & karang",fish:["GT","Tenggiri","Kerapu","Kakap Merah","Barakuda","Tongkol"],
  spots:"Pulau-pulau sekitar untuk GT & tenggiri; karang dalam untuk kerapu. Wilayah Taman Nasional Komodo dilarang mancing, cek batasnya.",
  bait:{"Popper":["GT"],"Jig logam":["Tenggiri","Tongkol","GT"],"Ikan umpan hidup":["Kerapu","Barakuda"],"Potongan cumi":["Kakap Merah"]},tide:"Arus kuat; mancing saat arus melambat."}
);
const IDRULE="Tidak ada ukuran minimum nasional untuk pemancing rekreasi; lepas ikan yang masih kecil.";
Object.assign(SP,{
 "Kakap Merah":{b:"#e0796a",d:"#b24c40",fin:"#d9705f",h:.38,pat:"",min:0,lim:IDRULE,ciri:"Merah terang, mulut besar dengan gigi taring, sirip ekor agak berlekuk.",lat:"Lutjanus spp."},
 "Kakap Putih":{b:"#cfd3cf",d:"#6f7f7c",fin:"#a8aea6",h:.32,pat:"",min:0,lim:IDRULE,ciri:"Perak, kepala runcing cekung, mata merah menyala dalam gelap, ekor membulat (barramundi).",lat:"Lates calcarifer"},
 "Kerapu":{b:"#a68a6c",d:"#6b5640",fin:"#8a7155",h:.38,pat:"spots",min:0,lim:IDRULE,ciri:"Badan tebal, mulut lebar, bintik-bintik atau bercak, suka bersembunyi di karang.",lat:"Epinephelus spp."},
 "GT":{b:"#c2c7c8",d:"#4d5558",fin:"#5e6669",h:.44,pat:"",min:0,lim:"Banyak pemancing menerapkan catch & release.",ciri:"Kuwe besar: perak gelap, dahi curam, badan tinggi, ekor bercabang kuat.",lat:"Caranx ignobilis"},
 "Barakuda":{b:"#d4dad8",d:"#5c6e6c",fin:"#9fb0ad",h:.16,pat:"bars",min:0,lim:IDRULE,ciri:"Panjang seperti tombak, rahang bawah menonjol, gigi tajam, garis-garis gelap.",lat:"Sphyraena spp."},
 "Tenggiri":{b:"#d6dde2",d:"#3f5f7a",fin:"#7f95a8",h:.18,pat:"bars",min:0,lim:IDRULE,ciri:"Ramping, punggung biru, garis-garis vertikal bergelombang, ekor bercabang tajam.",lat:"Scomberomorus commerson"},
 "Tongkol":{b:"#cfd6db",d:"#273e57",fin:"#506b85",h:.3,pat:"bars",min:0,lim:IDRULE,ciri:"Mirip tuna kecil, punggung biru tua dengan garis miring, bintik hitam di bawah sirip dada.",lat:"Euthynnus affinis"},
 "Baronang":{b:"#b3ad8f",d:"#6c6748",fin:"#a39d7e",h:.44,pat:"spots",min:0,lim:"Duri siripnya berbisa, pegang hati-hati.",ciri:"Pipih tinggi, mulut kecil seperti kelinci, bintik terang, duri sirip berbisa.",lat:"Siganus spp."},
 "Bawal":{b:"#d8d9d6",d:"#8d918f",fin:"#b5b8b5",h:.58,pat:"",min:0,lim:IDRULE,ciri:"Badan bulat pipih sangat tinggi, perak, ekor bercabang dalam (bawal putih).",lat:"Pampus argenteus"},
 "Belanak":{b:"#c7ccc7",d:"#6a7470",fin:"#9aa29e",h:.24,pat:"lines",min:0,lim:IDRULE,ciri:"Silinder, kepala tumpul, garis-garis memanjang samar, suka bergerombol di permukaan.",lat:"Mugilidae"},
 "Cumi":{squid:1,b:"#e9c9c9",d:"#b07b88",min:0,lim:IDRULE,ciri:"Cumi-cumi; badan tabung bening, keluar ke cahaya lampu di malam hari.",lat:"Loligo / Sepioteuthis"}
});
Object.assign(BAITINFO,{"Udang hidup":"Kait di punggung agar tetap hidup; terbaik untuk kakap putih.","Lumut":"Lumut hijau dari batu, untuk baronang & belanak (pakai kail kecil).","Ikan umpan hidup":"Ikan kecil (selar, kembung) dikait di punggung.","Jig logam":"Metal jig 30–80 g, jatuhkan ke dasar lalu tarik cepat.","Popper":"Umpan permukaan yang menyemburkan air; untuk GT."});
Object.assign(HABITAT,{"Kakap Merah":["reef","deep"],"Kakap Putih":["snags","pylons","rocks"],"Kerapu":["reef","rocks"],"GT":["whitewater","reef","deep"],"Barakuda":["deep","pylons"],"Tenggiri":["deep","whitewater"],"Tongkol":["deep"],"Baronang":["weed","rocks"],"Bawal":["deep","pylons"],"Belanak":["sand","weed"],"Cumi":["weed","pylons"]});
Object.assign(HOWTO,{"Kakap Merah":"Turunkan umpan ke dasar karang dalam, angkat sedikit agar tidak tersangkut.","Kakap Putih":"Lempar ke dekat kayu/tiang saat air pasang, tarik pelan.","Kerapu":"Begitu makan, langsung angkat kuat agar tidak masuk lubang karang.","GT":"Lempar popper jauh ke buih, sentak keras; pakai senar minimal PE 6.","Barakuda":"Pakai leader kawat, tarik umpan cepat.","Tenggiri":"Lempar jig logam jauh, gulung cepat; leader kawat tipis.","Tongkol":"Cari burung atau ikan meloncat, lempar jig ke gerombolan.","Baronang":"Kail kecil dengan lumut, pelampung, dekat batu berlumut.","Bawal":"Udang di kail kecil, jangan terlalu dalam.","Belanak":"Kail sangat kecil, umpan lumut/adonan di permukaan.","Cumi":"Malam hari di dekat lampu, sentak squid jig lalu diam."});
Object.assign(SCENE,{
 ancol:{face:0,shore:"Ujung pemecah ombak",me:[150,168],f:{rocks:[60,130],weed:[240,120],pylons:[200,80],snags:[90,85],deep:[150,30]}},
 seribu:{face:0,shore:"Ujung dermaga pulau",me:[150,165],f:{reef:[90,80],deep:[170,30],weed:[240,120],pylons:[200,140],rocks:[40,130]}},
 anyer:{face:270,shore:"Ujung dermaga",me:[150,165],f:{rocks:[50,120],reef:[210,70],weed:[100,90],pylons:[190,140],deep:[150,30]}},
 pelabuhanratu:{face:180,shore:"Batu karang tepi pantai",me:[150,168],f:{whitewater:[110,110],reef:[220,70],deep:[150,25],rocks:[40,135],sand:[250,140]}},
 karimunjawa:{face:0,shore:"Perahu di atas gosong",me:[150,165],f:{reef:[100,90],deep:[180,30],whitewater:[250,70],weed:[50,130],rocks:[240,135]}},
 serangan:{face:90,shore:"Perahu dekat mulut selat",me:[150,165],f:{whitewater:[230,70],reef:[90,80],deep:[160,25],weed:[50,130],pylons:[250,140]}},
 sekotong:{face:0,shore:"Perahu dekat Gili",me:[150,165],f:{reef:[90,85],whitewater:[230,80],deep:[160,25],weed:[50,135],rocks:[250,135]}},
 labuanbajo:{face:0,shore:"Perahu dekat pulau",me:[150,165],f:{whitewater:[230,75],reef:[90,85],deep:[160,25],rocks:[250,135],weed:[50,135]}}
});

/* ================= LOMBOK ================= */
const LBS=[
 ["trawangan","Gili Trawangan","Gili Matra, Lombok Utara",-8.352,116.040,"Pantai & karang (perahu)",["GT","Barakuda","Kakap Merah","Cumi","Tongkol"],{"Popper":["GT"],"Jig logam":["Barakuda","Tongkol","GT"],"Potongan cumi":["Kakap Merah"],"Squid jig":["Cumi"]},"Tepi karang yang turun ke selat Lombok untuk GT & barakuda. Kawasan konservasi Gili Matra: cek zona larangan & bayar retribusi.","Arus selat sangat kuat; mancing saat arus melambat."],
 ["bangsal","Pelabuhan Bangsal","Pemenang, Lombok Utara",-8.360,116.090,"Dermaga",["Cumi","Baronang","Kakap Putih","Barakuda"],{"Squid jig":["Cumi"],"Lumut":["Baronang"],"Udang hidup":["Kakap Putih"],"Jig logam":["Barakuda"]},"Tiang dermaga untuk kakap putih & barakuda; lampu dermaga malam untuk cumi. Hindari jalur kapal penyeberangan.","Malam hari, pasang naik."],
 ["medana","Teluk Medana","Tanjung, Lombok Utara",-8.350,116.150,"Teluk & marina",["Cumi","Baronang","Kakap Merah","Kerapu"],{"Squid jig":["Cumi"],"Lumut":["Baronang"],"Potongan cumi":["Kakap Merah","Kerapu"]},"Tepi karang di mulut teluk untuk kerapu; padang lamun untuk baronang & cumi.","Pagi & sore, air tenang."],
 ["nipah","Pantai Nipah","Malimbu, Lombok Utara",-8.430,116.050,"Pantai berbatu",["Baronang","Kakap Merah","Kerapu","Cumi"],{"Lumut":["Baronang"],"Potongan cumi":["Kakap Merah","Kerapu"],"Squid jig":["Cumi"]},"Batu karang di ujung pantai untuk kerapu & baronang.","Pasang naik."],
 ["senggigi","Senggigi","Batu Layar, Lombok Barat",-8.490,116.040,"Pantai & tanjung batu",["Kakap Merah","Kerapu","Cumi","Baronang","GT"],{"Potongan cumi":["Kakap Merah","Kerapu"],"Squid jig":["Cumi"],"Lumut":["Baronang"],"Popper":["GT"]},"Tanjung Batu Bolong & ujung pantai untuk kerapu dan kakap; malam di pantai untuk cumi.","Senja hingga malam."],
 ["ampenan","Pantai Ampenan","Kota Mataram",-8.570,116.070,"Pantai & muara",["Kakap Putih","Belanak","Bawal","Barakuda"],{"Udang hidup":["Kakap Putih","Bawal"],"Lumut":["Belanak"],"Soft plastic kecil":["Kakap Putih","Barakuda"]},"Muara sungai Jangkok untuk kakap putih & belanak; sisa dermaga tua untuk barakuda.","Pasang naik, terutama setelah hujan."],
 ["lembar","Pelabuhan Lembar","Lombok Barat",-8.730,116.070,"Dermaga & teluk",["Cumi","Kakap Putih","Baronang","Barakuda","Kerapu"],{"Squid jig":["Cumi"],"Udang hidup":["Kakap Putih"],"Lumut":["Baronang"],"Ikan umpan hidup":["Barakuda","Kerapu"]},"Tepi teluk berbakau untuk kakap putih; dermaga ikan untuk cumi & barakuda (patuhi larangan di area pelabuhan).","Malam, air pasang."],
 ["bangkobangko","Bangko-Bangko (Desert Point)","Sekotong Barat",-8.750,115.830,"Batu karang ujung barat",["GT","Tenggiri","Tongkol","Kerapu","Kakap Merah"],{"Popper":["GT"],"Jig logam":["Tenggiri","Tongkol"],"Potongan cumi":["Kerapu","Kakap Merah"]},"Karang dangkal dan buih ombak untuk GT; air biru di luar karang untuk tenggiri & tongkol. Ombak besar, sangat licin.","Subuh, ombak kecil, arus berganti."],
 ["selongbelanak","Selong Belanak","Praya Barat, Lombok Tengah",-8.870,116.170,"Pantai pasir & batu",["Kakap Putih","Belanak","Barakuda","GT"],{"Udang hidup":["Kakap Putih"],"Lumut":["Belanak"],"Metal lure":["Barakuda","GT"]},"Batu di kedua ujung pantai untuk GT & barakuda; parit pasir untuk kakap putih.","Pagi buta, laut tenang."],
 ["mawun","Pantai Mawun","Pujut, Lombok Tengah",-8.910,116.230,"Teluk pantai",["Kakap Merah","Kerapu","Barakuda","Cumi"],{"Potongan cumi":["Kakap Merah","Kerapu"],"Jig logam":["Barakuda"],"Squid jig":["Cumi"]},"Batu di sisi kiri & kanan teluk untuk kerapu dan kakap.","Pasang naik, pagi."],
 ["kuta","Kuta Mandalika","Pujut, Lombok Tengah",-8.900,116.280,"Pantai & tanjung batu",["GT","Kakap Merah","Barakuda","Kerapu","Cumi"],{"Popper":["GT"],"Potongan cumi":["Kakap Merah","Kerapu"],"Jig logam":["Barakuda"],"Squid jig":["Cumi"]},"Tanjung batu dan bukit Merese untuk GT; karang di teluk untuk kerapu.","Subuh & senja."],
 ["gerupuk","Teluk Gerupuk","Pujut, Lombok Tengah",-8.920,116.360,"Teluk & keramba (perahu)",["Kerapu","Kakap Merah","Cumi","Baronang","Barakuda"],{"Potongan cumi":["Kerapu","Kakap Merah"],"Squid jig":["Cumi"],"Lumut":["Baronang"],"Ikan umpan hidup":["Barakuda","Kerapu"]},"Sekitar keramba & bagan apung untuk kerapu dan cumi; mulut teluk untuk barakuda. Sewa perahu nelayan lokal.","Malam di bagan; pagi di mulut teluk."],
 ["ekas","Teluk Ekas","Jerowaru, Lombok Timur",-8.880,116.470,"Teluk & tebing",["GT","Kerapu","Tenggiri","Cumi","Kakap Merah"],{"Popper":["GT"],"Jig logam":["Tenggiri","GT"],"Potongan cumi":["Kerapu","Kakap Merah"],"Squid jig":["Cumi"]},"Tebing di mulut teluk untuk GT & tenggiri; dalam teluk untuk kerapu dan cumi.","Arus masuk teluk saat pasang."],
 ["tanjungringgit","Tanjung Ringgit","Jerowaru, Lombok Timur",-8.860,116.580,"Tebing batu tinggi",["GT","Tenggiri","Tongkol","Kerapu"],{"Popper":["GT"],"Jig logam":["Tenggiri","Tongkol"],"Ikan umpan hidup":["Kerapu","GT"]},"Ujung tenggara Lombok: tebing langsung ke laut dalam, spot GT terkenal. Sangat berbahaya, jangan sendirian.","Subuh, angin & ombak kecil."],
 ["labuhanhaji","Labuhan Haji","Lombok Timur",-8.680,116.580,"Pantai & dermaga",["Tongkol","Kakap Merah","Cumi","Barakuda"],{"Jig logam":["Tongkol","Barakuda"],"Potongan cumi":["Kakap Merah"],"Squid jig":["Cumi"]},"Ujung dermaga untuk tongkol & barakuda saat gerombolan masuk; malam untuk cumi.","Pagi saat burung terlihat menyelam."],
 ["kayangan","Pelabuhan Kayangan","Labuhan Lombok, Lombok Timur",-8.480,116.710,"Dermaga & selat Alas",["Cumi","Baronang","Tongkol","Barakuda"],{"Squid jig":["Cumi"],"Lumut":["Baronang"],"Jig logam":["Tongkol","Barakuda"]},"Pinggir pelabuhan Labuhan Lombok untuk cumi & baronang (jauhi jalur feri).","Malam, air pasang."],
 ["gilisulat","Gili Sulat & Gili Kondo","Sambelia, Lombok Timur",-8.320,116.710,"Pulau karang & bakau (perahu)",["Kerapu","GT","Kakap Merah","Baronang","Kakap Putih"],{"Potongan cumi":["Kerapu","Kakap Merah"],"Popper":["GT"],"Lumut":["Baronang"],"Udang hidup":["Kakap Putih"]},"Tubir di sekitar gili untuk kerapu & GT; tepi bakau Gili Sulat untuk kakap putih.","Pagi, arus sedang."]
];
LBS.forEach(([id,n,a,lat,lon,type,fish,bait,spots,tide])=>LOC.push({id,region:"ID",n,a,lat,lon,type,fish,bait,spots,tide}));

/* ===== Tambahan Lombok Timur & Lombok Tengah (koordinat perkiraan) ===== */
const TPL={
 tebing:{type:"Tebing & batu karang",fish:["GT","Kerapu","Kakap Merah","Tenggiri","Barakuda"],bait:{"Popper":["GT"],"Jig logam":["Tenggiri","Barakuda","GT"],"Potongan cumi":["Kerapu","Kakap Merah"],"Ikan umpan hidup":["Kerapu","Barakuda"]},s:"Ujung batu yang langsung menghadap laut dalam untuk GT & tenggiri; celah karang di bawah tebing untuk kerapu. Ombak selatan besar, jangan sendirian.",t:"Subuh saat ombak kecil, awal pasang."},
 teluk:{type:"Teluk pantai & batu",fish:["Kakap Merah","Kerapu","Baronang","Cumi","Barakuda"],bait:{"Potongan cumi":["Kakap Merah","Kerapu"],"Lumut":["Baronang"],"Squid jig":["Cumi"],"Jig logam":["Barakuda"]},s:"Batu di kedua sisi teluk untuk kerapu & baronang; tengah teluk yang berpasir untuk kakap; malam di pantai untuk cumi.",t:"Pasang naik, pagi atau senja."},
 pelabuhan:{type:"Pelabuhan & dermaga ikan",fish:["Cumi","Baronang","Tongkol","Barakuda","Kakap Putih"],bait:{"Squid jig":["Cumi"],"Lumut":["Baronang"],"Jig logam":["Tongkol","Barakuda"],"Udang hidup":["Kakap Putih"]},s:"Ujung dermaga dan tiang untuk barakuda & kakap putih; lampu kapal malam hari untuk cumi. Jauhi jalur kapal & patuhi larangan pelabuhan.",t:"Malam, air pasang."},
 gili:{type:"Pulau karang (perahu)",fish:["Kerapu","GT","Kakap Merah","Baronang","Cumi"],bait:{"Potongan cumi":["Kerapu","Kakap Merah"],"Popper":["GT"],"Lumut":["Baronang"],"Squid jig":["Cumi"]},s:"Tubir di sekeliling gili untuk kerapu & kakap merah; sisi berarus untuk GT. Sewa perahu nelayan setempat.",t:"Pagi, arus sedang."},
 pasir:{type:"Pantai pasir & muara",fish:["Kakap Putih","Belanak","Bawal","Barakuda"],bait:{"Udang hidup":["Kakap Putih","Bawal"],"Lumut":["Belanak"],"Metal lure":["Barakuda"]},s:"Parit pasir dan muara kecil untuk kakap putih & belanak; ujung pantai berbatu untuk barakuda.",t:"Pasang naik, subuh."}
};
[
 // Lombok Timur
 ["pantaipink","Pantai Pink (Tangsi)","Jerowaru, Lombok Timur",-8.857,116.600,"teluk"],
 ["kaliantan","Pantai Kaliantan","Jerowaru, Lombok Timur",-8.875,116.520,"tebing"],
 ["tanjungbloam","Tanjung Bloam","Jerowaru, Lombok Timur",-8.870,116.560,"tebing"],
 ["cemaralt","Pantai Cemara","Jerowaru, Lombok Timur",-8.830,116.470,"pasir"],
 ["tanjungluar","Tanjung Luar","Keruak, Lombok Timur",-8.760,116.505,"pelabuhan"],
 ["gilikere","Gili Kere","Teluk Jukung, Lombok Timur",-8.790,116.515,"gili"],
 ["gilipetagan","Gili Petagan","Pringgabaya, Lombok Timur",-8.455,116.720,"gili"],
 ["labuhanpandan","Labuhan Pandan","Sambelia, Lombok Timur",-8.355,116.680,"pelabuhan"],
 ["gililampu","Gili Lampu","Sambelia, Lombok Timur",-8.300,116.685,"gili"],
 ["gilibidara","Gili Bidara","Sambelia, Lombok Timur",-8.330,116.715,"gili"],
 ["sambelia","Pantai Sambelia","Sambelia, Lombok Timur",-8.375,116.665,"pasir"],
 ["transat","Pantai Trans (Ketapang)","Pringgabaya, Lombok Timur",-8.560,116.660,"pasir"],
 ["gilire","Gili Re","Jerowaru, Lombok Timur",-8.870,116.430,"gili"],
 // Lombok Tengah
 ["mawi","Pantai Mawi","Pujut, Lombok Tengah",-8.905,116.135,"tebing"],
 ["semeti","Pantai Semeti","Pujut, Lombok Tengah",-8.905,116.120,"tebing"],
 ["torok","Pantai Torok","Praya Barat Daya, Lombok Tengah",-8.865,116.070,"teluk"],
 ["telawas","Pantai Telawas","Praya Barat, Lombok Tengah",-8.890,116.105,"teluk"],
 ["pengantap","Pantai Pengantap","Praya Barat, Lombok Tengah",-8.890,116.155,"teluk"],
 ["areguling","Pantai Are Guling","Pujut, Lombok Tengah",-8.910,116.185,"teluk"],
 ["tampah","Pantai Tampah","Pujut, Lombok Tengah",-8.900,116.210,"tebing"],
 ["seger","Pantai Seger","Pujut, Lombok Tengah",-8.905,116.310,"tebing"],
 ["merese","Bukit Merese","Pujut, Lombok Tengah",-8.912,116.325,"tebing"],
 ["tanjungaan","Pantai Tanjung Aan & Batu Payung","Pujut, Lombok Tengah",-8.910,116.335,"teluk"],
 ["bumbang","Teluk Bumbang","Pujut, Lombok Tengah",-8.915,116.350,"pelabuhan"],
 ["serenting","Pantai Serenting","Pujut, Lombok Tengah",-8.925,116.390,"tebing"]
].forEach(([id,n,a,lat,lon,k])=>{const t=TPL[k];LOC.push({id,region:"ID",n,a,lat,lon,type:t.type,fish:t.fish.slice(),bait:JSON.parse(JSON.stringify(t.bait)),spots:t.s,tide:t.t})});
{const sk=LOC.find(l=>l.id==="sekotong");sk.region="ID";sk.n="Gili Nanggu & Gili Sudak";sk.a="Sekotong, Lombok Barat";sk.lat=-8.71;sk.lon=115.99;}
const MAPS_LB={B:{n:-8.18,s:-8.98,w:115.78,e:116.78},k:1,label:"SELAT LOMBOK · SELAT ALAS",poly:[[[-8.22,116.40],[-8.33,116.18],[-8.36,116.07],[-8.50,116.045],[-8.65,116.06],[-8.72,115.95],[-8.745,115.82],[-8.82,115.86],[-8.80,116.00],[-8.88,116.10],[-8.93,116.28],[-8.89,116.45],[-8.88,116.58],[-8.75,116.61],[-8.55,116.70],[-8.38,116.64],[-8.27,116.52]],[[-8.345,116.025],[-8.345,116.045],[-8.36,116.04]],[[-8.345,116.055],[-8.345,116.07],[-8.36,116.063]],[[-8.355,116.075],[-8.355,116.09],[-8.37,116.083]],[[-8.70,115.97],[-8.70,116.0],[-8.725,115.99]]]};
// skema peta lempar otomatis untuk spot tanpa skema khusus
function autoScene(s){
  const t=(s.type||"").toLowerCase(),f={deep:[150,30]};
  if(/dermaga|pelabuhan|marina/.test(t))f.pylons=[200,130];
  if(/batu|tebing|tanjung|karang/.test(t)){f.rocks=[60,130];f.whitewater=[230,80]}
  if(/pantai|pasir|muara/.test(t))f.sand=[230,135];
  if(/teluk|lamun|bakau/.test(t)){f.weed=[60,90];f.snags=[250,125]}
  f.reef=f.reef||[110,75];if(!f.weed)f.weed=[45,105];
  return{face:0,shore:s.type||"Tepi air",me:[150,168],f};
}


/* ================= AUSTRALIA: spot utama tiap negara bagian ================= */
Object.assign(SP,{
 "Barramundi":{b:"#c9cdc6",d:"#5e6a5c",fin:"#8d9686",h:.3,pat:"",min:58,lim:"QLD 58–120 cm, NT min. 55 cm; ada musim tutup (Nov–Jan) di QLD",ciri:"Perak-perunggu, kepala runcing cekung, mata merah menyala di gelap, ekor membulat.",lat:"Lates calcarifer"},
 "Mangrove Jack":{b:"#c9533f",d:"#8d2f22",fin:"#b9483a",h:.38,pat:"",min:35,lim:"QLD min. 35 cm",ciri:"Merah tembaga, gigi taring tajam, hidup di bawah akar bakau dan kayu.",lat:"Lutjanus argentimaculatus"},
 "King George Whiting":{b:"#e2d6b6",d:"#a8926a",fin:"#cdbb93",h:.22,pat:"spots",min:32,lim:"SA min. 32 cm, VIC min. 27 cm, WA min. 28 cm",ciri:"Ramping, moncong runcing, bintik-bintik cokelat di badan keemasan.",lat:"Sillaginodes punctatus"},
 "Spanish Mackerel":{b:"#d6dde2",d:"#3f5f7a",fin:"#7f95a8",h:.18,pat:"bars",min:75,lim:"QLD min. 75 cm, maks 3",ciri:"Panjang ramping, punggung biru, garis vertikal bergelombang, gigi tajam.",lat:"Scomberomorus commerson"},
 "Coral Trout":{b:"#e46a4c",d:"#a8382a",fin:"#d05a40",h:.36,pat:"bluespots",min:38,lim:"QLD min. 38 cm, maks 7; ada penutupan musiman",ciri:"Merah-oranye dengan bintik biru kecil, mulut besar, hidup di karang.",lat:"Plectropomus leopardus"},
 "Golden Trevally":{b:"#e8d68a",d:"#a8913f",fin:"#e3c24a",h:.42,pat:"bars",min:0,lim:"Cek aturan negara bagian",ciri:"Kuning keemasan dengan garis vertikal gelap saat muda, bibir tebal.",lat:"Gnathanodon speciosus"}
});
Object.assign(HABITAT,{"Barramundi":["snags","pylons","rocks"],"Mangrove Jack":["snags","rocks","pylons"],"King George Whiting":["sand","weed"],"Spanish Mackerel":["deep","whitewater"],"Coral Trout":["reef"],"Golden Trevally":["sand","deep"]});
Object.assign(HOWTO,{"Barramundi":"Lempar soft plastic/hardbody ke dekat kayu saat air pasang mulai surut, gulung pelan.","Mangrove Jack":"Lempar sedekat mungkin ke akar bakau, langsung tarik kuat begitu disambar.","King George Whiting":"Cacing atau potongan cumi kecil di dasar pasir dekat lamun, pemberat ringan.","Spanish Mackerel":"Trolling minnow atau umpan ikan utuh di tepi karang/tubir; leader kawat.","Coral Trout":"Umpan ikan hidup atau soft plastic di karang, tahan kuat agar tidak masuk lubang.","Golden Trevally":"Soft plastic atau jig kecil di flat pasir, gulung cepat."});
Object.assign(BAITINFO,{"Hardbody lure":"Umpan tiruan ikan dengan lidah selam; untuk barramundi & mangrove jack."});
const FISHBAIT={"Snapper":["Pilchard utuh","Soft plastic besar","Potongan cumi"],"Kingfish":["Squid hidup","Jig logam","Soft plastic besar"],"Flathead":["Soft plastic kecil","Pilchard utuh"],"Bream":["Udang mentah","Soft plastic kecil"],"Whiting":["Cacing laut","Udang mentah"],"Squid":["Squid jig"],"Tailor":["Pilchard utuh","Metal lure"],"Salmon Australia":["Metal lure","Pilchard utuh"],"Mulloway":["Squid hidup","Potongan cumi"],"Luderick":["Rumput laut hijau"],"Trevally":["Udang mentah","Soft plastic kecil"],"Drummer":["Roti"],"Barramundi":["Hardbody lure","Soft plastic besar","Udang hidup"],"Mangrove Jack":["Hardbody lure","Ikan umpan hidup"],"King George Whiting":["Cacing laut","Potongan cumi"],"Spanish Mackerel":["Minnow troll","Ikan umpan hidup"],"Coral Trout":["Ikan umpan hidup","Soft plastic besar"],"Golden Trevally":["Soft plastic kecil","Jig logam"],"GT":["Popper","Jig logam"]};
const AUTPL={pantai:"Pantai & batu",muara:"Muara & sungai",dermaga:"Dermaga & teluk",karang:"Karang & pulau (perahu)",breakwall:"Pemecah ombak"};
const AUSPOT={pantai:"Ujung batu untuk tailor & salmon saat subuh/senja; parit pasir di pantai untuk whiting & flathead.",muara:"Tepi bakau, kayu tenggelam, dan alur dalam saat arus berganti; jembatan & tiang untuk predator.",dermaga:"Tiang dermaga untuk bream & trevally; lampu dermaga malam untuk cumi; drop-off pasir untuk flathead/whiting.",karang:"Tubir & karang dalam dengan perahu; cek zona taman laut sebelum memancing.",breakwall:"Ujung pemecah ombak di arus masuk-keluar untuk tailor, salmon, mulloway; tengah tembok untuk bream & luderick."};
[
 // NSW
 ["nelsonbay","Nelson Bay","Port Stephens","NSW",-32.716,152.143,"dermaga",["Snapper","Kingfish","Flathead","Bream","Squid","Tailor"]],
 ["newcastle","Newcastle Breakwall","Newcastle","NSW",-32.918,151.795,"breakwall",["Tailor","Salmon Australia","Bream","Mulloway","Luderick"]],
 ["swansea","Swansea Channel","Lake Macquarie","NSW",-33.087,151.643,"muara",["Flathead","Bream","Whiting","Squid","Trevally"]],
 ["theentrance","The Entrance","Central Coast","NSW",-33.343,151.503,"muara",["Flathead","Bream","Whiting","Luderick"]],
 ["portmacquarie","Port Macquarie","Hastings River","NSW",-31.431,152.918,"breakwall",["Mulloway","Bream","Flathead","Whiting","Trevally"]],
 ["coffs","Coffs Harbour","Mid North Coast","NSW",-30.302,153.147,"dermaga",["Snapper","Spanish Mackerel","Tailor","Bream","Trevally"]],
 ["yamba","Yamba","Clarence River","NSW",-29.433,153.360,"muara",["Mulloway","Bream","Flathead","Mangrove Jack","Whiting"]],
 ["ballina","Ballina","Richmond River","NSW",-28.875,153.590,"breakwall",["Mulloway","Bream","Mangrove Jack","Flathead","Tailor"]],
 ["jervisbay","Jervis Bay","Huskisson","NSW",-35.039,150.672,"dermaga",["Snapper","Kingfish","Squid","Whiting","Salmon Australia"]],
 ["batemans","Batemans Bay","Clyde River","NSW",-35.708,150.183,"muara",["Flathead","Bream","Snapper","Luderick","Mulloway"]],
 ["eden","Eden","Twofold Bay","NSW",-37.064,149.906,"dermaga",["Snapper","Kingfish","Salmon Australia","Tailor","Squid"]],
 // QLD
 ["goldcoast","Gold Coast Seaway","Southport","QLD",-27.940,153.430,"breakwall",["Flathead","Bream","Trevally","Mulloway","Tailor"]],
 ["wynnum","Wynnum–Manly","Moreton Bay, Brisbane","QLD",-27.445,153.180,"dermaga",["Bream","Whiting","Flathead","Squid","Snapper"]],
 ["bribie","Bribie Island","Pumicestone Passage","QLD",-27.070,153.200,"pantai",["Whiting","Flathead","Bream","Tailor","Mangrove Jack"]],
 ["herveybay","Hervey Bay","Fraser Coast (K'gari)","QLD",-25.290,152.850,"dermaga",["Whiting","Golden Trevally","Snapper","Spanish Mackerel","Tailor"]],
 ["gladstone","Gladstone","Gladstone Harbour","QLD",-23.840,151.260,"muara",["Barramundi","Mangrove Jack","Coral Trout","Spanish Mackerel"]],
 ["whitsundays","Whitsundays","Airlie Beach","QLD",-20.270,148.720,"karang",["Coral Trout","Spanish Mackerel","GT","Golden Trevally"]],
 ["townsville","Townsville","Ross River & Strand","QLD",-19.250,146.820,"muara",["Barramundi","Mangrove Jack","Coral Trout","Spanish Mackerel"]],
 ["cairns","Cairns","Trinity Inlet","QLD",-16.920,145.780,"muara",["Barramundi","Mangrove Jack","GT","Coral Trout"]],
 ["weipa","Weipa","Cape York","QLD",-12.630,141.870,"muara",["Barramundi","GT","Spanish Mackerel","Golden Trevally"]],
 // NT
 ["darwin","Darwin Harbour","Darwin","NT",-12.460,130.840,"dermaga",["Barramundi","Golden Trevally","Spanish Mackerel","Mangrove Jack"]],
 ["maryriver","Mary River","Top End","NT",-12.400,131.650,"muara",["Barramundi","Mangrove Jack"]],
 // WA
 ["broome","Broome","Roebuck Bay","WA",-17.960,122.240,"pantai",["Barramundi","GT","Spanish Mackerel","Golden Trevally"]],
 ["exmouth","Exmouth","Ningaloo","WA",-21.930,114.130,"karang",["GT","Spanish Mackerel","Coral Trout","Golden Trevally"]],
 ["fremantle","Fremantle","Perth","WA",-32.055,115.740,"breakwall",["Tailor","Salmon Australia","King George Whiting","Squid","Snapper"]],
 ["albany","Albany","King George Sound","WA",-35.030,117.880,"pantai",["Salmon Australia","King George Whiting","Squid","Tailor"]],
 // SA
 ["glenelg","Glenelg & Brighton Jetty","Adelaide","SA",-34.980,138.510,"dermaga",["Squid","King George Whiting","Snapper","Salmon Australia"]],
 ["portlincoln","Port Lincoln","Eyre Peninsula","SA",-34.730,135.870,"dermaga",["King George Whiting","Snapper","Kingfish","Squid","Salmon Australia"]],
 ["kangarooisland","Kangaroo Island","Kingscote","SA",-35.650,137.640,"pantai",["King George Whiting","Salmon Australia","Squid","Snapper"]],
 // VIC
 ["stkilda","St Kilda Pier","Port Phillip, Melbourne","VIC",-37.866,144.970,"dermaga",["Snapper","Squid","King George Whiting","Flathead"]],
 ["sanremo","San Remo","Western Port","VIC",-38.520,145.370,"dermaga",["Snapper","King George Whiting","Squid","Salmon Australia"]],
 ["lakesentrance","Lakes Entrance","Gippsland Lakes","VIC",-37.880,147.980,"muara",["Bream","Flathead","Salmon Australia","Tailor"]],
 ["portland","Portland","Portland Bay","VIC",-38.350,141.610,"dermaga",["Kingfish","Snapper","Salmon Australia","Squid"]],
 // TAS
 ["hobart","Sungai Derwent","Hobart","TAS",-42.880,147.330,"muara",["Flathead","Squid","Salmon Australia","Bream"]],
 ["sthelens","St Helens","Georges Bay","TAS",-41.320,148.250,"muara",["Bream","Flathead","Salmon Australia","Squid"]],
 ["georgetown","George Town","Sungai Tamar","TAS",-41.100,146.820,"muara",["Snapper","Flathead","Squid","Salmon Australia"]]
].forEach(([id,n,a,st,lat,lon,k,fish])=>{const bait={};fish.forEach(f=>(FISHBAIT[f]||["Udang mentah"]).forEach(b=>(bait[b]=bait[b]||[]).push(f)));
  LOC.push({id,region:"AU",st,n,a:a+", "+st,lat,lon,type:AUTPL[k],fish,bait,spots:AUSPOT[k],tide:k==="karang"?"Arus sedang, pagi hari; perhatikan angin & gelombang.":"Pergantian arus, subuh & senja."})});
LOC.forEach(l=>{if(l.region==="AU"&&!l.st)l.st="Sydney"});
const AU_OUTLINE=[[-10.7,142.5],[-12.6,141.6],[-14.5,141.5],[-17.4,140.8],[-16.5,139.3],[-15.0,135.6],[-12.2,136.8],[-11.2,132.6],[-12.3,130.4],[-13.8,129.6],[-15.0,128.0],[-14.0,126.0],[-16.4,123.0],[-18.0,122.2],[-19.7,121.1],[-20.4,117.2],[-21.8,114.1],[-24.0,113.5],[-26.6,113.8],[-28.8,114.6],[-31.8,115.7],[-34.3,115.0],[-35.0,116.6],[-34.9,118.0],[-33.9,123.0],[-32.3,126.0],[-31.6,129.0],[-31.5,131.2],[-32.1,133.5],[-34.0,135.2],[-34.9,135.8],[-33.0,137.8],[-35.0,138.1],[-35.8,138.1],[-35.6,139.4],[-37.0,139.8],[-38.0,140.6],[-38.4,141.5],[-38.8,143.5],[-38.0,144.4],[-38.5,145.0],[-38.9,146.4],[-37.8,148.0],[-37.5,149.9],[-36.0,150.1],[-34.5,150.9],[-33.2,151.6],[-32.0,152.5],[-30.0,153.3],[-28.2,153.6],[-26.6,153.1],[-24.9,152.4],[-23.5,151.0],[-22.1,149.6],[-20.6,148.7],[-19.3,147.1],[-18.0,146.0],[-15.9,145.4],[-14.4,144.2],[-12.0,143.3]];
const TAS_OUTLINE=[[-40.7,144.7],[-40.9,146.9],[-40.8,148.3],[-42.2,148.2],[-43.3,147.3],[-43.6,146.0],[-42.2,145.2]];
/* ================= PERINGKAT SPOT PER IKAN ================= */
function catchRows(){return (typeof feed!=="undefined"&&feed?feed:[]).map(x=>({f:x.f||x.fish,sid:x.sid||x.spot_id,t:x.t||Date.parse(x.created_at||0),len:x.len||x.length_cm}))}
function rankSpots(fish,rg){
  const rows=catchRows().filter(r=>r.f===fish&&Date.now()-r.t<90*864e5);
  return LOC.filter(l=>!rg||l.region===rg).map(l=>{
    const d=spotData(l),i=d.fish.indexOf(fish),n=rows.filter(r=>r.sid===l.id).length;
    if(i<0&&!n)return null;
    const baits=Object.entries(d.bait).filter(([,fs])=>fs.includes(fish)).map(([b])=>b);
    const base=i<0?20:Math.max(30,70-i*9)+Math.min(10,baits.length*4);
    const score=Math.min(100,Math.round(base+Math.min(30,n*6)));
    return{l,score,n,baits};
  }).filter(Boolean).sort((a,b)=>b.score-a.score||b.n-a.n);
}
const stars=s=>{const k=Math.max(1,Math.round(s/20));return "★".repeat(k)+"☆".repeat(5-k)};
function rankListHtml(fish,limit){
  const r=rankSpots(fish,region).slice(0,limit||10);
  if(!r.length)return `<p class="note">Belum ada spot untuk ${esc(fish)} di wilayah ini.</p>`;
  return `<div class="list rank">${r.map((x,i)=>`<button data-rank="${x.l.id}"><span><b>${i+1}. ${esc(x.l.n)}</b><br><span class="note">${esc(x.l.a||"")}${x.baits.length?" · "+esc(x.baits.slice(0,2).join(", ")):""}</span></span><span style="text-align:right"><span class="stars" aria-label="${x.score} dari 100">${stars(x.score)}</span><br><span class="note">${x.n?x.n+" tangkapan/90 hr":"data panduan"}</span></span></button>`).join("")}</div>`;
}
function rankCardHtml(){
  const fishes=[...new Set(LOC.filter(l=>l.region===region).flatMap(l=>spotData(l).fish))].filter(f=>SP[f]).sort();
  let sel=store.get("mm_rank_"+region,fishes[0]);if(!fishes.includes(sel))sel=fishes[0];
  return `<div class="card"><h3>🏆 Spot terbaik per ikan</h3><p class="note">Peringkat dari data panduan aplikasi, ditambah tangkapan komunitas 90 hari terakhir.</p>
   <select class="f" id="rankFish" aria-label="Pilih ikan untuk peringkat">${fishes.map(f=>`<option ${f===sel?"selected":""}>${f}</option>`).join("")}</select>
   <div style="margin-top:8px">${rankListHtml(sel,10)}</div></div>`;
}
function bindRank(){
  const rf=document.getElementById("rankFish");if(rf)rf.onchange=e=>{store.set("mm_rank_"+region,e.target.value);render()};
  document.querySelectorAll("[data-rank]").forEach(b=>b.onclick=()=>setSpot(b.dataset.rank));
}

let region=store.get("mm_region","AU");if(region==="LB")region="ID";let mapZoom=store.get("mm_zoom","all");
const inLombok=s=>s.lat<-8.15&&s.lat>-9.0&&s.lon>115.78&&s.lon<116.78;
const regionOf=(lat,lon)=>lat>-11.5?(lon!=null&&lat<-8.15&&lat>-9.0&&lon>115.78&&lon<116.78?"ID":"ID"):"AU";
const tzLL=(lat,lon)=>lat>-11.5?(lon<114.6?7:lon<126.5?8:9):sydOffset(new Date());
const tzName=(lat,lon)=>lat<=-11.5?"Australia/Sydney":(lon<114.6?"Asia/Jakarta":lon<126.5?"Asia/Makassar":"Asia/Jayapura");
const MAPS={
 AU:{B:{n:-33.50,s:-34.13,w:151.05,e:151.36},k:1.2,label:"TASMAN SEA"},
 ID:{B:{n:6,s:-11,w:95,e:141.5},k:1,label:"SAMUDRA HINDIA"}
};
MAPS.LB=MAPS_LB;
const ISL=[[[5.5,95.3],[4,98],[1,102],[-2,105],[-5.9,105.8],[-5.5,104.5],[-3,102],[0,99.5],[2,98],[5,95.5]],[[-6,105.8],[-6.2,108],[-6.9,112.7],[-7.7,114.5],[-8.5,114.4],[-8.3,111],[-7.7,108],[-7,106],[-6.8,105.4]],[[1,109],[4.3,117.5],[1,119],[-1,116.8],[-4,114.5],[-3,110.5],[-1,109.5]],[[1.5,124.8],[0.8,120.8],[-1,119.6],[-5.6,119.4],[-4.5,121],[-2.5,121.3],[-1,123.5],[0.5,121.8],[1,124.2]],[[-0.8,131],[-1.5,135],[-2.5,141.5],[-9,141.5],[-8,138],[-4.5,135.5],[-3.5,132.5],[-2,130.5]],[[-8.1,114.6],[-8.1,115.7],[-8.8,115.2]],[[-8.2,115.9],[-8.3,116.7],[-8.9,116.3]],[[-8.3,116.9],[-8.1,119],[-8.9,118.5],[-8.8,117]],[[-8.3,119.9],[-8.2,123],[-8.9,122.5],[-8.9,120]],[[-9,123.6],[-8.6,125.2],[-9.5,125],[-10.3,123.6]]];

/* ================= LOKASI: GPS + cari nama tempat (OpenStreetMap Nominatim) ================= */
let here=store.get("mm_here",null),locMsg="",locBusy=false,searchRes=[];
const km=(a,b,c,d)=>{const R=6371,x=(d-b)*rad*Math.cos((a+c)/2*rad),y=(c-a)*rad;return Math.round(Math.hypot(x,y)*R*10)/10};
const nearest=(lat,lon,n=3)=>everySpot().map(l=>({l,d:km(lat,lon,l.lat,l.lon)})).sort((a,b)=>a.d-b.d).slice(0,n);
function useHere(lat,lon,label,acc){
  here={lat,lon,label,acc:acc||null,t:Date.now()};store.set("mm_here",here);locMsg="";searchRes=[];
  const rg=regionOf(lat,lon);if(rg!==region){region=rg;store.set("mm_region",rg);$("#region").value=rg}
  const n=nearest(lat,lon,1)[0];if(n){curId=n.l.id;store.set("mm_cur",curId);fillPick()}
  render();
}
function detectGPS(silent){
  if(!("geolocation" in navigator)){if(!silent){locMsg="HP/browser ini tidak mendukung GPS. Cari dengan nama tempat.";render()}return}
  locBusy=true;if(!silent)render();
  navigator.geolocation.getCurrentPosition(p=>{locBusy=false;useHere(p.coords.latitude,p.coords.longitude,"Lokasimu sekarang",Math.round(p.coords.accuracy))},
    e=>{locBusy=false;if(!silent){locMsg=e.code===1?"Izin lokasi ditolak. Aktifkan izin lokasi untuk situs ini di pengaturan browser, atau cari dengan nama tempat.":"Lokasi tidak ditemukan. Pastikan GPS menyala lalu coba lagi.";render()}},
    {enableHighAccuracy:true,timeout:15000,maximumAge:120000});
}
async function searchPlace(q){
  locBusy=true;locMsg="";render();
  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&countrycodes=id,au&accept-language=id&q=${encodeURIComponent(q)}`,{headers:{"Accept":"application/json"}});
    if(!r.ok)throw 0;const j=await r.json();
    searchRes=j.map(x=>({lat:+x.lat,lon:+x.lon,label:x.display_name}));
    if(!searchRes.length)locMsg=`"${q}" tidak ditemukan. Coba tambahkan nama kota, mis. "Pantai Lovina, Bali".`;
  }catch(e){locMsg="Pencarian gagal. Periksa koneksi internet lalu coba lagi."}
  locBusy=false;render();
}
function locateCard(){
  const h=here,near=h?nearest(h.lat,h.lon,3):[],n0=near[0]?.l,data=n0?spotData(n0):null;
  return `<div class="card"><h3>Lokasimu</h3>
   <button class="btn" id="gpsBtn" style="width:100%" ${locBusy?"disabled":""}>${locBusy?"Mencari lokasi…":"📍 Deteksi lokasi otomatis (GPS)"}</button>
   <form id="locF" style="grid-template-columns:1fr auto;margin-top:8px"><input id="locQ" placeholder="atau ketik: Pantai Ancol, Bondi, Senggigi…" aria-label="Nama tempat"><button class="btn ghost" type="submit">Cari</button></form>
   ${locMsg?`<p class="note" style="color:var(--bad)">${esc(locMsg)}</p>`:""}
   ${searchRes.length?`<div class="list" style="margin-top:8px">${searchRes.map((r,i)=>`<button data-sr="${i}"><span class="note">${esc(r.label)}</span></button>`).join("")}</div>`:""}
   ${h?`<div style="margin-top:10px"><span class="tag">${esc(h.label)}${h.acc?" · akurasi ±"+h.acc+" m":""}</span>
     <p class="note">${h.lat.toFixed(4)}, ${h.lon.toFixed(4)}</p>
     <h3 style="margin-top:6px">Spot terdekat</h3>
     <div class="list">${near.map(n=>`<button data-near="${n.l.id}"><span><b>${esc(n.l.n)}</b><br><span class="note">${esc(n.l.a||"")}</span></span><span class="badge">${n.d} km</span></button>`).join("")}</div>
     ${data&&near[0].d<40?`<h3>Ikan & umpan di sekitarmu</h3><p class="note">Berdasarkan spot terdekat (${esc(n0.n)}).</p>
       <table><thead><tr><th>Umpan</th><th>Ikan</th></tr></thead><tbody>${Object.entries(data.bait).map(([b,fs])=>`<tr><td>${esc(b)}</td><td>${fs.map(fishMini).join("")}</td></tr>`).join("")}</tbody></table>
       <button class="btn ghost" id="saveHere" style="margin-top:8px;width:100%">Simpan lokasi ini sebagai spot</button>`
      :`<p class="note">Belum ada spot di aplikasi dalam radius 40 km. Simpan lokasi ini sebagai spot pribadi, lalu catat tangkapan di sana.</p><button class="btn ghost" id="saveHere" style="width:100%">Simpan lokasi ini sebagai spot</button>`}
   </div>`:""}</div>`;
}
function bindLocate(){
  const g=$("#gpsBtn");if(!g)return;g.onclick=()=>detectGPS(false);
  $("#locF").onsubmit=e=>{e.preventDefault();const q=$("#locQ").value.trim();if(q&&!locBusy)searchPlace(q)};
  document.querySelectorAll("[data-sr]").forEach(b=>b.onclick=()=>{const r=searchRes[+b.dataset.sr];useHere(r.lat,r.lon,r.label.split(",").slice(0,2).join(","))});
  document.querySelectorAll("[data-near]").forEach(b=>b.onclick=()=>{const l=everySpot().find(x=>x.id===b.dataset.near);setRegion(l.region||regionOf(l.lat,l.lon),l.id)});
  const sv=$("#saveHere");if(sv)sv.onclick=()=>{const h=here,n=nearest(h.lat,h.lon,1)[0],src=n&&n.d<40?n.l:null,id="my"+Date.now();
    const name=(h.label||"Spot baru").split(",")[0].slice(0,40);
    mySpots.push({id,n:name==="Lokasimu sekarang"?"Spot pribadi "+(mySpots.length+1):name,a:src?"Dekat "+src.n:"Spot pribadi",lat:h.lat,lon:h.lon,type:src?.type||"Tepi air",custom:true,region:regionOf(h.lat,h.lon),fish:src?src.fish.slice():[],bait:src?JSON.parse(JSON.stringify(src.bait)):{},spots:src?.spots||"",tide:src?.tide||""});
    store.set("mm_spots",mySpots);setRegion(regionOf(h.lat,h.lon),id)};
}

function setRegion(rg,id){region=rg;store.set("mm_region",rg);$("#region").value=rg;setSpot(id||allSpots().find(s=>(s.region||regionOf(s.lat,s.lon))===rg).id)}
/* ================= WAKTU & PASANG ================= */
const rad=Math.PI/180;
function sydOffset(date){const y=date.getUTCFullYear(),fs=m=>{const d=new Date(Date.UTC(y,m,1));return 1+((7-d.getUTCDay())%7)};const st=Date.UTC(y,9,fs(9),-9),en=Date.UTC(y,3,fs(3),-10),t=date.getTime();return(t>=st||t<en)?11:10}
function sunTimes(date,lat,lon){const tz=tzLL(lat,lon);const d=new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth(),date.getUTCDate()));const n=Math.floor((d-Date.UTC(d.getUTCFullYear(),0,0))/864e5);const g=2*Math.PI/365*(n-1);const eq=229.18*(0.000075+0.001868*Math.cos(g)-0.032077*Math.sin(g)-0.014615*Math.cos(2*g)-0.040849*Math.sin(2*g));const dec=0.006918-0.399912*Math.cos(g)+0.070257*Math.sin(g)-0.006758*Math.cos(2*g)+0.000907*Math.sin(2*g)-0.002697*Math.cos(3*g)+0.00148*Math.sin(3*g);const ha=Math.acos(Math.cos(90.833*rad)/(Math.cos(lat*rad)*Math.cos(dec))-Math.tan(lat*rad)*Math.tan(dec))/rad;return{rise:(720-4*(lon+ha)-eq)/60+tz,set:(720-4*(lon-ha)-eq)/60+tz}}
const SYN=29.530588853,NEWREF=Date.UTC(2000,0,6,18,14);
const moonAge=t=>(((t-NEWREF)/864e5)%SYN+SYN)%SYN;
const LX=(id,en)=>region==="AU"?en:id;const LOC_=()=>region==="AU"?"en-AU":"id-ID";
const PHASE_EN=["New moon","Waxing crescent","First quarter","Waxing gibbous","Full moon","Waning gibbous","Last quarter","Waning crescent"];
const PHASE=["Bulan baru","Sabit awal","Separuh awal","Cembung awal","Purnama","Cembung akhir","Separuh akhir","Sabit akhir"];
function dayStart(off,tz=tzLL(cur().lat,cur().lon)){const now=new Date(),l=new Date(now.getTime()+tz*36e5);return Date.UTC(l.getUTCFullYear(),l.getUTCMonth(),l.getUTCDate()+off)-tz*36e5}
// daftar titik ekstrem nyata (ms UTC)
const EXT=[];TIDES.forEach(([d,arr])=>arr.forEach(([t,v])=>{const[h,m]=t.split(":").map(Number);const[Y,M,D]=d.split("-").map(Number);EXT.push({t:Date.UTC(Y,M-1,D,h,m)-11*36e5,v})}));
EXT.unshift({t:EXT[0].t-6.2*36e5,v:1.35});EXT.push({t:EXT[EXT.length-1].t+6.2*36e5,v:1.4});
const tideFrom={t0:EXT[1].t,t1:EXT[EXT.length-2].t};
function estTide(ms){const age=moonAge(ms);const spring=Math.cos(4*Math.PI*age/SYN);return 1.0+(0.6+0.25*spring)*Math.cos(2*Math.PI*((ms-EXT[3].t)/36e5)/12.42)} // fase dikunci ke pasang nyata terakhir yg diketahui
function tideMs(ms){
  if(ms>=EXT[0].t&&ms<=EXT[EXT.length-1].t){for(let i=0;i<EXT.length-1;i++){const a=EXT[i],b=EXT[i+1];if(ms>=a.t&&ms<=b.t){const f=(ms-a.t)/(b.t-a.t);return a.v+(b.v-a.v)*(1-Math.cos(Math.PI*f))/2}}}
  return estTide(ms);
}
const isReal=ds=>cur().lat<=-11.5&&ds>=tideFrom.t0-36e5*4&&ds+864e5<=tideFrom.t1+36e5*6;
function fishScore(off,lat,lon){
  const ds=dayStart(off,tzLL(lat,lon)),age=moonAge(ds+12*36e5),sun=sunTimes(new Date(ds+12*36e5),lat,lon),hours=[];
  for(let h=0;h<24;h++){let s=Math.abs(tideMs(ds+(h+.5)*36e5)-tideMs(ds+h*36e5))*2*1.4;if(Math.abs(h-sun.rise)<1.5||Math.abs(h-sun.set)<1.5)s+=.55;hours.push(Math.min(1,s))}
  const sb=(Math.cos(4*Math.PI*age/SYN)+1)/2;
  return{hours,total:Math.round(Math.min(100,hours.reduce((a,b)=>a+b,0)/24*90+sb*25)),age,sun,ds};
}
const fmt=h=>{h=(h+24)%24;let H=Math.floor(h),M=Math.round((h-H)*60);if(M===60){H=(H+1)%24;M=0}return String(H).padStart(2,"0")+":"+String(M).padStart(2,"0")};
const scoreCol=s=>s>=65?"var(--good)":s>=45?"var(--mid)":"var(--bad)";
const scoreTxt=s=>s>=65?LX("Bagus","Good"):s>=45?LX("Sedang","Fair"):LX("Lemah","Poor");


/* ===== Banner pasang aplikasi (hanya di versi web) ===== */
function installBanner(){
  if(window.Capacitor||store.get("mm_banner_off",false))return "";
  if(window.matchMedia&&matchMedia("(display-mode: standalone)").matches)return "";
  const ua=navigator.userAgent||"",isAnd=/Android/i.test(ua),isIOS=/iPhone|iPad|iPod/i.test(ua);
  return `<div class="card instbar"><button class="x" id="instX" aria-label="Tutup" style="float:right">✕</button>
   <h3>📲 Pasang Mancing Mania</h3>
   ${isIOS?`<p class="note">Di iPhone: ketuk tombol <b>Bagikan</b> di Safari, lalu pilih <b>Tambah ke Layar Utama</b>.</p>`
   :`<p class="note">${isAnd?"Unduh aplikasi Android, lalu buka file-nya untuk menginstal.":"Aplikasi Android tersedia sebagai file APK."}</p>
     <a class="btn" href="mancing-mania.apk" download style="display:block;margin-top:6px">⬇️ Unduh APK Android</a>
     <p class="note" style="margin-top:6px">Saat menginstal, izinkan "Instal aplikasi tidak dikenal". Pengguna iPhone: buka link ini di Safari → Bagikan → Tambah ke Layar Utama.</p>`}</div>`;
}
function bindInstall(){const x=document.getElementById("instX");if(x)x.onclick=()=>{store.set("mm_banner_off",true);render()}}
/* ================= PETA (Leaflet + OpenStreetMap) ================= */
let lmap=null,pendingLL=null,commOn=store.get("mm_comm",true);
function killMap(){if(lmap){lmap.remove();lmap=null}}
function mapView(){
  const c=cur(),sc=fishScore(0,c.lat,c.lon);
  $("#main").innerHTML=`${offlineBadge()}${installBanner()}
   <div class="mapwrap"><div id="lmap" class="lmap" role="application" aria-label="Peta spot mancing"></div><span class="hint">Ketuk peta untuk menyimpan spot baru</span></div>
   <label class="note" style="display:flex;align-items:center;gap:6px;margin-top:6px"><input type="checkbox" id="commTog" style="width:auto" ${commOn?"checked":""}> 🐟 Tampilkan tangkapan komunitas 7 hari terakhir</label>
   <form id="addForm" class="card" hidden style="margin-top:12px"><h3>Spot baru</h3><input id="newName" placeholder="Nama spot, mis. Batu favorit" required maxlength="40"><p class="note" id="newCoord"></p><div class="two"><button class="btn" type="submit">Simpan</button><button class="btn ghost" type="button" id="cancelAdd">Batal</button></div></form>
   <div style="margin-top:12px">${locateCard()}</div>
   <div class="card"><span class="tag">${esc(c.a||"Spot pribadi")} · ${esc(c.type||"Disimpan olehmu")}</span><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h2>${esc(c.n)}</h2><button class="x" id="favBtn" data-fav="${c.id}" aria-pressed="${isFav(c.id)}">${isFav(c.id)?"★ Favorit":"☆ Favoritkan"}</button></div>
     <div class="row"><div class="kv"><span class="tag">Aktivitas hari ini</span><strong style="color:${scoreCol(sc.total)}">${sc.total} · ${scoreTxt(sc.total)}</strong></div><div class="kv"><span class="tag">Matahari</span><strong>${fmt(sc.sun.rise)}–${fmt(sc.sun.set)}</strong></div></div>
     ${c.fish?.length?`<div style="margin-top:6px">${c.fish.slice(0,4).map(fishMini).join("")}</div>`:""}
     ${(()=>{const r=(feed||[]).filter(x=>x.spot_id===c.id).slice(0,3);return `<h3 style="margin-top:10px">Laporan terbaru di sini</h3>${r.length?r.map(feedItem).join(""):`<p class="note">${feed===null?"Memuat…":"Belum ada laporan tangkapan di spot ini."}</p>`}`})()}
     <p class="note">${c.lat.toFixed(4)}, ${c.lon.toFixed(4)} · <a href="https://www.google.com/maps/dir/?api=1&destination=${c.lat},${c.lon}" target="_blank" rel="noopener">Navigasi ke sini</a>${c.custom?` · <button class="x" id="delSpot">Hapus spot</button>`:""}</p></div>
   ${favCardHtml()}
   <h3>Semua spot</h3>
   <div class="list">${allSpots().map(s=>{const t=fishScore(0,s.lat,s.lon).total;return `<button data-id="${s.id}"><span><b>${esc(s.n)}</b><br><span class="note">${esc(s.a||"Spot pribadi")}${here?" · "+km(here.lat,here.lon,s.lat,s.lon)+" km":""}</span></span><span class="score" style="background:${scoreCol(t)}">${t}</span></button>`}).join("")}</div>`;
  document.querySelectorAll(".list button[data-id]").forEach(p=>p.onclick=()=>setSpot(p.dataset.id));
  bindLocate();bindInstall();bindFav();bindFeed();
  $("#commTog").onchange=e=>{commOn=e.target.checked;store.set("mm_comm",commOn);render()};
  $("#cancelAdd").onclick=()=>{$("#addForm").hidden=true};
  $("#addForm").onsubmit=e=>{e.preventDefault();const id="my"+Date.now();mySpots.push({id,n:$("#newName").value.trim()||"Spot baru",lat:pendingLL.lat,lon:pendingLL.lng,custom:true,region:regionOf(pendingLL.lat,pendingLL.lng),fish:[],bait:{}});store.set("mm_spots",mySpots);setSpot(id)};
  const del=$("#delSpot");if(del)del.onclick=()=>{mySpots=mySpots.filter(s=>s.id!==c.id);store.set("mm_spots",mySpots);setSpot(allSpots()[0]?.id)};
  if(!window.L){$("#lmap").innerHTML=`<p class="note" style="padding:16px">Peta butuh internet. Daftar spot di bawah tetap bisa dipakai.</p>`;return}
  lmap=L.map("lmap",{zoomControl:true,attributionControl:true}).setView([c.lat,c.lon],region==="AU"?11:inLombok(c)?10:region==="ID"?(c.custom?11:9):11);
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:18,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'}).addTo(lmap);
  allSpots().forEach(s=>{const on=s.id===c.id;
    L.circleMarker([s.lat,s.lon],{radius:on?10:7,color:"#fff",weight:2,fillColor:s.custom?"#f0a51a":"#1565c0",fillOpacity:1}).addTo(lmap).bindTooltip(s.n,{permanent:on,direction:"right"}).on("click",()=>setSpot(s.id))});
  if(commOn)(feed||[]).filter(x=>x.lat!=null&&inRegion(x)&&!blocked.has(x.user_id)&&Date.now()-Date.parse(x.created_at)<7*864e5).forEach(x=>{
    const ic=L.divIcon({className:"commpin",html:"🐟",iconSize:[22,22]});
    L.marker([x.lat,x.lon],{icon:ic}).addTo(lmap).bindPopup(`<b>${esc(x.fish)}</b>${x.length_cm?" "+x.length_cm+" cm":""}<br>${esc(x.profiles?.name||"Pemancing")} · ${ago(x.created_at)}<br>${esc(x.spot_name||"")}`).on("popupopen",e=>tr(e.popup.getElement()))});
  if(here){L.circleMarker([here.lat,here.lon],{radius:8,color:"#fff",weight:3,fillColor:"#2f7de1",fillOpacity:1}).addTo(lmap).bindTooltip("Kamu",{direction:"top"});if(here.acc)L.circle([here.lat,here.lon],{radius:here.acc,color:"#2f7de1",weight:1,fillOpacity:.08}).addTo(lmap)}
  lmap.on("click",e=>{pendingLL=e.latlng;$("#addForm").hidden=false;$("#newCoord").textContent=`Koordinat: ${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`;$("#newName").focus()});
  setTimeout(()=>lmap&&lmap.invalidateSize(),60);
}

/* ================= PRAKIRAAN: Open-Meteo (cuaca, angin, ombak, tinggi muka laut) ================= */
const wx={};let wxBusy={};
const wxKey=s=>s.lat.toFixed(2)+","+s.lon.toFixed(2);
async function loadWx(s){
  const k=wxKey(s);if(wxBusy[k])return;
  const cached=wx[k]||store.get("mm_wx_"+k,null);
  if(cached&&Date.now()-cached.t<3*36e5){wx[k]=cached;return}
  if(cached)wx[k]=cached;
  wxBusy[k]=true;
  try{
    const q=`latitude=${s.lat}&longitude=${s.lon}&timezone=auto&forecast_days=7`;
    const [w,m]=await Promise.all([
      fetch(`https://api.open-meteo.com/v1/forecast?${q}&hourly=temperature_2m,precipitation_probability,wind_speed_10m,wind_direction_10m,weather_code&daily=sunrise,sunset&wind_speed_unit=kmh`).then(r=>r.ok?r.json():null),
      fetch(`https://marine-api.open-meteo.com/v1/marine?${q}&hourly=wave_height,sea_level_height_msl,sea_surface_temperature`).then(r=>r.ok?r.json():null).catch(()=>null)
    ]);
    if(!w)throw 0;
    const d={t:Date.now(),w,m};wx[k]=d;
    // simpan versi ringkas untuk dipakai offline
    store.set("mm_wx_"+k,d);
  }catch(e){if(!wx[k])wx[k]={err:1,t:0}}
  wxBusy[k]=false;if(view==="prakiraan"&&wxKey(cur())===k)render();
}
const WCODE=c=>c==null?"":c<=1?LX("☀️ Cerah","☀️ Clear"):c<=3?LX("⛅ Berawan","⛅ Cloudy"):c<=48?LX("🌫️ Kabut","🌫️ Fog"):c<=67?LX("🌧️ Hujan","🌧️ Rain"):c<=77?LX("🌨️ Salju","🌨️ Snow"):c<=82?LX("🌦️ Hujan lokal","🌦️ Showers"):LX("⛈️ Badai","⛈️ Storm");
const dirTxt=d=>(region==="AU"?["N","NE","E","SE","S","SW","W","NW"]:["U","TL","T","TG","S","BD","B","BL"])[Math.round(d/45)%8];
function dayHours(arr,times,date){const out=[];times.forEach((t,i)=>{if(t.startsWith(date))out.push(arr?.[i])});return out}
function extremes(hv){const e=[];for(let i=1;i<hv.length-1;i++){const[a,b,c]=[hv[i-1],hv[i],hv[i+1]];if(a==null||b==null||c==null)continue;if((b>a&&b>=c)||(b<a&&b<=c)){const den=a-2*b+c,off=den?(a-c)/(2*den):0,v=b-(a-c)*off/4;e.push({h:i+Math.max(-.5,Math.min(.5,off)),v,hi:b>a})}}return e}
const hhmm=s=>s.slice(11,16),h2n=s=>+s.slice(11,13)+ +s.slice(14,16)/60;
function forecastView(){
  const c=cur(),k=wxKey(c),W=wx[k];
  if(!W||(!W.w&&!W.err)){$("#main").innerHTML=`<h2>${esc(c.n)}</h2><div class="card"><p class="note">${LX("Memuat cuaca, angin, ombak & pasang surut…","Loading weather, wind, waves & tides…")}</p></div>`;loadWx(c);return}
  if(W.err){forecastEstimate(LX("Tidak bisa memuat data live (offline?). Menampilkan perkiraan.","Couldn't load live data (offline?). Showing an estimate."));loadWx(c);return}
  if(Date.now()-W.t>3*36e5)loadWx(c);
  const w=W.w,m=W.m,dates=w.daily.time,di=Math.min(dayOff,dates.length-1),date=dates[di];
  const sea=m?.hourly?.sea_level_height_msl?dayHours(m.hourly.sea_level_height_msl,m.hourly.time,date):[];
  const hasSea=sea.filter(v=>v!=null).length>12;
  // kurva pasang: data model, atau perkiraan bila tidak tersedia
  const tz=tzLL(c.lat,c.lon),ds=Date.parse(date+"T00:00:00Z")-tz*36e5;
  const tv=[];if(hasSea){const base=Math.min(...sea.filter(v=>v!=null));sea.forEach((v,h)=>{if(v!=null)tv.push([h,v-base])})}else{for(let h=0;h<=24;h+=.25)tv.push([h,tideMs(ds+h*36e5)])}
  const ext=hasSea?extremes(sea).map(e=>({...e,v:e.v-Math.min(...sea.filter(v=>v!=null))})):(()=>{const x=[];for(let i=1;i<tv.length-1;i++){const[a,b,d]=[tv[i-1][1],tv[i][1],tv[i+1][1]];if((b>a&&b>=d)||(b<a&&b<=d))x.push({h:tv[i][0],v:b,hi:b>a})}return x})();
  const vmax=Math.max(.5,...tv.map(x=>x[1]))*1.1;
  const sunR=h2n(w.daily.sunrise[di]),sunS=h2n(w.daily.sunset[di]);
  // skor aktivitas per jam: arus (perubahan muka air) + subuh/senja + fase bulan + angin
  const wind=dayHours(w.hourly.wind_speed_10m,w.hourly.time,date),wdir=dayHours(w.hourly.wind_direction_10m,w.hourly.time,date),temp=dayHours(w.hourly.temperature_2m,w.hourly.time,date),rain=dayHours(w.hourly.precipitation_probability,w.hourly.time,date),code=dayHours(w.hourly.weather_code,w.hourly.time,date);
  const wave=m?.hourly?.wave_height?dayHours(m.hourly.wave_height,m.hourly.time,date):[],sst=m?.hourly?.sea_surface_temperature?dayHours(m.hourly.sea_surface_temperature,m.hourly.time,date):[];
  const val=h=>{const a=tv.find(x=>x[0]>=h);return a?a[1]:tv[tv.length-1][1]};
  const age=moonAge(ds+12*36e5),sb=(Math.cos(4*Math.PI*age/SYN)+1)/2;
  const hours=[];for(let h=0;h<24;h++){let s=Math.abs(val(h+1)-val(h))/vmax*3.2;if(Math.abs(h-sunR)<1.5||Math.abs(h-sunS)<1.5)s+=.5;if((wind[h]||0)>30)s-=.3;if((wave[h]||0)>2.5)s-=.3;hours.push(Math.max(0,Math.min(1,s)))}
  const total=Math.round(Math.max(0,Math.min(100,hours.reduce((a,b)=>a+b,0)/24*90+sb*25)));
  const best=hours.map((v,h)=>[v,h]).sort((a,b)=>b[0]-a[0]).slice(0,3).map(x=>x[1]).sort((a,b)=>a-b);
  const now=new Date(),nowH=di===0?((now.getTime()-ds)/36e5):null;
  const cw=340,ch=150,pl=34,pb=20,X=h=>pl+h/24*(cw-pl-6),Y=v=>ch-pb-(v/vmax)*(ch-pb-12);
  const path=tv.map(([h,v],i)=>(i?"L":"M")+X(h).toFixed(1)+","+Y(v).toFixed(1)).join("");
  const grid=[0,6,12,18,24].map(h=>`<line x1="${X(h)}" x2="${X(h)}" y1="10" y2="${ch-pb}" stroke="var(--line)"/><text x="${X(h)}" y="${ch-5}" font-size="10" text-anchor="middle" fill="var(--muted)">${String(h).padStart(2,"0")}</text>`).join("")+[0,vmax/2/1.1,vmax/1.1].map(v=>`<text x="2" y="${Y(v)+3}" font-size="9" fill="var(--muted)">${v.toFixed(1)}m</text>`).join("");
  const night=`<rect x="${X(0)}" y="10" width="${X(sunR)-X(0)}" height="${ch-pb-10}" fill="var(--fg)" opacity=".06"/><rect x="${X(sunS)}" y="10" width="${X(24)-X(sunS)}" height="${ch-pb-10}" fill="var(--fg)" opacity=".06"/>`;
  const pi=Math.floor(age/SYN*8+.5)%8,illum=Math.round((1-Math.cos(2*Math.PI*age/SYN))/2*100);
  const nh=nowH!=null?Math.max(0,Math.min(23,Math.floor(nowH))):12;
  const safe=(wave[nh]||0)>2.5||(wind[nh]||0)>35;
  $("#main").innerHTML=`
   <h2>${esc(c.n)}</h2>
   <div class="days">${dates.map((d,i)=>`<button data-o="${i}" aria-pressed="${i===di}">${new Date(d+"T12:00:00Z").toLocaleDateString(LOC_(),{weekday:"short",day:"numeric",timeZone:"UTC"})}</button>`).join("")}</div>
   ${safe?`<div class="card" style="border-color:var(--bad)"><b style="color:var(--bad)">${LX("Hati-hati:","Caution:")}</b> ${(wave[nh]||0)>2.5?`${LX("ombak","waves")} ±${wave[nh].toFixed(1)} m`:""} ${(wind[nh]||0)>35?`${LX("angin","wind")} ${Math.round(wind[nh])} ${LX("km/j","km/h")}`:""}. ${LX("Hindari mancing batu & perahu kecil.","Avoid rock fishing & small boats.")}</div>`:""}
   <div class="card" style="margin-top:10px"><div class="row">
     <div class="kv"><span class="tag">${di===0?LX("Sekarang","Now"):LX("Siang","Midday")}</span><strong>${WCODE(code[nh])}</strong><span class="note">${temp[nh]!=null?Math.round(temp[nh])+"°C":""}${rain[nh]!=null?" · "+LX("hujan","rain")+" "+rain[nh]+"%":""}</span></div>
     <div class="kv"><span class="tag">${LX("Angin","Wind")}</span><strong>${wind[nh]!=null?Math.round(wind[nh])+" "+LX("km/j","km/h"):"–"}</strong><span class="note">${wdir[nh]!=null?LX("dari ","from ")+dirTxt(wdir[nh]):""}</span></div>
     <div class="kv"><span class="tag">${LX("Ombak","Waves")}</span><strong>${wave[nh]!=null?wave[nh].toFixed(1)+" m":"–"}</strong><span class="note">${sst[nh]!=null?LX("air ","water ")+Math.round(sst[nh])+"°C":""}</span></div></div>
     <div class="tbl" style="margin-top:8px"><table><thead><tr><th>${LX("Jam","Time")}</th><th>${LX("Cuaca","Weather")}</th><th>${LX("Angin","Wind")}</th><th>${LX("Ombak","Waves")}</th></tr></thead><tbody>${[3,6,9,12,15,18,21].map(h=>`<tr><td>${String(h).padStart(2,"0")}:00</td><td>${WCODE(code[h])} ${temp[h]!=null?Math.round(temp[h])+"°":""}</td><td>${wind[h]!=null?Math.round(wind[h])+" "+dirTxt(wdir[h]):"–"}</td><td>${wave[h]!=null?wave[h].toFixed(1)+" m":"–"}</td></tr>`).join("")}</tbody></table></div></div>
   <div class="card chart"><div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:0">${LX("Pasang surut","Tides")}</h3><span class="badge">${hasSea?LX("Live · model Open-Meteo","Live · Open-Meteo model"):LX("Perkiraan","Estimate")}</span></div>
     <svg viewBox="0 0 ${cw} ${ch}" style="margin-top:8px">${night}${grid}<path d="${path} L${X(tv[tv.length-1][0])},${ch-pb} L${X(tv[0][0])},${ch-pb}Z" fill="var(--accent)" opacity=".15"/><path d="${path}" fill="none" stroke="var(--accent)" stroke-width="2"/>${ext.map(e=>`<circle cx="${X(e.h)}" cy="${Y(e.v)}" r="3.5" fill="var(--accent)"/><text x="${X(e.h)}" y="${Y(e.v)+(e.hi?-8:14)}" font-size="9.5" text-anchor="middle" fill="var(--fg)">${fmt(e.h)}</text>`).join("")}${nowH!=null&&nowH<24?`<line x1="${X(nowH)}" x2="${X(nowH)}" y1="10" y2="${ch-pb}" stroke="var(--sand)" stroke-width="2"/>`:""}</svg>
     <table><thead><tr><th>${LX("Jam","Time")}</th><th>${LX("Tipe","Type")}</th><th>${LX("Relatif","Relative")}</th></tr></thead><tbody>${ext.map(e=>`<tr><td>${fmt(e.h)}</td><td>${e.hi?LX("▲ Pasang","▲ High"):LX("▼ Surut","▼ Low")}</td><td>${e.v.toFixed(2)} m</td></tr>`).join("")}</tbody></table>
     <p class="note">${hasSea?LX("Tinggi muka laut dari model global Open-Meteo, ditampilkan relatif terhadap surut terendah hari ini. Di teluk sempit dan muara, waktunya bisa bergeser.","Sea level from Open-Meteo's global model, shown relative to today's lowest tide. In narrow bays and estuaries the timing can shift."):LX("Data muka laut tidak tersedia untuk titik ini, jadi ditampilkan perkiraan dari posisi bulan.","Sea-level data isn't available for this point, so an estimate from the moon's position is shown.")} ${LX("Jadwal resmi:","Official tide times:")} ${region==="AU"?`<a href="https://www.bom.gov.au/australia/tides/" target="_blank" rel="noopener">BOM</a>`:`<a href="https://maritim.bmkg.go.id/" target="_blank" rel="noopener">BMKG Maritim</a>`}.</p></div>
   <div class="card"><div class="row"><div class="kv"><span class="tag">${LX("Aktivitas ikan","Fish activity")}</span><strong style="color:${scoreCol(total)}">${total}/100</strong></div><div class="kv"><span class="tag">${LX("Jam terbaik","Best hours")}</span><strong>${best.map(h=>fmt(h)).join(" · ")}</strong></div></div>
     <div class="fishbar" style="margin-top:10px">${hours.map((v,h)=>`<i style="height:${Math.max(4,v*100)}%;${best.includes(h)?"background:var(--sand)":""}" title="${fmt(h)}"></i>`).join("")}</div>
     <div class="row note" style="justify-content:space-between"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div><p class="note">${LX("Dari kecepatan perubahan pasang, subuh/senja, fase bulan, angin & ombak.","Based on tidal flow, dawn/dusk, moon phase, wind & waves.")}</p></div>
   <div class="card"><div class="row"><div class="kv"><span class="tag">${LX("Terbit","Sunrise")}</span><strong>${hhmm(w.daily.sunrise[di])}</strong></div><div class="kv"><span class="tag">${LX("Terbenam","Sunset")}</span><strong>${hhmm(w.daily.sunset[di])}</strong></div><div class="kv"><span class="tag">${LX("Bulan","Moon")}</span><strong>${LX(PHASE[pi],PHASE_EN[pi])}</strong><span class="note">${illum}% ${LX("terang","lit")}</span></div></div></div>
   <p class="note">${LX("Data cuaca & laut:","Weather & marine data:")} <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo</a> (CC BY 4.0). ${LX("Diperbarui","Updated")} ${new Date(W.t).toLocaleTimeString(LOC_(),{hour:"2-digit",minute:"2-digit"})}.</p>`;
  document.querySelectorAll(".days button").forEach(b=>b.onclick=()=>{dayOff=+b.dataset.o;render()});
}

/* ================= PASANG & PRAKIRAAN ================= */
function forecastEstimate(msg){
  const c=cur(),now=new Date(),T=fishScore(dayOff,c.lat,c.lon),real=isReal(T.ds);
  const dname=o=>new Date(dayStart(o)+12*36e5).toLocaleDateString(LOC_(),{weekday:"short",day:"numeric",timeZone:tzName(c.lat,c.lon)});
  const days=[0,1,2,3,4,5,6].map(o=>{const s=fishScore(o,c.lat,c.lon).total;return `<button data-o="${o}" aria-pressed="${o===dayOff}">${dname(o)}<small style="color:${scoreCol(s)}">${s} · ${scoreTxt(s)}</small></button>`}).join("");
  const cw=340,ch=150,pl=30,pb=20,X=h=>pl+h/24*(cw-pl-6),Y=v=>ch-pb-(v/2)*(ch-pb-10);
  const tv=[];for(let h=0;h<=24;h+=.25)tv.push([h,tideMs(T.ds+h*36e5)]);
  const path=tv.map(([h,v],i)=>(i?"L":"M")+X(h).toFixed(1)+","+Y(v).toFixed(1)).join("");
  let ext=EXT.filter(e=>e.t>=T.ds&&e.t<T.ds+864e5&&real).map(e=>({h:(e.t-T.ds)/36e5,v:e.v}));
  if(!real){ext=[];for(let i=1;i<tv.length-1;i++){const[a,b,d]=[tv[i-1][1],tv[i][1],tv[i+1][1]];if((b>a&&b>=d)||(b<a&&b<=d))ext.push({h:tv[i][0],v:b})}}
  ext.forEach((e,i)=>{const nb=ext[i+1]||ext[i-1];e.hi=nb?e.v>nb.v:e.v>1});
  const grid=[0,6,12,18,24].map(h=>`<line x1="${X(h)}" x2="${X(h)}" y1="10" y2="${ch-pb}" stroke="var(--line)"/><text x="${X(h)}" y="${ch-5}" font-size="10" text-anchor="middle" fill="var(--muted)">${String(h).padStart(2,"0")}</text>`).join("")+[0,1,2].map(v=>`<text x="4" y="${Y(v)+3}" font-size="10" fill="var(--muted)">${v}m</text>`).join("");
  const nowH=dayOff===0?(now.getTime()-T.ds)/36e5:null;
  const night=`<rect x="${X(0)}" y="10" width="${X(T.sun.rise)-X(0)}" height="${ch-pb-10}" fill="var(--fg)" opacity=".06"/><rect x="${X(T.sun.set)}" y="10" width="${X(24)-X(T.sun.set)}" height="${ch-pb-10}" fill="var(--fg)" opacity=".06"/>`;
  const age=T.age,pi=Math.floor(age/SYN*8+.5)%8,illum=Math.round((1-Math.cos(2*Math.PI*age/SYN))/2*100);
  const best=T.hours.map((v,h)=>[v,h]).sort((a,b)=>b[0]-a[0]).slice(0,3).map(x=>x[1]).sort((a,b)=>a-b);
  let nowTxt="";if(nowH!==null){const v=tideMs(now.getTime()),v2=tideMs(now.getTime()+6e5);nowTxt=`<div class="kv"><span class="tag">${LX("Sekarang","Now")}</span><strong>${v.toFixed(2)} m ${v2>v?LX("↑ naik","↑ rising"):LX("↓ turun","↓ falling")}</strong></div>`}
  $("#main").innerHTML=`
   <h2>${esc(c.n)}</h2><div class="card"><p class="note">${esc(msg)}</p></div><div class="days">${days}</div>
   <div class="card chart" style="margin-top:10px"><div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:0">${LX("Pasang surut","Tides")}</h3><span class="badge">${real?"WillyWeather · Fort Denison":LX("Perkiraan","Estimate")}</span></div>
     <div class="row" style="margin:8px 0">${nowTxt}<div class="kv"><span class="tag">${LX("Tertinggi","Highest")}</span><strong>${Math.max(...tv.map(x=>x[1])).toFixed(2)} m</strong></div></div>
     <svg viewBox="0 0 ${cw} ${ch}">${night}${grid}<path d="${path} L${X(24)},${ch-pb} L${X(0)},${ch-pb}Z" fill="var(--accent)" opacity=".15"/><path d="${path}" fill="none" stroke="var(--accent)" stroke-width="2"/>${ext.map(e=>`<circle cx="${X(e.h)}" cy="${Y(e.v)}" r="3.5" fill="var(--accent)"/><text x="${X(e.h)}" y="${Y(e.v)+(e.hi?-8:14)}" font-size="9.5" text-anchor="middle" fill="var(--fg)">${fmt(e.h)}</text>`).join("")}${nowH!==null?`<line x1="${X(nowH)}" x2="${X(nowH)}" y1="10" y2="${ch-pb}" stroke="var(--sand)" stroke-width="2"/>`:""}</svg>
     <table><thead><tr><th>${LX("Jam","Time")}</th><th>${LX("Tipe","Type")}</th><th>${LX("Tinggi","Height")}</th></tr></thead><tbody>${ext.map(e=>`<tr><td>${fmt(e.h)}</td><td>${e.hi?LX("▲ Pasang","▲ High"):LX("▼ Surut","▼ Low")}</td><td>${e.v.toFixed(2)} m</td></tr>`).join("")}</tbody></table>
     <p class="note">${real?`Source: <a href="${TIDE_SRC}" target="_blank" rel="noopener">WillyWeather, Fort Denison station</a> (fetched 13 Oct 2026). Spots outside the harbour can differ by a few minutes. Heights between high and low are interpolated.`:region!=="AU"?`Perkiraan kasar. Banyak perairan Indonesia hanya punya satu pasang sehari, jadi jam bisa jauh berbeda. Cek jadwal resmi di <a href="https://maritim.bmkg.go.id/" target="_blank" rel="noopener">BMKG Maritim</a> atau <a href="https://srgi.big.go.id/" target="_blank" rel="noopener">BIG (pasut)</a>.`:`Outside the WillyWeather data range (13–19 Oct), so this is an estimate. Check <a href="${TIDE_SRC}" target="_blank" rel="noopener">WillyWeather</a> for the latest tide times.`}</p></div>
   <div class="card"><div class="row"><div class="kv"><span class="tag">${LX("Aktivitas ikan","Fish activity")}</span><strong style="color:${scoreCol(T.total)}">${T.total}/100</strong></div><div class="kv"><span class="tag">${LX("Jam terbaik","Best hours")}</span><strong>${best.map(h=>fmt(h)).join(" · ")}</strong></div></div>
     <div class="fishbar" style="margin-top:10px">${T.hours.map((v,h)=>`<i style="height:${Math.max(4,v*100)}%;${best.includes(h)?"background:var(--sand)":""}" title="${fmt(h)}"></i>`).join("")}</div>
     <div class="row note" style="justify-content:space-between"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div><p class="note">${LX("Skor dihitung dari kecepatan arus pasang, subuh/senja, dan fase bulan.","Score is based on tidal flow, dawn/dusk and moon phase.")}</p></div>
   <div class="card"><div class="row"><div class="kv"><span class="tag">${LX("Terbit","Sunrise")}</span><strong>${fmt(T.sun.rise)}</strong></div><div class="kv"><span class="tag">${LX("Terbenam","Sunset")}</span><strong>${fmt(T.sun.set)}</strong></div><div class="kv"><span class="tag">${LX("Bulan","Moon")}</span><strong>${LX(PHASE[pi],PHASE_EN[pi])}</strong><span class="note">${illum}% ${LX("terang","lit")}</span></div></div></div>
   <div class="card"><h3>${LX("Cuaca, angin & ombak","Weather, wind & waves")}</h3>${region!=="AU"?`<ul><li><a href="https://www.bmkg.go.id/cuaca/prakiraan-cuaca" target="_blank" rel="noopener">Prakiraan cuaca BMKG</a></li><li><a href="https://maritim.bmkg.go.id/" target="_blank" rel="noopener">Gelombang & angin laut (BMKG Maritim)</a></li></ul>`:`<ul><li><a href="https://www.willyweather.com.au/nsw/sydney.html" target="_blank" rel="noopener">WillyWeather Sydney</a></li><li><a href="https://www.bom.gov.au/nsw/forecasts/sydney-coastal.shtml" target="_blank" rel="noopener">Coastal wind & swell (BOM)</a></li></ul>`}</div>`;
  document.querySelectorAll(".days button").forEach(b=>b.onclick=()=>{dayOff=+b.dataset.o;render()});
}

/* ================= IKAN & UMPAN ================= */

/* ===== Mode darat / perahu ===== */
let mode=store.get("mm_mode","darat");
Object.assign(BAITINFO,{"Minnow troll":"Umpan tiruan ikan yang ditarik di belakang perahu (trolling) 5–8 knot."});
function boatData(c){
  const est=/sungai|muara|river|teluk|bakau/i.test((c.type||"")+" "+(c.a||""));
  if(est)return{fish:c.fish,bait:Object.assign({},c.bait,{"Soft plastic besar":c.fish.filter(f=>["Flathead","Mulloway","Kakap Putih","Barakuda","Kingfish"].includes(f))}),
    spots:"Dari perahu: lempar ke tepi bakau, kayu tenggelam, dan tiang dari arah air; jangkar di tepi alur dalam untuk ikan besar saat arus melambat.",tide:c.tide,est:1};
  if(c.region==="AU")return{fish:["Snapper","Kingfish","Flathead","Mulloway","Trevally","Squid"],
    bait:{"Soft plastic besar":["Snapper","Flathead","Kingfish"],"Squid hidup":["Kingfish","Mulloway"],"Pilchard utuh":["Snapper","Trevally"],"Jig logam":["Kingfish","Snapper"],"Minnow troll":["Kingfish"],"Squid jig":["Squid"]},
    spots:"Drift di atas karang dalam 15–40 m untuk snapper; sekitar penanda navigasi dan tanjung untuk kingfish; drift di atas pasir untuk flathead. Pakai sonar & GPS.",tide:"Pergantian arus dan subuh. Cek angin & swell BOM sebelum keluar heads."};
  return{fish:["Kakap Merah","Kerapu","GT","Tenggiri","Tongkol","Barakuda"],
    bait:{"Potongan cumi":["Kakap Merah","Kerapu"],"Ikan umpan hidup":["Kerapu","Tenggiri","Barakuda"],"Jig logam":["Tenggiri","Tongkol","GT","Kakap Merah"],"Popper":["GT"],"Minnow troll":["Tenggiri","Tongkol","Barakuda"]},
    spots:"Tubir & karang dalam 20–60 m untuk kerapu dan kakap merah (dasaran / slow jig); rumpon untuk tongkol & tenggiri; tanjung berarus untuk GT (popping). Sewa perahu nelayan setempat yang tahu titiknya.",tide:"Arus sedang di awal pasang atau surut; hindari saat gelombang tinggi (cek BMKG Maritim)."};
}
const spotData=c=>mode==="perahu"&&c.fish?.length?boatData(c):c;

/* ===== Animasi cara mancing di peta lempar ===== */
const TECH={popper:["GT"],cepat:["Tailor","Salmon Australia","Tenggiri","Tongkol","Barakuda","Kingfish"],dasar:["Kakap Merah","Kerapu","Snapper","Mulloway","Flathead","Drummer"],pelampung:["Luderick","Baronang","Yellowtail","Belanak"],cumi:["Squid","Cumi"]};
const techOf=f=>Object.keys(TECH).find(k=>TECH[k].includes(f))||"pelan";
const TECHTXT={
 popper:["Lempar popper sejauh mungkin ke buih.","Sentak joran keras: popper menyemburkan air.","Jeda sebentar, sentak lagi. GT menyambar di permukaan!"],
 cepat:["Lempar jauh melewati target.","Gulung cepat dan rata, umpan meluncur di bawah permukaan.","Ikan predator mengejar dan menyambar. Jangan berhenti menggulung!"],
 dasar:["Lempar ke arah karang/dasar.","Biarkan umpan tenggelam sampai dasar (hitung 5–10).","Angkat joran pelan, umpan melompat lalu jatuh lagi. Rasakan tarikan!"],
 pelampung:["Lempar pelampung ke depan struktur.","Biarkan hanyut mengikuti arus di sepanjang rumput laut/batu.","Pelampung tenggelam = ikan makan. Angkat joran!"],
 cumi:["Lempar squid jig ke tepi rumput laut.","Biarkan tenggelam, lalu sentak 2–3 kali.","Diam beberapa detik. Cumi memeluk jig saat diam!"],
 pelan:["Lempar ke dekat struktur.","Biarkan umpan jatuh alami, gulung sangat pelan.","Ikan mengambil umpan. Tunggu sebentar, lalu angkat joran."]
};
let caRAF=null;
function castAnimStop(){if(caRAF)cancelAnimationFrame(caRAF);caRAF=null}
function castAnimStart(){
  castAnimStop();const svg=document.getElementById("castSvg");if(!svg)return;
  const[mx,my,cx,cy,tx,ty]=svg.dataset.a.split(",").map(Number),fish=svg.dataset.fish,tech=techOf(fish),T=TECHTXT[tech],boat=mode==="perahu";
  const g=id=>document.getElementById(id);
  const lure=g("caLure"),line=g("caLine"),rings=g("caRings"),fsh=g("caFish"),cap=g("caTxt"),stp=g("caStep"),btn=g("caPlay");
  const sRod=g("sRod"),sLine=g("sLine"),sLure=g("sLure"),sFish=g("sFish"),sFloat=g("sFloat"),sRings=g("sRings"),sDepth=g("sDepth");
  const bez=t=>[(1-t)*(1-t)*mx+2*(1-t)*t*cx+t*t*tx,(1-t)*(1-t)*my+2*(1-t)*t*cy+t*t*ty];
  const back=u=>[tx+(mx-tx)*u*.45,ty+(my-ty)*u*.45];
  const NS="http://www.w3.org/2000/svg";
  const ring=(host,x,y,col)=>{const c=document.createElementNS(NS,"circle");c.setAttribute("cx",x);c.setAttribute("cy",y);c.setAttribute("r",2);c.setAttribute("fill","none");c.setAttribute("stroke",col);c.setAttribute("stroke-width","1.5");c.dataset.b=performance.now();host.appendChild(c)};
  // tampak samping: permukaan y=34, dasar y=104, pemancing di x=26
  const SURF=34,BOT=104,HX=26,HY=boat?30:24,X0=60,X1=280;
  const depthEnd={dasar:BOT-4,cumi:BOT-14,pelampung:70,popper:SURF,cepat:52,pelan:80}[tech];
  const D=[1400,1800,4200,1800],total=D[0]+D[1]+D[2]+D[3];
  let t0=null,phase=-1,last=0,paused=false,pauseAt=0;
  const setP=i=>{if(i===phase)return;phase=i;cap.textContent=i<3?T[i]:"Strike! Angkat joran, jaga senar tetap tegang, lalu gulung.";stp.textContent=`Langkah ${i+1} dari 4 · ${({popper:"Popping",cepat:"Gulung cepat",dasar:"Mancing dasar",pelampung:"Pelampung",cumi:"Squid jig",pelan:"Umpan alami"})[tech]}`};
  btn.textContent="❚❚ Jeda";
  btn.onclick=()=>{if(!paused){paused=true;pauseAt=performance.now();btn.textContent="▶ Lanjut"}else{paused=false;t0+=performance.now()-pauseAt;btn.textContent="❚❚ Jeda";caRAF=requestAnimationFrame(frame)}};
  const rod=(ang,bend)=>{const L=40,r=ang*rad,ex=HX+Math.cos(r)*L,ey=HY-Math.sin(r)*L,mxr=HX+Math.cos(r)*L*.55+bend*.4,myr=HY-Math.sin(r)*L*.55+bend;sRod.setAttribute("d",`M${HX} ${HY} Q${mxr} ${myr} ${ex+bend*.3} ${ey+bend*.8}`);return[ex+bend*.3,ey+bend*.8]};
  function frame(now){
    if(!document.body.contains(svg)){castAnimStop();return}
    if(paused)return;
    if(t0===null)t0=now;const e=(now-t0)%total;
    let x,y,sx,sy,ang=55,bend=0,jerk=0,fishOn=false,floatX=null;
    if(e<D[0]){setP(0);const t=e/D[0];
      const sw=Math.min(1,t/.25);ang=t<.25?55+sw*70:125-Math.min(1,(t-.25)/.15)*95;
      [x,y]=bez(t);const ft=Math.max(0,(t-.3)/.7);sx=X0+(X1-X0)*ft;sy=ft>0?SURF-Math.sin(Math.PI*ft)*28:null;
      if(t>.97&&now-last>500){ring(rings,tx,ty,"var(--fg)");ring(sRings,X1,SURF,"var(--fg)");last=now}}
    else if(e<D[0]+D[1]){setP(1);const u=(e-D[0])/D[1];x=tx;y=ty;sx=X1;sy=SURF+(depthEnd-SURF)*Math.min(1,u*1.3);ang=40;
      if(tech==="pelampung"){x=tx+u*14;y=ty+Math.sin(u*9)*1.5;sx=X1-u*0;floatX=sx;sy=SURF+(70-SURF)*Math.min(1,u*2)}
      if(tech==="popper")sy=SURF;
      if(tech==="dasar"&&u>.75&&now-last>600){ring(sRings,X1,BOT,"var(--accent)");last=now}}
    else if(e<D[0]+D[1]+D[2]){setP(2);const u=(e-D[0]-D[1])/D[2];ang=40;
      const back2=v=>X1-(X1-170)*v;
      if(tech==="pelampung"){x=tx+14+u*22;y=ty+Math.sin(u*20)*1.5;sx=X1+u*10;floatX=sx;sy=70+Math.sin(u*14)*2}
      else{[x,y]=back(u);sx=back2(u);sy=depthEnd;
        if(tech==="dasar"){const k=u*5,f=k-Math.floor(k),h=f<.35?Math.sin(f/.35*Math.PI/2):Math.cos((f-.35)/.65*Math.PI/2);sy=BOT-4-h*22;y-=h*6;jerk=f<.35?f/.35:Math.max(0,1-(f-.35)/.2)}
        if(tech==="cumi"){const k=u*4,f=k-Math.floor(k);const h=f<.2?f/.2:Math.max(0,1-(f-.2)/.8);sy=BOT-14-h*30;jerk=f<.2?1:0;[x,y]=back((Math.floor(k)+Math.min(1,f/.2))/4);sx=back2((Math.floor(k)+Math.min(1,f/.2))/4)}
        if(tech==="popper"){const k=u*6,f=k-Math.floor(k);const p=f<.25?f/.25:1;[x,y]=back((Math.floor(k)+p)/6);sx=back2((Math.floor(k)+p)/6);sy=SURF;jerk=f<.25?1-f/.25:0;if(f<.06&&now-last>250){ring(rings,x,y,"#fff");ring(sRings,sx,SURF,"#fff");last=now}}
        if(tech==="cepat"){sy=50+Math.sin(u*30)*2;if(now-last>260){ring(rings,x,y,"var(--accent)");last=now}}
        if(tech==="pelan"){sy=80+Math.sin(u*6)*4}}
      ang=40+jerk*28}
    else{setP(3);const u=(e-D[0]-D[1]-D[2])/D[3];fishOn=true;
      const[ex,ey]=tech==="pelampung"?[tx+36,ty]:back(1);x=ex+Math.sin(u*40)*3;y=ey+Math.cos(u*33)*2;
      sx=(tech==="pelampung"?X1+10:170)+Math.sin(u*30)*4;sy=(tech==="popper"?SURF+4:tech==="pelampung"?74:depthEnd)+Math.cos(u*25)*3;
      if(tech==="pelampung"){floatX=X1+10}
      ang=70;bend=14+Math.sin(u*30)*3;
      if(now-last>220){ring(rings,x,y,"var(--sand)");last=now}}
    // peta (atas)
    lure.setAttribute("cx",x);lure.setAttribute("cy",y);
    line.setAttribute("d",`M${mx} ${my} Q${(mx+x)/2} ${Math.min(my,y)-(e<D[0]?20:6)} ${x} ${y}`);
    fsh.setAttribute("opacity",fishOn?1:0);if(fishOn)fsh.setAttribute("transform",`translate(${x+10},${y+4})`);
    // tampak samping
    const[tipX,tipY]=rod(ang,bend);
    if(sy==null){sLure.setAttribute("cx",-20);sLine.setAttribute("d","")}
    else{sLure.setAttribute("cx",sx);sLure.setAttribute("cy",sy);
      const anchorX=floatX!=null?floatX:sx,anchorY=floatX!=null?SURF:sy;
      sLine.setAttribute("d",floatX!=null?`M${tipX} ${tipY} Q${(tipX+anchorX)/2} ${SURF-6} ${anchorX} ${SURF} L${sx} ${sy}`:`M${tipX} ${tipY} Q${(tipX+sx)/2} ${Math.max(tipY,Math.min(sy,SURF))+(phase===0?-6:fishOn?2:8)} ${sx} ${sy}`)}
    sFloat.setAttribute("transform",floatX!=null?`translate(${floatX},${SURF+(fishOn?6:0)})`:"translate(-40,0)");
    sFish.setAttribute("opacity",fishOn?1:0);if(fishOn)sFish.setAttribute("transform",`translate(${sx+12},${sy+2})`);
    sDepth.textContent=sy==null?"":sy<=SURF+1?"di permukaan":`± ${Math.max(0,Math.round((sy-SURF)/(BOT-SURF)*(boat?30:6)))} m`;
    sDepth.setAttribute("x",Math.min(250,(sx||0)+8));sDepth.setAttribute("y",(sy||0)-8);
    [rings,sRings].forEach(h=>[...h.children].forEach(c=>{const a=(now-c.dataset.b)/900;if(a>1)c.remove();else{c.setAttribute("r",2+a*12);c.setAttribute("opacity",1-a)}}));
    caRAF=requestAnimationFrame(frame)}
  caRAF=requestAnimationFrame(frame);
}
function sideSVG(){const boat=mode==="perahu";return `<div class="side"><span class="tag">Tampak samping (bawah air)</span><svg viewBox="0 -14 300 132" role="img" aria-label="Tampak samping lemparan">
  <rect y="-14" width="300" height="132" fill="var(--sea)"/><rect y="-14" width="300" height="48" fill="var(--surface)" opacity=".55"/>
  <path d="M0 34 q10 -3 20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0" stroke="var(--accent)" stroke-width="1.5" fill="none"/>
  <path d="M${boat?0:0} 118 L0 104 Q90 ${boat?112:96} 160 108 Q220 112 250 100 Q275 92 300 108 V118Z" fill="var(--land)"/>
  ${boat?`<path d="M6 30 h40 l-6 10 h-28z" fill="var(--muted)"/>`:`<path d="M0 26 h40 L52 118 H0Z" fill="var(--land)"/>`}
  <g fill="var(--fg)"><circle cx="20" cy="${boat?8:2}" r="4"/><path d="M20 ${boat?12:6} v12 M20 ${boat?24:18} l-4 ${boat?6:8} M20 ${boat?24:18} l4 ${boat?6:8} M20 ${boat?15:9} l6 4" stroke="var(--fg)" stroke-width="2.5" stroke-linecap="round"/></g>
  <path id="sRod" stroke="var(--fg)" stroke-width="2.5" fill="none" stroke-linecap="round"/>
  <path id="sLine" stroke="var(--fg)" stroke-width="1" fill="none" opacity=".75"/>
  <g id="sFloat"><ellipse rx="3" ry="6" fill="var(--bad)"/></g>
  <g id="sRings"></g>
  <g id="sFish" opacity="0"><path d="M0 0 q-12 -8 -24 0 q12 8 24 0z M0 0 l8 -6 v12z" fill="var(--fg)" opacity=".8"/></g>
  <circle id="sLure" r="4" fill="var(--sand)" stroke="var(--fg)" stroke-width="1.2" cx="-20" cy="0"/>
  <text id="sDepth" font-size="9" fill="var(--fg)" font-family="var(--mono)"></text>
 </svg></div>`}
let castPick=null;
function castSpot(f){const ok=LOC.filter(l=>l.region===region&&spotData(l).fish.includes(f)).map(l=>l.id);if(castPick&&ok.includes(castPick))return castPick;return ok.includes(curId)?curId:ok[0]}
function spotView(){
  const c0=cur(),c=Object.assign({},c0,spotData(c0)),BAITS=Object.keys(BAITINFO),sel=store.get("mm_bait",BAITS[0]);
  const hits=LOC.filter(l=>l.region===region&&spotData(l).bait[sel]).map(l=>({n:l.n,bait:spotData(l).bait}));const fromBait=[...new Set(hits.flatMap(l=>l.bait[sel]))];
  const f=fishSel&&SP[fishSel]?fishSel:null;
  $("#main").innerHTML=`
   <h2>${esc(c.n)}</h2>
   <div class="seg" role="group" aria-label="Cara mancing"><button data-mode="darat" aria-pressed="${mode==="darat"}">🧍 Dari darat</button><button data-mode="perahu" aria-pressed="${mode==="perahu"}">🚤 Pakai perahu</button></div>
   ${mode==="perahu"?`<p class="note" style="margin-top:-4px">Wajib pelampung di perahu. ${c.est?"Mode perahu di perairan dalam/sungai.":"Ikan & umpan di bawah untuk perairan lepas di sekitar spot ini."}</p>`:""}
   ${f?`<div class="card"><div class="illo">${fishSVG(f)}</div><h3 style="margin-top:8px">${f} <span class="note"><i>${SP[f].lat}</i></span></h3><p>${SP[f].ciri}</p><p class="note">Aturan: ${SP[f].lim}</p>
     <p><b>Umpan yang cocok:</b> ${[...new Set(LOC.flatMap(l=>Object.entries(l.bait).filter(([,fs])=>fs.includes(f)).map(([b])=>b)))].join(", ")}</p>
     <h3 style="margin-top:12px">🏆 Spot terbaik untuk ${f}</h3>${rankListHtml(f,5)}
     <p><b>Biasanya berada di:</b> ${(HABITAT[f]||[]).map(k=>FEAT[k]).join(", ")}</p>
     <h3 style="margin-top:12px">${mode==="perahu"?"Posisi perahu & lemparan":"Peta lempar"}</h3>
     <select class="f" id="castSpot" aria-label="Lokasi peta lempar">${LOC.filter(l=>l.region===region&&spotData(l).fish.includes(f)).map(l=>`<option value="${l.id}" ${l.id===castSpot(f)?"selected":""}>${l.n}</option>`).join("")}</select>
     <div style="margin-top:8px">${castMap(castSpot(f),f)}</div>${sideSVG()}
     <p class="note">Skema tidak berskala; sesuaikan dengan kondisi air di lokasi.</p>
     <div class="caCap"><span class="tag" id="caStep">Animasi</span><p id="caTxt" style="margin:2px 0 8px">Tekan putar untuk melihat cara memancing ${f}.</p><button class="btn" id="caPlay" type="button" style="width:100%">▶ Putar animasi</button></div>
     ${videoBlock(f,"how to catch "+f)}
     <button class="btn ghost" id="closeFish" style="margin-top:10px">Tutup</button></div>`:""}
   ${!c.fish?.length?`<div class="card"><p>Spot ini belum punya data ikan. Pakai "Kamu di mana?" di tab Peta untuk mencarinya.</p></div>`:`
   ${(()=>{const n=inSeasonNow(c.fish);return n.length?`<div class="card inseason"><b>🔥 Sedang musim:</b> ${n.map(fishMini).join("")}</div>`:""})()}
   <h3>Ikan di lokasi ini</h3>
   <div class="fishgrid">${c.fish.map(n=>`<button class="fcard" data-f="${n}">${fishSVG(n)}<b>${n}</b><span class="note">${SP[n]?.lim||""}</span></button>`).join("")}</div>
   <div class="card" style="margin-top:12px"><h3>Posisi ikan</h3><p>${c.spots}</p><h3>Waktu & pasang terbaik</h3><p>${c.tide}</p></div>
   <div class="card"><h3>Umpan → ikan yang didapat</h3><table><thead><tr><th>Umpan</th><th>Ikan</th></tr></thead><tbody>${Object.entries(c.bait).map(([b,fs])=>`<tr><td><b>${b}</b><br><span class="note">${BAITINFO[b]||""}</span></td><td>${fs.map(fishMini).join("")}</td></tr>`).join("")}</tbody></table></div>`}
   ${rankCardHtml()}
   <div class="card"><h3>Punya umpan apa?</h3>
     <select class="f" id="baitSel" aria-label="Pilih umpan">${BAITS.map(b=>`<option ${b===sel?"selected":""}>${b}</option>`).join("")}</select>
     <p class="note">${BAITINFO[sel]}</p><div>${fromBait.map(fishMini).join("")}</div>
     <table style="margin-top:8px"><thead><tr><th>Lokasi</th><th>Ikan</th></tr></thead><tbody>${hits.map(l=>`<tr><td>${l.n}</td><td>${l.bait[sel].join(", ")}</td></tr>`).join("")}</tbody></table></div>
   ${region==="AU"?`<p class="note">Fish pictures are for identification. Size & bag limits can change, check <a href="https://www.dpi.nsw.gov.au/fishing/recreational" target="_blank" rel="noopener">NSW DPI</a>.</p>`:""}`;
  document.querySelectorAll(".fcard").forEach(b=>b.onclick=()=>{fishSel=b.dataset.f;render();$("#main").scrollTop=0});
  const cf=$("#closeFish");if(cf)cf.onclick=()=>{fishSel=null;render()};
  const cs=$("#castSpot");if(cs)cs.onchange=e=>{castPick=e.target.value;render()};
  castAnimStop();const cp=$("#caPlay");if(cp){cp.onclick=castAnimStart;castAnimStart()}
  $("#baitSel").onchange=e=>{store.set("mm_bait",e.target.value);render()};
  bindRank();
  document.querySelectorAll("[data-mode]").forEach(b=>b.onclick=()=>{mode=b.dataset.mode;store.set("mm_mode",mode);fishSel=null;render()});
}

/* ================= KOMUNITAS (Supabase): akun, feed tangkapan, foto, lapor, blokir ================= */
const CFG=window.MM_CONFIG||{};
const sb=(window.supabase&&CFG.SUPABASE_URL&&CFG.SUPABASE_ANON_KEY)?window.supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_ANON_KEY):null;
let me=null,myName="",isAdmin=false,blocked=new Set(),feed=null,feedErr="",feedFilter="semua";
let pendingPhoto=null,pendingBlob=null,pickFish="",postMsg="";
try{pendingPhoto=sessionStorage.getItem("mm_photo");pickFish=sessionStorage.getItem("mm_fish")||"";if(pendingPhoto)fetch(pendingPhoto).then(r=>r.blob()).then(b=>pendingBlob=b)}catch(e){}
const savePending=()=>{try{pendingPhoto?sessionStorage.setItem("mm_photo",pendingPhoto):sessionStorage.removeItem("mm_photo");sessionStorage.setItem("mm_fish",pickFish||"")}catch(e){}};
let authStep="email",authEmail="",authMsg="";
function shrink(file,max){return new Promise((res,rej)=>{const img=new Image();img.onload=()=>{const k=Math.min(1,max/Math.max(img.width,img.height)),cv=document.createElement("canvas");cv.width=Math.round(img.width*k);cv.height=Math.round(img.height*k);cv.getContext("2d").drawImage(img,0,0,cv.width,cv.height);res(cv);URL.revokeObjectURL(img.src)};img.onerror=rej;img.src=URL.createObjectURL(file)})}
const photoUrl=p=>p&&sb?sb.storage.from("photos").getPublicUrl(p).data.publicUrl:"";
async function initCommunity(){
  if(!sb){feed=[];feedErr="Komunitas belum diaktifkan. Pemilik aplikasi perlu mengisi config.js (lihat PANDUAN).";return}
  const{data}=await sb.auth.getSession();await setUser(data.session?.user||null);
  sb.auth.onAuthStateChange((_e,s)=>{const nu=s?.user||null;if((nu?.id||null)===(me?.id||null))return;setUser(nu).then(()=>{if(["tangkapan","lainnya","peta"].includes(view))render()})});
  await loadFeed();loadApproved().then(()=>{fillPick();if(view!=="tangkapan")render()});
}
async function setUser(u){
  me=u;myName="";isAdmin=false;blocked=new Set();
  if(!u)return;
  const[p,a,b]=await Promise.all([sb.from("profiles").select("name").eq("id",u.id).maybeSingle(),sb.from("admins").select("user_id").eq("user_id",u.id).maybeSingle(),sb.from("blocks").select("blocked")]);
  myName=p.data?.name||"";isAdmin=!!a.data;(b.data||[]).forEach(x=>blocked.add(x.blocked));
}
async function loadFeed(){
  if(!sb)return;
  const{data,error}=await sb.from("catches").select("id,user_id,fish,length_cm,bait,released,spot_id,spot_name,area,lat,lon,photo_path,created_at,hidden,profiles(name)").order("created_at",{ascending:false}).limit(200);
  if(error){const fc=store.get("mm_feed_cache",null);if(fc&&!feed){feed=fc.feed;likes=fc.likes||{};comments=fc.comments||{};feedErr=""}else{feedErr="Feed tidak bisa dimuat. Periksa koneksi lalu tarik ulang.";feed=feed||[]}}else{feed=data;feedErr="";loadSocial()}
  if(["tangkapan","peta"].includes(view))render();
}
const ago=t=>{const m=Math.round((Date.now()-Date.parse(t))/6e4);return m<60?Math.max(1,m)+" mnt lalu":m<1440?Math.round(m/60)+" jam lalu":Math.round(m/1440)+" hari lalu"};
function authCard(compact){
  if(!sb)return `<div class="card"><p class="note">Komunitas belum diaktifkan di aplikasi ini.</p></div>`;
  if(me&&!myName)return `<form id="nameF" class="card"><h3>Satu langkah lagi</h3><p class="note">Nama ini terlihat oleh pemancing lain.</p><input id="nm" placeholder="Nama panggilan (2–30 huruf)" minlength="2" maxlength="30" required><button class="btn" type="submit">Simpan nama</button><p class="note" id="nmMsg"></p></form>`;
  if(me)return compact?"":`<div class="card"><span class="tag">Masuk sebagai</span><h3>${esc(myName)}</h3><p class="note">${esc(me.email||"")}</p></div>`;
  return `<form id="authF" class="card"><h3>Masuk untuk berbagi tangkapan</h3>
   ${authStep==="email"?`<p class="note">Kami kirim link masuk ke email kamu. Tanpa kata sandi.</p><input id="em" type="email" placeholder="email@contoh.com" required autocomplete="email"><button class="btn" type="submit">Kirim link masuk</button>`
    :`<p class="note">Link masuk sudah dikirim ke <b>${esc(authEmail)}</b> (cek juga folder Spam).</p>
     <ol class="note" style="margin:4px 0 8px">${window.Capacitor?`<li>Buka email itu, <b>tekan lama</b> tombol/link masuk, lalu pilih <b>Salin link</b>.</li><li>Tempel link-nya di bawah, lalu ketuk Masuk.</li>`:`<li>Buka email itu di HP/komputer ini dan klik link masuk, <b>atau</b></li><li>salin link-nya dan tempel di bawah.</li>`}</ol>
     <input id="otp" placeholder="Tempel link dari email (atau kode)" required autocomplete="off"><div class="two"><button class="btn" type="submit">Masuk</button><button class="btn ghost" type="button" id="authBack">Ganti email</button></div>`}
   <p class="note" style="color:var(--bad)">${esc(authMsg)}</p></form>`;
}
function bindAuth(){
  const f=$("#authF");if(f)f.onsubmit=async e=>{e.preventDefault();authMsg="";const btn=f.querySelector("button[type=submit]");btn.disabled=true;
    if(authStep==="email"){authEmail=$("#em").value.trim();const{error}=await sb.auth.signInWithOtp({email:authEmail,options:window.Capacitor?{}:{emailRedirectTo:location.origin+location.pathname}});
      if(error)authMsg=/rate/i.test(error.message)?"Terlalu sering. Tunggu beberapa menit lalu coba lagi.":"Gagal mengirim kode. Periksa alamat email.";else authStep="kode"}
    else{const v=$("#otp").value.trim();let res;
      if(/token(_hash)?=/.test(v)){let u;try{u=new URL(v)}catch(e){u=null}
        const q=u?new URLSearchParams(u.search+"&"+u.hash.replace(/^#/,"")):new URLSearchParams(v.split("?")[1]||"");
        const th=q.get("token_hash")||q.get("token");res=await sb.auth.verifyOtp({token_hash:th,type:"email"});
        if(res.error)res=await sb.auth.verifyOtp({token_hash:th,type:"magiclink"});}
      else res=await sb.auth.verifyOtp({email:authEmail,token:v,type:"email"});
      if(res.error)authMsg="Link/kode tidak valid atau sudah kedaluwarsa (berlaku 1 jam, sekali pakai). Minta link baru.";else authStep="email"}
    render()};
  const bk=$("#authBack");if(bk)bk.onclick=()=>{authStep="email";authMsg="";render()};
  const nf=$("#nameF");if(nf)nf.onsubmit=async e=>{e.preventDefault();const n=$("#nm").value.trim();const{error}=await sb.from("profiles").upsert({id:me.id,name:n});if(error){$("#nmMsg").textContent="Nama tidak bisa disimpan. Coba nama lain."}else{myName=n;render()}};
}
function catchView(){
  const c=cur(),regionFish=[...new Set(LOC.filter(l=>l.region===region).flatMap(l=>spotData(l).fish))].filter(f=>SP[f]),fishList=[...new Set(regionFish.concat(Object.keys(SP).sort()))];
  const rfeed=(feed||[]).filter(inRegion);
  const list=rfeed.filter(x=>!blocked.has(x.user_id)&&(feedFilter==="semua"||(feedFilter==="spot"&&x.spot_id===c.id)||(feedFilter==="saya"&&me&&x.user_id===me.id)));
  const week=rfeed.filter(x=>Date.now()-Date.parse(x.created_at)<7*864e5),top={},hot={};week.forEach(x=>{top[x.fish]=(top[x.fish]||0)+1;if(x.spot_name)hot[x.spot_name]=(hot[x.spot_name]||0)+1});
  const canPost=sb&&me&&myName;
  $("#main").innerHTML=`
   ${offlineBadge()}<h2>Tangkapan</h2>
   ${canPost?`<div class="card"><h3>Foto tangkapanmu</h3>
     <div class="two"><label class="btn" for="cam">📷 Buka kamera</label><label class="btn ghost" for="gal">Pilih dari galeri</label></div>
     <input type="file" id="cam" accept="image/*" capture="environment" hidden><input type="file" id="gal" accept="image/*" hidden>
     ${pendingPhoto?`<img class="preview" src="${pendingPhoto}" alt="Foto tangkapan">`:""}
     <h3 style="margin-top:10px">Ikan apa ini?</h3><p class="note">Bandingkan dengan gambar, lalu ketuk yang paling mirip.</p>
     <div class="pickgrid">${regionFish.map(f=>`<button type="button" class="pick" data-pick="${f}" aria-pressed="${pickFish===f}">${fishSVG(f)}<span>${f}</span></button>`).join("")}</div></div>
   <form id="cf" class="card"><h3>Bagikan ke komunitas</h3>
     <div class="two"><select class="f" id="cfish" aria-label="Ikan">${fishList.map(f=>`<option ${f===pickFish?"selected":""}>${f}</option>`).join("")}<option value="__new">➕ Ikan lain (tulis sendiri)</option></select><input id="clen" type="number" min="1" max="400" placeholder="Panjang (cm)" aria-label="Panjang"></div>
     <div class="two"><input id="cbait" placeholder="Umpan" aria-label="Umpan" maxlength="60"><label class="note" style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="crel" style="width:auto"> Dilepas</label></div>
     <input id="cnewfish" placeholder="Nama ikan (mis. Kakap Batu)" maxlength="40" style="display:none" aria-label="Nama ikan baru">
     <h3 style="margin-top:8px">Lokasi</h3>
     <div class="seg"><button type="button" data-lm="spot" aria-pressed="true">Spot: ${esc(c.n)}</button><button type="button" data-lm="gps" aria-pressed="false">📍 Lokasiku (GPS)</button><button type="button" data-lm="new" aria-pressed="false">➕ Spot baru</button></div>
     <div id="clocx" style="display:none"><input id="cplace" placeholder="Nama tempat (mis. Pantai Kaliantan sisi timur)" maxlength="60" aria-label="Nama tempat"><p class="note" id="cgps">Mengambil lokasi GPS…</p></div>
     <label class="note" style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="chide" style="width:auto"> Rahasiakan spot (hanya tampilkan daerah: ${esc(c.a||"")})</label>
     <p class="note" style="color:var(--good,#1a9e5a);font-weight:600">${esc(postMsg)}</p><p class="note" id="cwarn" style="color:var(--bad)"></p>
     <button class="btn" type="submit" id="postBtn">⬆️ Upload di ${esc(c.n)}${pendingPhoto?" + foto":""}</button></form>`:authCard()}
   <div class="card"><h3>7 hari terakhir</h3><div class="row"><div class="kv"><span class="tag">Tangkapan</span><strong>${week.length}</strong></div><div class="kv"><span class="tag">Ikan terbanyak</span><strong>${Object.entries(top).sort((a,b)=>b[1]-a[1])[0]?.[0]||"–"}</strong></div><div class="kv"><span class="tag">Spot terpanas</span><strong style="font-size:1rem">${Object.entries(hot).sort((a,b)=>b[1]-a[1])[0]?.[0]||"–"}</strong></div></div></div>
   ${logbookHtml()}
   ${leaderboardHtml(rfeed.filter(x=>!blocked.has(x.user_id)))}
   <div class="seg"><button data-ff="semua" aria-pressed="${feedFilter==="semua"}">Semua</button><button data-ff="spot" aria-pressed="${feedFilter==="spot"}">Di ${esc(c.n)}</button>${me?`<button data-ff="saya" aria-pressed="${feedFilter==="saya"}">Punyaku</button>`:""}<button id="refresh" aria-label="Muat ulang">↻</button></div>
   <div class="card" id="feedList">${feed===null?`<p class="note">Memuat tangkapan…</p>`:feedErr?`<p class="note">${feedErr}</p>`:list.length?list.map(feedItem).join(""):`<p class="note">Belum ada tangkapan${feedFilter==="spot"?" di spot ini":""}. Jadilah yang pertama!</p>`}</div>`;
  bindAuth();bindFeed();bindLogbook();
  document.querySelectorAll("[data-ff]").forEach(b=>b.onclick=()=>{feedFilter=b.dataset.ff;render()});
  const rf=$("#refresh");if(rf)rf.onclick=()=>{feed=null;render();loadFeed()};
  if(!canPost)return;
  document.querySelectorAll("[data-pick]").forEach(b=>b.onclick=()=>{pickFish=b.dataset.pick;savePending();render()});
  const chk=()=>{const f=$("#cfish").value,l=+$("#clen").value,m=region==="AU"?SP[f]?.min:0;$("#cwarn").textContent=m&&l&&l<m?`Di bawah ukuran minimum ${f} (${m} cm). Wajib dilepas.`:""};
  $("#cfish").onchange=chk;$("#clen").oninput=chk;
  const onPick=async e=>{const f=e.target.files[0];if(!f)return;try{const cv=await shrink(f,1000);pendingBlob=await new Promise(r=>cv.toBlob(r,"image/jpeg",.78));pendingPhoto=cv.toDataURL("image/jpeg",.6);postMsg="Foto siap. Isi data di bawah lalu tekan tombol Upload.";savePending();render();setTimeout(()=>$("#cf")?.scrollIntoView({behavior:"smooth"}),50)}catch(err){$("#cwarn").textContent="Foto tidak bisa dibaca. Coba foto lain."}};
  let locMode="spot",gpsPos=null;
  $("#cfish").addEventListener("change",()=>{$("#cnewfish").style.display=$("#cfish").value==="__new"?"":"none"});
  document.querySelectorAll("[data-lm]").forEach(b=>b.onclick=()=>{locMode=b.dataset.lm;document.querySelectorAll("[data-lm]").forEach(x=>x.setAttribute("aria-pressed",x===b));
    $("#clocx").style.display=locMode==="spot"?"none":"";$("#cplace").placeholder=locMode==="new"?"Nama spot baru (wajib)":"Nama tempat (opsional)";
    if(locMode!=="spot"&&!gpsPos){$("#cgps").textContent="Mengambil lokasi GPS…";navigator.geolocation?navigator.geolocation.getCurrentPosition(p=>{gpsPos=[p.coords.latitude,p.coords.longitude];$("#cgps").textContent=`📍 Lokasi didapat (±${Math.round(p.coords.accuracy)} m). Akan ditampilkan di peta komunitas.`},()=>{$("#cgps").textContent="Lokasi tidak bisa diambil. Izinkan akses lokasi di browser/HP lalu ketuk lagi."},{enableHighAccuracy:true,timeout:15000}):$("#cgps").textContent="HP ini tidak mendukung GPS."}});
  $("#cam").onchange=onPick;$("#gal").onchange=onPick;
  $("#cf").onsubmit=async e=>{e.preventDefault();const btn=$("#postBtn");btn.disabled=true;btn.textContent="Mengupload…";
    try{
      let path=null;
      if(pendingBlob){path=`${me.id}/${Date.now()}.jpg`;const up=await sb.storage.from("photos").upload(path,pendingBlob,{contentType:"image/jpeg",cacheControl:"31536000"});if(up.error)throw up.error}
      const hide=$("#chide").checked;let fish=$("#cfish").value;
      if(fish==="__new"){fish=$("#cnewfish").value.trim();if(fish.length<2)throw new Error("Tulis nama ikannya dulu")}
      let sid=c.id,sname=c.n,la=c.lat,lo=c.lon;
      if(locMode!=="spot"){if(!gpsPos)throw new Error("Lokasi GPS belum didapat, izinkan lokasi lalu coba lagi");const nm=$("#cplace").value.trim();if(locMode==="new"&&nm.length<3)throw new Error("Tulis nama spot barunya dulu");sid=null;sname=nm||"Lokasi pemancing";la=gpsPos[0];lo=gpsPos[1]}
      const row={fish,length_cm:+$("#clen").value||null,bait:$("#cbait").value.trim().slice(0,60)||null,released:$("#crel").checked,spot_id:hide?null:sid,spot_name:hide?null:sname,area:c.a||null,lat:hide?null:+la.toFixed(3),lon:hide?null:+lo.toFixed(3),photo_path:path};
      const{error}=await sb.from("catches").insert(row);if(error)throw error;
      if($("#cfish").value==="__new"&&!SP[fish])submitNew("fish",{name:fish});
      if(locMode==="new")submitNew("spot",{name:sname,lat:+la.toFixed(4),lon:+lo.toFixed(4),area:c.a||null,fish});
      pendingPhoto=pendingBlob=null;pickFish="";savePending();feedFilter="semua";postMsg="✅ Terkirim! Tangkapanmu sudah tampil di daftar di bawah.";await loadFeed();render();setTimeout(()=>$("#feedList")?.scrollIntoView({behavior:"smooth"}),50);
    }catch(err){btn.disabled=false;btn.textContent="Coba upload lagi";$("#cwarn").textContent="Upload gagal: "+(err?.message||err)+". Kirim tangkapan layar ini lewat menu Saran & laporan bila terus terjadi."}};
}
async function deleteAccount(){
  // hapus semua foto milik sendiri, lalu akun (data tangkapan ikut terhapus lewat ON DELETE CASCADE)
  const{data:files}=await sb.storage.from("photos").list(me.id,{limit:1000});
  if(files?.length)await sb.storage.from("photos").remove(files.map(f=>`${me.id}/${f.name}`));
  const{error}=await sb.rpc("delete_my_account");if(error)throw error;
  await sb.auth.signOut();
}

/* ================= TUTORIAL & TIPS ================= */
const svgRig=i=>`<svg viewBox="0 0 280 160" role="img"><g stroke="currentColor" fill="none" stroke-width="2">${i}</g></svg>`;
const T=(x,y,s)=>`<text x="${x}" y="${y}" font-size="11" fill="currentColor" stroke="none">${s}</text>`;
const yt=q=>`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`;
const RIGS=[
 {n:"Running sinker rig",u:"Paling serbaguna: bream, flathead, whiting.",v:"running sinker rig fishing tutorial",svg:svgRig(`<line x1="10" y1="80" x2="130" y2="80"/><circle cx="90" cy="80" r="8" fill="currentColor"/><rect x="128" y="74" width="12" height="12"/><line x1="140" y1="80" x2="240" y2="80" stroke-dasharray="4 3"/><path d="M240 80 q14 0 14 14 q0 10 -10 8"/>${T(60,62,"pemberat bebas")}${T(118,104,"swivel")}${T(160,70,"leader 40–60 cm")}`),s:["Masukkan pemberat bola ke senar utama.","Ikat senar utama ke swivel (improved clinch).","Ikat leader 40–60 cm ke sisi lain swivel.","Ikat kail di ujung leader.","Pemberat bergerak bebas, ikan tidak merasakan beban."]},
 {n:"Paternoster rig",u:"Mancing dasar dari batu/perahu: snapper, trevally.",v:"paternoster rig how to tie",svg:svgRig(`<line x1="140" y1="10" x2="140" y2="130"/><path d="M140 140 l-8 -10 h16z" fill="currentColor"/><line x1="140" y1="50" x2="200" y2="50" stroke-dasharray="4 3"/><line x1="140" y1="90" x2="200" y2="90" stroke-dasharray="4 3"/><path d="M200 50 q12 0 12 12 q0 8 -8 6"/><path d="M200 90 q12 0 12 12 q0 8 -8 6"/>${T(40,54,"dropper loop")}${T(60,148,"pemberat di ujung")}`),s:["Buat 2 dropper loop di leader, jarak ±30 cm.","Pasang kail ke tiap loop.","Ikat pemberat bintang di ujung bawah.","Ikat atas leader ke swivel lalu senar utama.","Turunkan sampai dasar, gulung sedikit agar tegang."]},
 {n:"Float rig",u:"Luderick, yellowtail, garfish di dermaga dan batu.",v:"luderick float rig setup",svg:svgRig(`<line x1="20" y1="50" x2="260" y2="50" stroke-dasharray="2 4"/><ellipse cx="140" cy="45" rx="8" ry="18"/><line x1="140" y1="63" x2="140" y2="140"/><circle cx="140" cy="100" r="3" fill="currentColor"/><path d="M140 140 q10 0 10 10 q0 6 -6 5"/>${T(160,40,"pelampung")}${T(150,104,"split shot")}`),s:["Pasang stopper di senar untuk mengatur kedalaman.","Masukkan pelampung.","Jepit 1–3 split shot agar pelampung tegak.","Ikat kail kecil no. 8–10.","Atur kedalaman 1–2 m untuk luderick."]},
 {n:"Jighead + soft plastic",u:"Flathead, bream, kingfish kecil.",v:"how to rig soft plastic jighead flathead",svg:svgRig(`<line x1="10" y1="80" x2="110" y2="80"/><circle cx="120" cy="80" r="10" fill="currentColor"/><path d="M130 80 q40 -14 80 0 q20 4 40 -6 q-10 14 -40 14 q-40 0 -80 -8"/>${T(80,62,"jighead 1/8–1/4 oz")}${T(160,118,"soft plastic")}`),s:["1/8 oz di air tenang, 1/4–3/8 oz di arus kuat.","Tusuk ujung kepala plastik tepat di tengah.","Dorong sampai kail keluar di punggung, harus lurus.","Ikat ke leader fluorocarbon 8–12 lb dengan loop knot.","Lempar, biarkan ke dasar, angkat joran, ulangi."]},
 {n:"Gang hook (pilchard)",u:"Tailor & salmon dengan pilchard utuh.",v:"how to rig pilchard gang hooks tailor",svg:svgRig(`<line x1="10" y1="80" x2="60" y2="80"/><path d="M60 80 Q140 60 230 78 Q140 98 60 80Z" fill="currentColor" opacity=".2"/><g><path d="M90 74 q10 -14 0 -18"/><path d="M140 72 q10 -14 0 -18"/><path d="M190 74 q10 -14 0 -18"/></g>${T(80,120,"3–4 kail bersambung (gang)")}`),s:["Pakai gang hook 3–4 kail (ukuran 3/0–4/0).","Tusuk kail pertama di mata pilchard.","Kail berikutnya ditusuk di sepanjang badan.","Pastikan pilchard lurus agar tidak berputar.","Lempar dan gulung pelan di permukaan air berbuih."]}
];
const TIPS=[
 {h:"Berley (umpan tabur)",t:"Campur roti basah, pelet ayam, dan pilchard cincang. Tabur sedikit tapi terus-menerus agar ikan bertahan di depanmu.",v:"berley tips fishing australia",svg:svgRig(`<line x1="10" y1="50" x2="270" y2="50" stroke-dasharray="2 4"/><path d="M40 20 q10 -10 20 0 v20 h-20z" fill="currentColor" opacity=".3"/>${[60,80,100,120,140,160].map((x,i)=>`<circle cx="${x+i*4}" cy="${70+i*12}" r="3" fill="currentColor"/>`).join("")}<path d="M210 120 q20 -10 40 0 q-20 10 -40 0z" fill="currentColor"/><path d="M200 100 q20 -10 40 0 q-20 10 -40 0z" fill="currentColor" opacity=".6"/>${T(20,150,"tabur sedikit-sedikit → ikan naik ke kolom air")}`)},
 {h:"Mancing squid",t:"Jig 2.5–3.0 di sekitar rumput laut saat subuh/senja. Lempar, biarkan tenggelam, sentak 2–3 kali lalu diam. Squid menyambar saat jig diam.",v:"squid jigging Sydney tips",svg:svgRig(`<path d="M10 30 Q80 20 140 60 Q190 90 260 70"/>${[[60,26],[120,50],[170,80]].map(([x,y])=>`<path d="M${x} ${y} l12 -14 M${x} ${y} l12 14" stroke-width="1.5"/>`).join("")}<path d="M240 66 l20 -6 -6 14z" fill="currentColor"/>${T(20,140,"sentak – sentak – DIAM (squid menyambar di sini)")}`)},
 {h:"Flathead dengan soft plastic",t:"Lompatkan umpan pelan di dasar pasir saat pasang turun. Flathead menunggu di tepi drop-off.",v:"flathead soft plastic technique",svg:svgRig(`<path d="M10 130 h260" stroke-width="3"/><path d="M20 128 l30 -30 l20 30 l30 -30 l20 30 l30 -30 l20 30" stroke-dasharray="5 3"/><path d="M200 126 Q230 116 260 126" fill="currentColor" opacity=".4"/>${T(20,40,"angkat – jatuh ke dasar – ulangi")}${T(190,112,"flathead")}`)},
 {h:"Bream itu pemalu",t:"Leader fluorocarbon 4–6 lb, kail no. 4–1, pemberat seringan mungkin. Lempar ke tiang dermaga dan bayangan perahu.",v:"bream fishing tips Sydney",svg:svgRig(`${[60,120,180].map(x=>`<rect x="${x}" y="20" width="12" height="130" fill="currentColor" opacity=".25"/>`).join("")}<path d="M10 40 Q90 30 100 100" stroke-dasharray="4 3"/><circle cx="100" cy="100" r="4" fill="currentColor"/>${T(130,80,"umpan jatuh alami")}${T(130,96,"di dekat tiang")}`)},
 {h:"Keselamatan mancing batu",t:"Pakai pelampung (wajib di beberapa area NSW), sepatu anti-licin, amati ombak 15 menit dulu, dan jangan pernah membelakangi laut.",v:"rock fishing safety NSW",svg:svgRig(`<path d="M10 140 L80 90 L140 100 L200 70 L270 80 V150 H10Z" fill="currentColor" opacity=".25"/><path d="M200 60 q20 -40 50 -20 q-10 10 0 20" stroke-width="3"/><rect x="120" y="60" width="16" height="22" rx="4" fill="#e8742a" stroke="none"/><circle cx="128" cy="52" r="6"/>${T(20,30,"ombak set datang tiba-tiba")}`)},
 {h:"Merawat ikan",t:"Mau dibawa pulang: matikan cepat (iki jime), keluarkan darah, simpan di es. Mau dilepas: basahi tangan, lepas kail cepat, pegang horizontal di air sampai berenang sendiri.",v:"ikijime fish humane dispatch",svg:svgRig(`<rect x="30" y="60" width="130" height="80" rx="8"/><path d="M40 60 h110" stroke-width="4"/>${[50,80,110,140].map(x=>`<rect x="${x-8}" y="95" width="16" height="16" fill="currentColor" opacity=".3"/>`).join("")}${T(40,50,"es + air laut (slurry)")}<path d="M180 100 q30 -20 60 0 q-30 20 -60 0z" fill="currentColor" opacity=".5"/>${T(180,135,"lepas di air")}`)},
 {h:"Membaca air",t:"Cari pertemuan arus, air keruh dan jernih, bayangan, dan karang. Burung yang menyelam berarti ikan umpan sedang dikejar ikan predator.",v:"how to read the water fishing",svg:svgRig(`<path d="M10 80 Q70 60 140 80 T270 80"/><path d="M10 100 Q70 80 140 100 T270 100" opacity=".5"/><path d="M150 30 l15 20 l15 -20" stroke-width="3"/>${[150,165,180,170].map((x,i)=>`<circle cx="${x}" cy="${88+i*3}" r="2" fill="currentColor"/>`).join("")}${T(20,140,"burung menyelam = ikan umpan diburu")}`)},
 {h:"Zona marine park",t:"Beberapa area dilarang mancing, misalnya Cabbage Tree Bay di Manly dan sebagian Botany Bay. Cek peta zona NSW sebelum berangkat.",v:"NSW marine park fishing zones",svg:svgRig(`<rect x="30" y="30" width="220" height="100" rx="6" stroke-dasharray="6 4"/><circle cx="140" cy="80" r="30"/><line x1="118" y1="58" x2="162" y2="102" stroke-width="4"/>${T(50,150,"zona larangan: tidak boleh mancing")}`)}
];

/* ================= TUTORIAL ANIMASI ================= */
const LINE='stroke="var(--fg)" stroke-width="2.5" fill="none" stroke-linecap="round"',TAG='stroke="var(--accent)" stroke-width="3" fill="none" stroke-linecap="round"';
const dr=(d,attr,on)=>`<path d="${d}" ${attr} pathLength="1" class="${on?"draw":""}"/>`;
const coilPath=(()=>{let d="M200 92";for(let i=0;i<6;i++){const x=200-i*12;d+=` Q${x-3} 58 ${x-6} 80 Q${x-9} 102 ${x-12} 88`}return d})();
const HOOK=`<g stroke="var(--muted)" stroke-width="4" fill="none" stroke-linecap="round"><circle cx="222" cy="80" r="9"/><path d="M231 82 L262 82 Q292 84 290 112 Q286 138 262 132 Q250 128 254 114"/><path d="M254 114 l-7 -2" stroke-width="3"/></g>`;
const ANIMS=[
 {id:"clinch",n:"Improved clinch knot",u:"Simpul paling umum untuk mengikat kail atau swivel. Kuat dan mudah.",steps:[
  {h:"Masukkan senar ke mata kail",t:"Masukkan ujung senar (hijau) ke lubang mata kail, tarik keluar sekitar 15 cm.",L:on=>dr("M10 80 L213 80",LINE,0)+dr("M213 80 Q240 80 236 94 Q230 100 205 93",TAG,on)},
  {h:"Lilitkan 5–7 kali",t:"Putar ujung senar mengelilingi senar utama 5 sampai 7 kali, menjauhi kail.",L:on=>`<g class="coils">${dr(coilPath,TAG,on)}</g>`},
  {h:"Masuk ke loop kecil",t:"Bawa ujung senar kembali dan masukkan ke loop kecil tepat di depan mata kail.",L:on=>dr("M128 88 C136 122 196 120 212 88",TAG,on)+`<circle cx="212" cy="88" r="8" fill="none" stroke="var(--sand)" stroke-width="2" class="${on?"pulse":""}"/>`},
  {h:"Lalu ke loop besar",t:"Ujung yang sama dimasukkan lagi ke loop besar yang baru terbentuk. Inilah bedanya dengan clinch biasa.",L:on=>dr("M212 88 C206 46 168 46 162 70 L150 66",TAG,on)+`<ellipse cx="180" cy="104" rx="38" ry="14" fill="none" stroke="var(--sand)" stroke-width="2" stroke-dasharray="4 3" class="${on?"pulse":""}"/>`},
  {h:"Basahi lalu tarik",t:"Basahi simpul dengan air liur, tarik senar utama perlahan sampai lilitan rapat ke mata kail.",squeeze:1,L:on=>`<path d="M30 70 l-14 10 l14 10" stroke="var(--sand)" stroke-width="3" fill="none" class="${on?"pulse":""}"/>`},
  {h:"Potong sisa senar",t:"Potong sisa ujung, tinggalkan 2–3 mm. Simpul selesai.",squeeze:1,cut:1,L:on=>`<g class="${on?"pop":""}"><circle cx="140" cy="128" r="6" fill="none" stroke="var(--bad)" stroke-width="2.5"/><circle cx="140" cy="146" r="6" fill="none" stroke="var(--bad)" stroke-width="2.5"/><path d="M145 125 L168 104 M145 149 L168 98" stroke="var(--bad)" stroke-width="2.5"/></g><text x="176" y="140" font-size="11" fill="var(--fg)">sisa 2–3 mm</text>`}
 ]},
 {id:"runsink",n:"Rakitan running sinker",u:"Rakitan dasar serbaguna untuk bream, flathead, whiting, kakap.",steps:[
  {h:"Masukkan pemberat",t:"Masukkan pemberat bola ke senar utama. Pemberat harus bisa bergeser bebas.",L:on=>`<g class="${on?"slide":""}"><circle cx="110" cy="80" r="11" fill="var(--muted)"/></g><text x="92" y="60" font-size="11" fill="var(--fg)">pemberat bola</text>`},
  {h:"Ikat ke swivel",t:"Ikat ujung senar utama ke swivel dengan improved clinch knot. Swivel menahan pemberat.",L:on=>`<g class="${on?"pop":""}"><rect x="160" y="73" width="10" height="14" rx="2" fill="none" stroke="var(--fg)" stroke-width="2.5"/><circle cx="157" cy="80" r="4" fill="none" stroke="var(--fg)" stroke-width="2"/><circle cx="173" cy="80" r="4" fill="none" stroke="var(--fg)" stroke-width="2"/></g><text x="148" y="108" font-size="11" fill="var(--fg)">swivel</text>`},
  {h:"Ikat leader 40–60 cm",t:"Ikat leader (senar fluorocarbon lebih tipis) ke sisi lain swivel, panjang 40–60 cm.",L:on=>dr("M177 80 L292 80",TAG.replace('stroke-width="3"','stroke-width="2.5" stroke-dasharray="0"'),on)+`<text x="200" y="70" font-size="11" fill="var(--accent)">leader 40–60 cm</text>`},
  {h:"Ikat kail",t:"Ikat kail di ujung leader. Ukuran no. 4–1 untuk bream, 1/0–2/0 untuk flathead & kakap.",L:on=>dr("M292 80 Q306 82 304 104 Q300 122 284 116 Q276 112 280 102",'stroke="var(--muted)" stroke-width="3.5" fill="none" stroke-linecap="round"',on)},
  {h:"Pasang umpan",t:"Pasang udang dari ekor sampai mata kail tertutup, ujung kail sedikit keluar.",L:on=>`<g class="${on?"pop":""}"><path d="M282 98 q14 -10 24 2 q4 14 -8 20 q-14 4 -18 -8z" fill="#e58f6c" opacity=".9"/><path d="M304 98 l10 -10 M306 101 l12 -6" stroke="#e58f6c" stroke-width="1.5"/></g>`},
  {h:"Cara kerjanya",t:"Saat ikan menarik umpan, senar meluncur menembus pemberat. Ikan tidak merasa berat, jadi umpan tidak dilepas.",L:on=>`<g class="${on?"swim":""}"><path d="M330 102 q-20 -16 -40 0 q20 16 40 0z M330 102 l12 -8 v16z" fill="var(--accent)" opacity=".8"/></g><text x="40" y="140" font-size="11" fill="var(--fg)">pemberat diam ←  senar bergerak  → ikan menarik</text>`}
 ]}
];
let anim={k:0,i:0,play:false,timer:null};
function animSVG(){
  const A=ANIMS[anim.k],st=A.steps,i=anim.i,sq=st[i].squeeze;
  let body="";
  if(A.id==="clinch"){
    body+=HOOK;
    for(let j=0;j<=i;j++){let lay=st[j].L(j===i);if(j===1)lay=lay.replace('class="coils"',`class="coils${sq?" squeeze":""}"`);if(st[i].cut&&j===3)lay=lay.replace('L150 66','L156 68');body+=lay}
  }else{
    body+=`<path d="M10 80 L155 80" ${LINE}/><text x="10" y="70" font-size="11" fill="var(--muted)">senar utama</text>`;
    for(let j=0;j<=i;j++)body+=st[j].L(j===i);
  }
  return `<svg viewBox="0 0 340 160" role="img" aria-label="${A.n}, langkah ${i+1}">${body}</svg>`;
}
function animStop(){clearInterval(anim.timer);anim.timer=null;anim.play=false}
function animCard(){
  const A=ANIMS[anim.k],s=A.steps[anim.i];
  return `<div class="card"><div class="seg">${ANIMS.map((a,k)=>`<button data-ak="${k}" aria-pressed="${k===anim.k}">${a.n}</button>`).join("")}</div>
   <p class="note">${A.u}</p>
   <div class="stage" id="stage">${animSVG()}</div>
   <div class="dots">${A.steps.map((_,j)=>`<button data-aj="${j}" aria-label="Langkah ${j+1}" aria-pressed="${j===anim.i}"></button>`).join("")}</div>
   <span class="tag">Langkah ${anim.i+1} dari ${A.steps.length}</span><h3>${s.h}</h3><p>${s.t}</p>
   <div class="ctrl"><button class="btn ghost" id="aPrev" ${anim.i?"":"disabled"} aria-label="Sebelumnya">⏮</button><button class="btn" id="aPlay">${anim.play?"❚❚ Jeda":"▶ Putar"}</button><button class="btn ghost" id="aNext" ${anim.i<A.steps.length-1?"":"disabled"} aria-label="Berikutnya">⏭</button><button class="btn ghost" id="aRe" aria-label="Ulangi">↺</button></div></div>`;
}
function animGo(i){const n=ANIMS[anim.k].steps.length;anim.i=Math.max(0,Math.min(n-1,i));if(view==="belajar")render()}
function bindAnim(){
  document.querySelectorAll("[data-ak]").forEach(b=>b.onclick=()=>{animStop();anim.k=+b.dataset.ak;anim.i=0;render()});
  document.querySelectorAll("[data-aj]").forEach(b=>b.onclick=()=>{animStop();animGo(+b.dataset.aj)});
  const g=id=>document.getElementById(id);if(!g("aPlay"))return;
  g("aPrev").onclick=()=>{animStop();animGo(anim.i-1)};g("aNext").onclick=()=>{animStop();animGo(anim.i+1)};
  g("aRe").onclick=()=>{animStop();anim.i=0;anim.play=true;startTimer();render()};
  g("aPlay").onclick=()=>{if(anim.play){animStop();render()}else{if(anim.i>=ANIMS[anim.k].steps.length-1)anim.i=0;anim.play=true;startTimer();render()}};
}
function startTimer(){clearInterval(anim.timer);anim.timer=setInterval(()=>{if(view!=="belajar"){animStop();return}const n=ANIMS[anim.k].steps.length;if(anim.i>=n-1){animStop();render();return}animGo(anim.i+1)},3800)}

function learnView(){
  $("#main").innerHTML=`<h2>Tutorial</h2><div class="seg"><button data-l="animasi" aria-pressed="${learn==="animasi"}">▶ Animasi</button><button data-l="tutorial" aria-pressed="${learn==="tutorial"}">Rakitan & simpul</button><button data-l="tips" aria-pressed="${learn==="tips"}">Tips & trik</button><button data-l="video" aria-pressed="${learn==="video"}">🎬 Video</button></div>`+
   (learn==="animasi"?animCard():learn==="video"?videoListHtml():learn==="tips"?TIPS.map(x=>`<div class="card illo"><h3>${x.h}</h3>${x.svg}<p>${x.t}</p>${videoBlock(x.h,x.v)}</div>`).join(""):
    RIGS.map(r=>`<div class="card illo"><h3>${r.n}</h3><p class="note">${r.u}</p>${r.svg}<ol>${r.s.map(x=>`<li>${x}</li>`).join("")}</ol>${videoBlock(r.n,r.v)}</div>`).join("")+
    `<div class="card"><h3>Simpul wajib</h3><ul><li><b>Improved clinch</b>: kail/swivel ke senar. Lilit 5–7 kali, masuk ke loop kecil lalu loop besar, basahi, tarik.</li><li><b>Uni to uni</b>: menyambung senar braid ke leader.</li><li><b>Loop knot</b>: agar soft plastic bergerak lebih hidup.</li></ul>
     <a class="vid" href="https://www.animatedknots.com/fishing-knots" target="_blank" rel="noopener"><span class="play"></span><span>Animasi simpul (Animated Knots)</span></a></div>`);
  document.querySelectorAll("[data-l]").forEach(b=>b.onclick=()=>{animStop();learn=b.dataset.l;render()});bindAnim();
}


/* ================= SARAN & LAPORAN (Supabase: tabel feedback) ================= */
const FB_KINDS=[["saran","💡 Saran fitur"],["bug","🐞 Laporan bug / error"],["data","🐟 Data spot/ikan salah"],["spot","📍 Usulan spot baru"],["lain","💬 Lainnya"]];
const FB_STATUS={baru:["Terkirim","var(--muted)"],proses:["Diproses","var(--mid)"],selesai:["Selesai","var(--good)"]};
let fbMine=null,fbAll=null,fbBlob=null,fbPrev=null,fbMsg="",fbBusy=false,fbAdminView=false,fbFilter="semua";
async function fbLoad(admin){
  if(!sb||!me)return;
  let q=sb.from("feedback").select("*").order("created_at",{ascending:false}).limit(200);
  if(!admin)q=q.eq("user_id",me.id);
  const{data,error}=await q;
  if(admin){fbAll=error?[]:data;if(data?.length){const ids=[...new Set(data.map(x=>x.user_id))];const{data:ps}=await sb.from("profiles").select("id,name").in("id",ids);(ps||[]).forEach(p=>fbNames[p.id]=p.name)}}
  else fbMine=error?[]:data;
  if(view==="lainnya"&&more==="masukan")moreView();
}
const fbNames={};
function fbItem(x,admin){
  const st=FB_STATUS[x.status]||FB_STATUS.baru,k=(FB_KINDS.find(k=>k[0]===x.kind)||FB_KINDS[4])[1];
  return `<div class="card fbi"><div class="row" style="justify-content:space-between;align-items:center"><span class="tag">${k}</span><span class="badge" style="color:${st[1]}">${st[0]}</span></div>
   <p style="margin:6px 0;white-space:pre-wrap">${esc(x.message)}</p>${x.photo_path?`<img class="preview" src="${photoUrl(x.photo_path)}" alt="Lampiran" loading="lazy">`:""}
   <p class="note">${admin?esc(fbNames[x.user_id]||"Pengguna")+" · ":""}${x.spot_name?esc(x.spot_name)+" · ":""}${new Date(x.created_at).toLocaleString("id-ID",{dateStyle:"medium",timeStyle:"short"})}${admin&&x.app_info?" · "+esc(x.app_info):""}</p>
   ${x.reply?`<div class="idres"><b>Balasan:</b> ${esc(x.reply)}</div>`:""}
   ${admin?`<form class="fbAdm" data-id="${x.id}" style="margin-top:8px"><textarea rows="2" placeholder="Balas pengguna…" aria-label="Balasan" maxlength="600">${esc(x.reply||"")}</textarea><div class="two"><select class="f" aria-label="Status">${Object.entries(FB_STATUS).map(([v,[l]])=>`<option value="${v}" ${x.status===v?"selected":""}>${l}</option>`).join("")}</select><button class="btn" type="submit">Simpan</button></div><button type="button" class="x" data-fbdel="${x.id}" data-p="${esc(x.photo_path||"")}">Hapus masukan</button></form>`:""}</div>`;
}
function feedbackHtml(){
  const c=cur();
  if(!sb)return `<h2>Saran & laporan</h2><div class="card"><p class="note">Fitur ini aktif setelah pemilik aplikasi mengisi config.js.</p></div>`;
  if(!me||!myName)return `<h2>Saran & laporan</h2><p class="note">Masuk dulu supaya kamu bisa melihat balasan dari pengelola.</p>${authCard(false)}`;
  if(fbMine===null&&!fbAdminView)fbLoad(false);
  if(isAdmin&&fbAdminView&&fbAll===null)fbLoad(true);
  const list=(fbAll||[]).filter(x=>fbFilter==="semua"||x.status===fbFilter);
  return `<h2>Saran & laporan</h2>
   ${isAdmin?`<div class="seg"><button data-fv="0" aria-pressed="${!fbAdminView}">Kirim masukan</button><button data-fv="1" aria-pressed="${fbAdminView}">📥 Kotak masuk (admin)</button></div>`:""}
   ${isAdmin&&fbAdminView?(fbAll===null?`<div class="card"><p class="note">Memuat semua masukan…</p></div>`:
     `<div class="card"><div class="row">${Object.entries(FB_STATUS).map(([v,[l]])=>`<div class="kv"><span class="tag">${l}</span><strong>${fbAll.filter(x=>x.status===v).length}</strong></div>`).join("")}</div></div>
      <div class="seg"><button data-ff2="semua" aria-pressed="${fbFilter==="semua"}">Semua</button>${Object.entries(FB_STATUS).map(([v,[l]])=>`<button data-ff2="${v}" aria-pressed="${fbFilter===v}">${l}</button>`).join("")}<button id="fbRef" aria-label="Muat ulang">↻</button></div>
      ${list.length?list.map(x=>fbItem(x,true)).join(""):`<div class="card"><p class="note">Tidak ada masukan di sini.</p></div>`}`)
   :`<form id="fbF" class="card"><p class="note">Ceritakan saran atau masalahmu. Hanya pengelola aplikasi yang bisa membacanya.</p>
     <label class="tag" for="fbK">Jenis</label><select class="f" id="fbK">${FB_KINDS.map(([v,l])=>`<option value="${v}">${l}</option>`).join("")}</select>
     <label class="tag" for="fbT">Pesan</label><textarea id="fbT" rows="4" minlength="3" maxlength="1000" required placeholder="mis. Koordinat Pantai Mawi salah, seharusnya lebih ke barat."></textarea>
     <label class="note" style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="fbS" checked style="width:auto"> Sertakan spot: ${esc(c.n)}</label>
     <div class="two"><label class="btn ghost" for="fbP">📎 Lampirkan foto</label><input type="file" id="fbP" accept="image/*" hidden><span class="note">${fbPrev?"Foto terlampir":"Opsional, mis. screenshot error"}</span></div>
     ${fbPrev?`<img class="preview" src="${fbPrev}" alt="Lampiran"><button type="button" class="x" id="fbPx">Hapus foto</button>`:""}
     <button class="btn" type="submit" ${fbBusy?"disabled":""}>${fbBusy?"Mengirim…":"Kirim"}</button><p class="note" id="fbM">${esc(fbMsg)}</p></form>
     <h3>Masukan saya</h3>${fbMine===null?`<p class="note">Memuat…</p>`:fbMine.length?fbMine.map(x=>fbItem(x,false)).join(""):`<p class="note">Belum ada. Masukanmu dan balasan pengelola akan muncul di sini.</p>`}`}`;
}
function bindFeedback(){
  const c=cur();
  document.querySelectorAll("[data-fv]").forEach(b=>b.onclick=()=>{fbAdminView=b.dataset.fv==="1";if(fbAdminView)fbAll=null;else fbMine=null;moreView()});
  document.querySelectorAll("[data-ff2]").forEach(b=>b.onclick=()=>{fbFilter=b.dataset.ff2;moreView()});
  const rf=$("#fbRef");if(rf)rf.onclick=()=>{fbAll=null;moreView()};
  const fp=$("#fbP");if(fp)fp.onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const cv=await shrink(f,1000);fbBlob=await new Promise(r=>cv.toBlob(r,"image/jpeg",.78));fbPrev=cv.toDataURL("image/jpeg",.5);moreView()}catch(err){$("#fbM").textContent="Foto tidak bisa dibaca."}};
  const px=$("#fbPx");if(px)px.onclick=()=>{fbBlob=fbPrev=null;moreView()};
  const f=$("#fbF");if(f)f.onsubmit=async e=>{e.preventDefault();if(fbBusy)return;fbBusy=true;fbMsg="";const kind=$("#fbK").value,msg=$("#fbT").value.trim(),withSpot=$("#fbS").checked;moreView();
    try{let path=null;if(fbBlob){path=`${me.id}/fb-${Date.now()}.jpg`;const up=await sb.storage.from("photos").upload(path,fbBlob,{contentType:"image/jpeg"});if(up.error)throw up.error}
      const{error}=await sb.from("feedback").insert({kind,message:msg.slice(0,1000),spot_id:withSpot?c.id:null,spot_name:withSpot?c.n:null,photo_path:path,app_info:(navigator.userAgent||"").slice(0,200)});
      if(error)throw error;fbBlob=fbPrev=null;fbMsg="Terkirim. Terima kasih atas masukanmu!";fbMine=null}
    catch(err){fbMsg="Gagal mengirim. Periksa koneksi lalu coba lagi."}
    fbBusy=false;moreView()};
  document.querySelectorAll(".fbAdm").forEach(fm=>fm.onsubmit=async e=>{e.preventDefault();const b=fm.querySelector("button[type=submit]");b.disabled=true;b.textContent="Menyimpan…";
    const{error}=await sb.from("feedback").update({reply:fm.querySelector("textarea").value.trim()||null,status:fm.querySelector("select").value,updated_at:new Date().toISOString()}).eq("id",fm.dataset.id);
    if(error){b.disabled=false;b.textContent="Gagal, coba lagi"}else{fbAll=null;moreView()}});
  document.querySelectorAll("[data-fbdel]").forEach(b=>b.onclick=async()=>{if(b.dataset.c!=="1"){b.dataset.c="1";b.textContent="Yakin hapus?";return}if(b.dataset.p)await sb.storage.from("photos").remove([b.dataset.p]);await sb.from("feedback").delete().eq("id",b.dataset.fbdel);fbAll=null;moreView()});
}

/* ================= LAINNYA: akun, checklist, aturan ================= */
const GEAR0=["Izin mancing","Joran & reel, senar cadangan","Leader 6–20 lb, kail no. 4–4/0, pemberat","Umpan + berley","Penggaris ukur ikan","Tang & pemotong senar","Ember/cool box + es","Pelampung (wajib untuk mancing batu & perahu)","Topi, sunscreen, air minum","Senter kepala untuk subuh/malam","Kantong sampah (bawa pulang senar bekas)"];
Object.defineProperty(window,"GEAR",{get:()=>[region==="AU"?"Izin mancing negara bagian (mis. NSW Fishing Fee, VIC licence)":"Izin/retribusi pengelola kawasan (bila di taman nasional)"].concat(GEAR0.slice(1))});
let more="akun",delStep=0;
function moreView(){
  const ck=store.get("mm_gear",{});
  $("#main").innerHTML=`<div class="seg"><button data-m="akun" aria-pressed="${more==="akun"}">Akun</button><button data-m="masukan" aria-pressed="${more==="masukan"}">Saran & laporan</button><button data-m="cek" aria-pressed="${more==="cek"}">Checklist</button><button data-m="musim" aria-pressed="${more==="musim"}">📅 Musim ikan</button><button data-m="aturan" aria-pressed="${more==="aturan"}">Aturan & darurat</button><button data-m="info" aria-pressed="${more==="info"}">Tentang</button>${isAdmin?`<button data-m="admin" aria-pressed="${more==="admin"}">Admin</button>`:""}</div>`+
  (more==="masukan"?feedbackHtml():more==="akun"?`<h2>Akun</h2>${authCard(false)}
     ${me&&myName?`<div class="card"><button class="btn ghost" id="logout" style="width:100%">Keluar</button></div>
     <div class="card" style="border-color:var(--bad)"><h3>Hapus akun</h3><p class="note">Menghapus akun, profil, semua tangkapan, dan foto kamu secara permanen.</p>
       <button class="btn" id="delAcc" style="background:var(--bad)">${delStep?"Ya, hapus permanen":"Hapus akun saya"}</button><p class="note" id="delMsg"></p></div>`:""}
     <p class="note"><a href="privacy.html" target="_blank" rel="noopener">Kebijakan privasi</a> · <a href="hapus-akun.html" target="_blank" rel="noopener">Cara menghapus akun</a></p>`
  :more==="cek"?`<h2>Checklist sebelum berangkat</h2><div class="card check">${GEAR.map((g,i)=>`<label><input type="checkbox" data-g="${i}" ${ck[i]?"checked":""}> ${g}</label>`).join("")}</div><button class="btn ghost" id="resetG">Reset checklist</button>`
  :more==="aturan"?rulesHtml():more==="musim"?seasonHtml():more==="admin"?`<h2>Admin</h2><p class="note">Spot dan ikan baru dari pengguna. Yang kamu setujui otomatis muncul di peta, daftar spot, dan daftar ikan untuk semua orang.</p><h3>📊 Statistik</h3><div class="card" id="statBox"><p class="note">Memuat…</p></div><h3>Kiriman spot & ikan</h3><div class="card" id="adminBox"><p class="note">Memuat…</p></div>`:`<h2>Tentang Mancing Mania</h2><div class="card"><p>Aplikasi gratis untuk pemancing di Indonesia dan Australia.</p>
     <ul><li>Peta: © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors</li><li>Cuaca, ombak & muka laut: <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo</a> (CC BY 4.0)</li><li>Pencarian tempat: Nominatim / OpenStreetMap</li><li>Foto ikan: <a href="https://commons.wikimedia.org/" target="_blank" rel="noopener">Wikipedia / Wikimedia Commons</a> (lisensi CC, hak cipta pada masing-masing fotografer)</li></ul>
     ${window.Capacitor?"":`<a class="btn" href="mancing-mania.apk" download style="display:block;margin:8px 0">⬇️ Unduh APK Android</a>`}<p class="note">Data ikan, umpan & spot adalah panduan umum dan bisa tidak akurat. Selalu utamakan keselamatan dan aturan setempat.</p></div>`);
  document.querySelectorAll("[data-m]").forEach(b=>b.onclick=()=>{more=b.dataset.m;delStep=0;render()});
  document.querySelectorAll("[data-g]").forEach(x=>x.onchange=()=>{ck[x.dataset.g]=x.checked;store.set("mm_gear",ck)});
  const rg=$("#resetG");if(rg)rg.onclick=()=>{store.set("mm_gear",{});render()};
  bindAuth();if(more==="masukan")bindFeedback();if(more==="admin"){renderAdmin();adminStatsHtml().then(h=>{const b=$("#statBox");if(b){b.innerHTML=h;tr(b)}})}
  const lo=$("#logout");if(lo)lo.onclick=async()=>{await sb.auth.signOut();render()};
  const da=$("#delAcc");if(da)da.onclick=async()=>{if(!delStep){delStep=1;render();return}da.disabled=true;$("#delMsg").textContent="Menghapus…";try{await deleteAccount();delStep=0;await loadFeed();render()}catch(e){da.disabled=false;$("#delMsg").textContent="Gagal menghapus. Coba lagi atau hubungi pengelola."}};
}

const VID_AU={"Running sinker rig":"xGqRMIFW1PQ","Paternoster rig":"QQykBqBuwvQ","Float rig":"q7Cj0lDKdPQ","Jighead + soft plastic":"1JyA3qb_clo","Gang hook (pilchard)":"Ow6k4btIIK4",
 "Berley (umpan tabur)":"s-2rOokIqn8","Mancing squid":"qnK-EDN_yjQ","Flathead dengan soft plastic":"0XNN1Rbz6nk","Bream itu pemalu":"vMBsOyXZEVI","Keselamatan mancing batu":"nFx43ZHYAKw","Merawat ikan":"IdZU1BpT5GA","Membaca air":"yqjzCW3FuK0",
 "Bream":"FUhlzgeMmrc","Flathead":"uR3ZL5uct3A","Whiting":"Q7FH7W83bco","King George Whiting":"NA8oxKxo9vE","Mulloway":"zF3TZaF5-5A","Snapper":"dlTkCoO8MS4","Kingfish":"BUiL5I3S1NM","Squid":"qnK-EDN_yjQ","Barramundi":"4ZsW6stwBPQ","Coral Trout":"xweQ0YA2UkQ"};
const VID_ID={"GT":"ECTZgH39hbo","Kakap Merah":"gHquM2cCqHQ","Cumi":"cpwAaZ9C4xM","Kerapu":"zcQsBkz_XDk","Kakap Putih":"UanERbk1hq8","Tenggiri":"K2eEcvnGTqQ","Mancing squid":"cpwAaZ9C4xM","Keselamatan mancing batu":"tFuC7GDZirM"};
function vidId(key){const own=region==="AU"?VID_AU:VID_ID,other=region==="AU"?VID_ID:VID_AU;return (CFG.VIDEOS||{})[key]||own[key]||other[key]||null}
function videoBlock(key,q){const id=vidId(key);
  if(!id)return `<a class="vid" href="${yt(q||"how to catch "+key)}" target="_blank" rel="noopener"><span class="play"></span><span>Cari video ${esc(key)} di YouTube</span></a>`;
  return `<div class="yt ytlite" data-yt="${id}" role="button" tabindex="0" aria-label="Putar video ${esc(key)}"><img src="https://i.ytimg.com/vi/${id}/hqdefault.jpg" alt="" loading="lazy"><span class="ytplay">▶</span></div><p class="note" style="margin-top:4px"><a href="https://www.youtube.com/watch?v=${id}" target="_blank" rel="noopener">Buka di YouTube</a></p>`}
document.addEventListener("click",e=>{const v=e.target.closest&&e.target.closest(".ytlite");if(!v)return;v.classList.remove("ytlite");v.innerHTML=`<iframe src="https://www.youtube-nocookie.com/embed/${v.dataset.yt}?autoplay=1&playsinline=1&rel=0" title="Video" allow="autoplay; accelerometer; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>`});
function videoListHtml(){
  const T=Object.fromEntries(TIPS.map(t=>[t.h,1])),R=Object.fromEntries(RIGS.map(r=>[r.n,1]));
  const keys=[...new Set(Object.keys(region==="AU"?VID_AU:VID_ID).concat(Object.keys(VID_AU).filter(k=>R[k])))];
  const grp=[["Ikan",keys.filter(k=>SP[k]&&!R[k]&&!T[k])],["Rakitan & simpul",keys.filter(k=>R[k])],["Tips & trik",keys.filter(k=>T[k])]];
  return grp.filter(g=>g[1].length).map(([h,ks])=>`<h3>${h}</h3>`+ks.map(k=>`<div class="card"><b>${esc(k)}</b>${videoBlock(k)}</div>`).join("")).join("")+`<p class="note">Video milik masing-masing kanal YouTube. Ketuk untuk memutar di dalam aplikasi.</p>`;
}

/* ================= BAHASA: Australia = English, Indonesia = Bahasa Indonesia ================= */
let LANG="id";
const EN=window.MM_EN||{},EN_PH=(window.MM_EN_PHRASES||[]).map(([a,b])=>[new RegExp(a,"g"),b]);
const ORIG=new WeakMap();
function trStr(v){
  const k=v.trim();if(!k||!/[A-Za-z]/.test(k))return v;
  let out=EN[k];
  if(out==null){out=k;for(const[r,b]of EN_PH)out=out.replace(r,b);if(out===k)return v}
  return v.replace(k,out);
}
function tr(root){
  if(LANG!=="en"||!root)return;
  const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT);let n=root;
  while(n){
    if(n.nodeType===3){const p=n.parentNode;if(p&&!/^(SCRIPT|STYLE|TEXTAREA)$/.test(p.nodeName)){const v=n.nodeValue,t=trStr(v);if(t!==v){if(!ORIG.has(n))ORIG.set(n,v);n.nodeValue=t}}}
    else if(n.nodeType===1){if(n.nodeName==="SCRIPT"||n.nodeName==="STYLE"){n=w.nextSibling()||nextUp(w);continue}
      for(const a of["placeholder","aria-label","title","alt"]){const v=n.getAttribute&&n.getAttribute(a);if(v){const t=trStr(v);if(t!==v){if(!n.dataset["o_"+a.replace("-","")])n.dataset["o_"+a.replace("-","")]=v;n.setAttribute(a,t)}}}}
    n=w.nextNode();
  }
}
function nextUp(w){let p;while((p=w.parentNode())){const s=w.nextSibling();if(s)return s}return null}
function untr(){ // kembalikan teks statis (header, tab) ke Bahasa Indonesia
  const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT);let n;
  while((n=w.nextNode())){if(n.nodeType===3){if(ORIG.has(n)){n.nodeValue=ORIG.get(n);ORIG.delete(n)}}else for(const a of["placeholder","aria-label","title","alt"]){const k="o_"+a.replace("-","");if(n.dataset&&n.dataset[k]){n.setAttribute(a,n.dataset[k]);delete n.dataset[k]}}}
}
function setLang(){const l=region==="AU"?"en":"id";if(l!==LANG){LANG=l;document.documentElement.lang=l;if(l==="id")untr()}}
let trBusy=false;
new MutationObserver(ms=>{if(LANG!=="en"||trBusy)return;trBusy=true;try{ms.forEach(m=>{if(m.type==="characterData")tr(m.target.parentNode);else m.addedNodes.forEach(x=>tr(x.nodeType===3?x.parentNode:x))})}finally{trBusy=false}}).observe(document.documentElement,{childList:true,subtree:true,characterData:true});

/* ================= v2: KOMUNITAS LANJUTAN ================= */
// --- wilayah sebuah tangkapan (untuk menyaring feed per negara) ---
const catchRegion=x=>{if(x.lat!=null)return x.lat>-11.5?"ID":"AU";const s=x.spot_id&&everySpot().find(l=>l.id===x.spot_id);if(s)return s.region||regionOf(s.lat,s.lon);const a=everySpot().find(l=>l.a&&l.a===x.area);return a?a.region:null};
const inRegion=x=>{const r=catchRegion(x);return !r||r===region};

// --- suka & komentar ---
let likes={},myLikes=new Set(),comments={};
async function loadSocial(){
  if(!sb||!feed?.length)return;const ids=feed.map(x=>x.id);
  const[l,c]=await Promise.all([sb.from("likes").select("catch_id,user_id").in("catch_id",ids),sb.from("comments").select("id,catch_id,user_id,body,created_at,profiles(name)").in("catch_id",ids).order("created_at").limit(2000)]);
  likes={};myLikes=new Set();comments={};
  (l.data||[]).forEach(r=>{likes[r.catch_id]=(likes[r.catch_id]||0)+1;if(me&&r.user_id===me.id)myLikes.add(r.catch_id)});
  (c.data||[]).forEach(r=>(comments[r.catch_id]=comments[r.catch_id]||[]).push(r));
  try{store.set("mm_feed_cache",{feed,likes,comments,t:Date.now()})}catch(e){}
  if(["tangkapan","peta"].includes(view))render();
}
function feedItem(x){
  const mine=me&&x.user_id===me.id,img=photoUrl(x.photo_path),nm=mine?"Kamu":(x.profiles?.name||"Pemancing"),nc=(comments[x.id]||[]).length;
  return `<div class="log">${img?`<img src="${img}" alt="${esc(x.fish)}" loading="lazy" data-zoom="${img}" style="cursor:zoom-in">`:`<span class="thumb">${fishSVG(x.fish)}</span>`}<span class="grow"><b>${esc(x.fish)}</b> ${x.length_cm?x.length_cm+" cm":""} ${x.released?'<span class="badge">dilepas</span>':""} ${x.hidden?'<span class="badge">disembunyikan</span>':""}<br><span class="note"><button class="x linkish" data-prof="${x.user_id}">${esc(nm)}</button> · ${esc(x.spot_name||x.area||"")} · ${ago(x.created_at)}${x.bait?" · "+esc(x.bait):""}</span>
   <span class="acts"><button class="x" data-like="${x.id}" aria-pressed="${myLikes.has(x.id)}">${myLikes.has(x.id)?"❤️":"🤍"} ${likes[x.id]||0}</button><button class="x" data-com="${x.id}">💬 ${nc}</button><button class="x" data-share="${x.id}" aria-label="Bagikan">📤</button>${mine||isAdmin?`<button class="x" data-del="${x.id}" data-p="${esc(x.photo_path||"")}">Hapus</button>`:""}${!mine&&me?`<button class="x" data-rep="${x.id}">Laporkan</button><button class="x" data-blk="${x.user_id}">Blokir</button>`:""}${isAdmin&&!mine?`<button class="x" data-hide="${x.id}" data-h="${x.hidden?0:1}">${x.hidden?"Tampilkan":"Sembunyikan"}</button>`:""}</span></span></div>`;
}
function bindFeed(){
  document.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{if(b.dataset.c!=="1"){b.dataset.c="1";b.textContent="Yakin hapus?";return}b.disabled=true;if(b.dataset.p)await sb.storage.from("photos").remove([b.dataset.p]);const{error}=await sb.from("catches").delete().eq("id",b.dataset.del);if(error){b.textContent="Gagal";b.disabled=false}else loadFeed()});
  document.querySelectorAll("[data-rep]").forEach(b=>b.onclick=async()=>{b.disabled=true;const{error}=await sb.from("reports").insert({catch_id:b.dataset.rep,reason:"tidak pantas"});b.textContent=error&&!String(error.message).includes("duplicate")?"Gagal":"Dilaporkan"});
  document.querySelectorAll("[data-blk]").forEach(b=>b.onclick=async()=>{if(b.dataset.c!=="1"){b.dataset.c="1";b.textContent="Blokir orang ini?";return}await sb.from("blocks").insert({blocked:b.dataset.blk});blocked.add(b.dataset.blk);render()});
  document.querySelectorAll("[data-hide]").forEach(b=>b.onclick=async()=>{await sb.from("catches").update({hidden:b.dataset.h==="1"}).eq("id",b.dataset.hide);loadFeed()});
  document.querySelectorAll("[data-zoom]").forEach(i=>i.onclick=()=>openSheet(`<img src="${i.dataset.zoom}" alt="Foto tangkapan" style="width:100%;border-radius:10px">`,true));
  document.querySelectorAll("[data-like]").forEach(b=>b.onclick=async()=>{if(!me||!myName){openSheet(`<h3>Masuk dulu</h3><p class="note">Masuk lewat tab Tangkapan untuk memberi suka.</p>`);return}const id=b.dataset.like,on=myLikes.has(id);
    if(on){myLikes.delete(id);likes[id]--;await sb.from("likes").delete().eq("catch_id",id).eq("user_id",me.id)}else{myLikes.add(id);likes[id]=(likes[id]||0)+1;await sb.from("likes").insert({catch_id:id})}
    b.textContent=(myLikes.has(id)?"❤️ ":"🤍 ")+(likes[id]||0);b.setAttribute("aria-pressed",myLikes.has(id));tr(b)});
  document.querySelectorAll("[data-com]").forEach(b=>b.onclick=()=>openComments(b.dataset.com));
  document.querySelectorAll("[data-share]").forEach(b=>b.onclick=()=>{const x=(feed||[]).find(f=>f.id===b.dataset.share);if(x)shareCatch({fish:x.fish,len:x.length_cm,spot:x.spot_name||x.area,bait:x.bait,photo:x.photo_path?photoUrl(x.photo_path):null,t:Date.parse(x.created_at)})});
  document.querySelectorAll("[data-prof]").forEach(b=>b.onclick=()=>openProfile(b.dataset.prof));
}
function openComments(id){
  const x=(feed||[]).find(f=>f.id===id),cs=comments[id]||[];
  openSheet(`<h3>Komentar · ${esc(x?.fish||"")}</h3>
   <div id="comList">${cs.length?cs.map(c=>`<div class="com"><b>${esc(me&&c.user_id===me.id?"Kamu":(c.profiles?.name||"Pemancing"))}</b> <span class="note">${ago(c.created_at)}</span>${me&&(c.user_id===me.id||isAdmin)?` <button class="x" data-cdel="${c.id}">Hapus</button>`:""}<br>${esc(c.body)}</div>`).join(""):`<p class="note">Belum ada komentar. Tanyakan umpan atau tekniknya!</p>`}</div>
   ${me&&myName?`<form id="comF" class="two" style="margin-top:8px"><input id="comT" maxlength="300" placeholder="Tulis komentar…" required><button class="btn" type="submit">Kirim</button></form>`:`<p class="note">Masuk lewat tab Tangkapan untuk berkomentar.</p>`}`);
  const f=$("#comF");if(f)f.onsubmit=async e=>{e.preventDefault();const t=$("#comT").value.trim();if(!t)return;f.querySelector("button").disabled=true;
    const{data,error}=await sb.from("comments").insert({catch_id:id,body:t}).select("id,catch_id,user_id,body,created_at").single();
    if(error){f.querySelector("button").disabled=false;alertNote("Komentar gagal dikirim: "+error.message);return}
    (comments[id]=comments[id]||[]).push({...data,profiles:{name:myName}});openComments(id);if(view==="tangkapan")render()};
  document.querySelectorAll("[data-cdel]").forEach(b=>b.onclick=async()=>{await sb.from("comments").delete().eq("id",b.dataset.cdel);comments[id]=(comments[id]||[]).filter(c=>c.id!==b.dataset.cdel);openComments(id);render()});
}
const alertNote=t=>{const n=document.createElement("p");n.className="note";n.style.color="var(--bad)";n.textContent=t;$("#sheetBody")?.appendChild(n);tr(n)};

// --- lembar pop-up (foto besar, komentar, profil) ---
function openSheet(html,photo){
  let s=$("#sheet");if(!s){s=document.createElement("div");s.id="sheet";s.className="sheet";document.body.appendChild(s);s.onclick=e=>{if(e.target===s)closeSheet()}}
  s.innerHTML=`<div class="sheetbox${photo?" photo":""}" role="dialog" aria-modal="true"><button class="x sheetx" id="sheetX" aria-label="Tutup">✕</button><div id="sheetBody">${html}</div></div>`;
  s.hidden=false;$("#sheetX").onclick=closeSheet;tr(s);
}
function closeSheet(){const s=$("#sheet");if(s)s.hidden=true}
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeSheet()});

// --- profil pemancing ---
function openProfile(uid){
  const xs=(feed||[]).filter(x=>x.user_id===uid),nm=me&&uid===me.id?myName:(xs[0]?.profiles?.name||"Pemancing"),best={};
  xs.forEach(x=>{if(x.length_cm&&(!best[x.fish]||x.length_cm>best[x.fish].length_cm))best[x.fish]=x});
  const spots={};xs.forEach(x=>{if(x.spot_name)spots[x.spot_name]=(spots[x.spot_name]||0)+1});
  const lk=xs.reduce((a,x)=>a+(likes[x.id]||0),0);
  openSheet(`<h3>${esc(nm)}</h3>
   <div class="row"><div class="kv"><span class="tag">Tangkapan</span><strong>${xs.length}</strong></div><div class="kv"><span class="tag">Suka diterima</span><strong>${lk}</strong></div><div class="kv"><span class="tag">Spot favorit</span><strong style="font-size:.95rem">${esc(Object.entries(spots).sort((a,b)=>b[1]-a[1])[0]?.[0]||"–")}</strong></div></div>
   <h3 style="margin-top:10px">Rekor terbesar</h3>${Object.keys(best).length?`<table><tbody>${Object.values(best).sort((a,b)=>b.length_cm-a.length_cm).map(x=>`<tr><td>${fishMini(x.fish)}</td><td><b>${x.length_cm} cm</b></td><td class="note">${esc(x.spot_name||x.area||"")}</td></tr>`).join("")}</tbody></table>`:`<p class="note">Belum ada tangkapan dengan ukuran.</p>`}
   <h3 style="margin-top:10px">Semua tangkapan</h3>${xs.map(feedItem).join("")||`<p class="note">Belum ada.</p>`}`);
  bindFeed();
}

// --- peringkat bulanan ---
function leaderboardHtml(list){
  const m0=new Date();m0.setDate(1);m0.setHours(0,0,0,0);
  const xs=list.filter(x=>x.length_cm&&Date.parse(x.created_at)>=m0.getTime()),best={};
  xs.forEach(x=>{if(!best[x.fish]||x.length_cm>best[x.fish].length_cm)best[x.fish]=x});
  const rows=Object.values(best).sort((a,b)=>b.length_cm-a.length_cm).slice(0,10);
  const bulan=m0.toLocaleDateString(region==="AU"?"en-AU":"id-ID",{month:"long",year:"numeric"});
  return `<div class="card"><h3>🏆 Peringkat bulan ini <span class="note">(${bulan})</span></h3><p class="note">Ikan terbesar per jenis, dari tangkapan yang mencantumkan panjang.</p>
   ${rows.length?`<table><tbody>${rows.map((x,i)=>`<tr><td>${["🥇","🥈","🥉"][i]||i+1}</td><td>${fishMini(x.fish)}</td><td><b>${x.length_cm} cm</b></td><td class="note"><button class="x linkish" data-prof="${x.user_id}">${esc(me&&x.user_id===me.id?"Kamu":(x.profiles?.name||"Pemancing"))}</button></td></tr>`).join("")}</tbody></table>`:`<p class="note">Belum ada tangkapan bulan ini. Isi panjang ikan saat upload supaya masuk peringkat!</p>`}</div>`;
}

// --- kiriman spot & ikan baru (disetujui admin) ---
let subs=[];
async function loadApproved(){
  if(!sb)return;const{data}=await sb.from("submissions").select("*").eq("status","setuju").limit(1000);
  (data||[]).forEach(applySub);try{store.set("mm_subs",data||[])}catch(e){}
}
function applySub(s){
  if(s.kind==="fish"&&!SP[s.name])SP[s.name]={b:"#9fb3b8",d:"#5d7279",fin:"#b9c7c9",h:.32,pat:"",lim:region==="AU"?"Cek aturan negara bagian":"–",ciri:"Ditambahkan oleh komunitas.",community:1};
  if(s.kind==="spot"&&s.lat!=null&&!LOC.some(l=>l.id==="sub_"+s.id)){
    const fish=s.fish?[s.fish]:[];if(s.fish&&!SP[s.fish])applySub({kind:"fish",name:s.fish});
    LOC.push({id:"sub_"+s.id,region:s.region||regionOf(s.lat,s.lon),st:s.region==="AU"?"NSW":undefined,n:s.name,a:s.area||"Kiriman komunitas",lat:s.lat,lon:s.lon,type:"Spot kiriman komunitas",fish,bait:{},community:1,tide:"Belum ada catatan; pakai prakiraan pasang surut."});
  }
}
store.get("mm_subs",[]).forEach(applySub);
async function adminSubsHtml(){
  const{data,error}=await sb.from("submissions").select("*").eq("status","baru").order("created_at",{ascending:false}).limit(100);
  subs=data||[];
  return error?`<p class="note">Gagal memuat: ${esc(error.message)}</p>`:subs.length?subs.map(s=>`<div class="log"><span class="grow"><span class="badge">${s.kind==="spot"?"Spot":"Ikan"}</span> <b>${esc(s.name)}</b><br><span class="note">${s.region==="AU"?"Australia":"Indonesia"}${s.area?" · "+esc(s.area):""}${s.lat!=null?` · <a href="https://www.google.com/maps?q=${s.lat},${s.lon}" target="_blank" rel="noopener">lihat peta</a>`:""}${s.fish?" · ikan: "+esc(s.fish):""} · ${ago(s.created_at)}</span>
    <span class="acts"><button class="x" data-ok="${s.id}">✅ Setujui</button><button class="x" data-no="${s.id}">Tolak</button></span></span></div>`).join(""):`<p class="note">Tidak ada kiriman baru. 👍</p>`;
}
async function renderAdmin(){
  const box=$("#adminBox");if(!box)return;box.innerHTML=await adminSubsHtml();tr(box);
  box.querySelectorAll("[data-ok],[data-no]").forEach(b=>b.onclick=async()=>{const id=b.dataset.ok||b.dataset.no,ok=!!b.dataset.ok;b.disabled=true;
    const{error}=await sb.from("submissions").update({status:ok?"setuju":"tolak"}).eq("id",id);
    if(error){b.textContent="Gagal";return}if(ok)applySub(subs.find(s=>s.id===id));fillPick();renderAdmin()});
}
async function submitNew(kind,o){try{await sb.from("submissions").insert({kind,region,...o})}catch(e){}}

// --- favorit & waktu terbaik ---
let favs=store.get("mm_favs",[]);
const isFav=id=>favs.includes(id);
function toggleFav(id){favs=isFav(id)?favs.filter(f=>f!==id):favs.concat(id);store.set("mm_favs",favs);render()}
function bestWindow(s,off=0){const sc=fishScore(off,s.lat,s.lon);let bi=0,bv=-1;for(let h=4;h<21;h++){const v=sc.hours[h]+sc.hours[h+1];if(v>bv){bv=v;bi=h}}return{from:bi,to:bi+2,total:sc.total}}
function favCardHtml(){
  const fs=favs.map(id=>everySpot().find(s=>s.id===id)).filter(s=>s&&(s.region||regionOf(s.lat,s.lon))===region);
  const perm=typeof Notification!=="undefined"?Notification.permission:"unsupported";
  return `<div class="card"><h3>⭐ Spot favorit · waktu terbaik hari ini</h3>
   ${fs.length?fs.map(s=>{const b=bestWindow(s);return `<button class="favrow" data-id="${s.id}"><span><b>${esc(s.n)}</b><br><span class="note">Terbaik ${fmt(b.from)}–${fmt(b.to)}</span></span><span class="score" style="background:${scoreCol(b.total)}">${b.total}</span></button>`}).join(""):`<p class="note">Belum ada favorit. Ketuk ☆ di kartu spot untuk menambahkan.</p>`}
   ${fs.length&&perm!=="unsupported"?(perm==="granted"?`<p class="note">🔔 Pengingat aktif: tiap pagi saat aplikasi dibuka, kamu dapat ringkasan waktu terbaik.</p>`:`<button class="btn ghost" id="notifOn" style="width:100%">🔔 Aktifkan pengingat waktu terbaik</button>`):""}</div>`;
}
function bindFav(){
  document.querySelectorAll(".favrow").forEach(b=>b.onclick=()=>setSpot(b.dataset.id));
  const fb=$("#favBtn");if(fb)fb.onclick=()=>toggleFav(fb.dataset.fav);
  const n=$("#notifOn");if(n)n.onclick=async()=>{try{await Notification.requestPermission()}catch(e){}store.set("mm_notif_day","");dailyReminder();render()};
}
function dailyReminder(){
  if(typeof Notification==="undefined"||Notification.permission!=="granted")return;
  const today=new Date().toDateString();if(store.get("mm_notif_day","")===today)return;
  const fs=favs.map(id=>everySpot().find(s=>s.id===id)).filter(Boolean).slice(0,4);if(!fs.length)return;
  const en=region==="AU",body=fs.map(s=>{const b=bestWindow(s);return `${s.n}: ${fmt(b.from)}–${fmt(b.to)} (${b.total})`}).join("\n");
  const title=en?"Best fishing times today":"Waktu mancing terbaik hari ini";
  const show=()=>navigator.serviceWorker?.ready?navigator.serviceWorker.ready.then(r=>r.showNotification(title,{body,icon:"icons/icon-192.png"})).catch(()=>new Notification(title,{body})):new Notification(title,{body});
  try{show();store.set("mm_notif_day",today)}catch(e){}
}

// --- mode offline ---
function offlineBadge(){return navigator.onLine?"":`<div class="card offline"><b>📴 Sedang offline.</b> <span class="note">Spot, tutorial, aturan dan prakiraan terakhir yang tersimpan tetap bisa dibuka.</span></div>`}
addEventListener("online",()=>{render();loadFeed()});addEventListener("offline",()=>render());
{const fc=store.get("mm_feed_cache",null);if(fc&&!navigator.onLine){feed=fc.feed;likes=fc.likes||{};comments=fc.comments||{}}}

// --- aturan per negara bagian Australia ---
const AU_RULES={
 NSW:{n:"New South Wales",u:"https://www.dpi.nsw.gov.au/fishing/recreational/fishing-rules-and-regs",lic:"NSW Recreational Fishing Fee wajib (usia 18+), mis. 3 hari, 1 bulan, 1 atau 3 tahun.",licU:"https://www.dpi.nsw.gov.au/fishing/recreational/fishing-fee"},
 QLD:{n:"Queensland",u:"https://www.daf.qld.gov.au/business-priorities/fisheries/recreational/rules-regulations",lic:"Tidak perlu izin umum; izin khusus untuk bendungan (SIPS)."},
 VIC:{n:"Victoria",u:"https://vfa.vic.gov.au/recreational-fishing/fishing-regulations",lic:"Recreational Fishing Licence wajib (usia 18–69).",licU:"https://vfa.vic.gov.au/recreational-fishing/recreational-fishing-licence"},
 TAS:{n:"Tasmania",u:"https://fishing.tas.gov.au/recreational-fishing",lic:"Izin hanya untuk jenis tertentu (lobster, abalone, scallop, jaring)."},
 SA:{n:"South Australia",u:"https://www.pir.sa.gov.au/recreational_fishing",lic:"Tidak perlu izin umum; ada batas tangkap harian & per perahu."},
 WA:{n:"Western Australia",u:"https://www.dpird.wa.gov.au/individuals/recreational-fishing/",lic:"Izin wajib untuk mancing dari perahu (RFBL) dan beberapa jenis.",licU:"https://www.fish.wa.gov.au/Fishing-and-Aquaculture/Recreational-Fishing/Recreational-Fishing-Licences"},
 NT:{n:"Northern Territory",u:"https://nt.gov.au/marine/recreational-fishing",lic:"Tidak perlu izin umum; batas tangkap ketat untuk Barramundi & Jewfish."}};
function rulesHtml(){
  if(region!=="AU")return `<h2>Aturan & darurat</h2>
     <div class="card"><h3>Darurat Indonesia</h3><p>Darurat umum: <b>112</b> · Basarnas (SAR): <b>115</b> · Polisi: <b>110</b></p></div>
     <div class="card"><h3>Mancing di Indonesia</h3><p>Tidak ada izin nasional atau batas ukuran untuk pemancing rekreasi. Yang perlu diperhatikan:</p><ul><li>Taman nasional & kawasan konservasi laut (Komodo, Karimunjawa, Kepulauan Seribu, Gili Matra, Bunaken) punya zona larangan dan retribusi. Tanyakan ke pengelola.</li><li>Jangan ambil penyu, hiu, pari manta, dan napoleon (dilindungi).</li><li>Lepaskan ikan kecil supaya stok tetap ada.</li></ul></div>`;
  const st=cur().st&&AU_RULES[cur().st==="Sydney"?"NSW":cur().st]?(cur().st==="Sydney"?"NSW":cur().st):"NSW",R=AU_RULES[st];
  return `<h2>Aturan & darurat</h2>
   <div class="card"><h3>Darurat Australia</h3><p>Polisi/ambulans/pemadam: <b>000</b> · Penyelamatan laut: VHF channel 16</p></div>
   <div class="card"><span class="tag">Negara bagian spot ini</span><h3>${R.n}</h3><p>${R.lic}${R.licU?` <a href="${R.licU}" target="_blank" rel="noopener">Beli/cek izin</a>`:""}</p>
    <p><a class="btn ghost" href="${R.u}" target="_blank" rel="noopener" style="display:block">Aturan resmi ${R.n} ↗</a></p>
    <div class="seg" style="flex-wrap:wrap">${Object.keys(AU_RULES).map(k=>`<a class="x" href="${AU_RULES[k].u}" target="_blank" rel="noopener">${k}</a>`).join(" ")}</div></div>
   <div class="card"><h3>Ukuran minimum & batas tangkap (acuan NSW)</h3><table><thead><tr><th>Ikan</th><th>Aturan</th></tr></thead><tbody>${Object.entries(SP).filter(([k,v])=>v.lim&&v.lim!=="–"&&!v.community).map(([k,v])=>`<tr><td>${fishMini(k)}</td><td>${v.lim}</td></tr>`).join("")}</tbody></table>
   <p class="note">Ringkasan acuan NSW. Aturan berbeda antar negara bagian dan bisa berubah, jadi selalu cek situs resmi di atas sebelum membawa pulang ikan. Ada juga zona larangan (marine park sanctuary zones).</p></div>`;
}


/* ===== Foto ikan asli (Wikipedia / Wikimedia Commons), gambar kartun jadi cadangan ===== */
const WIKI={"Bream":"Acanthopagrus_australis","Flathead":"Platycephalus_fuscus","Whiting":"Sillago_ciliata","Squid":"Sepioteuthis_australis","Kingfish":"Seriola_lalandi","Mulloway":"Argyrosomus_japonicus","Snapper":"Australasian_snapper","Tailor":"Bluefish","Luderick":"Girella_tricuspidata","Drummer":"Girella_elevata","Salmon Australia":"Arripis_trutta","Trevally":"Pseudocaranx_georgianus","Yellowtail":"Trachurus_novaezelandiae","Tarwhine":"Rhabdosargus_sarba","Estuary Perch":"Percalates_colonorum","Kakap Merah":"Lutjanus_malabaricus","Kakap Putih":"Barramundi","Kerapu":"Epinephelus_coioides","GT":"Giant_trevally","Barakuda":"Great_barracuda","Tenggiri":"Narrow-barred_Spanish_mackerel","Tongkol":"Mackerel_tuna","Baronang":"Siganus_canaliculatus","Bawal":"Silver_pomfret","Belanak":"Flathead_grey_mullet","Cumi":"Bigfin_reef_squid","Barramundi":"Barramundi","Mangrove Jack":"Mangrove_red_snapper","King George Whiting":"King_George_whiting","Spanish Mackerel":"Narrow-barred_Spanish_mackerel","Coral Trout":"Leopard_coral_grouper","Golden Trevally":"Golden_trevally"};
const fpCache=store.get("mm_fp2",{}),fpWait={};
function fetchFP(n){
  if(fpWait[n])return fpWait[n];
  return fpWait[n]=fetch("https://en.wikipedia.org/api/rest_v1/page/summary/"+encodeURIComponent(WIKI[n])).then(r=>r.ok?r.json():null).then(j=>{const u=j?.thumbnail?.source||"";fpCache[n]=u;store.set("mm_fp2",fpCache);return u}).catch(()=>"");
}
function hydrateFish(root){
  if(!root||!root.querySelectorAll)return;
  root.querySelectorAll(".fishpic[data-sp]:not([data-done])").forEach(el=>{
    el.dataset.done="1";const n=el.dataset.sp;if(!WIKI[n])return;
    const set=u=>{if(!u)return;const im=new Image();im.alt=n;im.onload=()=>{el.innerHTML="";el.appendChild(im);el.classList.add("photo")};im.src=u};
    if(fpCache[n]!==undefined&&fpCache[n]!=="")set(fpCache[n]);else if(navigator.onLine)fetchFP(n).then(set);
  });
}
new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(x=>x.nodeType===1&&hydrateFish(x)))).observe(document.documentElement,{childList:true,subtree:true});

/* ================= v3: STATISTIK ADMIN, MUSIM IKAN, LOGBOOK, BAGIKAN ================= */
// --- statistik admin ---
async function adminStatsHtml(){
  const{data,error}=await sb.rpc("admin_stats");
  if(error)return `<p class="note">Statistik gagal dimuat: ${esc(error.message)}</p>`;
  const d=data||{},k=(l,v,sub)=>`<div class="kv"><span class="tag">${l}</span><strong>${v??0}</strong>${sub?`<span class="note">${sub}</span>`:""}</div>`;
  return `<div class="row statgrid">${k("Pengguna terdaftar",d.users,`+${d.new7||0} minggu ini`)}${k("Login 7 hari",d.login7)}${k("Login 30 hari",d.login30)}${k("Tangkapan",d.catches,`+${d.catches7||0} minggu ini`)}${k("Dengan foto",d.photos)}${k("Suka",d.likes)}${k("Komentar",d.comments)}${k("Masukan baru",d.feedback_new)}${k("Kiriman baru",d.subs_new)}${k("Laporan konten",d.reports)}</div>
   <p class="note">Hanya menghitung orang yang login. Pengunjung tanpa login tidak tercatat.</p>`;
}

// --- kalender musim ikan (panduan umum) ---
// p = bulan puncak, s = bulan sepi/tutup (1–12); selain itu = biasa
const SEASON={
 AU:{"Bream":{p:[5,6,7,8]},"Flathead":{p:[10,11,12,1,2,3,4],s:[6,7]},"Whiting":{p:[11,12,1,2,3],s:[6,7,8]},"King George Whiting":{p:[11,12,1,2,3,4]},"Squid":{p:[5,6,7,8,9,10]},"Kingfish":{p:[11,12,1,2,3,4],s:[7,8]},
  "Mulloway":{p:[3,4,5,6,10,11]},"Snapper":{p:[5,6,7,8,9]},"Tailor":{p:[4,5,6,7,8,9]},"Luderick":{p:[4,5,6,7,8,9]},"Drummer":{p:[5,6,7,8,9]},"Salmon Australia":{p:[4,5,6,7,8,9]},"Trevally":{p:[3,4,5,6]},"Yellowtail":{p:[]},"Tarwhine":{p:[10,11,12,1,2,3]},
  "Estuary Perch":{p:[9,10,11,12,1,2,3],s:[6,7,8]},"Barramundi":{p:[9,10,2,3,4],s:[11,12,1]},"Mangrove Jack":{p:[11,12,1,2,3,4],s:[6,7,8]},"Spanish Mackerel":{p:[7,8,9,10]},"Coral Trout":{p:[4,5,6,7,8,9,10]},"GT":{p:[9,10,11,12]},"Golden Trevally":{p:[9,10,11,12,1]}},
 ID:{"GT":{p:[9,10,11],s:[1,2]},"Kakap Merah":{p:[3,4,5,9,10,11],s:[1,2]},"Kakap Putih":{p:[11,12,1,2]},"Kerapu":{p:[4,5,6,7,8,9,10],s:[1,2]},"Tenggiri":{p:[6,7,8,9,10],s:[12,1,2]},"Tongkol":{p:[5,6,7,8]},"Baronang":{p:[4,5,6,7,8]},
  "Belanak":{p:[]},"Barakuda":{p:[4,5,6,7,8,9]},"Cumi":{p:[6,7,8,9],s:[12,1]},"Bawal":{p:[2,3,4,5,6]}}};
const MON_ID=["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"],MON_EN=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const seasonOf=(f,m)=>{const s=SEASON[region]?.[f];if(!s)return null;return s.p.includes(m)?"p":(s.s||[]).includes(m)?"s":"b"};
function inSeasonNow(fishes){const m=new Date().getMonth()+1;return fishes.filter(f=>seasonOf(f,m)==="p")}
function seasonHtml(){
  const m=new Date().getMonth()+1,MON=region==="AU"?MON_EN:MON_ID,S=SEASON[region]||{};
  const fs=Object.keys(S).sort((a,b)=>(seasonOf(b,m)==="p")-(seasonOf(a,m)==="p")||a.localeCompare(b));
  const now=fs.filter(f=>seasonOf(f,m)==="p");
  return `<h2>Musim ikan</h2>
   <div class="card"><h3>🔥 Sedang musim bulan ini (${MON[m-1]})</h3><div>${now.length?now.map(fishMini).join(""):`<p class="note">Tidak ada puncak musim khusus bulan ini.</p>`}</div></div>
   <div class="card"><div class="tbl"><table class="season"><thead><tr><th>Ikan</th>${MON.map((x,i)=>`<th class="${i+1===m?"curm":""}">${x[0]}</th>`).join("")}</tr></thead><tbody>
   ${fs.map(f=>`<tr><td>${esc(f)}</td>${MON.map((x,i)=>{const v=seasonOf(f,i+1);return `<td class="sz ${v}${i+1===m?" curm":""}" title="${x}"></td>`}).join("")}</tr>`).join("")}</tbody></table></div>
   <p class="note"><span class="sz p legend"></span> Puncak musim <span class="sz b legend"></span> Biasa <span class="sz s legend"></span> ${region==="AU"?"Sepi / bisa ada musim tutup":"Sepi / ombak besar"}</p>
   <p class="note">${region==="AU"?"Panduan umum untuk pesisir timur (NSW–QLD). Daerah lain bisa bergeser 1–2 bulan. Cek aturan musim tutup di menu Aturan.":"Panduan umum. Musim barat (Des–Mar) biasanya ombak besar; musim timur (Jun–Sep) cocok untuk ikan pelagis seperti tenggiri dan tongkol."}</p></div>`;
}

// --- logbook pribadi (tersimpan di HP, tanpa login) ---
let logbook=store.get("mm_log",[]);
const saveLog=()=>{let ok=store.set("mm_log",logbook);while(!ok&&logbook.some(e=>e.photo)){const e=logbook.slice().reverse().find(e=>e.photo);e.photo=null;ok=store.set("mm_log",logbook)}return ok};
let logPhoto=null;
function logbookHtml(){
  const xs=logbook.filter(e=>(e.region||region)===region);
  return `<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h3 style="margin:0">📒 Logbook pribadi</h3><button class="btn" id="logAdd">+ Catat</button></div>
   <p class="note">Tersimpan di HP ini saja, bisa tanpa login & tanpa sinyal.</p>
   ${xs.length?xs.slice().reverse().map(e=>`<div class="log">${e.photo?`<img src="${e.photo}" alt="${esc(e.fish)}" data-zoom="${e.photo}">`:`<span class="thumb">${fishSVG(e.fish)}</span>`}<span class="grow"><b>${esc(e.fish)}</b> ${e.len?e.len+" cm":""}<br><span class="note">${esc(e.spot||"")} · ${new Date(e.t).toLocaleDateString(region==="AU"?"en-AU":"id-ID",{day:"numeric",month:"short",year:"numeric"})}${e.bait?" · "+esc(e.bait):""}</span>${e.note?`<br><span class="note">${esc(e.note)}</span>`:""}
     <span class="acts"><button class="x" data-lshare="${e.id}">📤 Bagikan</button>${me&&myName&&!e.posted?`<button class="x" data-lpost="${e.id}">⬆️ Ke komunitas</button>`:e.posted?`<span class="badge">sudah dibagikan</span>`:""}<button class="x" data-ldel="${e.id}">Hapus</button></span></span></div>`).join(""):`<p class="note">Belum ada catatan.</p>`}</div>`;
}
function openLogForm(){
  const c=cur(),fl=[...new Set(LOC.filter(l=>l.region===region).flatMap(l=>spotData(l).fish))].filter(f=>SP[f]).concat(Object.keys(SP).sort());
  logPhoto=null;
  openSheet(`<h3>Catat tangkapan</h3><form id="logF">
   <select class="f" id="lfish">${[...new Set(fl)].map(f=>`<option>${esc(f)}</option>`).join("")}<option value="__new">➕ Ikan lain (tulis sendiri)</option></select>
   <input id="lnew" placeholder="Nama ikan" maxlength="40" style="display:none;margin-top:6px">
   <div class="two" style="margin-top:6px"><input id="llen" type="number" min="1" max="400" placeholder="Panjang (cm)"><input id="lbait" placeholder="Umpan" maxlength="60"></div>
   <input id="lspot" value="${esc(c.n)}" maxlength="60" style="margin-top:6px" aria-label="Spot">
   <textarea id="lnote" rows="2" maxlength="300" placeholder="Catatan (cuaca, teknik, dll.)" style="margin-top:6px"></textarea>
   <label class="btn ghost" for="lpic" style="display:block;margin-top:6px">📷 Tambah foto</label><input type="file" id="lpic" accept="image/*" hidden><div id="lprev"></div>
   <button class="btn" type="submit" style="width:100%;margin-top:8px">Simpan ke logbook</button></form>`);
  $("#lfish").onchange=()=>{$("#lnew").style.display=$("#lfish").value==="__new"?"":"none"};
  $("#lpic").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const cv=await shrink(f,700);logPhoto=cv.toDataURL("image/jpeg",.6);$("#lprev").innerHTML=`<img class="preview" src="${logPhoto}" alt="">`}catch(x){}};
  $("#logF").onsubmit=e=>{e.preventDefault();let fish=$("#lfish").value;if(fish==="__new")fish=$("#lnew").value.trim();if(!fish)return;
    logbook.push({id:"l"+Date.now(),t:Date.now(),fish,len:+$("#llen").value||null,bait:$("#lbait").value.trim(),spot:$("#lspot").value.trim(),note:$("#lnote").value.trim(),photo:logPhoto,region,spotId:c.id,lat:c.lat,lon:c.lon});
    if(!saveLog())alertNote("Memori HP penuh: foto lama tidak disimpan.");closeSheet();render()};
}
function bindLogbook(){
  const a=$("#logAdd");if(a)a.onclick=openLogForm;
  document.querySelectorAll("[data-ldel]").forEach(b=>b.onclick=()=>{if(b.dataset.c!=="1"){b.dataset.c="1";b.textContent="Yakin hapus?";tr(b);return}logbook=logbook.filter(e=>e.id!==b.dataset.ldel);saveLog();render()});
  document.querySelectorAll("[data-lshare]").forEach(b=>b.onclick=()=>{const e=logbook.find(x=>x.id===b.dataset.lshare);if(e)shareCatch({fish:e.fish,len:e.len,spot:e.spot,photo:e.photo,bait:e.bait,t:e.t})});
  document.querySelectorAll("[data-lpost]").forEach(b=>b.onclick=async()=>{const e=logbook.find(x=>x.id===b.dataset.lpost);if(!e)return;b.disabled=true;b.textContent="Mengupload…";tr(b);
    try{let path=null;if(e.photo){const blob=await (await fetch(e.photo)).blob();path=`${me.id}/${Date.now()}.jpg`;const up=await sb.storage.from("photos").upload(path,blob,{contentType:"image/jpeg"});if(up.error)throw up.error}
      const s=everySpot().find(x=>x.id===e.spotId);
      const{error}=await sb.from("catches").insert({fish:e.fish,length_cm:e.len,bait:e.bait||null,released:false,spot_id:s?s.id:null,spot_name:e.spot||null,area:s?.a||null,lat:e.lat!=null?+(+e.lat).toFixed(3):null,lon:e.lon!=null?+(+e.lon).toFixed(3):null,photo_path:path});if(error)throw error;
      e.posted=true;saveLog();await loadFeed();render()}catch(err){b.disabled=false;b.textContent="Gagal: "+(err.message||err)}});
}

// --- bagikan tangkapan sebagai gambar (WhatsApp, dll.) ---
const loadImg=src=>new Promise((res,rej)=>{const i=new Image();i.crossOrigin="anonymous";i.onload=()=>res(i);i.onerror=rej;i.src=src});
async function shareCatch(x){
  const W=1080,H=1350,cv=document.createElement("canvas");cv.width=W;cv.height=H;const g=cv.getContext("2d");
  g.fillStyle="#0b1e33";g.fillRect(0,0,W,H);
  let src=x.photo||(WIKI[x.fish]?(fpCache[x.fish]||await fetchFP(x.fish)):"");
  if(src&&!x.photo)src=src.replace(/\/(\d+)px-/,"/800px-");
  try{if(src){const im=await loadImg(src).catch(()=>loadImg(x.photo||fpCache[x.fish]));const r=Math.max(W/im.width,1000/im.height),w=im.width*r,h=im.height*r;g.drawImage(im,(W-w)/2,(1000-h)/2,w,h)}}catch(e){}
  const gr=g.createLinearGradient(0,700,0,H);gr.addColorStop(0,"rgba(11,30,51,0)");gr.addColorStop(.35,"rgba(11,30,51,.92)");gr.addColorStop(1,"#0b1e33");g.fillStyle=gr;g.fillRect(0,700,W,H-700);
  try{const lg=await loadImg("icons/header-logo-dark.png");const lh=120,lw=lg.width*lh/lg.height;g.fillStyle="rgba(11,30,51,.55)";g.fillRect(30,30,lw+40,lh+30);g.drawImage(lg,50,45,lw,lh)}catch(e){}
  g.fillStyle="#fff";g.font="bold 96px system-ui,sans-serif";g.fillText(x.fish,60,1060);
  g.fillStyle="#f2a33a";g.font="bold 72px system-ui,sans-serif";if(x.len)g.fillText(x.len+" cm",60,1150);
  g.fillStyle="#cfe3f5";g.font="44px system-ui,sans-serif";
  const line=[x.spot,x.bait?(region==="AU"?"Bait: ":"Umpan: ")+x.bait:"",x.t?new Date(x.t).toLocaleDateString(region==="AU"?"en-AU":"id-ID",{day:"numeric",month:"long",year:"numeric"}):""].filter(Boolean).join(" · ");
  g.fillText(line.slice(0,48),60,x.len?1225:1150);
  g.fillStyle="#8fb3d1";g.font="34px system-ui,sans-serif";g.fillText(location.host?"amonkshark.github.io/mancing-mania-web":"Mancing Mania",60,1300);
  let blob=null;try{blob=await new Promise(r=>cv.toBlob(r,"image/jpeg",.88))}catch(e){}
  const text=(region==="AU"?`My catch: ${x.fish}${x.len?" "+x.len+" cm":""}${x.spot?" at "+x.spot:""} 🎣 via Mancing Mania`:`Tangkapanku: ${x.fish}${x.len?" "+x.len+" cm":""}${x.spot?" di "+x.spot:""} 🎣 lewat Mancing Mania`)+"\nhttps://amonkshark.github.io/mancing-mania-web/";
  const file=blob&&new File([blob],"mancing-mania.jpg",{type:"image/jpeg"});
  if(file&&navigator.canShare&&navigator.canShare({files:[file]})){try{await navigator.share({files:[file],text});return}catch(e){if(e.name==="AbortError")return}}
  const url=blob?URL.createObjectURL(blob):"";
  openSheet(`<h3>Bagikan tangkapan</h3>${url?`<img src="${url}" alt="" style="width:100%;border-radius:10px">`:""}
   <div class="two" style="margin-top:8px">${url?`<a class="btn ghost" href="${url}" download="mancing-mania.jpg">⬇️ Simpan gambar</a>`:""}<a class="btn" href="https://wa.me/?text=${encodeURIComponent(text)}" target="_blank" rel="noopener">WhatsApp</a></div>
   <p class="note">Simpan gambarnya dulu, lalu lampirkan di WhatsApp bersama pesannya.</p>`);
}

/* ================= SHELL ================= */
function setSpot(id){if(!id)return;curId=id;store.set("mm_cur",id);fishSel=null;castPick=null;fillPick();render()}
function fillPick(){const o=s=>`<option value="${s.id}" ${s.id===curId?"selected":""}>${esc(s.n)}</option>`,a=allSpots();$("#spotPick").innerHTML=region==="AU"?["Sydney","NSW","QLD","NT","WA","SA","VIC","TAS"].map(g=>{const xs=a.filter(x=>(x.st||(x.custom?"Spot pribadi":"Sydney"))===g);return xs.length?`<optgroup label="${g==="Sydney"?"Sydney":g==="NSW"?"New South Wales":g==="QLD"?"Queensland":g==="NT"?"Northern Territory":g==="WA"?"Western Australia":g==="SA"?"South Australia":g==="VIC"?"Victoria":"Tasmania"}">${xs.map(o).join("")}</optgroup>`:""}).join("")+(a.some(x=>x.custom)?`<optgroup label="Spot pribadi">${a.filter(x=>x.custom).map(o).join("")}</optgroup>`:""):region==="ID"?["Lombok Timur","Lombok Tengah"].map(g=>`<optgroup label="${g}">${a.filter(x=>inLombok(x)&&(x.a||"").includes(g)).map(o).join("")}</optgroup>`).join("")+`<optgroup label="Lombok lainnya">${a.filter(x=>inLombok(x)&&!/Lombok (Timur|Tengah)/.test(x.a||"")).map(o).join("")}</optgroup><optgroup label="Indonesia lainnya">${a.filter(s=>!inLombok(s)).map(o).join("")}</optgroup>`:a.map(o).join("")}
$("#spotPick").onchange=e=>setSpot(e.target.value);
$("#region").value=region;$("#region").onchange=e=>setRegion(e.target.value);
function render(){killMap();castAnimStop();setLang();({peta:mapView,prakiraan:forecastView,spot:spotView,tangkapan:catchView,belajar:learnView,lainnya:moreView})[view]();tr(document.body);hydrateFish(document.body)}
document.querySelectorAll(".tabbar button").forEach(b=>b.onclick=()=>{view=b.dataset.v;document.querySelectorAll(".tabbar button").forEach(x=>x.setAttribute("aria-selected",x===b));$("#main").scrollTop=0;render()});
fillPick();render();initCommunity();setTimeout(dailyReminder,3000);
// deteksi lokasi otomatis bila izin sudah pernah diberikan
// setiap aplikasi dibuka: pakai lokasi HP untuk memilih negara & spot terdekat
detectGPS(true);
// PWA: service worker untuk mode offline & install
if(!window.Capacitor&&"serviceWorker" in navigator&&location.protocol==="https:")navigator.serviceWorker.register("sw.js").catch(()=>{});

// tema terang / gelap
(function(){const k="mm_theme";let t="light";try{t=localStorage.getItem(k)||"light"}catch(e){}
 const apply=v=>{document.documentElement.dataset.mm=v;const b=document.getElementById("thBtn");if(b){b.textContent=v==="dark"?"☀️":"🌙";b.setAttribute("aria-label",v==="dark"?"Ganti ke tema terang":"Ganti ke tema gelap")}const m=document.querySelector('meta[name="theme-color"]');if(m)m.content=v==="dark"?"#050d1e":"#ffffff"};
 apply(t);document.getElementById("thBtn").onclick=()=>{t=t==="dark"?"light":"dark";try{localStorage.setItem(k,t)}catch(e){}apply(t)}})();

// Cegah zoom halaman (cubit & ketuk dua kali) kecuali di peta
(function(){
  const onMap=t=>t&&t.closest&&t.closest(".leaflet-container");
  ["gesturestart","gesturechange","gestureend"].forEach(ev=>document.addEventListener(ev,e=>{if(!onMap(e.target))e.preventDefault()},{passive:false}));
  document.addEventListener("touchmove",e=>{if(e.touches.length>1&&!onMap(e.target))e.preventDefault()},{passive:false});
  document.addEventListener("wheel",e=>{if(e.ctrlKey&&!onMap(e.target))e.preventDefault()},{passive:false});
  document.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&["+","-","=","0"].includes(e.key))e.preventDefault()});
})();
