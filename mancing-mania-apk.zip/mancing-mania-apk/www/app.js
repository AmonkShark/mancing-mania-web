
/* ================= DATA ================= */
const LOC=[
 {id:"balmoral",n:"Balmoral",a:"Middle Harbour",lat:-33.827,lon:151.252,type:"Pantai & dermaga",fish:["Bream","Whiting","Flathead","Tarwhine","Squid"],
  spots:"Ujung dermaga untuk squid saat subuh; pasir depan rotunda untuk whiting; karang Rocky Point untuk bream.",
  bait:{"Udang mentah":["Bream","Whiting","Tarwhine"],"Cacing laut":["Whiting"],"Squid jig":["Squid"],"Soft plastic kecil":["Flathead","Bream"]},tide:"Pasang naik, pagi atau senja."},
 {id:"watsons",n:"Watsons Bay",a:"South Head",lat:-33.843,lon:151.282,type:"Dermaga",fish:["Yellowtail","Squid","Bream","Trevally","Luderick"],
  spots:"Sisi dalam dermaga untuk yellowtail & squid; tiang dermaga untuk bream.",
  bait:{"Roti":["Yellowtail","Luderick"],"Udang mentah":["Bream","Trevally"],"Squid jig":["Squid"],"Rumput laut hijau":["Luderick"]},tide:"Pasang tinggi & air jernih."},
 {id:"spit",n:"The Spit Bridge",a:"Middle Harbour",lat:-33.804,lon:151.246,type:"Tepi & jembatan",fish:["Kingfish","Bream","Flathead","Squid","Tailor"],
  spots:"Tiang jembatan & marina untuk kingfish dan bream; pasir arah Clontarf untuk flathead.",
  bait:{"Squid hidup":["Kingfish"],"Soft plastic besar":["Kingfish","Flathead"],"Udang mentah":["Bream"],"Metal lure":["Tailor"]},tide:"Arus kuat saat pasang perbani."},
 {id:"cabarita",n:"Cabarita",a:"Parramatta River",lat:-33.840,lon:151.116,type:"Taman & dermaga",fish:["Bream","Flathead","Mulloway","Estuary Perch","Luderick"],
  spots:"Dermaga dan taman Cabarita; tepi berbatu untuk bream; malam hari untuk mulloway.",
  bait:{"Udang mentah":["Bream"],"Potongan cumi":["Mulloway","Flathead"],"Soft plastic kecil":["Bream","Flathead","Estuary Perch"],"Squid hidup":["Mulloway"]},tide:"Malam + pasang tinggi. Ada peringatan konsumsi ikan di sungai ini, cek NSW DPI."},
 {id:"bareisland",n:"Bare Island",a:"La Perouse",lat:-33.991,lon:151.231,type:"Batu & jembatan",fish:["Luderick","Drummer","Bream","Yellowtail","Squid"],
  spots:"Sekitar jembatan untuk luderick & squid; batu sisi timur untuk drummer.",
  bait:{"Rumput laut hijau":["Luderick"],"Roti":["Drummer","Yellowtail"],"Udang mentah":["Bream","Yellowtail"],"Squid jig":["Squid"]},tide:"Pasang turun di sekitar jembatan."},
 {id:"kurnell",n:"Kurnell",a:"Botany Bay",lat:-34.008,lon:151.207,type:"Batu & pantai",fish:["Flathead","Bream","Trevally","Salmon Australia","Tailor","Snapper"],
  spots:"Silver Beach untuk flathead & whiting; Inscription Point untuk salmon, tailor & snapper (hati-hati ombak).",
  bait:{"Pilchard utuh":["Tailor","Salmon Australia","Snapper"],"Soft plastic besar":["Flathead","Snapper"],"Udang mentah":["Bream","Trevally"],"Metal lure":["Salmon Australia","Tailor"]},tide:"Pergantian arus; tailor saat senja."},
 {id:"bundeena",n:"Bundeena",a:"Port Hacking",lat:-34.084,lon:151.151,type:"Dermaga & flat",fish:["Whiting","Flathead","Bream","Squid","Luderick"],
  spots:"Flat pasir Gunnamatta & Bundeena untuk whiting dan flathead; dermaga untuk squid.",
  bait:{"Cacing laut":["Whiting"],"Udang mentah":["Whiting","Bream"],"Soft plastic kecil":["Flathead"],"Squid jig":["Squid"],"Rumput laut hijau":["Luderick"]},tide:"Pasang naik di atas flat pasir."},
 {id:"longreef",n:"Long Reef",a:"Northern Beaches",lat:-33.741,lon:151.310,type:"Batu & pantai",fish:["Salmon Australia","Tailor","Drummer","Bream","Whiting"],
  spots:"Pantai Collaroy–Long Reef untuk whiting & salmon; batu tanjung untuk drummer dan tailor.",
  bait:{"Pilchard utuh":["Tailor","Salmon Australia"],"Cacing laut":["Whiting"],"Roti":["Drummer"],"Metal lure":["Salmon Australia","Tailor"]},tide:"Pagi buta & senja; batu hanya saat laut tenang."},
 {id:"brooklyn",n:"Brooklyn",a:"Hawkesbury River",lat:-33.548,lon:151.226,type:"Sungai & dermaga",fish:["Mulloway","Flathead","Bream","Estuary Perch","Squid"],
  spots:"Dermaga Brooklyn; tiang jembatan kereta untuk mulloway; teluk bakau untuk bream & perch.",
  bait:{"Squid hidup":["Mulloway"],"Potongan cumi":["Mulloway","Flathead"],"Soft plastic kecil":["Bream","Estuary Perch","Flathead"],"Udang mentah":["Bream"]},tide:"Saat arus berhenti (slack) untuk mulloway."}
];
/* Spesies: ilustrasi (warna badan/punggung, bentuk, pola) + aturan + ciri pengenal */
const SP={
 "Bream":{b:"#c9cfc8",d:"#6f7a6a",fin:"#e3c24a",h:.42,pat:"",min:27,lim:"min. 27 cm, maks 20",ciri:"Badan tinggi pipih, perak kehijauan, sirip perut & dubur kuning (yellowfin bream).",lat:"Acanthopagrus australis"},
 "Flathead":{b:"#b59a72",d:"#7d6544",fin:"#c9a16a",h:.22,flat:1,pat:"spots",min:36,lim:"36–70 cm, maks 10",ciri:"Kepala gepeng lebar, badan pipih memanjang, bintik cokelat; ekor ada bercak biru-hitam (dusky).",lat:"Platycephalus fuscus"},
 "Whiting":{b:"#e8dcc0",d:"#b8a682",fin:"#d8c79f",h:.24,pat:"",min:27,lim:"min. 27 cm",ciri:"Ramping, moncong runcing, warna pasir keemasan, bintik hitam di pangkal sirip dada.",lat:"Sillago ciliata"},
 "Squid":{squid:1,b:"#e9c9c9",d:"#b07b88",min:0,lim:"maks 20",ciri:"Badan tabung bening-kemerahan, sirip lebar di sepanjang badan (southern calamari).",lat:"Sepioteuthis australis"},
 "Kingfish":{b:"#dfe7ea",d:"#4f6e86",fin:"#e8c33a",h:.28,pat:"stripe",min:65,lim:"min. 65 cm, maks 5",ciri:"Torpedo, punggung biru-hijau, garis kuning dari mata ke ekor, ekor kuning bercabang.",lat:"Seriola lalandi"},
 "Mulloway":{b:"#c8ccd2",d:"#7b8590",fin:"#a7a9a5",h:.3,pat:"",min:70,lim:"min. 70 cm, maks 2",ciri:"Perak-perunggu, besar, garis lateral bertitik terang, ekor membulat lurus.",lat:"Argyrosomus japonicus"},
 "Snapper":{b:"#e6a59a",d:"#c06d63",fin:"#e7a39a",h:.42,pat:"bluespots",min:30,lim:"min. 30 cm, maks 10",ciri:"Merah-merah muda dengan bintik biru terang, dahi menonjol pada ikan besar.",lat:"Chrysophrys auratus"},
 "Tailor":{b:"#d4dde0",d:"#5f7f87",fin:"#b8c6c6",h:.28,pat:"",min:30,lim:"min. 30 cm, maks 20",ciri:"Perak kebiruan, gigi tajam, sirip ekor gelap bercabang.",lat:"Pomatomus saltatrix"},
 "Luderick":{b:"#8f9a86",d:"#4b5446",fin:"#636c5a",h:.38,pat:"bars",min:27,lim:"min. 27 cm, maks 10",ciri:"Hijau keabu gelap dengan garis-garis vertikal tipis, mulut kecil (blackfish).",lat:"Girella tricuspidata"},
 "Drummer":{b:"#4d5552",d:"#2e3432",fin:"#3a403e",h:.42,pat:"",min:30,lim:"min. 30 cm",ciri:"Hitam pekat, badan tebal & tinggi, sangat kuat di karang (rock blackfish).",lat:"Girella elevata"},
 "Salmon Australia":{b:"#d9dfd6",d:"#4f6a6e",fin:"#9fb0a6",h:.28,pat:"spots",min:0,lim:"maks 5",ciri:"Torpedo, punggung hijau-biru dengan bintik gelap, perut perak.",lat:"Arripis trutta"},
 "Trevally":{b:"#dfe3e3",d:"#91a2a8",fin:"#e3cf6a",h:.4,pat:"",min:0,lim:"maks 20",ciri:"Perak, badan tinggi pipih, bercak hitam di tutup insang, garis lateral bersisik keras.",lat:"Pseudocaranx georgianus"},
 "Yellowtail":{b:"#d5dfe0",d:"#5c7f86",fin:"#e8c33a",h:.24,pat:"stripe",min:0,lim:"sering jadi umpan hidup",ciri:"Kecil ramping, ekor kuning, garis lateral bersisik (yellowtail scad).",lat:"Trachurus novaezelandiae"},
 "Tarwhine":{b:"#d7d8cc",d:"#9aa08c",fin:"#e3c24a",h:.42,pat:"lines",min:23,lim:"min. 23 cm",ciri:"Mirip bream tapi ada garis-garis keemasan horizontal di badan.",lat:"Rhabdosargus sarba"},
 "Estuary Perch":{b:"#b9b9a3",d:"#6b6d58",fin:"#8e8c74",h:.36,pat:"",min:0,lim:"maks 2",ciri:"Perunggu-zaitun, dahi cekung, duri sirip punggung tajam.",lat:"Percalates colonorum"}
};
const BAITINFO={"Udang mentah":"Umpan paling universal. Pasang dari ekor sampai mata kail tertutup.","Cacing laut":"Beachworm / bloodworm, terbaik untuk whiting.","Squid jig":"Umpan tiruan udang khusus cumi, ukuran 2.5–3.0.","Soft plastic kecil":"Grub/minnow 2–3 inci di jighead 1/8 oz.","Soft plastic besar":"Jerkbait 4–5 inci di jighead 1/4–3/8 oz.","Roti":"Murah; untuk berley dan umpan di kail kecil.","Rumput laut hijau":"Untuk luderick, pakai dengan float rig.","Squid hidup":"Umpan terbaik untuk kingfish & mulloway.","Potongan cumi":"Strip cumi awet di kail, untuk ikan dasar.","Pilchard utuh":"Ikan mati (mulie) di gang hook untuk tailor & salmon.","Metal lure":"Logam 20–40 g, lempar jauh & gulung cepat."};

/* Data pasang Fort Denison dari WillyWeather (13–19 Okt 2026), jam AEDT */
const TIDE_SRC="https://tides.willyweather.com.au/nsw/sydney/fort-denison.html";
const TIDES=[["2026-10-13",[["04:05",.47],["10:33",1.73],["17:03",.42],["23:00",1.34]]],["2026-10-14",[["04:35",.54],["11:09",1.70],["17:46",.47],["23:40",1.27]]],["2026-10-15",[["05:08",.61],["11:45",1.65],["18:30",.53]]],["2026-10-16",[["00:23",1.20],["05:45",.68],["12:27",1.58],["19:21",.59]]],["2026-10-17",[["01:13",1.15],["06:31",.73],["13:14",1.51],["20:19",.63]]],["2026-10-18",[["02:12",1.11],["07:30",.78],["14:12",1.46],["21:26",.64]]],["2026-10-19",[["03:25",1.12],["08:43",.80],["15:21",1.43],["22:30",.61]]]];

const $=s=>document.querySelector(s);
const store={get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}};
let mySpots=store.get("mm_spots",[]);
let curId=store.get("mm_cur","balmoral"),view="peta",dayOff=0,learn="animasi",fishSel=null;
const allSpots=()=>LOC.concat(mySpots).filter(s=>(s.region||regionOf(s.lat,s.lon))===region);const everySpot=()=>LOC.concat(mySpots);
const cur=()=>allSpots().find(s=>s.id===curId)||allSpots()[0];
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

/* ================= ILUSTRASI IKAN ================= */
function fishSVG(name,w){return `<span class="fishpic" data-sp="${esc(name)}">${fishSVG0(name,w)}</span>`}
function fishSVG0(name,w=200){
  const s=SP[name]||SP.Bream,H=100;
  if(s.squid){return `<svg viewBox="0 0 200 100" role="img" aria-label="${name}"><path d="M20 50 Q30 20 110 30 L140 50 L110 70 Q30 80 20 50Z" fill="${s.b}"/><path d="M28 50 Q40 18 110 32 Q80 50 110 68 Q40 82 28 50Z" fill="none" stroke="${s.d}" stroke-width="2" opacity=".6"/><g stroke="${s.d}" stroke-width="3" stroke-linecap="round"><path d="M140 46 Q165 40 190 36"/><path d="M140 50 Q168 50 192 50"/><path d="M140 54 Q165 60 190 64"/><path d="M138 44 Q160 30 178 26"/><path d="M138 56 Q160 70 178 74"/></g><circle cx="128" cy="44" r="5" fill="#222"/><circle cx="129" cy="43" r="1.5" fill="#fff"/></svg>`}
  const h=s.h*H*1.6, top=50-h/2, bot=50+h/2;
  const body=`M28 50 Q${s.flat?45:55} ${top} 110 ${top+2} Q150 ${top+4} 172 ${s.flat?48:46} Q176 50 172 ${s.flat?52:54} Q150 ${bot-2} 110 ${bot} Q55 ${bot} 28 50Z`;
  let pat="";
  if(s.pat==="spots")for(let i=0;i<14;i++)pat+=`<circle cx="${50+((i*37)%110)}" cy="${top+6+((i*13)%Math.max(6,h*.45))}" r="2.6" fill="${s.d}" opacity=".7"/>`;
  if(s.pat==="bluespots")for(let i=0;i<12;i++)pat+=`<circle cx="${60+((i*29)%100)}" cy="${top+8+((i*11)%Math.max(6,h*.5))}" r="1.8" fill="#4aa3e0"/>`;
  if(s.pat==="bars")for(let x=55;x<160;x+=11)pat+=`<line x1="${x}" y1="${top+4}" x2="${x-3}" y2="${bot-4}" stroke="${s.d}" stroke-width="2" opacity=".5"/>`;
  if(s.pat==="lines")for(let k=1;k<5;k++)pat+=`<path d="M45 ${top+k*h/5} Q110 ${top+k*h/5-3} 165 ${50+(k-2.5)*3}" stroke="${s.fin}" stroke-width="1.3" fill="none" opacity=".8"/>`;
  if(s.pat==="stripe")pat+=`<path d="M40 50 Q110 ${50-2} 172 50" stroke="${s.fin}" stroke-width="4" fill="none"/>`;
  return `<svg viewBox="0 0 200 100" role="img" aria-label="${name}">
   <path d="M30 50 L6 ${50-h*.45} Q14 50 6 ${50+h*.45}Z" fill="${s.fin||s.d}"/>
   <path d="M70 ${top+3} Q100 ${top-14} 135 ${top+4}Z" fill="${s.fin||s.d}" opacity=".9"/>
   <path d="M85 ${bot-2} Q100 ${bot+10} 115 ${bot-1}Z" fill="${s.fin||s.d}" opacity=".9"/>
   <path d="${body}" fill="${s.b}"/>
   <path d="M28 50 Q55 ${top} 110 ${top+2} Q150 ${top+4} 172 ${s.flat?48:46} Q120 ${50-h*.15} 28 50Z" fill="${s.d}" opacity=".75"/>
   ${pat}
   <path d="M150 ${top+8} Q144 50 150 ${bot-8}" stroke="${s.d}" stroke-width="1.5" fill="none" opacity=".6"/>
   <circle cx="160" cy="${48-h*.08}" r="4.5" fill="#fff"/><circle cx="161" cy="${48-h*.08}" r="2.6" fill="#1a1a1a"/>
   <path d="M120 54 Q132 62 140 56" fill="${s.fin||s.d}" opacity=".85"/></svg>`;
}
const fishMini=n=>`<span class="fishmini">${fishSVG(n)}${esc(n)}</span>`;

/* ================= PETA LEMPAR (skema lokal per spot) =================
   Kotak 300x190: air di atas, darat di bawah, pemancing di tepi. face = arah kompas air di depan pemancing. 1 unit ≈ 0.6 m */
const SCENE={
 balmoral:{face:90,shore:"Dermaga & pantai",me:[150,168],f:{sand:[150,105],weed:[60,80],rocks:[255,120],pylons:[95,140],deep:[175,35]}},
 watsons:{face:270,shore:"Ujung dermaga",me:[150,150],f:{pylons:[120,135],weed:[40,95],sand:[230,100],deep:[150,40],rocks:[270,140]}},
 spit:{face:0,shore:"Tepi selatan jembatan",me:[110,168],f:{pylons:[150,95],deep:[150,40],sand:[250,130],snags:[45,120],weed:[60,70]}},
 cabarita:{face:0,shore:"Dermaga taman",me:[150,165],f:{pylons:[175,140],rocks:[50,130],snags:[260,125],deep:[150,45],sand:[100,95]}},
 bareisland:{face:180,shore:"Jembatan Bare Island",me:[150,160],f:{pylons:[120,130],weed:[220,95],rocks:[45,110],whitewater:[260,40],deep:[150,45]}},
 kurnell:{face:0,shore:"Batu Inscription Point",me:[150,168],f:{whitewater:[85,95],reef:[200,60],deep:[150,25],sand:[255,140],rocks:[40,140]}},
 bundeena:{face:0,shore:"Pantai & dermaga",me:[150,168],f:{sand:[120,115],weed:[230,95],pylons:[260,145],deep:[150,35],rocks:[40,130]}},
 longreef:{face:90,shore:"Tepi batu tanjung",me:[150,168],f:{whitewater:[110,110],reef:[200,55],sand:[40,120],deep:[160,25],rocks:[250,130]}},
 brooklyn:{face:0,shore:"Dermaga Brooklyn",me:[150,165],f:{pylons:[210,110],deep:[150,40],snags:[45,120],weed:[90,90],sand:[260,135]}}
};
const FEAT={sand:"Pasir & drop-off",weed:"Rumput laut",rocks:"Karang/batu",pylons:"Tiang dermaga/jembatan",deep:"Alur dalam",whitewater:"Air berbuih",reef:"Karang dalam",snags:"Kayu tenggelam/bakau"};
const HABITAT={Kingfish:["pylons","deep","reef"],Bream:["pylons","rocks","snags"],Flathead:["sand"],Whiting:["sand"],Squid:["weed"],Luderick:["weed","rocks"],Drummer:["whitewater","rocks"],Tailor:["whitewater","deep"],"Salmon Australia":["whitewater","sand"],Mulloway:["deep","pylons"],Snapper:["reef","deep"],Trevally:["deep","pylons"],Yellowtail:["pylons","weed"],Tarwhine:["rocks","weed"],"Estuary Perch":["snags","rocks"]};
const HOWTO={Kingfish:"Lempar dan gulung cepat melewati tiang; tahan kuat agar ikan tidak lari ke tiang.",Bream:"Biarkan umpan jatuh pelan di dekat struktur, jangan terlalu banyak digerakkan.",Flathead:"Lempar melewati drop-off lalu seret/lompatkan kembali melintasi tepinya.",Whiting:"Lempar ke air dangkal berpasir, gulung sangat pelan.",Squid:"Lempar ke tepi rumput laut, biarkan jig tenggelam lalu sentak.",Luderick:"Hanyutkan float di sepanjang rumput laut mengikuti arus.",Drummer:"Pancing di buih tepat di depan batu, senar kuat, tanpa banyak pemberat.",Tailor:"Lempar jauh ke air berbuih saat senja, gulung cepat.","Salmon Australia":"Lempar metal lure ke buih atau parit pantai.",Mulloway:"Turunkan umpan hidup ke alur dalam saat arus melambat.",Snapper:"Pemberat ringan, biarkan umpan tenggelam pelan ke karang dalam.",Trevally:"Pakai berley, umpan di tengah kolom air.",Yellowtail:"Kail kecil + roti/udang dekat dermaga dengan berley.",Tarwhine:"Udang kecil di dekat karang dangkal.","Estuary Perch":"Lempar soft plastic ke dekat kayu, biarkan tenggelam."};
const compass=d=>["Utara","Timur Laut","Timur","Tenggara","Selatan","Barat Daya","Barat","Barat Laut"][Math.round(((d%360)+360)%360/45)%8];
function castMap(spotId,fish){
  const S=SCENE[spotId]||autoScene(everySpot().find(x=>x.id===spotId)||{});
  const feats=Object.entries(S.f),want=HABITAT[fish]||[];
  const tgtKey=want.find(k=>S.f[k]);if(!tgtKey)return `<p class="note">Habitat ${fish} tidak umum di spot ini.</p>`;
  const[tx,ty]=S.f[tgtKey],boat=mode==="perahu",[mx,my]=boat?[Math.min(270,Math.max(30,tx+(tx<150?55:-55))),Math.min(150,ty+40)]:S.me,dx=tx-mx,dy=ty-my;
  const dist=Math.round(Math.hypot(dx,dy)*.6/5)*5,ang=Math.atan2(dx,-dy)/rad,bear=(S.face+ang+360)%360;
  const shape=(k,[x,y],on)=>{const st=on?`stroke="var(--sand)" stroke-width="2.5"`:"";const op=on?1:.55;
    if(k==="sand")return `<ellipse cx="${x}" cy="${y}" rx="45" ry="18" fill="#e7d6a8" opacity="${op}" ${st}/>`;
    if(k==="weed")return `<g opacity="${op}">${[0,1,2,3,4].map(i=>`<path d="M${x-20+i*10} ${y+12} q-4 -12 0 -24" stroke="#3f8a4f" stroke-width="3" fill="none"/>`).join("")}${on?`<circle cx="${x}" cy="${y}" r="24" fill="none" ${st}/>`:""}</g>`;
    if(k==="rocks"||k==="reef")return `<g opacity="${op}">${[[-14,4],[0,-6],[14,5],[-4,10]].map(([a,b])=>`<circle cx="${x+a}" cy="${y+b}" r="${k==="reef"?9:8}" fill="${k==="reef"?"#8a6f6a":"#7d7a70"}"/>`).join("")}${on?`<circle cx="${x}" cy="${y}" r="24" fill="none" ${st}/>`:""}</g>`;
    if(k==="pylons")return `<g opacity="${op}">${[-20,-7,6,19].map(a=>`<rect x="${x+a-3}" y="${y-14}" width="6" height="28" fill="#6b5a45"/>`).join("")}${on?`<rect x="${x-28}" y="${y-20}" width="56" height="40" rx="6" fill="none" ${st}/>`:""}</g>`;
    if(k==="deep")return `<ellipse cx="${x}" cy="${y}" rx="70" ry="16" fill="var(--accent)" opacity="${on?.35:.18}" ${st}/>`;
    if(k==="whitewater")return `<g opacity="${op}">${[0,1,2].map(i=>`<path d="M${x-30} ${y-8+i*8} q10 -6 20 0 t20 0 t20 0" stroke="#fff" stroke-width="3" fill="none"/>`).join("")}${on?`<circle cx="${x}" cy="${y}" r="28" fill="none" ${st}/>`:""}</g>`;
    if(k==="snags")return `<g opacity="${op}"><path d="M${x-22} ${y+8} L${x+18} ${y-8} M${x-8} ${y+2} l-6 -14 M${x+6} ${y-3} l8 -12" stroke="#5b4630" stroke-width="4" fill="none"/>${on?`<circle cx="${x}" cy="${y}" r="24" fill="none" ${st}/>`:""}</g>`;
  };
  return `<div class="cast"><svg viewBox="0 0 300 200" role="img" aria-label="Peta lempar ${fish}" id="castSvg" data-a="${mx},${my},${(mx+tx)/2+dx*.15-20},${Math.min(my,ty)-30},${tx},${ty+6}" data-fish="${fish}">
    <defs><marker id="ah" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto"><path d="M0 0 L8 4 L0 8z" fill="var(--sand)"/></marker></defs>
    <rect width="300" height="200" fill="var(--sea)"/><path d="M0 175 Q80 165 150 172 T300 170 V200 H0Z" fill="var(--land)"/>
    ${feats.map(([k,p])=>shape(k,p,k===tgtKey)).join("")}
    <path d="M${mx} ${my} Q${(mx+tx)/2+dx*.15-20} ${Math.min(my,ty)-30} ${tx} ${ty+6}" fill="none" stroke="var(--sand)" stroke-width="2.5" stroke-dasharray="6 4" marker-end="url(#ah)" opacity=".45"/><g id="ca"><path id="caLine" fill="none" stroke="var(--fg)" stroke-width="1.2" opacity=".8"/><g id="caRings"></g><g id="caFish" opacity="0"><path d="M0 0 q-12 -8 -24 0 q12 8 24 0z M0 0 l8 -6 v12z" fill="var(--fg)" opacity=".75"/></g><circle id="caLure" r="4.5" fill="var(--sand)" stroke="var(--fg)" stroke-width="1.5" cx="-20" cy="-20"/></g>
    ${boat?`<path d="M${mx-14} ${my-2} h28 l-6 9 h-16z" fill="var(--fg)"/><rect x="${mx-4}" y="${my-10}" width="8" height="8" fill="var(--fg)"/><text x="${mx+16}" y="${my+4}" font-size="10" fill="var(--fg)">Perahu</text>`:`<circle cx="${mx}" cy="${my}" r="7" fill="var(--fg)"/><text x="${mx+10}" y="${my+4}" font-size="10" fill="var(--fg)">Kamu</text>`}
    <text x="${tx}" y="${ty-26}" font-size="10" text-anchor="middle" fill="var(--fg)" font-weight="600" paint-order="stroke" stroke="var(--sea)" stroke-width="3">${fish} di sini</text>
    <g transform="translate(276,22)"><circle r="14" fill="var(--surface)" stroke="var(--line)"/><path d="M0 -10 L4 2 L0 0 L-4 2Z" fill="var(--bad)" transform="rotate(${-S.face})"/><text y="-17" font-size="8" text-anchor="middle" fill="var(--muted)" transform="rotate(${-S.face})">U</text></g>
   </svg>
   <div class="row" style="margin-top:8px"><div class="kv"><span class="tag">Arah lempar</span><strong>${compass(bear)}</strong><span class="note">${Math.round(bear)}°</span></div><div class="kv"><span class="tag">Jarak ±</span><strong>${Math.max(5,dist)} m</strong></div><div class="kv"><span class="tag">Target</span><strong style="font-size:.95rem">${FEAT[tgtKey]}</strong></div></div>
   <p class="note">${boat?"Posisikan perahu di sisi atas arus, lalu biarkan hanyut (drift) melewati target. Jangan jangkar di atas karang hidup.":"Posisi berdiri: "+S.shore+"."} ${HOWTO[fish]||""}</p></div>`;
}


/* ================= INDONESIA ================= */
LOC.forEach(l=>l.region="AU");
LOC.push(
 {id:"ancol",region:"ID",n:"Pantai Ancol",a:"Jakarta",lat:-6.122,lon:106.84,type:"Dermaga & pemecah ombak",fish:["Kakap Putih","Baronang","Belanak","Cumi","Bawal"],
  spots:"Ujung pemecah ombak untuk kakap putih saat air pasang; batu berlumut untuk baronang & belanak; lampu dermaga malam hari untuk cumi.",
  bait:{"Udang hidup":["Kakap Putih","Bawal"],"Lumut":["Baronang","Belanak"],"Squid jig":["Cumi"],"Soft plastic kecil":["Kakap Putih"]},tide:"Pasang naik menjelang malam."},
 {id:"seribu",region:"ID",n:"Pulau Pramuka",a:"Kepulauan Seribu",lat:-5.745,lon:106.614,type:"Dermaga & karang",fish:["Kerapu","Kakap Merah","GT","Tongkol","Cumi","Baronang"],
  spots:"Tubir (tepi karang yang turun ke laut dalam) untuk kerapu & kakap merah; perairan terbuka untuk tongkol; dermaga malam untuk cumi.",
  bait:{"Potongan cumi":["Kerapu","Kakap Merah"],"Ikan umpan hidup":["GT","Kerapu"],"Jig logam":["Tongkol","GT"],"Squid jig":["Cumi"],"Lumut":["Baronang"]},tide:"Arus mulai bergerak, pagi atau sore."},
 {id:"anyer",region:"ID",n:"Anyer",a:"Banten",lat:-6.06,lon:105.88,type:"Pantai batu & dermaga",fish:["Kakap Merah","Kerapu","Barakuda","Baronang","Cumi"],
  spots:"Batu karang di sepanjang pantai untuk kerapu & baronang; ujung dermaga untuk barakuda dan cumi.",
  bait:{"Potongan cumi":["Kakap Merah","Kerapu"],"Ikan umpan hidup":["Barakuda","Kerapu"],"Lumut":["Baronang"],"Squid jig":["Cumi"]},tide:"Pasang naik, laut tenang."},
 {id:"pelabuhanratu",region:"ID",n:"Pelabuhan Ratu",a:"Sukabumi",lat:-7.0,lon:106.53,type:"Pantai & batu karang",fish:["GT","Tenggiri","Barakuda","Kakap Merah","Tongkol"],
  spots:"Batu karang dan buih ombak untuk GT; muara dan perairan terbuka untuk tenggiri & tongkol. Ombak Samudra Hindia besar, waspada.",
  bait:{"Popper":["GT"],"Jig logam":["Tenggiri","Tongkol","Barakuda"],"Ikan umpan hidup":["Tenggiri","Barakuda"],"Potongan cumi":["Kakap Merah"]},tide:"Subuh, saat ombak kecil."},
 {id:"karimunjawa",region:"ID",n:"Karimunjawa",a:"Jawa Tengah",lat:-5.86,lon:110.43,type:"Pulau & karang",fish:["Kerapu","Kakap Merah","GT","Tenggiri","Baronang"],
  spots:"Gosong karang dan tubir untuk kerapu & kakap merah; tanjung berarus untuk GT dan tenggiri. Sebagian area taman nasional, cek zona.",
  bait:{"Potongan cumi":["Kerapu","Kakap Merah"],"Popper":["GT"],"Jig logam":["Tenggiri","GT"],"Lumut":["Baronang"]},tide:"Arus kuat sekitar bulan baru & purnama."},
 {id:"serangan",region:"ID",n:"Serangan",a:"Bali",lat:-8.73,lon:115.24,type:"Pantai & perahu",fish:["GT","Kakap Merah","Barakuda","Tongkol","Cumi"],
  spots:"Mulut selat dan rumpon dengan perahu untuk GT & tongkol; karang dalam untuk kakap merah; pinggir pantai malam untuk cumi.",
  bait:{"Popper":["GT"],"Jig logam":["Tongkol","Barakuda","GT"],"Potongan cumi":["Kakap Merah"],"Squid jig":["Cumi"]},tide:"Pergantian arus di selat."},
 {id:"sekotong",region:"ID",n:"Sekotong",a:"Lombok",lat:-8.75,lon:115.98,type:"Pulau-pulau kecil (Gili)",fish:["GT","Kerapu","Kakap Merah","Barakuda","Cumi"],
  spots:"Sekitar Gili Nanggu & Gili Sudak: tubir untuk kerapu, tanjung berarus untuk GT.",
  bait:{"Popper":["GT"],"Ikan umpan hidup":["Kerapu","Barakuda"],"Potongan cumi":["Kakap Merah","Kerapu"],"Squid jig":["Cumi"]},tide:"Pagi hari, arus sedang."},
 {id:"labuanbajo",region:"ID",n:"Labuan Bajo",a:"Flores, NTT",lat:-8.49,lon:119.88,type:"Perahu & karang",fish:["GT","Tenggiri","Kerapu","Kakap Merah","Barakuda","Tongkol"],
  spots:"Pulau-pulau sekitar untuk GT & tenggiri; karang dalam untuk kerapu. Wilayah Taman Nasional Komodo dilarang mancing, cek batasnya.",
  bait:{"Popper":["GT"],"Jig logam":["Tenggiri","Tongkol","GT"],"Ikan umpan hidup":["Kerapu","Barakuda"],"Potongan cumi":["Kakap Merah"]},tide:"Arus kuat; mancing saat arus melambat."}
);
const IDRULE="Tidak ada ukuran minimum nasional untuk pemancing rekreasi; lepas ikan yang masih kecil.";
Object.assign(SP,{
 "Kakap Merah":{b:"#e0796a",d:"#b24c40",fin:"#d9705f",h:.38,pat:"",min:0,lim:IDRULE,ciri:"Merah terang, mulut besar dengan gigi taring, sirip ekor agak berlekuk.",lat:"Lutjanus spp."},
 "Kakap Putih":{b:"#cfd3cf",d:"#6f7f7c",fin:"#a8aea6",h:.32,pat:"",min:0,lim:IDRULE,ciri:"Perak, kepala runcing cekung, mata merah menyala dalam gelap, ekor membulat (barramundi).",lat:"Lates calcarifer"},
 "Kerapu":{b:"#a68a6c",d:"#6b5640",fin:"#8a7155",h:.38,pat:"spots",min:0,lim:IDRULE,ciri:"Badan tebal, mulut lebar, bintik-bintik atau bercak, suka bersembunyi di karang.",lat:"Epinephelus spp."},
 "GT":{b:"#c2c7c8",d:"#4d5558",fin:"#5e6669",h:.44,pat:"",min:0,lim:"Banyak pemancing menerapkan catch & release.",ciri:"Kuwe besar: perak gelap, dahi curam, badan tinggi, ekor bercabang kuat.",lat:"Caranx ignobilis"},
 "Barakuda":{b:"#d4dad8",d:"#5c6e6c",fin:"#9fb0ad",h:.16,pat:"bars",min:0,lim:IDRULE,ciri:"Panjang seperti tombak, rahang bawah menonjol, gigi tajam, garis-garis gelap.",lat:"Sphyraena spp."},
 "Tenggiri":{b:"#d6dde2",d:"#3f5f7a",fin:"#7f95a8",h:.18,pat:"bars",min:0,lim:IDRULE,ciri:"Ramping, punggung biru, garis-garis vertikal bergelombang, ekor bercabang tajam.",lat:"Scomberomorus commerson"},
 "Tongkol":{b:"#cfd6db",d:"#273e57",fin:"#506b85",h:.3,pat:"bars",min:0,lim:IDRULE,ciri:"Mirip tuna kecil, punggung biru tua dengan garis miring, bintik hitam di bawah sirip dada.",lat:"Euthynnus affinis"},
 "Baronang":{b:"#b3ad8f",d:"#6c6748",fin:"#a39d7e",h:.44,pat:"spots",min:0,lim:"Duri siripnya berbisa, pegang hati-hati.",ciri:"Pipih tinggi, mulut kecil seperti kelinci, bintik terang, duri sirip berbisa.",lat:"Siganus spp."},
 "Bawal":{b:"#d8d9d6",d:"#8d918f",fin:"#b5b8b5",h:.58,pat:"",min:0,lim:IDRULE,ciri:"Badan bulat pipih sangat tinggi, perak, ekor bercabang dalam (bawal putih).",lat:"Pampus argenteus"},
 "Belanak":{b:"#c7ccc7",d:"#6a7470",fin:"#9aa29e",h:.24,pat:"lines",min:0,lim:IDRULE,ciri:"Silinder, kepala tumpul, garis-garis memanjang samar, suka bergerombol di permukaan.",lat:"Mugilidae"},
 "Cumi":{squid:1,b:"#e9c9c9",d:"#b07b88",min:0,lim:IDRULE,ciri:"Cumi-cumi; badan tabung bening, keluar ke cahaya lampu di malam hari.",lat:"Loligo / Sepioteuthis"}
});
Object.assign(BAITINFO,{"Udang hidup":"Kait di punggung agar tetap hidup; terbaik untuk kakap putih.","Lumut":"Lumut hijau dari batu, untuk baronang & belanak (pakai kail kecil).","Ikan umpan hidup":"Ikan kecil (selar, kembung) dikait di punggung.","Jig logam":"Metal jig 30–80 g, jatuhkan ke dasar lalu tarik cepat.","Popper":"Umpan permukaan yang menyemburkan air; untuk GT."});
Object.assign(HABITAT,{"Kakap Merah":["reef","deep"],"Kakap Putih":["snags","pylons","rocks"],"Kerapu":["reef","rocks"],"GT":["whitewater","reef","deep"],"Barakuda":["deep","pylons"],"Tenggiri":["deep","whitewater"],"Tongkol":["deep"],"Baronang":["weed","rocks"],"Bawal":["deep","pylons"],"Belanak":["sand","weed"],"Cumi":["weed","pylons"]});
Object.assign(HOWTO,{"Kakap Merah":"Turunkan umpan ke dasar karang dalam, angkat sedikit agar tidak tersangkut.","Kakap Putih":"Lempar ke dekat kayu/tiang saat air pasang, tarik pelan.","Kerapu":"Begitu makan, langsung angkat kuat agar tidak masuk lubang karang.","GT":"Lempar popper jauh ke buih, sentak keras; pakai senar minimal PE 6.","Barakuda":"Pakai leader kawat, tarik umpan cepat.","Tenggiri":"Lempar jig logam jauh, gulung cepat; leader kawat tipis.","Tongkol":"Cari burung atau ikan meloncat, lempar jig ke gerombolan.","Baronang":"Kail kecil dengan lumut, pelampung, dekat batu berlumut.","Bawal":"Udang di kail kecil, jangan terlalu dalam.","Belanak":"Kail sangat kecil, umpan lumut/adonan di permukaan.","Cumi":"Malam hari di dekat lampu, sentak squid jig lalu diam."});
Object.assign(SCENE,{
 ancol:{face:0,shore:"Ujung pemecah ombak",me:[150,168],f:{rocks:[60,130],weed:[240,120],pylons:[200,80],snags:[90,85],deep:[150,30]}},
 seribu:{face:0,shore:"Ujung dermaga pulau",me:[150,165],f:{reef:[90,80],deep:[170,30],weed:[240,120],pylons:[200,140],rocks:[40,130]}},
 anyer:{face:270,shore:"Ujung dermaga",me:[150,165],f:{rocks:[50,120],reef:[210,70],weed:[100,90],pylons:[190,140],deep:[150,30]}},
 pelabuhanratu:{face:180,shore:"Batu karang tepi pantai",me:[150,168],f:{whitewater:[110,110],reef:[220,70],deep:[150,25],rocks:[40,135],sand:[250,140]}},
 karimunjawa:{face:0,shore:"Perahu di atas gosong",me:[150,165],f:{reef:[100,90],deep:[180,30],whitewater:[250,70],weed:[50,130],rocks:[240,135]}},
 serangan:{face:90,shore:"Perahu dekat mulut selat",me:[150,165],f:{whitewater:[230,70],reef:[90,80],deep:[160,25],weed:[50,130],pylons:[250,140]}},
 sekotong:{face:0,shore:"Perahu dekat Gili",me:[150,165],f:{reef:[90,85],whitewater:[230,80],deep:[160,25],weed:[50,135],rocks:[250,135]}},
 labuanbajo:{face:0,shore:"Perahu dekat pulau",me:[150,165],f:{whitewater:[230,75],reef:[90,85],deep:[160,25],rocks:[250,135],weed:[50,135]}}
});

/* ================= LOMBOK ================= */
const LBS=[
 ["trawangan","Gili Trawangan","Gili Matra, Lombok Utara",-8.352,116.040,"Pantai & karang (perahu)",["GT","Barakuda","Kakap Merah","Cumi","Tongkol"],{"Popper":["GT"],"Jig logam":["Barakuda","Tongkol","GT"],"Potongan cumi":["Kakap Merah"],"Squid jig":["Cumi"]},"Tepi karang yang turun ke selat Lombok untuk GT & barakuda. Kawasan konservasi Gili Matra: cek zona larangan & bayar retribusi.","Arus selat sangat kuat; mancing saat arus melambat."],
 ["bangsal","Pelabuhan Bangsal","Pemenang, Lombok Utara",-8.360,116.090,"Dermaga",["Cumi","Baronang","Kakap Putih","Barakuda"],{"Squid jig":["Cumi"],"Lumut":["Baronang"],"Udang hidup":["Kakap Putih"],"Jig logam":["Barakuda"]},"Tiang dermaga untuk kakap putih & barakuda; lampu dermaga malam untuk cumi. Hindari jalur kapal penyeberangan.","Malam hari, pasang naik."],
 ["medana","Teluk Medana","Tanjung, Lombok Utara",-8.350,116.150,"Teluk & marina",["Cumi","Baronang","Kakap Merah","Kerapu"],{"Squid jig":["Cumi"],"Lumut":["Baronang"],"Potongan cumi":["Kakap Merah","Kerapu"]},"Tepi karang di mulut teluk untuk kerapu; padang lamun untuk baronang & cumi.","Pagi & sore, air tenang."],
 ["nipah","Pantai Nipah","Malimbu, Lombok Utara",-8.430,116.050,"Pantai berbatu",["Baronang","Kakap Merah","Kerapu","Cumi"],{"Lumut":["Baronang"],"Potongan cumi":["Kakap Merah","Kerapu"],"Squid jig":["Cumi"]},"Batu karang di ujung pantai untuk kerapu & baronang.","Pasang naik."],
 ["senggigi","Senggigi","Batu Layar, Lombok Barat",-8.490,116.040,"Pantai & tanjung batu",["Kakap Merah","Kerapu","Cumi","Baronang","GT"],{"Potongan cumi":["Kakap Merah","Kerapu"],"Squid jig":["Cumi"],"Lumut":["Baronang"],"Popper":["GT"]},"Tanjung Batu Bolong & ujung pantai untuk kerapu dan kakap; malam di pantai untuk cumi.","Senja hingga malam."],
 ["ampenan","Pantai Ampenan","Kota Mataram",-8.570,116.070,"Pantai & muara",["Kakap Putih","Belanak","Bawal","Barakuda"],{"Udang hidup":["Kakap Putih","Bawal"],"Lumut":["Belanak"],"Soft plastic kecil":["Kakap Putih","Barakuda"]},"Muara sungai Jangkok untuk kakap putih & belanak; sisa dermaga tua untuk barakuda.","Pasang naik, terutama setelah hujan."],
 ["lembar","Pelabuhan Lembar","Lombok Barat",-8.730,116.070,"Dermaga & teluk",["Cumi","Kakap Putih","Baronang","Barakuda","Kerapu"],{"Squid jig":["Cumi"],"Udang hidup":["Kakap Putih"],"Lumut":["Baronang"],"Ikan umpan hidup":["Barakuda","Kerapu"]},"Tepi teluk berbakau untuk kakap putih; dermaga ikan untuk cumi & barakuda (patuhi larangan di area pelabuhan).","Malam, air pasang."],
 ["bangkobangko","Bangko-Bangko (Desert Point)","Sekotong Barat",-8.750,115.830,"Batu karang ujung barat",["GT","Tenggiri","Tongkol","Kerapu","Kakap Merah"],{"Popper":["GT"],"Jig logam":["Tenggiri","Tongkol"],"Potongan cumi":["Kerapu","Kakap Merah"]},"Karang dangkal dan buih ombak untuk GT; air biru di luar karang untuk tenggiri & tongkol. Ombak besar, sangat licin.","Subuh, ombak kecil, arus berganti."],
 ["selongbelanak","Selong Belanak","Praya Barat, Lombok Tengah",-8.870,116.170,"Pantai pasir & batu",["Kakap Putih","Belanak","Barakuda","GT"],{"Udang hidup":["Kakap Putih"],"Lumut":["Belanak"],"Metal lure":["Barakuda","GT"]},"Batu di kedua ujung pantai untuk GT & barakuda; parit pasir untuk kakap putih.","Pagi buta, laut tenang."],
 ["mawun","Pantai Mawun","Pujut, Lombok Tengah",-8.910,116.230,"Teluk pantai",["Kakap Merah","Kerapu","Barakuda","Cumi"],{"Potongan cumi":["Kakap Merah","Kerapu"],"Jig logam":["Barakuda"],"Squid jig":["Cumi"]},"Batu di sisi kiri & kanan teluk untuk kerapu dan kakap.","Pasang naik, pagi."],
 ["kuta","Kuta Mandalika","Pujut, Lombok Tengah",-8.900,116.280,"Pantai & tanjung batu",["GT","Kakap Merah","Barakuda","Kerapu","Cumi"],{"Popper":["GT"],"Potongan cumi":["Kakap Merah","Kerapu"],"Jig logam":["Barakuda"],"Squid jig":["Cumi"]},"Tanjung batu dan bukit Merese untuk GT; karang di teluk untuk kerapu.","Subuh & senja."],
 ["gerupuk","Teluk Gerupuk","Pujut, Lombok Tengah",-8.920,116.360,"Teluk & keramba (perahu)",["Kerapu","Kakap Merah","Cumi","Baronang","Barakuda"],{"Potongan cumi":["Kerapu","Kakap Merah"],"Squid jig":["Cumi"],"Lumut":["Baronang"],"Ikan umpan hidup":["Barakuda","Kerapu"]},"Sekitar keramba & bagan apung untuk kerapu dan cumi; mulut teluk untuk barakuda. Sewa perahu nelayan lokal.","Malam di bagan; pagi di mulut teluk."],
 ["ekas","Teluk Ekas","Jerowaru, Lombok Timur",-8.880,116.470,"Teluk & tebing",["GT","Kerapu","Tenggiri","Cumi","Kakap Merah"],{"Popper":["GT"],"Jig logam":["Tenggiri","GT"],"Potongan cumi":["Kerapu","Kakap Merah"],"Squid jig":["Cumi"]},"Tebing di mulut teluk untuk GT & tenggiri; dalam teluk untuk kerapu dan cumi.","Arus masuk teluk saat pasang."],
 ["tanjungringgit","Tanjung Ringgit","Jerowaru, Lombok Timur",-8.860,116.580,"Tebing batu tinggi",["GT","Tenggiri","Tongkol","Kerapu"],{"Popper":["GT"],"Jig logam":["Tenggiri","Tongkol"],"Ikan umpan hidup":["Kerapu","GT"]},"Ujung tenggara Lombok: tebing langsung ke laut dalam, spot GT terkenal. Sangat berbahaya, jangan sendirian.","Subuh, angin & ombak kecil."],
 ["labuhanhaji","Labuhan Haji","Lombok Timur",-8.680,116.580,"Pantai & dermaga",["Tongkol","Kakap Merah","Cumi","Barakuda"],{"Jig logam":["Tongkol","Barakuda"],"Potongan cumi":["Kakap Merah"],"Squid jig":["Cumi"]},"Ujung dermaga untuk tongkol & barakuda saat gerombolan masuk; malam untuk cumi.","Pagi saat burung terlihat menyelam."],
 ["kayangan","Pelabuhan Kayangan","Labuhan Lombok, Lombok Timur",-8.480,116.710,"Dermaga & selat Alas",["Cumi","Baronang","Tongkol","Barakuda"],{"Squid jig":["Cumi"],"Lumut":["Baronang"],"Jig logam":["Tongkol","Barakuda"]},"Pinggir pelabuhan Labuhan Lombok untuk cumi & baronang (jauhi jalur feri).","Malam, air pasang."],
 ["gilisulat","Gili Sulat & Gili Kondo","Sambelia, Lombok Timur",-8.320,116.710,"Pulau karang & bakau (perahu)",["Kerapu","GT","Kakap Merah","Baronang","Kakap Putih"],{"Potongan cumi":["Kerapu","Kakap Merah"],"Popper":["GT"],"Lumut":["Baronang"],"Udang hidup":["Kakap Putih"]},"Tubir di sekitar gili untuk kerapu & GT; tepi bakau Gili Sulat untuk kakap putih.","Pagi, arus sedang."]
];
LBS.forEach(([id,n,a,lat,lon,type,fish,bait,spots,tide])=>LOC.push({id,region:"ID",n,a,lat,lon,type,fish,bait,spots,tide}));
/* ================= SELURUH INDONESIA (per pulau) ================= */
const NUS_T={
 karang:[["GT","Kerapu","Kakap Merah","Tenggiri","Cumi"],{"Popper":["GT"],"Potongan cumi":["Kerapu","Kakap Merah"],"Jig logam":["Tenggiri","GT"],"Squid jig":["Cumi"]}],
 samudra:[["GT","Tenggiri","Tongkol","Barakuda","Kakap Merah"],{"Popper":["GT"],"Jig logam":["Tenggiri","Tongkol","Barakuda"],"Ikan umpan hidup":["Tenggiri","Barakuda","GT"],"Potongan cumi":["Kakap Merah"]}],
 muara:[["Kakap Putih","Belanak","Bawal","Barakuda","Baronang"],{"Udang hidup":["Kakap Putih","Bawal"],"Lumut":["Belanak","Baronang"],"Soft plastic kecil":["Kakap Putih","Barakuda"]}],
 dermaga:[["Cumi","Baronang","Kakap Putih","Barakuda","Tongkol"],{"Squid jig":["Cumi"],"Lumut":["Baronang"],"Udang hidup":["Kakap Putih"],"Jig logam":["Barakuda","Tongkol"]}],
 pulau:[["Kerapu","Kakap Merah","GT","Baronang","Cumi","Tongkol"],{"Potongan cumi":["Kerapu","Kakap Merah"],"Ikan umpan hidup":["GT","Kerapu"],"Lumut":["Baronang"],"Squid jig":["Cumi"],"Jig logam":["Tongkol","GT"]}]
};
const NUS_TXT={
 karang:["Tubir (tepi karang yang turun ke laut dalam) untuk kerapu & kakap merah; tanjung berarus untuk GT dan tenggiri.","Arus mulai bergerak, pagi atau sore."],
 samudra:["Tanjung & batu karang menghadap laut lepas untuk GT; perairan terbuka atau rumpon untuk tenggiri & tongkol. Ombak bisa besar, waspada.","Subuh & sore saat ombak tenang."],
 muara:["Muara sungai, bakau & tiang jembatan untuk kakap putih; dasar berlumpur untuk bawal; batu berlumut untuk belanak & baronang.","Pasang naik, terutama sore–malam."],
 dermaga:["Tiang dan ujung dermaga untuk kakap putih & barakuda; lampu dermaga malam untuk cumi; batu berlumut untuk baronang.","Pasang naik menjelang malam."],
 pulau:["Gosong karang & tubir di sekitar pulau untuk kerapu & kakap merah; sisi berarus untuk GT dan tongkol; dermaga malam untuk cumi. Cek zona taman laut.","Pergantian arus, pagi atau sore."]
};
const NUS=[
 // Sumatra & sekitarnya
 ["sabang","Sabang","Pulau Weh, Aceh","Sumatra",5.89,95.32,"Pulau & karang","pulau"],
 ["lhoknga","Lhoknga","Aceh Besar","Sumatra",5.47,95.24,"Pantai & batu karang","samudra"],
 ["pbanyak","Pulau Banyak","Aceh Singkil","Sumatra",2.20,97.30,"Pulau & karang","pulau"],
 ["sibolga","Sibolga","Sumatera Utara","Sumatra",1.74,98.78,"Teluk & dermaga","dermaga"],
 ["nias","Teluk Dalam","Nias Selatan","Sumatra",0.56,97.82,"Pantai & batu karang","samudra"],
 ["mentawai","Kepulauan Mentawai","Sumatera Barat","Sumatra",-2.10,99.60,"Pulau & karang (perahu)","samudra"],
 ["bungus","Teluk Bungus","Padang, Sumatera Barat","Sumatra",-1.04,100.40,"Teluk & pulau kecil","pulau"],
 ["bengkulu","Pantai Panjang","Bengkulu","Sumatra",-3.82,102.27,"Pantai & dermaga","dermaga"],
 ["krui","Krui","Pesisir Barat, Lampung","Sumatra",-5.19,103.93,"Pantai & batu karang","samudra"],
 ["kiluan","Teluk Kiluan","Tanggamus, Lampung","Sumatra",-5.76,105.09,"Teluk & karang","karang"],
 ["batam","Barelang","Batam, Kepulauan Riau","Sumatra",0.95,104.08,"Jembatan & pulau kecil","dermaga"],
 ["bintan","Bintan","Kepulauan Riau","Sumatra",1.08,104.50,"Pantai & karang","pulau"],
 ["anambas","Kepulauan Anambas","Kepulauan Riau","Sumatra",3.20,106.25,"Pulau & karang (perahu)","pulau"],
 ["natuna","Natuna","Kepulauan Riau","Sumatra",3.95,108.38,"Pulau & karang (perahu)","pulau"],
 ["bangka","Pantai Parai","Sungailiat, Bangka","Sumatra",-1.82,106.15,"Pantai batu granit","karang"],
 ["belitung","Tanjung Kelayang","Belitung","Sumatra",-2.55,107.68,"Pantai batu granit & pulau","pulau"],
 // Jawa
 ["ujungkulon","Ujung Kulon","Pandeglang, Banten","Jawa",-6.75,105.30,"Pantai & karang (perahu)","samudra"],
 ["tidung","Pulau Tidung","Kepulauan Seribu","Jawa",-5.80,106.50,"Dermaga & karang","pulau"],
 ["muaraangke","Muara Angke","Jakarta Utara","Jawa",-6.105,106.775,"Muara & dermaga","muara"],
 ["ujunggenteng","Ujung Genteng","Sukabumi, Jawa Barat","Jawa",-7.37,106.40,"Pantai & batu karang","samudra"],
 ["pangandaran","Pangandaran","Jawa Barat","Jawa",-7.70,108.65,"Pantai & tanjung","samudra"],
 ["cilacap","Teluk Penyu","Cilacap, Jawa Tengah","Jawa",-7.73,109.02,"Pantai, muara & dermaga","muara"],
 ["jepara","Pantai Kartini","Jepara, Jawa Tengah","Jawa",-6.59,110.64,"Pantai & dermaga","dermaga"],
 ["pacitan","Teleng Ria","Pacitan, Jawa Timur","Jawa",-8.22,111.08,"Teluk & batu karang","samudra"],
 ["sendangbiru","Sendang Biru","Malang, Jawa Timur","Jawa",-8.43,112.68,"Pelabuhan & rumpon","samudra"],
 ["grajagan","Grajagan","Banyuwangi, Jawa Timur","Jawa",-8.62,114.23,"Teluk & pantai","samudra"],
 ["situbondo","Pasir Putih","Situbondo, Jawa Timur","Jawa",-7.69,113.82,"Pantai & karang","karang"],
 ["bawean","Pulau Bawean","Gresik, Jawa Timur","Jawa",-5.78,112.65,"Pulau & karang","pulau"],
 ["madura","Pantai Lombang","Sumenep, Madura","Jawa",-6.90,114.05,"Pantai & dermaga","dermaga"],
 // Bali & Nusa Tenggara
 ["nusapenida","Nusa Penida","Klungkung, Bali","Bali & Nusa Tenggara",-8.73,115.54,"Pulau & tebing karang","samudra"],
 ["amed","Amed","Karangasem, Bali","Bali & Nusa Tenggara",-8.34,115.66,"Pantai & karang","karang"],
 ["pemuteran","Pemuteran","Buleleng, Bali","Bali & Nusa Tenggara",-8.14,114.65,"Pantai & karang","karang"],
 ["benoa","Pelabuhan Benoa","Denpasar, Bali","Bali & Nusa Tenggara",-8.75,115.21,"Dermaga & teluk","dermaga"],
 ["moyo","Pulau Moyo","Sumbawa, NTB","Bali & Nusa Tenggara",-8.25,117.55,"Pulau & karang","pulau"],
 ["huu","Hu'u","Dompu, NTB","Bali & Nusa Tenggara",-8.75,118.43,"Pantai & batu karang","samudra"],
 ["bima","Teluk Bima","Bima, NTB","Bali & Nusa Tenggara",-8.45,118.70,"Teluk & dermaga","dermaga"],
 ["waingapu","Waingapu","Sumba Timur, NTT","Bali & Nusa Tenggara",-9.65,120.26,"Pelabuhan & pantai","dermaga"],
 ["sumbabarat","Pantai Marosi","Sumba Barat, NTT","Bali & Nusa Tenggara",-9.75,119.38,"Pantai & batu karang","samudra"],
 ["maumere","Teluk Maumere","Sikka, Flores","Bali & Nusa Tenggara",-8.60,122.30,"Teluk & pulau kecil","pulau"],
 ["alor","Alor","Kalabahi, NTT","Bali & Nusa Tenggara",-8.22,124.53,"Selat & karang (perahu)","karang"],
 ["kupang","Kupang","NTT","Bali & Nusa Tenggara",-10.16,123.58,"Teluk & dermaga","dermaga"],
 ["rote","Pulau Rote","NTT","Bali & Nusa Tenggara",-10.80,123.15,"Pantai & karang","samudra"],
 // Kalimantan
 ["pontianak","Muara Kapuas","Pontianak, Kalbar","Kalimantan",-0.02,109.25,"Muara & sungai","muara"],
 ["ketapang","Ketapang","Kalimantan Barat","Kalimantan",-1.83,109.97,"Muara & pantai","muara"],
 ["karimata","Kepulauan Karimata","Kayong Utara, Kalbar","Kalimantan",-1.60,108.90,"Pulau & karang (perahu)","pulau"],
 ["kumai","Kumai","Kotawaringin Barat, Kalteng","Kalimantan",-2.73,111.73,"Muara & sungai","muara"],
 ["kotabaru","Kotabaru","Pulau Laut, Kalsel","Kalimantan",-3.23,116.23,"Selat & karang","karang"],
 ["balikpapan","Teluk Balikpapan","Kalimantan Timur","Kalimantan",-1.25,116.82,"Teluk, bakau & dermaga","muara"],
 ["derawan","Derawan","Berau, Kaltim","Kalimantan",2.28,118.24,"Pulau & karang","pulau"],
 ["maratua","Maratua","Berau, Kaltim","Kalimantan",2.23,118.60,"Atol & tubir (perahu)","karang"],
 ["tarakan","Tarakan","Kalimantan Utara","Kalimantan",3.30,117.58,"Pantai, bakau & dermaga","muara"],
 // Sulawesi
 ["spermonde","Kepulauan Spermonde","Makassar, Sulsel","Sulawesi",-5.05,119.30,"Pulau & karang","pulau"],
 ["losari","Pantai Losari","Makassar, Sulsel","Sulawesi",-5.145,119.405,"Pantai & dermaga","dermaga"],
 ["selayar","Pulau Selayar","Sulawesi Selatan","Sulawesi",-6.10,120.46,"Pulau & karang","pulau"],
 ["takabonerate","Taka Bonerate","Selayar, Sulsel","Sulawesi",-6.80,121.10,"Atol & tubir (perahu)","karang"],
 ["wakatobi","Wakatobi","Sulawesi Tenggara","Sulawesi",-5.32,123.60,"Pulau & karang","karang"],
 ["kendari","Teluk Kendari","Sulawesi Tenggara","Sulawesi",-3.97,122.60,"Teluk & pulau kecil","pulau"],
 ["banggai","Kepulauan Banggai","Sulawesi Tengah","Sulawesi",-1.60,123.50,"Pulau & karang","pulau"],
 ["togean","Kepulauan Togean","Tojo Una-Una, Sulteng","Sulawesi",-0.40,121.95,"Pulau & karang","pulau"],
 ["palu","Teluk Palu","Sulawesi Tengah","Sulawesi",-0.80,119.85,"Teluk & dermaga","dermaga"],
 ["gorontalo","Teluk Tomini","Gorontalo","Sulawesi",0.50,123.06,"Teluk & tubir","karang"],
 ["bunaken","Bunaken","Manado, Sulut","Sulawesi",1.62,124.76,"Pulau & tubir","karang"],
 ["lembeh","Selat Lembeh","Bitung, Sulut","Sulawesi",1.45,125.23,"Selat & dermaga","dermaga"],
 ["sangihe","Kepulauan Sangihe","Sulawesi Utara","Sulawesi",3.60,125.50,"Pulau & laut dalam (perahu)","samudra"],
 // Maluku & Papua
 ["ambon","Teluk Ambon","Ambon, Maluku","Maluku & Papua",-3.68,128.15,"Teluk & dermaga","dermaga"],
 ["banda","Banda Neira","Maluku Tengah","Maluku & Papua",-4.53,129.90,"Pulau & tubir","karang"],
 ["kei","Kepulauan Kei","Maluku Tenggara","Maluku & Papua",-5.65,132.73,"Pulau & karang","pulau"],
 ["saumlaki","Saumlaki","Kepulauan Tanimbar","Maluku & Papua",-7.98,131.30,"Teluk & karang","pulau"],
 ["ternate","Ternate","Maluku Utara","Maluku & Papua",0.79,127.38,"Pulau & laut dalam","samudra"],
 ["halmahera","Halmahera","Maluku Utara","Maluku & Papua",0.60,127.90,"Teluk & karang (perahu)","karang"],
 ["morotai","Morotai","Maluku Utara","Maluku & Papua",2.05,128.30,"Pulau & tubir (perahu)","samudra"],
 ["rajaampat","Raja Ampat","Papua Barat Daya","Maluku & Papua",-0.55,130.65,"Pulau & karang (perahu)","pulau"],
 ["sorong","Sorong","Papua Barat Daya","Maluku & Papua",-0.88,131.25,"Dermaga & pulau kecil","dermaga"],
 ["kaimana","Kaimana","Papua Barat","Maluku & Papua",-3.66,133.75,"Teluk & tubir","karang"],
 ["biak","Biak","Papua","Maluku & Papua",-1.18,136.08,"Pantai & tubir","samudra"],
 ["jayapura","Teluk Youtefa","Jayapura, Papua","Maluku & Papua",-2.60,140.75,"Teluk & dermaga","dermaga"],
 ["merauke","Merauke","Papua Selatan","Maluku & Papua",-8.48,140.38,"Muara & pantai","muara"]
];
NUS.forEach(([id,n,a,g,lat,lon,type,t])=>{const[f,b]=NUS_T[t];LOC.push({id,region:"ID",g,n,a,lat,lon,type,fish:f.slice(),bait:JSON.parse(JSON.stringify(b)),spots:NUS_TXT[t][0],tide:NUS_TXT[t][1]})});
const ISL_OLD={ancol:"Jawa",seribu:"Jawa",anyer:"Jawa",pelabuhanratu:"Jawa",karimunjawa:"Jawa",serangan:"Bali & Nusa Tenggara",labuanbajo:"Bali & Nusa Tenggara"};
const islOf=s=>s.g||ISL_OLD[s.id]||"";
const PROV={sabang:"Aceh",lhoknga:"Aceh",pbanyak:"Aceh",sibolga:"Sumatera Utara",nias:"Sumatera Utara",mentawai:"Sumatera Barat",bungus:"Sumatera Barat",bengkulu:"Bengkulu",krui:"Lampung",kiluan:"Lampung",batam:"Kepulauan Riau",bintan:"Kepulauan Riau",anambas:"Kepulauan Riau",natuna:"Kepulauan Riau",bangka:"Kepulauan Bangka Belitung",belitung:"Kepulauan Bangka Belitung",
ujungkulon:"Banten",anyer:"Banten",tidung:"DKI Jakarta",muaraangke:"DKI Jakarta",ancol:"DKI Jakarta",seribu:"DKI Jakarta",ujunggenteng:"Jawa Barat",pelabuhanratu:"Jawa Barat",pangandaran:"Jawa Barat",cilacap:"Jawa Tengah",jepara:"Jawa Tengah",karimunjawa:"Jawa Tengah",pacitan:"Jawa Timur",sendangbiru:"Jawa Timur",grajagan:"Jawa Timur",situbondo:"Jawa Timur",bawean:"Jawa Timur",madura:"Jawa Timur",
nusapenida:"Bali",amed:"Bali",pemuteran:"Bali",benoa:"Bali",serangan:"Bali",moyo:"Nusa Tenggara Barat",huu:"Nusa Tenggara Barat",bima:"Nusa Tenggara Barat",waingapu:"Nusa Tenggara Timur",sumbabarat:"Nusa Tenggara Timur",maumere:"Nusa Tenggara Timur",alor:"Nusa Tenggara Timur",kupang:"Nusa Tenggara Timur",rote:"Nusa Tenggara Timur",labuanbajo:"Nusa Tenggara Timur",
pontianak:"Kalimantan Barat",ketapang:"Kalimantan Barat",karimata:"Kalimantan Barat",kumai:"Kalimantan Tengah",kotabaru:"Kalimantan Selatan",balikpapan:"Kalimantan Timur",derawan:"Kalimantan Timur",maratua:"Kalimantan Timur",tarakan:"Kalimantan Utara",
spermonde:"Sulawesi Selatan",losari:"Sulawesi Selatan",selayar:"Sulawesi Selatan",takabonerate:"Sulawesi Selatan",wakatobi:"Sulawesi Tenggara",kendari:"Sulawesi Tenggara",banggai:"Sulawesi Tengah",togean:"Sulawesi Tengah",palu:"Sulawesi Tengah",gorontalo:"Gorontalo",bunaken:"Sulawesi Utara",lembeh:"Sulawesi Utara",sangihe:"Sulawesi Utara",
ambon:"Maluku",banda:"Maluku",kei:"Maluku",saumlaki:"Maluku",ternate:"Maluku Utara",halmahera:"Maluku Utara",morotai:"Maluku Utara",rajaampat:"Papua Barat Daya",sorong:"Papua Barat Daya",kaimana:"Papua Barat",biak:"Papua",jayapura:"Papua",merauke:"Papua Selatan"};
const provOf=s=>{if(inLombok(s))return "Nusa Tenggara Barat";if(PROV[s.id])return PROV[s.id];if(s.lat==null)return "";let b="",d=150;LOC.forEach(x=>{const g=PROV[x.id]||(inLombok(x)?"Nusa Tenggara Barat":"");if(!g)return;const k=km(s.lat,s.lon,x.lat,x.lon);if(k<d){d=k;b=g}});return b};
const ISL_ORDER=["Sumatra","Jawa","Bali & Nusa Tenggara","Kalimantan","Sulawesi","Maluku & Papua"];


/* ===== Tambahan Lombok Timur & Lombok Tengah (koordinat perkiraan) ===== */
const TPL={
 tebing:{type:"Tebing & batu karang",fish:["GT","Kerapu","Kakap Merah","Tenggiri","Barakuda"],bait:{"Popper":["GT"],"Jig logam":["Tenggiri","Barakuda","GT"],"Potongan cumi":["Kerapu","Kakap Merah"],"Ikan umpan hidup":["Kerapu","Barakuda"]},s:"Ujung batu yang langsung menghadap laut dalam untuk GT & tenggiri; celah karang di bawah tebing untuk kerapu. Ombak selatan besar, jangan sendirian.",t:"Subuh saat ombak kecil, awal pasang."},
 teluk:{type:"Teluk pantai & batu",fish:["Kakap Merah","Kerapu","Baronang","Cumi","Barakuda"],bait:{"Potongan cumi":["Kakap Merah","Kerapu"],"Lumut":["Baronang"],"Squid jig":["Cumi"],"Jig logam":["Barakuda"]},s:"Batu di kedua sisi teluk untuk kerapu & baronang; tengah teluk yang berpasir untuk kakap; malam di pantai untuk cumi.",t:"Pasang naik, pagi atau senja."},
 pelabuhan:{type:"Pelabuhan & dermaga ikan",fish:["Cumi","Baronang","Tongkol","Barakuda","Kakap Putih"],bait:{"Squid jig":["Cumi"],"Lumut":["Baronang"],"Jig logam":["Tongkol","Barakuda"],"Udang hidup":["Kakap Putih"]},s:"Ujung dermaga dan tiang untuk barakuda & kakap putih; lampu kapal malam hari untuk cumi. Jauhi jalur kapal & patuhi larangan pelabuhan.",t:"Malam, air pasang."},
 gili:{type:"Pulau karang (perahu)",fish:["Kerapu","GT","Kakap Merah","Baronang","Cumi"],bait:{"Potongan cumi":["Kerapu","Kakap Merah"],"Popper":["GT"],"Lumut":["Baronang"],"Squid jig":["Cumi"]},s:"Tubir di sekeliling gili untuk kerapu & kakap merah; sisi berarus untuk GT. Sewa perahu nelayan setempat.",t:"Pagi, arus sedang."},
 pasir:{type:"Pantai pasir & muara",fish:["Kakap Putih","Belanak","Bawal","Barakuda"],bait:{"Udang hidup":["Kakap Putih","Bawal"],"Lumut":["Belanak"],"Metal lure":["Barakuda"]},s:"Parit pasir dan muara kecil untuk kakap putih & belanak; ujung pantai berbatu untuk barakuda.",t:"Pasang naik, subuh."}
};
[
 // Lombok Timur
 ["pantaipink","Pantai Pink (Tangsi)","Jerowaru, Lombok Timur",-8.857,116.600,"teluk"],
 ["kaliantan","Pantai Kaliantan","Jerowaru, Lombok Timur",-8.875,116.520,"tebing"],
 ["tanjungbloam","Tanjung Bloam","Jerowaru, Lombok Timur",-8.870,116.560,"tebing"],
 ["cemaralt","Pantai Cemara","Jerowaru, Lombok Timur",-8.830,116.470,"pasir"],
 ["tanjungluar","Tanjung Luar","Keruak, Lombok Timur",-8.760,116.505,"pelabuhan"],
 ["gilikere","Gili Kere","Teluk Jukung, Lombok Timur",-8.790,116.515,"gili"],
 ["gilipetagan","Gili Petagan","Pringgabaya, Lombok Timur",-8.455,116.720,"gili"],
 ["labuhanpandan","Labuhan Pandan","Sambelia, Lombok Timur",-8.355,116.680,"pelabuhan"],
 ["gililampu","Gili Lampu","Sambelia, Lombok Timur",-8.300,116.685,"gili"],
 ["gilibidara","Gili Bidara","Sambelia, Lombok Timur",-8.330,116.715,"gili"],
 ["sambelia","Pantai Sambelia","Sambelia, Lombok Timur",-8.375,116.665,"pasir"],
 ["transat","Pantai Trans (Ketapang)","Pringgabaya, Lombok Timur",-8.560,116.660,"pasir"],
 ["gilire","Gili Re","Jerowaru, Lombok Timur",-8.870,116.430,"gili"],
 // Lombok Tengah
 ["mawi","Pantai Mawi","Pujut, Lombok Tengah",-8.905,116.135,"tebing"],
 ["semeti","Pantai Semeti","Pujut, Lombok Tengah",-8.905,116.120,"tebing"],
 ["torok","Pantai Torok","Praya Barat Daya, Lombok Tengah",-8.865,116.070,"teluk"],
 ["telawas","Pantai Telawas","Praya Barat, Lombok Tengah",-8.890,116.105,"teluk"],
 ["pengantap","Pantai Pengantap","Praya Barat, Lombok Tengah",-8.890,116.155,"teluk"],
 ["areguling","Pantai Are Guling","Pujut, Lombok Tengah",-8.910,116.185,"teluk"],
 ["tampah","Pantai Tampah","Pujut, Lombok Tengah",-8.900,116.210,"tebing"],
 ["seger","Pantai Seger","Pujut, Lombok Tengah",-8.905,116.310,"tebing"],
 ["merese","Bukit Merese","Pujut, Lombok Tengah",-8.912,116.325,"tebing"],
 ["tanjungaan","Pantai Tanjung Aan & Batu Payung","Pujut, Lombok Tengah",-8.910,116.335,"teluk"],
 ["bumbang","Teluk Bumbang","Pujut, Lombok Tengah",-8.915,116.350,"pelabuhan"],
 ["serenting","Pantai Serenting","Pujut, Lombok Tengah",-8.925,116.390,"tebing"]
].forEach(([id,n,a,lat,lon,k])=>{const t=TPL[k];LOC.push({id,region:"ID",n,a,lat,lon,type:t.type,fish:t.fish.slice(),bait:JSON.parse(JSON.stringify(t.bait)),spots:t.s,tide:t.t})});
{const sk=LOC.find(l=>l.id==="sekotong");sk.region="ID";sk.n="Gili Nanggu & Gili Sudak";sk.a="Sekotong, Lombok Barat";sk.lat=-8.71;sk.lon=115.99;}
const MAPS_LB={B:{n:-8.18,s:-8.98,w:115.78,e:116.78},k:1,label:"SELAT LOMBOK · SELAT ALAS",poly:[[[-8.22,116.40],[-8.33,116.18],[-8.36,116.07],[-8.50,116.045],[-8.65,116.06],[-8.72,115.95],[-8.745,115.82],[-8.82,115.86],[-8.80,116.00],[-8.88,116.10],[-8.93,116.28],[-8.89,116.45],[-8.88,116.58],[-8.75,116.61],[-8.55,116.70],[-8.38,116.64],[-8.27,116.52]],[[-8.345,116.025],[-8.345,116.045],[-8.36,116.04]],[[-8.345,116.055],[-8.345,116.07],[-8.36,116.063]],[[-8.355,116.075],[-8.355,116.09],[-8.37,116.083]],[[-8.70,115.97],[-8.70,116.0],[-8.725,115.99]]]};
// skema peta lempar otomatis untuk spot tanpa skema khusus
function autoScene(s){
  const t=(s.type||"").toLowerCase(),f={deep:[150,30]};
  if(/dermaga|pelabuhan|marina/.test(t))f.pylons=[200,130];
  if(/batu|tebing|tanjung|karang/.test(t)){f.rocks=[60,130];f.whitewater=[230,80]}
  if(/pantai|pasir|muara/.test(t))f.sand=[230,135];
  if(/teluk|lamun|bakau/.test(t)){f.weed=[60,90];f.snags=[250,125]}
  f.reef=f.reef||[110,75];if(!f.weed)f.weed=[45,105];
  return{face:0,shore:s.type||"Tepi air",me:[150,168],f};
}


/* ================= AUSTRALIA: spot utama tiap negara bagian ================= */
Object.assign(SP,{
 "Barramundi":{b:"#c9cdc6",d:"#5e6a5c",fin:"#8d9686",h:.3,pat:"",min:58,lim:"QLD 58–120 cm, NT min. 55 cm; ada musim tutup (Nov–Jan) di QLD",ciri:"Perak-perunggu, kepala runcing cekung, mata merah menyala di gelap, ekor membulat.",lat:"Lates calcarifer"},
 "Mangrove Jack":{b:"#c9533f",d:"#8d2f22",fin:"#b9483a",h:.38,pat:"",min:35,lim:"QLD min. 35 cm",ciri:"Merah tembaga, gigi taring tajam, hidup di bawah akar bakau dan kayu.",lat:"Lutjanus argentimaculatus"},
 "King George Whiting":{b:"#e2d6b6",d:"#a8926a",fin:"#cdbb93",h:.22,pat:"spots",min:32,lim:"SA min. 32 cm, VIC min. 27 cm, WA min. 28 cm",ciri:"Ramping, moncong runcing, bintik-bintik cokelat di badan keemasan.",lat:"Sillaginodes punctatus"},
 "Spanish Mackerel":{b:"#d6dde2",d:"#3f5f7a",fin:"#7f95a8",h:.18,pat:"bars",min:75,lim:"QLD min. 75 cm, maks 3",ciri:"Panjang ramping, punggung biru, garis vertikal bergelombang, gigi tajam.",lat:"Scomberomorus commerson"},
 "Coral Trout":{b:"#e46a4c",d:"#a8382a",fin:"#d05a40",h:.36,pat:"bluespots",min:38,lim:"QLD min. 38 cm, maks 7; ada penutupan musiman",ciri:"Merah-oranye dengan bintik biru kecil, mulut besar, hidup di karang.",lat:"Plectropomus leopardus"},
 "Golden Trevally":{b:"#e8d68a",d:"#a8913f",fin:"#e3c24a",h:.42,pat:"bars",min:0,lim:"Cek aturan negara bagian",ciri:"Kuning keemasan dengan garis vertikal gelap saat muda, bibir tebal.",lat:"Gnathanodon speciosus"}
});
Object.assign(HABITAT,{"Barramundi":["snags","pylons","rocks"],"Mangrove Jack":["snags","rocks","pylons"],"King George Whiting":["sand","weed"],"Spanish Mackerel":["deep","whitewater"],"Coral Trout":["reef"],"Golden Trevally":["sand","deep"]});
Object.assign(HOWTO,{"Barramundi":"Lempar soft plastic/hardbody ke dekat kayu saat air pasang mulai surut, gulung pelan.","Mangrove Jack":"Lempar sedekat mungkin ke akar bakau, langsung tarik kuat begitu disambar.","King George Whiting":"Cacing atau potongan cumi kecil di dasar pasir dekat lamun, pemberat ringan.","Spanish Mackerel":"Trolling minnow atau umpan ikan utuh di tepi karang/tubir; leader kawat.","Coral Trout":"Umpan ikan hidup atau soft plastic di karang, tahan kuat agar tidak masuk lubang.","Golden Trevally":"Soft plastic atau jig kecil di flat pasir, gulung cepat."});
Object.assign(BAITINFO,{"Hardbody lure":"Umpan tiruan ikan dengan lidah selam; untuk barramundi & mangrove jack."});
const FISHBAIT={"Snapper":["Pilchard utuh","Soft plastic besar","Potongan cumi"],"Kingfish":["Squid hidup","Jig logam","Soft plastic besar"],"Flathead":["Soft plastic kecil","Pilchard utuh"],"Bream":["Udang mentah","Soft plastic kecil"],"Whiting":["Cacing laut","Udang mentah"],"Squid":["Squid jig"],"Tailor":["Pilchard utuh","Metal lure"],"Salmon Australia":["Metal lure","Pilchard utuh"],"Mulloway":["Squid hidup","Potongan cumi"],"Luderick":["Rumput laut hijau"],"Trevally":["Udang mentah","Soft plastic kecil"],"Drummer":["Roti"],"Barramundi":["Hardbody lure","Soft plastic besar","Udang hidup"],"Mangrove Jack":["Hardbody lure","Ikan umpan hidup"],"King George Whiting":["Cacing laut","Potongan cumi"],"Spanish Mackerel":["Minnow troll","Ikan umpan hidup"],"Coral Trout":["Ikan umpan hidup","Soft plastic besar"],"Golden Trevally":["Soft plastic kecil","Jig logam"],"GT":["Popper","Jig logam"]};
const AUTPL={pantai:"Pantai & batu",muara:"Muara & sungai",dermaga:"Dermaga & teluk",karang:"Karang & pulau (perahu)",breakwall:"Pemecah ombak"};
const AUSPOT={pantai:"Ujung batu untuk tailor & salmon saat subuh/senja; parit pasir di pantai untuk whiting & flathead.",muara:"Tepi bakau, kayu tenggelam, dan alur dalam saat arus berganti; jembatan & tiang untuk predator.",dermaga:"Tiang dermaga untuk bream & trevally; lampu dermaga malam untuk cumi; drop-off pasir untuk flathead/whiting.",karang:"Tubir & karang dalam dengan perahu; cek zona taman laut sebelum memancing.",breakwall:"Ujung pemecah ombak di arus masuk-keluar untuk tailor, salmon, mulloway; tengah tembok untuk bream & luderick."};
[
 // NSW
 ["nelsonbay","Nelson Bay","Port Stephens","NSW",-32.716,152.143,"dermaga",["Snapper","Kingfish","Flathead","Bream","Squid","Tailor"]],
 ["newcastle","Newcastle Breakwall","Newcastle","NSW",-32.918,151.795,"breakwall",["Tailor","Salmon Australia","Bream","Mulloway","Luderick"]],
 ["swansea","Swansea Channel","Lake Macquarie","NSW",-33.087,151.643,"muara",["Flathead","Bream","Whiting","Squid","Trevally"]],
 ["theentrance","The Entrance","Central Coast","NSW",-33.343,151.503,"muara",["Flathead","Bream","Whiting","Luderick"]],
 ["portmacquarie","Port Macquarie","Hastings River","NSW",-31.431,152.918,"breakwall",["Mulloway","Bream","Flathead","Whiting","Trevally"]],
 ["coffs","Coffs Harbour","Mid North Coast","NSW",-30.302,153.147,"dermaga",["Snapper","Spanish Mackerel","Tailor","Bream","Trevally"]],
 ["yamba","Yamba","Clarence River","NSW",-29.433,153.360,"muara",["Mulloway","Bream","Flathead","Mangrove Jack","Whiting"]],
 ["ballina","Ballina","Richmond River","NSW",-28.875,153.590,"breakwall",["Mulloway","Bream","Mangrove Jack","Flathead","Tailor"]],
 ["jervisbay","Jervis Bay","Huskisson","NSW",-35.039,150.672,"dermaga",["Snapper","Kingfish","Squid","Whiting","Salmon Australia"]],
 ["batemans","Batemans Bay","Clyde River","NSW",-35.708,150.183,"muara",["Flathead","Bream","Snapper","Luderick","Mulloway"]],
 ["eden","Eden","Twofold Bay","NSW",-37.064,149.906,"dermaga",["Snapper","Kingfish","Salmon Australia","Tailor","Squid"]],
 // QLD
 ["goldcoast","Gold Coast Seaway","Southport","QLD",-27.940,153.430,"breakwall",["Flathead","Bream","Trevally","Mulloway","Tailor"]],
 ["wynnum","Wynnum–Manly","Moreton Bay, Brisbane","QLD",-27.445,153.180,"dermaga",["Bream","Whiting","Flathead","Squid","Snapper"]],
 ["bribie","Bribie Island","Pumicestone Passage","QLD",-27.070,153.200,"pantai",["Whiting","Flathead","Bream","Tailor","Mangrove Jack"]],
 ["herveybay","Hervey Bay","Fraser Coast (K'gari)","QLD",-25.290,152.850,"dermaga",["Whiting","Golden Trevally","Snapper","Spanish Mackerel","Tailor"]],
 ["gladstone","Gladstone","Gladstone Harbour","QLD",-23.840,151.260,"muara",["Barramundi","Mangrove Jack","Coral Trout","Spanish Mackerel"]],
 ["whitsundays","Whitsundays","Airlie Beach","QLD",-20.270,148.720,"karang",["Coral Trout","Spanish Mackerel","GT","Golden Trevally"]],
 ["townsville","Townsville","Ross River & Strand","QLD",-19.250,146.820,"muara",["Barramundi","Mangrove Jack","Coral Trout","Spanish Mackerel"]],
 ["cairns","Cairns","Trinity Inlet","QLD",-16.920,145.780,"muara",["Barramundi","Mangrove Jack","GT","Coral Trout"]],
 ["weipa","Weipa","Cape York","QLD",-12.630,141.870,"muara",["Barramundi","GT","Spanish Mackerel","Golden Trevally"]],
 // NT
 ["darwin","Darwin Harbour","Darwin","NT",-12.460,130.840,"dermaga",["Barramundi","Golden Trevally","Spanish Mackerel","Mangrove Jack"]],
 ["maryriver","Mary River","Top End","NT",-12.400,131.650,"muara",["Barramundi","Mangrove Jack"]],
 // WA
 ["broome","Broome","Roebuck Bay","WA",-17.960,122.240,"pantai",["Barramundi","GT","Spanish Mackerel","Golden Trevally"]],
 ["exmouth","Exmouth","Ningaloo","WA",-21.930,114.130,"karang",["GT","Spanish Mackerel","Coral Trout","Golden Trevally"]],
 ["fremantle","Fremantle","Perth","WA",-32.055,115.740,"breakwall",["Tailor","Salmon Australia","King George Whiting","Squid","Snapper"]],
 ["albany","Albany","King George Sound","WA",-35.030,117.880,"pantai",["Salmon Australia","King George Whiting","Squid","Tailor"]],
 // SA
 ["glenelg","Glenelg & Brighton Jetty","Adelaide","SA",-34.980,138.510,"dermaga",["Squid","King George Whiting","Snapper","Salmon Australia"]],
 ["portlincoln","Port Lincoln","Eyre Peninsula","SA",-34.730,135.870,"dermaga",["King George Whiting","Snapper","Kingfish","Squid","Salmon Australia"]],
 ["kangarooisland","Kangaroo Island","Kingscote","SA",-35.650,137.640,"pantai",["King George Whiting","Salmon Australia","Squid","Snapper"]],
 // VIC
 ["stkilda","St Kilda Pier","Port Phillip, Melbourne","VIC",-37.866,144.970,"dermaga",["Snapper","Squid","King George Whiting","Flathead"]],
 ["sanremo","San Remo","Western Port","VIC",-38.520,145.370,"dermaga",["Snapper","King George Whiting","Squid","Salmon Australia"]],
 ["lakesentrance","Lakes Entrance","Gippsland Lakes","VIC",-37.880,147.980,"muara",["Bream","Flathead","Salmon Australia","Tailor"]],
 ["portland","Portland","Portland Bay","VIC",-38.350,141.610,"dermaga",["Kingfish","Snapper","Salmon Australia","Squid"]],
 // TAS
 ["hobart","Sungai Derwent","Hobart","TAS",-42.880,147.330,"muara",["Flathead","Squid","Salmon Australia","Bream"]],
 ["sthelens","St Helens","Georges Bay","TAS",-41.320,148.250,"muara",["Bream","Flathead","Salmon Australia","Squid"]],
 ["georgetown","George Town","Sungai Tamar","TAS",-41.100,146.820,"muara",["Snapper","Flathead","Squid","Salmon Australia"]]
].forEach(([id,n,a,st,lat,lon,k,fish])=>{const bait={};fish.forEach(f=>(FISHBAIT[f]||["Udang mentah"]).forEach(b=>(bait[b]=bait[b]||[]).push(f)));
  LOC.push({id,region:"AU",st,n,a:a+", "+st,lat,lon,type:AUTPL[k],fish,bait,spots:AUSPOT[k],tide:k==="karang"?"Arus sedang, pagi hari; perhatikan angin & gelombang.":"Pergantian arus, subuh & senja."})});
LOC.forEach(l=>{if(l.region==="AU"&&!l.st)l.st="Sydney"});
const AU_OUTLINE=[[-10.7,142.5],[-12.6,141.6],[-14.5,141.5],[-17.4,140.8],[-16.5,139.3],[-15.0,135.6],[-12.2,136.8],[-11.2,132.6],[-12.3,130.4],[-13.8,129.6],[-15.0,128.0],[-14.0,126.0],[-16.4,123.0],[-18.0,122.2],[-19.7,121.1],[-20.4,117.2],[-21.8,114.1],[-24.0,113.5],[-26.6,113.8],[-28.8,114.6],[-31.8,115.7],[-34.3,115.0],[-35.0,116.6],[-34.9,118.0],[-33.9,123.0],[-32.3,126.0],[-31.6,129.0],[-31.5,131.2],[-32.1,133.5],[-34.0,135.2],[-34.9,135.8],[-33.0,137.8],[-35.0,138.1],[-35.8,138.1],[-35.6,139.4],[-37.0,139.8],[-38.0,140.6],[-38.4,141.5],[-38.8,143.5],[-38.0,144.4],[-38.5,145.0],[-38.9,146.4],[-37.8,148.0],[-37.5,149.9],[-36.0,150.1],[-34.5,150.9],[-33.2,151.6],[-32.0,152.5],[-30.0,153.3],[-28.2,153.6],[-26.6,153.1],[-24.9,152.4],[-23.5,151.0],[-22.1,149.6],[-20.6,148.7],[-19.3,147.1],[-18.0,146.0],[-15.9,145.4],[-14.4,144.2],[-12.0,143.3]];
const TAS_OUTLINE=[[-40.7,144.7],[-40.9,146.9],[-40.8,148.3],[-42.2,148.2],[-43.3,147.3],[-43.6,146.0],[-42.2,145.2]];
/* ================= PERINGKAT SPOT PER IKAN ================= */
function catchRows(){return (typeof feed!=="undefined"&&feed?feed:[]).map(x=>({f:x.f||x.fish,sid:x.sid||x.spot_id,t:x.t||Date.parse(x.created_at||0),len:x.len||x.length_cm}))}
function rankSpots(fish,rg){
  const rows=catchRows().filter(r=>r.f===fish&&Date.now()-r.t<90*864e5);
  return LOC.filter(l=>!rg||l.region===rg).map(l=>{
    const d=spotData(l),i=d.fish.indexOf(fish),n=rows.filter(r=>r.sid===l.id).length;
    if(i<0&&!n)return null;
    const baits=Object.entries(d.bait).filter(([,fs])=>fs.includes(fish)).map(([b])=>b);
    const base=i<0?20:Math.max(30,70-i*9)+Math.min(10,baits.length*4);
    const score=Math.min(100,Math.round(base+Math.min(30,n*6)));
    return{l,score,n,baits};
  }).filter(Boolean).sort((a,b)=>b.score-a.score||b.n-a.n);
}
const stars=s=>{const k=Math.max(1,Math.round(s/20));return "★".repeat(k)+"☆".repeat(5-k)};
function rankListHtml(fish,limit){
  const r=rankSpots(fish,region).slice(0,limit||10);
  if(!r.length)return `<p class="note">Belum ada spot untuk ${esc(fish)} di wilayah ini.</p>`;
  return `<div class="list rank">${r.map((x,i)=>`<button data-rank="${x.l.id}"><span><b>${i+1}. ${esc(x.l.n)}</b><br><span class="note">${esc(x.l.a||"")}${x.baits.length?" · "+esc(x.baits.slice(0,2).join(", ")):""}</span></span><span style="text-align:right"><span class="stars" aria-label="${x.score} dari 100">${stars(x.score)}</span><br><span class="note">${x.n?x.n+" tangkapan/90 hr":"data panduan"}</span></span></button>`).join("")}</div>`;
}
function rankCardHtml(){
  const fishes=[...new Set(LOC.filter(l=>l.region===region).flatMap(l=>spotData(l).fish))].filter(f=>SP[f]).sort();
  let sel=store.get("mm_rank_"+region,fishes[0]);if(!fishes.includes(sel))sel=fishes[0];
  return `<div class="card"><h3>🏆 Spot terbaik per ikan</h3><p class="note">Peringkat dari data panduan aplikasi, ditambah tangkapan komunitas 90 hari terakhir.</p>
   <select class="f" id="rankFish" aria-label="Pilih ikan untuk peringkat">${fishes.map(f=>`<option ${f===sel?"selected":""}>${f}</option>`).join("")}</select>
   <div style="margin-top:8px">${rankListHtml(sel,10)}</div></div>`;
}
function bindRank(){
  const rf=document.getElementById("rankFish");if(rf)rf.onchange=e=>{store.set("mm_rank_"+region,e.target.value);render()};
  document.querySelectorAll("[data-rank]").forEach(b=>b.onclick=()=>setSpot(b.dataset.rank));
}

let region=store.get("mm_region","AU");if(region==="LB")region="ID";let mapZoom=store.get("mm_zoom","all");
const inLombok=s=>s.lat<-8.15&&s.lat>-9.0&&s.lon>115.78&&s.lon<116.78;
const regionOf=(lat,lon)=>lat>-11.5?(lon!=null&&lat<-8.15&&lat>-9.0&&lon>115.78&&lon<116.78?"ID":"ID"):"AU";
const tzLL=(lat,lon)=>lat>-11.5?(lon<114.6?7:lon<126.5?8:9):sydOffset(new Date());
const tzName=(lat,lon)=>lat<=-11.5?"Australia/Sydney":(lon<114.6?"Asia/Jakarta":lon<126.5?"Asia/Makassar":"Asia/Jayapura");
const MAPS={
 AU:{B:{n:-33.50,s:-34.13,w:151.05,e:151.36},k:1.2,label:"TASMAN SEA"},
 ID:{B:{n:6,s:-11,w:95,e:141.5},k:1,label:"SAMUDRA HINDIA"}
};
MAPS.LB=MAPS_LB;
const ISL=[[[5.5,95.3],[4,98],[1,102],[-2,105],[-5.9,105.8],[-5.5,104.5],[-3,102],[0,99.5],[2,98],[5,95.5]],[[-6,105.8],[-6.2,108],[-6.9,112.7],[-7.7,114.5],[-8.5,114.4],[-8.3,111],[-7.7,108],[-7,106],[-6.8,105.4]],[[1,109],[4.3,117.5],[1,119],[-1,116.8],[-4,114.5],[-3,110.5],[-1,109.5]],[[1.5,124.8],[0.8,120.8],[-1,119.6],[-5.6,119.4],[-4.5,121],[-2.5,121.3],[-1,123.5],[0.5,121.8],[1,124.2]],[[-0.8,131],[-1.5,135],[-2.5,141.5],[-9,141.5],[-8,138],[-4.5,135.5],[-3.5,132.5],[-2,130.5]],[[-8.1,114.6],[-8.1,115.7],[-8.8,115.2]],[[-8.2,115.9],[-8.3,116.7],[-8.9,116.3]],[[-8.3,116.9],[-8.1,119],[-8.9,118.5],[-8.8,117]],[[-8.3,119.9],[-8.2,123],[-8.9,122.5],[-8.9,120]],[[-9,123.6],[-8.6,125.2],[-9.5,125],[-10.3,123.6]]];

/* ================= LOKASI: GPS + cari nama tempat (OpenStreetMap Nominatim) ================= */
let here=store.get("mm_here",null),locMsg="",locBusy=false,searchRes=[];
const km=(a,b,c,d)=>{const R=6371,x=(d-b)*rad*Math.cos((a+c)/2*rad),y=(c-a)*rad;return Math.round(Math.hypot(x,y)*R*10)/10};
const nearest=(lat,lon,n=3)=>everySpot().map(l=>({l,d:km(lat,lon,l.lat,l.lon)})).sort((a,b)=>a.d-b.d).slice(0,n);
/* ===== Spot dari OpenStreetMap (dermaga, pemecah ombak, tempat mancing) di sekitar lokasi ===== */
let osmSpots=store.get("mm_osm",[]),osmBusy=false,osmLast="";
const OSM_TYPE={pier:["Dermaga","Wharf / jetty"],breakwater:["Pemecah ombak","Breakwall"],groyne:["Tanggul batu","Groyne"],fishing:["Tempat mancing","Fishing spot"],slipway:["Tempat turun perahu","Boat ramp"]};
function osmTemplate(lat,lon){ // pinjam ikan & umpan dari spot aplikasi terdekat di wilayah yang sama
  const rg=regionOf(lat,lon),n=LOC.filter(l=>l.region===rg).map(l=>({l,d:km(lat,lon,l.lat,l.lon)})).sort((a,b)=>a.d-b.d)[0];
  return n?{src:n.l,d:n.d,sd:spotData(n.l)}:null;
}
async function loadOsmSpots(lat,lon,radiusKm=25,fromMap){
  const key=lat.toFixed(2)+","+lon.toFixed(2);if(osmBusy||osmLast===key||!navigator.onLine)return;osmBusy=true;osmLast=key;
  const r=radiusKm*1000,q=`[out:json][timeout:20];(nwr(around:${r},${lat},${lon})["leisure"="fishing"];nwr(around:${r},${lat},${lon})["man_made"~"^(pier|breakwater|groyne)$"];nwr(around:${r},${lat},${lon})["leisure"="slipway"]["name"];);out center 80;`;
  try{
    let j=null;
    for(const ep of ["https://overpass-api.de/api/interpreter","https://overpass.private.coffee/api/interpreter","https://overpass.kumi.systems/api/interpreter"]){
      try{const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),20000);
        const x=await fetch(ep+"?data="+encodeURIComponent(q),{signal:ac.signal});clearTimeout(tm);
        if(x.ok){j=await x.json();break}}catch(e){}
    }
    if(!j)osmLast="";
    if(j?.elements){
      const got=j.elements.map(e=>{const la=e.lat??e.center?.lat,lo=e.lon??e.center?.lon,t=e.tags||{},k=t.leisure==="fishing"?"fishing":t.leisure==="slipway"?"slipway":t.man_made;
        return la==null?null:{id:"osm_"+e.type[0]+e.id,lat:la,lon:lo,name:t.name||t["name:en"]||t["name:id"]||"",k}}).filter(Boolean)
        .filter(o=>!LOC.some(l=>km(l.lat,l.lon,o.lat,o.lon)<0.4));
      const ids=new Set(osmSpots.map(o=>o.id)),fresh=got.filter(o=>!ids.has(o.id));fresh.forEach(o=>osmSpots.push(o));
      if(osmSpots.length>600)osmSpots=osmSpots.slice(-600);
      store.set("mm_osm",osmSpots);
      if(view==="peta"){if(fromMap&&lmap)fresh.forEach(addOsmMarker);else render()}
    }
  }catch(e){}
  osmBusy=false;
}
const osmLabel=o=>o.name||LX(OSM_TYPE[o.k]?.[0]||"Spot mancing",OSM_TYPE[o.k]?.[1]||"Fishing spot");
function addOsmMarker(o){if(!lmap||!window.L||regionOf(o.lat,o.lon)!==region||mySpots.some(s=>s.id===o.id))return;L.circleMarker([o.lat,o.lon],{radius:7,color:"#fff",weight:1.5,fillColor:"#16a085",fillOpacity:.95,bubblingMouseEvents:false}).addTo(lmap).bindTooltip(osmLabel(o),{direction:"top"}).on("click",e=>{L.DomEvent.stop(e);useOsmSpot(o);mapToast()})}
function mapToast(){const c=cur();setTimeout(()=>{$("#main").scrollTop=0;const t=document.createElement("div");t.className="maptoast";t.textContent="📍 "+LX("Spot dipilih: ","Spot selected: ")+c.n;document.body.appendChild(t);setTimeout(()=>t.remove(),2200)},50)}
function pickFromMap(id){setSpot(id);mapToast()}
function useOsmSpot(o){ // jadikan spot yang bisa dipilih, lalu pilih
  let s=mySpots.find(x=>x.id===o.id);
  if(!s){const t=osmTemplate(o.lat,o.lon);
    s={id:o.id,n:osmLabel(o),a:t?(LX("Dekat ","Near ")+t.src.n):"OpenStreetMap",lat:o.lat,lon:o.lon,custom:true,osm:true,region:regionOf(o.lat,o.lon),
      type:LX(OSM_TYPE[o.k]?.[0]||"Tepi air",OSM_TYPE[o.k]?.[1]||"Waterside"),fish:t&&t.d<80?t.sd.fish.slice():[],bait:t&&t.d<80?JSON.parse(JSON.stringify(t.sd.bait)):{},spots:t&&t.d<80?t.sd.spots:"",tide:t&&t.d<80?t.sd.tide:""};
    mySpots.push(s);store.set("mm_spots",mySpots)}
  setRegion(s.region,s.id);
}
function nearestAll(lat,lon,n=5){ // spot aplikasi + spot OSM
  const a=allSpots().filter(s=>s.id!=="here").map(l=>({l,d:km(lat,lon,l.lat,l.lon)}));
  const b=osmSpots.filter(o=>regionOf(o.lat,o.lon)===region&&!mySpots.some(s=>s.id===o.id)).map(o=>({o,d:km(lat,lon,o.lat,o.lon)}));
  return a.concat(b).sort((x,y)=>x.d-y.d).slice(0,n);
}
function useHere(lat,lon,label,acc){
  here={lat,lon,label,acc:acc||null,t:Date.now()};store.set("mm_here",here);locMsg="";searchRes=[];
  const rg=regionOf(lat,lon);if(rg!==region){region=rg;store.set("mm_region",rg);$("#region").value=rg}
  // pilih spot terdekat di wilayah yang sama; bila jauh (>15 km) buat spot "lokasi pilihan" agar pemilih spot ikut berubah
  const inRg=allSpots().filter(s=>s.id!=="here").map(l=>({l,d:km(lat,lon,l.lat,l.lon)})).sort((a,b)=>a.d-b.d),n=inRg[0];
  mySpots=mySpots.filter(s=>s.id!=="here");
  if(n&&n.d<=15){curId=n.l.id}
  else{const src=n&&n.d<40?n.l:null,sd=src?spotData(src):null;
    mySpots.push({id:"here",n:"📍 "+((label||"Lokasiku").split(",")[0].slice(0,34)),a:src?"Dekat "+src.n:(label||"").split(",").slice(1,3).join(",").trim(),lat,lon,custom:true,region:rg,type:src?.type||"Tepi air",
      fish:sd?sd.fish.slice():[],bait:sd?JSON.parse(JSON.stringify(sd.bait)):{},spots:sd?.spots||"",tide:sd?.tide||""});
    curId="here"}
  store.set("mm_spots",mySpots);store.set("mm_cur",curId);fishSel=null;mapRecenter=true;fillPick();
  render();
  // cari juga dermaga/tempat mancing di OpenStreetMap; bila ada yang sangat dekat, langsung pilih
  loadOsmSpots(lat,lon).then(()=>{if(curId!=="here")return;const o=osmSpots.filter(o=>regionOf(o.lat,o.lon)===region).map(o=>({o,d:km(lat,lon,o.lat,o.lon)})).sort((a,b)=>a.d-b.d)[0];if(o&&o.d<=5)useOsmSpot(o.o)});
}
function detectGPS(silent){
  if(!("geolocation" in navigator)){if(!silent){locMsg="HP/browser ini tidak mendukung GPS. Cari dengan nama tempat.";render()}return}
  locBusy=true;if(!silent)render();
  navigator.geolocation.getCurrentPosition(p=>{locBusy=false;useHere(p.coords.latitude,p.coords.longitude,"Lokasimu sekarang",Math.round(p.coords.accuracy))},
    e=>{locBusy=false;if(!silent){locMsg=e.code===1?"Izin lokasi ditolak. Aktifkan izin lokasi untuk situs ini di pengaturan browser, atau cari dengan nama tempat.":"Lokasi tidak ditemukan. Pastikan GPS menyala lalu coba lagi.";render()}},
    {enableHighAccuracy:true,timeout:15000,maximumAge:120000});
}
async function searchPlace(q){
  locBusy=true;locMsg="";render();
  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&countrycodes=id,au&accept-language=id&q=${encodeURIComponent(q)}`,{headers:{"Accept":"application/json"}});
    if(!r.ok)throw 0;const j=await r.json();
    searchRes=j.map(x=>({lat:+x.lat,lon:+x.lon,label:x.display_name}));
    if(!searchRes.length)locMsg=`"${q}" tidak ditemukan. Coba tambahkan nama kota, mis. "Pantai Lovina, Bali".`;
  }catch(e){locMsg="Pencarian gagal. Periksa koneksi internet lalu coba lagi."}
  locBusy=false;render();
}
function locateCard(){
  const h=here,nearA=h?nearestAll(h.lat,h.lon,6):[],near=h?nearest(h.lat,h.lon,3):[],n0=near[0]?.l,data=n0?spotData(n0):null;
  return `<div class="card"><h3>Lokasimu</h3>
   <button class="btn" id="gpsBtn" style="width:100%" ${locBusy?"disabled":""}>${locBusy?"Mencari lokasi…":"📍 Deteksi lokasi otomatis (GPS)"}</button>
   <form id="locF" style="grid-template-columns:1fr auto;margin-top:8px"><input id="locQ" placeholder="atau ketik: Pantai Ancol, Bondi, Senggigi…" aria-label="Nama tempat"><button class="btn ghost" type="submit">Cari</button></form>
   ${locMsg?`<p class="note" style="color:var(--bad)">${esc(locMsg)}</p>`:""}
   ${searchRes.length?`<div class="list" style="margin-top:8px">${searchRes.map((r,i)=>`<button data-sr="${i}"><span class="note">${esc(r.label)}</span></button>`).join("")}</div>`:""}
   ${h?`<div style="margin-top:10px"><span class="tag">${esc(h.label)}${h.acc?" · akurasi ±"+h.acc+" m":""}</span>
     <p class="note">${h.lat.toFixed(4)}, ${h.lon.toFixed(4)}</p>
     <h3 style="margin-top:6px">Spot terdekat</h3>
     <div class="list">${nearA.map(n=>n.l?`<button data-near="${n.l.id}"><span><b>${esc(n.l.n)}</b><br><span class="note">${esc(n.l.a||"")}</span></span><span class="badge">${n.d} km</span></button>`:`<button data-osm="${n.o.id}"><span><b>${esc(osmLabel(n.o))}</b><br><span class="note">${LX("Dari OpenStreetMap","From OpenStreetMap")} · ${LX(OSM_TYPE[n.o.k]?.[0]||"",OSM_TYPE[n.o.k]?.[1]||"")}</span></span><span class="badge">${n.d} km</span></button>`).join("")}</div>${osmBusy?`<p class="note">${LX("Mencari dermaga & tempat mancing di sekitar…","Looking for nearby wharves & fishing spots…")}</p>`:""}
     ${(()=>{const cs=cur(),cd=cs?spotData(cs):null;return cd?`<h3>${LX("Ikan & umpan di","Fish & bait at")} ${esc(cs.n)}</h3><p class="note">${LX("Mengikuti spot yang dipilih di atas.","Follows the spot selected above.")}</p>
       <table><thead><tr><th>Umpan</th><th>Ikan</th></tr></thead><tbody>${Object.entries(cd.bait).map(([b,fs])=>`<tr><td>${esc(b)}</td><td>${fs.map(fishMini).join("")}</td></tr>`).join("")}</tbody></table>`:""})()}
     ${data&&near[0].d<40?`${n0.id===cur()?.id?"":`<h3>Ikan & umpan di sekitarmu</h3><p class="note">Berdasarkan spot terdekat (${esc(n0.n)}).</p>
       <table><thead><tr><th>Umpan</th><th>Ikan</th></tr></thead><tbody>${Object.entries(data.bait).map(([b,fs])=>`<tr><td>${esc(b)}</td><td>${fs.map(fishMini).join("")}</td></tr>`).join("")}</tbody></table>`}
       <button class="btn ghost" id="saveHere" style="margin-top:8px;width:100%">Simpan lokasi ini sebagai spot</button>`
      :`<p class="note">Belum ada spot di aplikasi dalam radius 40 km. Simpan lokasi ini sebagai spot pribadi, lalu catat tangkapan di sana.</p><button class="btn ghost" id="saveHere" style="width:100%">Simpan lokasi ini sebagai spot</button>`}
   </div>`:""}</div>`;
}
function bindLocate(){
  const g=$("#gpsBtn");if(!g)return;g.onclick=()=>detectGPS(false);
  $("#locF").onsubmit=e=>{e.preventDefault();const q=$("#locQ").value.trim();if(q&&!locBusy)searchPlace(q)};
  document.querySelectorAll("[data-sr]").forEach(b=>b.onclick=()=>{const r=searchRes[+b.dataset.sr];useHere(r.lat,r.lon,r.label.split(",").slice(0,2).join(","))});
  document.querySelectorAll("[data-osm]").forEach(b=>b.onclick=()=>{const o=osmSpots.find(x=>x.id===b.dataset.osm);if(o)useOsmSpot(o)});
  document.querySelectorAll("[data-near]").forEach(b=>b.onclick=()=>{const l=everySpot().find(x=>x.id===b.dataset.near);setRegion(l.region||regionOf(l.lat,l.lon),l.id)});
  const sv=$("#saveHere");if(sv)sv.onclick=()=>{const h=here,n=nearest(h.lat,h.lon,1)[0],src=n&&n.d<40?n.l:null,id="my"+Date.now();
    const name=(h.label||"Spot baru").split(",")[0].slice(0,40);
    mySpots.push({id,n:name==="Lokasimu sekarang"?"Spot pribadi "+(mySpots.length+1):name,a:src?"Dekat "+src.n:"Spot pribadi",lat:h.lat,lon:h.lon,type:src?.type||"Tepi air",custom:true,region:regionOf(h.lat,h.lon),fish:src?src.fish.slice():[],bait:src?JSON.parse(JSON.stringify(src.bait)):{},spots:src?.spots||"",tide:src?.tide||""});
    store.set("mm_spots",mySpots);setRegion(regionOf(h.lat,h.lon),id)};
}

function setRegion(rg,id){region=rg;store.set("mm_region",rg);$("#region").value=rg;setSpot(id||allSpots().find(s=>(s.region||regionOf(s.lat,s.lon))===rg).id)}
/* ================= WAKTU & PASANG ================= */
const rad=Math.PI/180;
function sydOffset(date){const y=date.getUTCFullYear(),fs=m=>{const d=new Date(Date.UTC(y,m,1));return 1+((7-d.getUTCDay())%7)};const st=Date.UTC(y,9,fs(9),-9),en=Date.UTC(y,3,fs(3),-10),t=date.getTime();return(t>=st||t<en)?11:10}
function sunTimes(date,lat,lon){const tz=tzLL(lat,lon);const d=new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth(),date.getUTCDate()));const n=Math.floor((d-Date.UTC(d.getUTCFullYear(),0,0))/864e5);const g=2*Math.PI/365*(n-1);const eq=229.18*(0.000075+0.001868*Math.cos(g)-0.032077*Math.sin(g)-0.014615*Math.cos(2*g)-0.040849*Math.sin(2*g));const dec=0.006918-0.399912*Math.cos(g)+0.070257*Math.sin(g)-0.006758*Math.cos(2*g)+0.000907*Math.sin(2*g)-0.002697*Math.cos(3*g)+0.00148*Math.sin(3*g);const ha=Math.acos(Math.cos(90.833*rad)/(Math.cos(lat*rad)*Math.cos(dec))-Math.tan(lat*rad)*Math.tan(dec))/rad;return{rise:(720-4*(lon+ha)-eq)/60+tz,set:(720-4*(lon-ha)-eq)/60+tz}}
const SYN=29.530588853,NEWREF=Date.UTC(2000,0,6,18,14);
const moonAge=t=>(((t-NEWREF)/864e5)%SYN+SYN)%SYN;
const LX=(id,en)=>region==="AU"?en:id;const LOC_=()=>region==="AU"?"en-AU":"id-ID";
const PHASE_EN=["New moon","Waxing crescent","First quarter","Waxing gibbous","Full moon","Waning gibbous","Last quarter","Waning crescent"];
const PHASE=["Bulan baru","Sabit awal","Separuh awal","Cembung awal","Purnama","Cembung akhir","Separuh akhir","Sabit akhir"];
function dayStart(off,tz=tzLL(cur().lat,cur().lon)){const now=new Date(),l=new Date(now.getTime()+tz*36e5);return Date.UTC(l.getUTCFullYear(),l.getUTCMonth(),l.getUTCDate()+off)-tz*36e5}
// daftar titik ekstrem nyata (ms UTC)
const EXT=[];TIDES.forEach(([d,arr])=>arr.forEach(([t,v])=>{const[h,m]=t.split(":").map(Number);const[Y,M,D]=d.split("-").map(Number);EXT.push({t:Date.UTC(Y,M-1,D,h,m)-11*36e5,v})}));
EXT.unshift({t:EXT[0].t-6.2*36e5,v:1.35});EXT.push({t:EXT[EXT.length-1].t+6.2*36e5,v:1.4});
const tideFrom={t0:EXT[1].t,t1:EXT[EXT.length-2].t};
function estTide(ms){const age=moonAge(ms);const spring=Math.cos(4*Math.PI*age/SYN);return 1.0+(0.6+0.25*spring)*Math.cos(2*Math.PI*((ms-EXT[3].t)/36e5)/12.42)} // fase dikunci ke pasang nyata terakhir yg diketahui
function tideMs(ms){
  if(ms>=EXT[0].t&&ms<=EXT[EXT.length-1].t){for(let i=0;i<EXT.length-1;i++){const a=EXT[i],b=EXT[i+1];if(ms>=a.t&&ms<=b.t){const f=(ms-a.t)/(b.t-a.t);return a.v+(b.v-a.v)*(1-Math.cos(Math.PI*f))/2}}}
  return estTide(ms);
}
const isReal=ds=>cur().lat<=-11.5&&ds>=tideFrom.t0-36e5*4&&ds+864e5<=tideFrom.t1+36e5*6;
function fishScore(off,lat,lon){
  const ds=dayStart(off,tzLL(lat,lon)),age=moonAge(ds+12*36e5),sun=sunTimes(new Date(ds+12*36e5),lat,lon),hours=[];
  for(let h=0;h<24;h++){let s=Math.abs(tideMs(ds+(h+.5)*36e5)-tideMs(ds+h*36e5))*2*1.4;if(Math.abs(h-sun.rise)<1.5||Math.abs(h-sun.set)<1.5)s+=.55;hours.push(Math.min(1,s))}
  const sb=(Math.cos(4*Math.PI*age/SYN)+1)/2;
  return{hours,total:Math.round(Math.min(100,hours.reduce((a,b)=>a+b,0)/24*90+sb*25)),age,sun,ds};
}
const fmt=h=>{h=(h+24)%24;let H=Math.floor(h),M=Math.round((h-H)*60);if(M===60){H=(H+1)%24;M=0}return String(H).padStart(2,"0")+":"+String(M).padStart(2,"0")};
const scoreCol=s=>s>=65?"var(--good)":s>=45?"var(--mid)":"var(--bad)";
const scoreTxt=s=>s>=65?LX("Bagus","Good"):s>=45?LX("Sedang","Fair"):LX("Lemah","Poor");


/* ===== Banner pasang aplikasi (hanya di versi web) ===== */
function apkUpdateBanner(){ // APK yang memuat dari web tapi komponen Android-nya lama (belum ada plugin notifikasi)
  if(!window.Capacitor||LN()||store.get("mm_apkupd_off","")===new Date().toDateString())return "";
  return `<div class="card instbar"><button class="x" id="apkUpdX" aria-label="${LX("Nanti","Later")}" style="float:right">✕</button><h3>⬆️ ${LX("Ada versi APK baru","A new APK version is available")}</h3><p class="note">${LX("Pasang ulang sekali untuk mendapat notifikasi hari bagus mancing. Akun & data tetap aman.","Reinstall once to get good-fishing-day notifications. Your account & data stay safe.")}</p><a class="btn" href="https://amonkshark.github.io/mancing-mania-web/download.html" target="_blank" rel="noopener" style="display:block;margin-top:6px">⬇️ ${LX("Unduh APK terbaru","Download latest APK")}</a></div>`}
function installBanner(){
  if(window.Capacitor)return apkUpdateBanner();if(store.get("mm_banner_off",false))return "";
  if(window.matchMedia&&matchMedia("(display-mode: standalone)").matches)return "";
  const ua=navigator.userAgent||"",isAnd=/Android/i.test(ua),isIOS=/iPhone|iPad|iPod/i.test(ua);
  return `<div class="card instbar"><button class="x" id="instX" aria-label="${LX("Tutup","Close")}" style="float:right">✕</button>
   <h3>📲 ${LX("Pasang Mancing Mania","Install Mancing Mania")}</h3>
   ${isIOS?`<p class="note">${LX("Di iPhone: ketuk tombol <b>Bagikan</b> di Safari, lalu pilih <b>Tambah ke Layar Utama</b>.","On iPhone: tap the <b>Share</b> button in Safari, then choose <b>Add to Home Screen</b>.")}</p>`
   :`<p class="note">${isAnd?LX("Unduh aplikasi Android, lalu buka file-nya untuk menginstal.","Download the Android app, then open the file to install it."):LX("Aplikasi Android tersedia sebagai file APK.","The Android app is available as an APK file.")}</p>
     <a class="btn" href="mancing-mania.apk" download style="display:block;margin-top:6px">⬇️ ${LX("Unduh APK Android","Download Android APK")}</a>
     <p class="note" style="margin-top:6px">${LX(`Saat menginstal, izinkan "Instal aplikasi tidak dikenal". Pengguna iPhone: buka link ini di Safari → Bagikan → Tambah ke Layar Utama.`,`When installing, allow "Install unknown apps". iPhone users: open this link in Safari → Share → Add to Home Screen.`)}</p>`}</div>`;
}
function bindInstall(){const u=document.getElementById("apkUpdX");if(u)u.onclick=()=>{store.set("mm_apkupd_off",new Date().toDateString());render()};const x=document.getElementById("instX");if(x)x.onclick=()=>{store.set("mm_banner_off",true);render()}}
/* ================= PETA (Leaflet + OpenStreetMap) ================= */
let mapPos=null,mapRecenter=true,lmap=null,pendingLL=null,commOn=store.get("mm_comm",true);
function killMap(){if(lmap){lmap.remove();lmap=null}}
function mapView(){
  const c=cur(),sc=fishScore(0,c.lat,c.lon);
  $("#main").innerHTML=`${offlineBadge()}${todayCardHtml()}<div id="mwarn"></div>${installBanner()}
   <div class="mapwrap"><div id="lmap" class="lmap" role="application" aria-label="Peta spot mancing"></div><span class="hint">Ketuk peta untuk menyimpan spot baru</span></div>
   ${layerBarHtml()}
   <label class="note" style="display:flex;align-items:center;gap:6px;margin-top:6px"><input type="checkbox" id="commTog" style="width:auto" ${commOn?"checked":""}> 🐟 Tampilkan tangkapan komunitas 7 hari terakhir</label>
   <form id="addForm" class="card" hidden style="margin-top:12px"><h3>Spot baru</h3><input id="newName" placeholder="Nama spot, mis. Batu favorit" required maxlength="40"><p class="note" id="newCoord"></p><div class="two"><button class="btn" type="submit">Simpan</button><button class="btn ghost" type="button" id="cancelAdd">Batal</button></div></form>
   <div style="margin-top:12px">${locateCard()}</div>
   <div class="card"><span class="tag">${esc(c.a||"Spot pribadi")} · ${esc(c.type||"Disimpan olehmu")}</span><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h2>${esc(c.n)}</h2><button class="x" id="favBtn" data-fav="${c.id}" aria-pressed="${isFav(c.id)}">${isFav(c.id)?"★ Favorit":"☆ Favoritkan"}</button></div>
     <div class="row"><div class="kv"><span class="tag">Aktivitas hari ini</span><strong style="color:${scoreCol(sc.total)}">${sc.total} · ${scoreTxt(sc.total)}</strong></div><div class="kv"><span class="tag">Matahari</span><strong>${fmt(sc.sun.rise)}–${fmt(sc.sun.set)}</strong></div></div>
     ${c.fish?.length?`<div style="margin-top:6px">${c.fish.slice(0,4).map(fishMini).join("")}</div>`:""}
     ${(()=>{const r=(feed||[]).filter(x=>x.spot_id===c.id).slice(0,3);return `<h3 style="margin-top:10px">Laporan terbaru di sini</h3>${r.length?r.map(feedItem).join(""):`<p class="note">${feed===null?"Memuat…":"Belum ada laporan tangkapan di spot ini."}</p>`}`})()}
     ${region==="ID"&&mpaNear(c.lat,c.lon)?`<p class="note" style="color:var(--bad)">🛑 Di/dekat kawasan konservasi: <b>${esc(mpaNear(c.lat,c.lon).n)}</b>. Cek zona larangan ke pengelola.</p>`:""}<p class="note">${c.lat.toFixed(4)}, ${c.lon.toFixed(4)} · <a href="https://www.google.com/maps/dir/?api=1&destination=${c.lat},${c.lon}" target="_blank" rel="noopener">Navigasi ke sini</a>${c.custom?` · <button class="x" id="delSpot">Hapus spot</button>`:""}</p></div>
   ${weeklyHtml()}${favCardHtml()}
   ${gpsToolsHtml()}
   ${sosHtml()}
   <h3>Semua spot</h3>
   <div class="list">${allSpots().map(s=>{const t=fishScore(0,s.lat,s.lon).total;return `<button data-id="${s.id}"><span><b>${esc(s.n)}</b><br><span class="note">${esc(s.a||"Spot pribadi")}${here?" · "+km(here.lat,here.lon,s.lat,s.lon)+" km":""}</span></span><span class="score" style="background:${scoreCol(t)}">${t}</span></button>`}).join("")}</div>`;
  document.querySelectorAll(".list button[data-id]").forEach(p=>p.onclick=()=>setSpot(p.dataset.id));
  bindLocate();bindInstall();bindFav();bindGood();bindWeekly();bindToday();bindFeed();bindLayerBar();bindGps();bindSos();fillMarineWarn();
  $("#commTog").onchange=e=>{commOn=e.target.checked;store.set("mm_comm",commOn);render()};
  $("#cancelAdd").onclick=()=>{$("#addForm").hidden=true};
  $("#addForm").onsubmit=e=>{e.preventDefault();const id="my"+Date.now();mySpots.push({id,n:$("#newName").value.trim()||"Spot baru",lat:pendingLL.lat,lon:pendingLL.lng,custom:true,region:regionOf(pendingLL.lat,pendingLL.lng),fish:[],bait:{}});store.set("mm_spots",mySpots);setSpot(id)};
  const del=$("#delSpot");if(del)del.onclick=()=>{mySpots=mySpots.filter(s=>s.id!==c.id);store.set("mm_spots",mySpots);setSpot(allSpots()[0]?.id)};
  if(!window.L){$("#lmap").innerHTML=`<p class="note" style="padding:16px">Peta butuh internet. Daftar spot di bawah tetap bisa dipakai.</p>`;return}
  lmap=L.map("lmap",{zoomControl:true,attributionControl:true});
  // pertahankan posisi peta saat ganti lapisan/refresh; pusatkan ke spot hanya bila spot berganti
  if(mapPos&&!mapRecenter&&mapPos.id===c.id)lmap.setView(mapPos.c,mapPos.z);else lmap.setView([c.lat,c.lon],region==="AU"?11:inLombok(c)?10:region==="ID"?(c.custom?11:9):11);
  mapRecenter=false;
  lmap.on("moveend zoomend",()=>{if(lmap)mapPos={id:c.id,c:lmap.getCenter(),z:lmap.getZoom()}});
  const Loc=L.Control.extend({options:{position:"topleft"},onAdd(){const b=L.DomUtil.create("button","locbtn");b.type="button";b.title=LX("Lokasi saya","My location");b.setAttribute("aria-label",b.title);b.textContent="📍";
    L.DomEvent.disableClickPropagation(b);b.onclick=()=>{if(!navigator.geolocation)return;b.classList.add("busy");
      navigator.geolocation.getCurrentPosition(p=>{b.classList.remove("busy");const la=p.coords.latitude,lo=p.coords.longitude,acc=Math.round(p.coords.accuracy);
        here={...(here||{}),lat:la,lon:lo,acc,label:here?.label||"Lokasimu sekarang",t:Date.now()};store.set("mm_here",here);
        if(!lmap)return;if(window._meDot)window._meDot.forEach(m=>m.remove());
        window._meDot=[L.circle([la,lo],{radius:acc,color:"#2f7de1",weight:1,fillOpacity:.08}).addTo(lmap),L.circleMarker([la,lo],{radius:8,color:"#fff",weight:3,fillColor:"#2f7de1",fillOpacity:1}).addTo(lmap).bindTooltip(LX("Kamu","You"),{direction:"top"})];
        lmap.setView([la,lo],Math.max(lmap.getZoom(),14))},()=>{b.classList.remove("busy");alertBox(LX("Lokasi tidak bisa diambil. Nyalakan GPS dan izinkan akses lokasi.","Couldn't get your location. Turn on GPS and allow location access."))},{enableHighAccuracy:true,timeout:15000,maximumAge:30000})};return b}});
  new Loc().addTo(lmap);
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:18,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'}).addTo(lmap);
  allSpots().forEach(s=>{const on=s.id===c.id;
    L.circleMarker([s.lat,s.lon],{radius:on?12:9,color:"#fff",weight:2,fillColor:s.custom?"#f0a51a":"#1565c0",fillOpacity:1,bubblingMouseEvents:false}).addTo(lmap).bindTooltip(s.n,{permanent:on,direction:"right"}).on("click",e=>{L.DomEvent.stop(e);pickFromMap(s.id)})});
  osmSpots.forEach(addOsmMarker);applyMapLayer();drawGps();drawMpa();points.forEach(addPointMarker);
  lmap.on("moveend",()=>{if(mapLayer==="wind")drawWind()});
  lmap.on("moveend",()=>{if(lmap&&lmap.getZoom()>=11){const c=lmap.getCenter();loadOsmSpots(c.lat,c.lng,15,true)}});
  if(lmap.getZoom()>=11)loadOsmSpots(c.lat,c.lon,15,true);
  if(commOn)(feed||[]).filter(x=>x.lat!=null&&inRegion(x)&&!blocked.has(x.user_id)&&Date.now()-Date.parse(x.created_at)<7*864e5).forEach(x=>{
    const ic=L.divIcon({className:"commpin",html:"🐟",iconSize:[22,22]});
    L.marker([x.lat,x.lon],{icon:ic}).addTo(lmap).bindPopup(`<b>${esc(x.fish)}</b>${x.length_cm?" "+x.length_cm+" cm":""}<br>${esc(x.profiles?.name||"Pemancing")} · ${ago(x.created_at)}<br>${esc(x.spot_name||"")}`).on("popupopen",e=>tr(e.popup.getElement()))});
  if(here){L.circleMarker([here.lat,here.lon],{radius:8,color:"#fff",weight:3,fillColor:"#2f7de1",fillOpacity:1}).addTo(lmap).bindTooltip("Kamu",{direction:"top"});if(here.acc)L.circle([here.lat,here.lon],{radius:here.acc,color:"#2f7de1",weight:1,fillOpacity:.08}).addTo(lmap)}
  lmap.on("click",e=>{pendingLL=e.latlng;$("#addForm").hidden=false;$("#newCoord").textContent=`Koordinat: ${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`;$("#newName").focus()});
  setTimeout(()=>lmap&&lmap.invalidateSize(),60);
}

/* ================= PRAKIRAAN: Open-Meteo (cuaca, angin, ombak, tinggi muka laut) ================= */
const wx={};let wxBusy={};
const wxKey=s=>s.lat.toFixed(2)+","+s.lon.toFixed(2);
async function loadWx(s){
  const k=wxKey(s);if(wxBusy[k])return;
  const cached=wx[k]||store.get("mm_wx_"+k,null);
  if(cached&&Date.now()-cached.t<3*36e5){wx[k]=cached;return}
  if(cached)wx[k]=cached;
  wxBusy[k]=true;
  try{
    const q=`latitude=${s.lat}&longitude=${s.lon}&timezone=auto&forecast_days=7`;
    const [w,m]=await Promise.all([
      fetch(`https://api.open-meteo.com/v1/forecast?${q}&hourly=temperature_2m,precipitation_probability,wind_speed_10m,wind_direction_10m,weather_code&daily=sunrise,sunset&wind_speed_unit=kmh`).then(r=>r.ok?r.json():null),
      fetch(`https://marine-api.open-meteo.com/v1/marine?${q}&hourly=wave_height,sea_level_height_msl,sea_surface_temperature`).then(r=>r.ok?r.json():null).catch(()=>null)
    ]);
    if(!w)throw 0;
    const d={t:Date.now(),w,m};wx[k]=d;
    // simpan versi ringkas untuk dipakai offline
    store.set("mm_wx_"+k,d);
  }catch(e){if(!wx[k]||wx[k].err)wx[k]={err:1,t:Date.now()-3*36e5+6e4}} // coba lagi setelah 1 menit, bukan terus-menerus
  wxBusy[k]=false;if(view==="prakiraan"&&wxKey(cur())===k)render();
}
const WCODE=c=>c==null?"":c<=1?LX("☀️ Cerah","☀️ Clear"):c<=3?LX("⛅ Berawan","⛅ Cloudy"):c<=48?LX("🌫️ Kabut","🌫️ Fog"):c<=67?LX("🌧️ Hujan","🌧️ Rain"):c<=77?LX("🌨️ Salju","🌨️ Snow"):c<=82?LX("🌦️ Hujan lokal","🌦️ Showers"):LX("⛈️ Badai","⛈️ Storm");
const dirTxt=d=>(region==="AU"?["N","NE","E","SE","S","SW","W","NW"]:["U","TL","T","TG","S","BD","B","BL"])[Math.round(d/45)%8];
function dayHours(arr,times,date){const out=[];times.forEach((t,i)=>{if(t.startsWith(date))out.push(arr?.[i])});return out}
function extremes(hv){const e=[];for(let i=1;i<hv.length-1;i++){const[a,b,c]=[hv[i-1],hv[i],hv[i+1]];if(a==null||b==null||c==null)continue;if((b>a&&b>=c)||(b<a&&b<=c)){const den=a-2*b+c,off=den?(a-c)/(2*den):0,v=b-(a-c)*off/4;e.push({h:i+Math.max(-.5,Math.min(.5,off)),v,hi:b>a})}}return e}
const hhmm=s=>s.slice(11,16),h2n=s=>+s.slice(11,13)+ +s.slice(14,16)/60;
function forecastView(){
  const c=cur(),k=wxKey(c),W=wx[k];
  if(!W||(!W.w&&!W.err)){$("#main").innerHTML=`<h2>${esc(c.n)}</h2><div class="card"><p class="note">${LX("Memuat cuaca, angin, ombak & pasang surut…","Loading weather, wind, waves & tides…")}</p></div>`;loadWx(c);return}
  if(W.err){forecastEstimate(LX("Tidak bisa memuat data live (offline?). Menampilkan perkiraan.","Couldn't load live data (offline?). Showing an estimate."));loadWx(c);return}
  if(Date.now()-W.t>3*36e5)loadWx(c);
  const w=W.w,m=W.m,dates=w.daily.time,di=Math.min(dayOff,dates.length-1),date=dates[di];
  const sea=m?.hourly?.sea_level_height_msl?dayHours(m.hourly.sea_level_height_msl,m.hourly.time,date):[];
  const hasSea=sea.filter(v=>v!=null).length>12;
  // kurva pasang: data model, atau perkiraan bila tidak tersedia
  const tz=tzLL(c.lat,c.lon),ds=Date.parse(date+"T00:00:00Z")-tz*36e5;
  const tv=[];if(hasSea){const base=Math.min(...sea.filter(v=>v!=null));sea.forEach((v,h)=>{if(v!=null)tv.push([h,v-base])})}else{for(let h=0;h<=24;h+=.25)tv.push([h,tideMs(ds+h*36e5)])}
  const ext=hasSea?extremes(sea).map(e=>({...e,v:e.v-Math.min(...sea.filter(v=>v!=null))})):(()=>{const x=[];for(let i=1;i<tv.length-1;i++){const[a,b,d]=[tv[i-1][1],tv[i][1],tv[i+1][1]];if((b>a&&b>=d)||(b<a&&b<=d))x.push({h:tv[i][0],v:b,hi:b>a})}return x})();
  const vmax=Math.max(.5,...tv.map(x=>x[1]))*1.1;
  const sunR=h2n(w.daily.sunrise[di]),sunS=h2n(w.daily.sunset[di]);
  // skor aktivitas per jam: arus (perubahan muka air) + subuh/senja + fase bulan + angin
  const wind=dayHours(w.hourly.wind_speed_10m,w.hourly.time,date),wdir=dayHours(w.hourly.wind_direction_10m,w.hourly.time,date),temp=dayHours(w.hourly.temperature_2m,w.hourly.time,date),rain=dayHours(w.hourly.precipitation_probability,w.hourly.time,date),code=dayHours(w.hourly.weather_code,w.hourly.time,date);
  const wave=m?.hourly?.wave_height?dayHours(m.hourly.wave_height,m.hourly.time,date):[],sst=m?.hourly?.sea_surface_temperature?dayHours(m.hourly.sea_surface_temperature,m.hourly.time,date):[];
  const val=h=>{const a=tv.find(x=>x[0]>=h);return a?a[1]:tv[tv.length-1][1]};
  const age=moonAge(ds+12*36e5),sb=(Math.cos(4*Math.PI*age/SYN)+1)/2;
  const hours=[];for(let h=0;h<24;h++){let s=Math.abs(val(h+1)-val(h))/vmax*3.2;if(Math.abs(h-sunR)<1.5||Math.abs(h-sunS)<1.5)s+=.5;if((wind[h]||0)>30)s-=.3;if((wave[h]||0)>2.5)s-=.3;hours.push(Math.max(0,Math.min(1,s)))}
  const total=Math.round(Math.max(0,Math.min(100,hours.reduce((a,b)=>a+b,0)/24*90+sb*25)));
  const best=hours.map((v,h)=>[v,h]).sort((a,b)=>b[0]-a[0]).slice(0,3).map(x=>x[1]).sort((a,b)=>a-b);
  const now=new Date(),nowH=di===0?((now.getTime()-ds)/36e5):null;
  const cw=340,ch=150,pl=34,pb=20,X=h=>pl+h/24*(cw-pl-6),Y=v=>ch-pb-(v/vmax)*(ch-pb-12);
  const path=tv.map(([h,v],i)=>(i?"L":"M")+X(h).toFixed(1)+","+Y(v).toFixed(1)).join("");
  const grid=[0,6,12,18,24].map(h=>`<line x1="${X(h)}" x2="${X(h)}" y1="10" y2="${ch-pb}" stroke="var(--line)"/><text x="${X(h)}" y="${ch-5}" font-size="10" text-anchor="middle" fill="var(--muted)">${String(h).padStart(2,"0")}</text>`).join("")+[0,vmax/2/1.1,vmax/1.1].map(v=>`<text x="2" y="${Y(v)+3}" font-size="9" fill="var(--muted)">${v.toFixed(1)}m</text>`).join("");
  const night=`<rect x="${X(0)}" y="10" width="${X(sunR)-X(0)}" height="${ch-pb-10}" fill="var(--fg)" opacity=".06"/><rect x="${X(sunS)}" y="10" width="${X(24)-X(sunS)}" height="${ch-pb-10}" fill="var(--fg)" opacity=".06"/>`;
  const pi=Math.floor(age/SYN*8+.5)%8,illum=Math.round((1-Math.cos(2*Math.PI*age/SYN))/2*100);
  const nh=nowH!=null?Math.max(0,Math.min(23,Math.floor(nowH))):12;
  const safe=(wave[nh]||0)>2.5||(wind[nh]||0)>35;
  $("#main").innerHTML=`
   <h2>${esc(c.n)}</h2>
   ${marineWarnHtml(c)}${monsoonHtml()}
   <div class="days">${dates.map((d,i)=>`<button data-o="${i}" aria-pressed="${i===di}">${new Date(d+"T12:00:00Z").toLocaleDateString(LOC_(),{weekday:"short",day:"numeric",timeZone:"UTC"})}</button>`).join("")}</div>
   ${safe?`<div class="card" style="border-color:var(--bad)"><b style="color:var(--bad)">${LX("Hati-hati:","Caution:")}</b> ${(wave[nh]||0)>2.5?`${LX("ombak","waves")} ±${wave[nh].toFixed(1)} m`:""} ${(wind[nh]||0)>35?`${LX("angin","wind")} ${Math.round(wind[nh])} ${LX("km/j","km/h")}`:""}. ${LX("Hindari mancing batu & perahu kecil.","Avoid rock fishing & small boats.")}</div>`:""}
   <div class="card" style="margin-top:10px"><div class="row">
     <div class="kv"><span class="tag">${di===0?LX("Sekarang","Now"):LX("Siang","Midday")}</span><strong>${WCODE(code[nh])}</strong><span class="note">${temp[nh]!=null?Math.round(temp[nh])+"°C":""}${rain[nh]!=null?" · "+LX("hujan","rain")+" "+rain[nh]+"%":""}</span></div>
     <div class="kv"><span class="tag">${LX("Angin","Wind")}</span><strong>${wind[nh]!=null?Math.round(wind[nh])+" "+LX("km/j","km/h"):"–"}</strong><span class="note">${wdir[nh]!=null?LX("dari ","from ")+dirTxt(wdir[nh]):""}</span></div>
     <div class="kv"><span class="tag">${LX("Ombak","Waves")}</span><strong>${wave[nh]!=null?wave[nh].toFixed(1)+" m":"–"}</strong><span class="note">${sst[nh]!=null?LX("air ","water ")+Math.round(sst[nh])+"°C":""}</span></div></div>
     <div class="tbl" style="margin-top:8px"><table><thead><tr><th>${LX("Jam","Time")}</th><th>${LX("Cuaca","Weather")}</th><th>${LX("Angin","Wind")}</th><th>${LX("Ombak","Waves")}</th></tr></thead><tbody>${[3,6,9,12,15,18,21].map(h=>`<tr><td>${String(h).padStart(2,"0")}:00</td><td>${WCODE(code[h])} ${temp[h]!=null?Math.round(temp[h])+"°":""}</td><td>${wind[h]!=null?Math.round(wind[h])+" "+dirTxt(wdir[h]):"–"}</td><td>${wave[h]!=null?wave[h].toFixed(1)+" m":"–"}</td></tr>`).join("")}</tbody></table></div></div>
   <div class="card chart"><div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:0">${LX("Pasang surut","Tides")}</h3><span class="badge">${hasSea?LX("Live · model Open-Meteo","Live · Open-Meteo model"):LX("Perkiraan","Estimate")}</span></div>
     <svg viewBox="0 0 ${cw} ${ch}" style="margin-top:8px">${night}${grid}<path d="${path} L${X(tv[tv.length-1][0])},${ch-pb} L${X(tv[0][0])},${ch-pb}Z" fill="var(--accent)" opacity=".15"/><path d="${path}" fill="none" stroke="var(--accent)" stroke-width="2"/>${ext.map(e=>`<circle cx="${X(e.h)}" cy="${Y(e.v)}" r="3.5" fill="var(--accent)"/><text x="${X(e.h)}" y="${Y(e.v)+(e.hi?-8:14)}" font-size="9.5" text-anchor="middle" fill="var(--fg)">${fmt(e.h)}</text>`).join("")}${nowH!=null&&nowH<24?`<line x1="${X(nowH)}" x2="${X(nowH)}" y1="10" y2="${ch-pb}" stroke="var(--sand)" stroke-width="2"/>`:""}</svg>
     <table><thead><tr><th>${LX("Jam","Time")}</th><th>${LX("Tipe","Type")}</th><th>${LX("Relatif","Relative")}</th></tr></thead><tbody>${ext.map(e=>`<tr><td>${fmt(e.h)}</td><td>${e.hi?LX("▲ Pasang","▲ High"):LX("▼ Surut","▼ Low")}</td><td>${e.v.toFixed(2)} m</td></tr>`).join("")}</tbody></table>
     <p class="note">${hasSea?LX("Tinggi muka laut dari model global Open-Meteo, ditampilkan relatif terhadap surut terendah hari ini. Di teluk sempit dan muara, waktunya bisa bergeser.","Sea level from Open-Meteo's global model, shown relative to today's lowest tide. In narrow bays and estuaries the timing can shift."):LX("Data muka laut tidak tersedia untuk titik ini, jadi ditampilkan perkiraan dari posisi bulan.","Sea-level data isn't available for this point, so an estimate from the moon's position is shown.")} ${LX("Jadwal resmi:","Official tide times:")} ${region==="AU"?`<a href="https://www.bom.gov.au/australia/tides/" target="_blank" rel="noopener">BOM</a>`:`<a href="https://maritim.bmkg.go.id/" target="_blank" rel="noopener">BMKG Maritim</a>`}.</p></div>
   <div class="card"><div class="row"><div class="kv"><span class="tag">${LX("Aktivitas ikan","Fish activity")}</span><strong style="color:${scoreCol(total)}">${total}/100</strong></div><div class="kv"><span class="tag">${LX("Jam terbaik","Best hours")}</span><strong>${best.map(h=>fmt(h)).join(" · ")}</strong></div></div>
     <div class="fishbar" style="margin-top:10px">${hours.map((v,h)=>`<i style="height:${Math.max(4,v*100)}%;${best.includes(h)?"background:var(--sand)":""}" title="${fmt(h)}"></i>`).join("")}</div>
     <div class="row note" style="justify-content:space-between"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div><p class="note">${LX("Dari kecepatan perubahan pasang, subuh/senja, fase bulan, angin & ombak.","Based on tidal flow, dawn/dusk, moon phase, wind & waves.")}</p></div>
   ${solunarHtml(ds,c.lat,c.lon)}
   ${prayerHtml(ds,c.lat,c.lon)}
   <div class="card"><div class="row"><div class="kv"><span class="tag">${LX("Terbit","Sunrise")}</span><strong>${hhmm(w.daily.sunrise[di])}</strong></div><div class="kv"><span class="tag">${LX("Terbenam","Sunset")}</span><strong>${hhmm(w.daily.sunset[di])}</strong></div><div class="kv"><span class="tag">${LX("Bulan","Moon")}</span><strong>${LX(PHASE[pi],PHASE_EN[pi])}</strong><span class="note">${illum}% ${LX("terang","lit")}</span></div></div></div>
   <p class="note">${LX("Data cuaca & laut:","Weather & marine data:")} <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo</a> (CC BY 4.0). ${LX("Diperbarui","Updated")} ${new Date(W.t).toLocaleTimeString(LOC_(),{hour:"2-digit",minute:"2-digit"})}.</p>`;
  document.querySelectorAll(".days button").forEach(b=>b.onclick=()=>{dayOff=+b.dataset.o;render()});
}

/* ================= PASANG & PRAKIRAAN ================= */
function forecastEstimate(msg){
  const c=cur(),now=new Date(),T=fishScore(dayOff,c.lat,c.lon),real=isReal(T.ds);
  const dname=o=>new Date(dayStart(o)+12*36e5).toLocaleDateString(LOC_(),{weekday:"short",day:"numeric",timeZone:tzName(c.lat,c.lon)});
  const days=[0,1,2,3,4,5,6].map(o=>{const s=fishScore(o,c.lat,c.lon).total;return `<button data-o="${o}" aria-pressed="${o===dayOff}">${dname(o)}<small style="color:${scoreCol(s)}">${s} · ${scoreTxt(s)}</small></button>`}).join("");
  const cw=340,ch=150,pl=30,pb=20,X=h=>pl+h/24*(cw-pl-6),Y=v=>ch-pb-(v/2)*(ch-pb-10);
  const tv=[];for(let h=0;h<=24;h+=.25)tv.push([h,tideMs(T.ds+h*36e5)]);
  const path=tv.map(([h,v],i)=>(i?"L":"M")+X(h).toFixed(1)+","+Y(v).toFixed(1)).join("");
  let ext=EXT.filter(e=>e.t>=T.ds&&e.t<T.ds+864e5&&real).map(e=>({h:(e.t-T.ds)/36e5,v:e.v}));
  if(!real){ext=[];for(let i=1;i<tv.length-1;i++){const[a,b,d]=[tv[i-1][1],tv[i][1],tv[i+1][1]];if((b>a&&b>=d)||(b<a&&b<=d))ext.push({h:tv[i][0],v:b})}}
  ext.forEach((e,i)=>{const nb=ext[i+1]||ext[i-1];e.hi=nb?e.v>nb.v:e.v>1});
  const grid=[0,6,12,18,24].map(h=>`<line x1="${X(h)}" x2="${X(h)}" y1="10" y2="${ch-pb}" stroke="var(--line)"/><text x="${X(h)}" y="${ch-5}" font-size="10" text-anchor="middle" fill="var(--muted)">${String(h).padStart(2,"0")}</text>`).join("")+[0,1,2].map(v=>`<text x="4" y="${Y(v)+3}" font-size="10" fill="var(--muted)">${v}m</text>`).join("");
  const nowH=dayOff===0?(now.getTime()-T.ds)/36e5:null;
  const night=`<rect x="${X(0)}" y="10" width="${X(T.sun.rise)-X(0)}" height="${ch-pb-10}" fill="var(--fg)" opacity=".06"/><rect x="${X(T.sun.set)}" y="10" width="${X(24)-X(T.sun.set)}" height="${ch-pb-10}" fill="var(--fg)" opacity=".06"/>`;
  const age=T.age,pi=Math.floor(age/SYN*8+.5)%8,illum=Math.round((1-Math.cos(2*Math.PI*age/SYN))/2*100);
  const best=T.hours.map((v,h)=>[v,h]).sort((a,b)=>b[0]-a[0]).slice(0,3).map(x=>x[1]).sort((a,b)=>a-b);
  let nowTxt="";if(nowH!==null){const v=tideMs(now.getTime()),v2=tideMs(now.getTime()+6e5);nowTxt=`<div class="kv"><span class="tag">${LX("Sekarang","Now")}</span><strong>${v.toFixed(2)} m ${v2>v?LX("↑ naik","↑ rising"):LX("↓ turun","↓ falling")}</strong></div>`}
  $("#main").innerHTML=`
   <h2>${esc(c.n)}</h2><div class="card"><p class="note">${esc(msg)}</p></div>${monsoonHtml()}<div class="days">${days}</div>
   <div class="card chart" style="margin-top:10px"><div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:0">${LX("Pasang surut","Tides")}</h3><span class="badge">${real?"WillyWeather · Fort Denison":LX("Perkiraan","Estimate")}</span></div>
     <div class="row" style="margin:8px 0">${nowTxt}<div class="kv"><span class="tag">${LX("Tertinggi","Highest")}</span><strong>${Math.max(...tv.map(x=>x[1])).toFixed(2)} m</strong></div></div>
     <svg viewBox="0 0 ${cw} ${ch}">${night}${grid}<path d="${path} L${X(24)},${ch-pb} L${X(0)},${ch-pb}Z" fill="var(--accent)" opacity=".15"/><path d="${path}" fill="none" stroke="var(--accent)" stroke-width="2"/>${ext.map(e=>`<circle cx="${X(e.h)}" cy="${Y(e.v)}" r="3.5" fill="var(--accent)"/><text x="${X(e.h)}" y="${Y(e.v)+(e.hi?-8:14)}" font-size="9.5" text-anchor="middle" fill="var(--fg)">${fmt(e.h)}</text>`).join("")}${nowH!==null?`<line x1="${X(nowH)}" x2="${X(nowH)}" y1="10" y2="${ch-pb}" stroke="var(--sand)" stroke-width="2"/>`:""}</svg>
     <table><thead><tr><th>${LX("Jam","Time")}</th><th>${LX("Tipe","Type")}</th><th>${LX("Tinggi","Height")}</th></tr></thead><tbody>${ext.map(e=>`<tr><td>${fmt(e.h)}</td><td>${e.hi?LX("▲ Pasang","▲ High"):LX("▼ Surut","▼ Low")}</td><td>${e.v.toFixed(2)} m</td></tr>`).join("")}</tbody></table>
     <p class="note">${real?`Source: <a href="${TIDE_SRC}" target="_blank" rel="noopener">WillyWeather, Fort Denison station</a> (fetched 13 Oct 2026). Spots outside the harbour can differ by a few minutes. Heights between high and low are interpolated.`:region!=="AU"?`Perkiraan kasar. Banyak perairan Indonesia hanya punya satu pasang sehari, jadi jam bisa jauh berbeda. Cek jadwal resmi di <a href="https://maritim.bmkg.go.id/" target="_blank" rel="noopener">BMKG Maritim</a> atau <a href="https://srgi.big.go.id/" target="_blank" rel="noopener">BIG (pasut)</a>.`:`Outside the WillyWeather data range (13–19 Oct), so this is an estimate. Check <a href="${TIDE_SRC}" target="_blank" rel="noopener">WillyWeather</a> for the latest tide times.`}</p></div>
   <div class="card"><div class="row"><div class="kv"><span class="tag">${LX("Aktivitas ikan","Fish activity")}</span><strong style="color:${scoreCol(T.total)}">${T.total}/100</strong></div><div class="kv"><span class="tag">${LX("Jam terbaik","Best hours")}</span><strong>${best.map(h=>fmt(h)).join(" · ")}</strong></div></div>
     <div class="fishbar" style="margin-top:10px">${T.hours.map((v,h)=>`<i style="height:${Math.max(4,v*100)}%;${best.includes(h)?"background:var(--sand)":""}" title="${fmt(h)}"></i>`).join("")}</div>
     <div class="row note" style="justify-content:space-between"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div><p class="note">${LX("Skor dihitung dari kecepatan arus pasang, subuh/senja, dan fase bulan.","Score is based on tidal flow, dawn/dusk and moon phase.")}</p></div>
   ${solunarHtml(T.ds,c.lat,c.lon)}
   ${prayerHtml(T.ds,c.lat,c.lon)}
   <div class="card"><div class="row"><div class="kv"><span class="tag">${LX("Terbit","Sunrise")}</span><strong>${fmt(T.sun.rise)}</strong></div><div class="kv"><span class="tag">${LX("Terbenam","Sunset")}</span><strong>${fmt(T.sun.set)}</strong></div><div class="kv"><span class="tag">${LX("Bulan","Moon")}</span><strong>${LX(PHASE[pi],PHASE_EN[pi])}</strong><span class="note">${illum}% ${LX("terang","lit")}</span></div></div></div>
   <div class="card"><h3>${LX("Cuaca, angin & ombak","Weather, wind & waves")}</h3>${region!=="AU"?`<ul><li><a href="https://www.bmkg.go.id/cuaca/prakiraan-cuaca" target="_blank" rel="noopener">Prakiraan cuaca BMKG</a></li><li><a href="https://maritim.bmkg.go.id/" target="_blank" rel="noopener">Gelombang & angin laut (BMKG Maritim)</a></li></ul>`:`<ul><li><a href="https://www.willyweather.com.au/nsw/sydney.html" target="_blank" rel="noopener">WillyWeather Sydney</a></li><li><a href="https://www.bom.gov.au/nsw/forecasts/sydney-coastal.shtml" target="_blank" rel="noopener">Coastal wind & swell (BOM)</a></li></ul>`}</div>`;
  document.querySelectorAll(".days button").forEach(b=>b.onclick=()=>{dayOff=+b.dataset.o;render()});
}

/* ================= IKAN & UMPAN ================= */

/* ===== Mode darat / perahu ===== */
let mode=store.get("mm_mode","darat");
Object.assign(BAITINFO,{"Minnow troll":"Umpan tiruan ikan yang ditarik di belakang perahu (trolling) 5–8 knot."});
function boatData(c){
  const est=/sungai|muara|river|teluk|bakau/i.test((c.type||"")+" "+(c.a||""));
  if(est)return{fish:c.fish,bait:Object.assign({},c.bait,{"Soft plastic besar":c.fish.filter(f=>["Flathead","Mulloway","Kakap Putih","Barakuda","Kingfish"].includes(f))}),
    spots:"Dari perahu: lempar ke tepi bakau, kayu tenggelam, dan tiang dari arah air; jangkar di tepi alur dalam untuk ikan besar saat arus melambat.",tide:c.tide,est:1};
  if(c.region==="AU")return{fish:["Snapper","Kingfish","Flathead","Mulloway","Trevally","Squid"],
    bait:{"Soft plastic besar":["Snapper","Flathead","Kingfish"],"Squid hidup":["Kingfish","Mulloway"],"Pilchard utuh":["Snapper","Trevally"],"Jig logam":["Kingfish","Snapper"],"Minnow troll":["Kingfish"],"Squid jig":["Squid"]},
    spots:"Drift di atas karang dalam 15–40 m untuk snapper; sekitar penanda navigasi dan tanjung untuk kingfish; drift di atas pasir untuk flathead. Pakai sonar & GPS.",tide:"Pergantian arus dan subuh. Cek angin & swell BOM sebelum keluar heads."};
  return{fish:["Kakap Merah","Kerapu","GT","Tenggiri","Tongkol","Barakuda"],
    bait:{"Potongan cumi":["Kakap Merah","Kerapu"],"Ikan umpan hidup":["Kerapu","Tenggiri","Barakuda"],"Jig logam":["Tenggiri","Tongkol","GT","Kakap Merah"],"Popper":["GT"],"Minnow troll":["Tenggiri","Tongkol","Barakuda"]},
    spots:"Tubir & karang dalam 20–60 m untuk kerapu dan kakap merah (dasaran / slow jig); rumpon untuk tongkol & tenggiri; tanjung berarus untuk GT (popping). Sewa perahu nelayan setempat yang tahu titiknya.",tide:"Arus sedang di awal pasang atau surut; hindari saat gelombang tinggi (cek BMKG Maritim)."};
}
const spotData=c=>mode==="perahu"&&c.fish?.length?boatData(c):c;

/* ===== Animasi cara mancing di peta lempar ===== */
const TECH={popper:["GT"],cepat:["Tailor","Salmon Australia","Tenggiri","Tongkol","Barakuda","Kingfish"],dasar:["Kakap Merah","Kerapu","Snapper","Mulloway","Flathead","Drummer"],pelampung:["Luderick","Baronang","Yellowtail","Belanak"],cumi:["Squid","Cumi"]};
const techOf=f=>Object.keys(TECH).find(k=>TECH[k].includes(f))||"pelan";
const TECHTXT={
 popper:["Lempar popper sejauh mungkin ke buih.","Sentak joran keras: popper menyemburkan air.","Jeda sebentar, sentak lagi. GT menyambar di permukaan!"],
 cepat:["Lempar jauh melewati target.","Gulung cepat dan rata, umpan meluncur di bawah permukaan.","Ikan predator mengejar dan menyambar. Jangan berhenti menggulung!"],
 dasar:["Lempar ke arah karang/dasar.","Biarkan umpan tenggelam sampai dasar (hitung 5–10).","Angkat joran pelan, umpan melompat lalu jatuh lagi. Rasakan tarikan!"],
 pelampung:["Lempar pelampung ke depan struktur.","Biarkan hanyut mengikuti arus di sepanjang rumput laut/batu.","Pelampung tenggelam = ikan makan. Angkat joran!"],
 cumi:["Lempar squid jig ke tepi rumput laut.","Biarkan tenggelam, lalu sentak 2–3 kali.","Diam beberapa detik. Cumi memeluk jig saat diam!"],
 pelan:["Lempar ke dekat struktur.","Biarkan umpan jatuh alami, gulung sangat pelan.","Ikan mengambil umpan. Tunggu sebentar, lalu angkat joran."]
};
let caRAF=null;
function castAnimStop(){if(caRAF)cancelAnimationFrame(caRAF);caRAF=null}
function castAnimStart(){
  castAnimStop();const svg=document.getElementById("castSvg");if(!svg)return;
  const[mx,my,cx,cy,tx,ty]=svg.dataset.a.split(",").map(Number),fish=svg.dataset.fish,tech=techOf(fish),T=TECHTXT[tech],boat=mode==="perahu";
  const g=id=>document.getElementById(id);
  const lure=g("caLure"),line=g("caLine"),rings=g("caRings"),fsh=g("caFish"),cap=g("caTxt"),stp=g("caStep"),btn=g("caPlay");
  const sRod=g("sRod"),sLine=g("sLine"),sLure=g("sLure"),sFish=g("sFish"),sFloat=g("sFloat"),sRings=g("sRings"),sDepth=g("sDepth");
  const bez=t=>[(1-t)*(1-t)*mx+2*(1-t)*t*cx+t*t*tx,(1-t)*(1-t)*my+2*(1-t)*t*cy+t*t*ty];
  const back=u=>[tx+(mx-tx)*u*.45,ty+(my-ty)*u*.45];
  const NS="http://www.w3.org/2000/svg";
  const ring=(host,x,y,col)=>{const c=document.createElementNS(NS,"circle");c.setAttribute("cx",x);c.setAttribute("cy",y);c.setAttribute("r",2);c.setAttribute("fill","none");c.setAttribute("stroke",col);c.setAttribute("stroke-width","1.5");c.dataset.b=performance.now();host.appendChild(c)};
  // tampak samping: permukaan y=34, dasar y=104, pemancing di x=26
  const SURF=34,BOT=104,HX=26,HY=boat?30:24,X0=60,X1=280;
  const depthEnd={dasar:BOT-4,cumi:BOT-14,pelampung:70,popper:SURF,cepat:52,pelan:80}[tech];
  const D=[1400,1800,4200,1800],total=D[0]+D[1]+D[2]+D[3];
  let t0=null,phase=-1,last=0,paused=false,pauseAt=0;
  const setP=i=>{if(i===phase)return;phase=i;cap.textContent=i<3?T[i]:"Strike! Angkat joran, jaga senar tetap tegang, lalu gulung.";stp.textContent=`Langkah ${i+1} dari 4 · ${({popper:"Popping",cepat:"Gulung cepat",dasar:"Mancing dasar",pelampung:"Pelampung",cumi:"Squid jig",pelan:"Umpan alami"})[tech]}`};
  btn.textContent="❚❚ Jeda";
  btn.onclick=()=>{if(!paused){paused=true;pauseAt=performance.now();btn.textContent="▶ Lanjut"}else{paused=false;t0+=performance.now()-pauseAt;btn.textContent="❚❚ Jeda";caRAF=requestAnimationFrame(frame)}};
  const rod=(ang,bend)=>{const L=40,r=ang*rad,ex=HX+Math.cos(r)*L,ey=HY-Math.sin(r)*L,mxr=HX+Math.cos(r)*L*.55+bend*.4,myr=HY-Math.sin(r)*L*.55+bend;sRod.setAttribute("d",`M${HX} ${HY} Q${mxr} ${myr} ${ex+bend*.3} ${ey+bend*.8}`);return[ex+bend*.3,ey+bend*.8]};
  function frame(now){
    if(!document.body.contains(svg)){castAnimStop();return}
    if(paused)return;
    if(t0===null)t0=now;const e=(now-t0)%total;
    let x,y,sx,sy,ang=55,bend=0,jerk=0,fishOn=false,floatX=null;
    if(e<D[0]){setP(0);const t=e/D[0];
      const sw=Math.min(1,t/.25);ang=t<.25?55+sw*70:125-Math.min(1,(t-.25)/.15)*95;
      [x,y]=bez(t);const ft=Math.max(0,(t-.3)/.7);sx=X0+(X1-X0)*ft;sy=ft>0?SURF-Math.sin(Math.PI*ft)*28:null;
      if(t>.97&&now-last>500){ring(rings,tx,ty,"var(--fg)");ring(sRings,X1,SURF,"var(--fg)");last=now}}
    else if(e<D[0]+D[1]){setP(1);const u=(e-D[0])/D[1];x=tx;y=ty;sx=X1;sy=SURF+(depthEnd-SURF)*Math.min(1,u*1.3);ang=40;
      if(tech==="pelampung"){x=tx+u*14;y=ty+Math.sin(u*9)*1.5;sx=X1-u*0;floatX=sx;sy=SURF+(70-SURF)*Math.min(1,u*2)}
      if(tech==="popper")sy=SURF;
      if(tech==="dasar"&&u>.75&&now-last>600){ring(sRings,X1,BOT,"var(--accent)");last=now}}
    else if(e<D[0]+D[1]+D[2]){setP(2);const u=(e-D[0]-D[1])/D[2];ang=40;
      const back2=v=>X1-(X1-170)*v;
      if(tech==="pelampung"){x=tx+14+u*22;y=ty+Math.sin(u*20)*1.5;sx=X1+u*10;floatX=sx;sy=70+Math.sin(u*14)*2}
      else{[x,y]=back(u);sx=back2(u);sy=depthEnd;
        if(tech==="dasar"){const k=u*5,f=k-Math.floor(k),h=f<.35?Math.sin(f/.35*Math.PI/2):Math.cos((f-.35)/.65*Math.PI/2);sy=BOT-4-h*22;y-=h*6;jerk=f<.35?f/.35:Math.max(0,1-(f-.35)/.2)}
        if(tech==="cumi"){const k=u*4,f=k-Math.floor(k);const h=f<.2?f/.2:Math.max(0,1-(f-.2)/.8);sy=BOT-14-h*30;jerk=f<.2?1:0;[x,y]=back((Math.floor(k)+Math.min(1,f/.2))/4);sx=back2((Math.floor(k)+Math.min(1,f/.2))/4)}
        if(tech==="popper"){const k=u*6,f=k-Math.floor(k);const p=f<.25?f/.25:1;[x,y]=back((Math.floor(k)+p)/6);sx=back2((Math.floor(k)+p)/6);sy=SURF;jerk=f<.25?1-f/.25:0;if(f<.06&&now-last>250){ring(rings,x,y,"#fff");ring(sRings,sx,SURF,"#fff");last=now}}
        if(tech==="cepat"){sy=50+Math.sin(u*30)*2;if(now-last>260){ring(rings,x,y,"var(--accent)");last=now}}
        if(tech==="pelan"){sy=80+Math.sin(u*6)*4}}
      ang=40+jerk*28}
    else{setP(3);const u=(e-D[0]-D[1]-D[2])/D[3];fishOn=true;
      const[ex,ey]=tech==="pelampung"?[tx+36,ty]:back(1);x=ex+Math.sin(u*40)*3;y=ey+Math.cos(u*33)*2;
      sx=(tech==="pelampung"?X1+10:170)+Math.sin(u*30)*4;sy=(tech==="popper"?SURF+4:tech==="pelampung"?74:depthEnd)+Math.cos(u*25)*3;
      if(tech==="pelampung"){floatX=X1+10}
      ang=70;bend=14+Math.sin(u*30)*3;
      if(now-last>220){ring(rings,x,y,"var(--sand)");last=now}}
    // peta (atas)
    lure.setAttribute("cx",x);lure.setAttribute("cy",y);
    line.setAttribute("d",`M${mx} ${my} Q${(mx+x)/2} ${Math.min(my,y)-(e<D[0]?20:6)} ${x} ${y}`);
    fsh.setAttribute("opacity",fishOn?1:0);if(fishOn)fsh.setAttribute("transform",`translate(${x+10},${y+4})`);
    // tampak samping
    const[tipX,tipY]=rod(ang,bend);
    if(sy==null){sLure.setAttribute("cx",-20);sLine.setAttribute("d","")}
    else{sLure.setAttribute("cx",sx);sLure.setAttribute("cy",sy);
      const anchorX=floatX!=null?floatX:sx,anchorY=floatX!=null?SURF:sy;
      sLine.setAttribute("d",floatX!=null?`M${tipX} ${tipY} Q${(tipX+anchorX)/2} ${SURF-6} ${anchorX} ${SURF} L${sx} ${sy}`:`M${tipX} ${tipY} Q${(tipX+sx)/2} ${Math.max(tipY,Math.min(sy,SURF))+(phase===0?-6:fishOn?2:8)} ${sx} ${sy}`)}
    sFloat.setAttribute("transform",floatX!=null?`translate(${floatX},${SURF+(fishOn?6:0)})`:"translate(-40,0)");
    sFish.setAttribute("opacity",fishOn?1:0);if(fishOn)sFish.setAttribute("transform",`translate(${sx+12},${sy+2})`);
    sDepth.textContent=sy==null?"":sy<=SURF+1?LX("di permukaan","at the surface"):`± ${Math.max(0,Math.round((sy-SURF)/(BOT-SURF)*(boat?30:6)))} m`;
    sDepth.setAttribute("x",Math.min(250,(sx||0)+8));sDepth.setAttribute("y",(sy||0)-8);
    [rings,sRings].forEach(h=>[...h.children].forEach(c=>{const a=(now-c.dataset.b)/900;if(a>1)c.remove();else{c.setAttribute("r",2+a*12);c.setAttribute("opacity",1-a)}}));
    caRAF=requestAnimationFrame(frame)}
  caRAF=requestAnimationFrame(frame);
}
function sideSVG(){const boat=mode==="perahu";return `<div class="side"><span class="tag">Tampak samping (bawah air)</span><svg viewBox="0 -14 300 132" role="img" aria-label="Tampak samping lemparan">
  <rect y="-14" width="300" height="132" fill="var(--sea)"/><rect y="-14" width="300" height="48" fill="var(--surface)" opacity=".55"/>
  <path d="M0 34 q10 -3 20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0" stroke="var(--accent)" stroke-width="1.5" fill="none"/>
  <path d="M${boat?0:0} 118 L0 104 Q90 ${boat?112:96} 160 108 Q220 112 250 100 Q275 92 300 108 V118Z" fill="var(--land)"/>
  ${boat?`<path d="M6 30 h40 l-6 10 h-28z" fill="var(--muted)"/>`:`<path d="M0 26 h40 L52 118 H0Z" fill="var(--land)"/>`}
  <g fill="var(--fg)"><circle cx="20" cy="${boat?8:2}" r="4"/><path d="M20 ${boat?12:6} v12 M20 ${boat?24:18} l-4 ${boat?6:8} M20 ${boat?24:18} l4 ${boat?6:8} M20 ${boat?15:9} l6 4" stroke="var(--fg)" stroke-width="2.5" stroke-linecap="round"/></g>
  <path id="sRod" stroke="var(--fg)" stroke-width="2.5" fill="none" stroke-linecap="round"/>
  <path id="sLine" stroke="var(--fg)" stroke-width="1" fill="none" opacity=".75"/>
  <g id="sFloat"><ellipse rx="3" ry="6" fill="var(--bad)"/></g>
  <g id="sRings"></g>
  <g id="sFish" opacity="0"><path d="M0 0 q-12 -8 -24 0 q12 8 24 0z M0 0 l8 -6 v12z" fill="var(--fg)" opacity=".8"/></g>
  <circle id="sLure" r="4" fill="var(--sand)" stroke="var(--fg)" stroke-width="1.2" cx="-20" cy="0"/>
  <text id="sDepth" font-size="9" fill="var(--fg)" font-family="var(--mono)"></text>
 </svg></div>`}
let castPick=null;
function castSpot(f){const ok=LOC.filter(l=>l.region===region&&spotData(l).fish.includes(f)).map(l=>l.id);if(castPick&&ok.includes(castPick))return castPick;return ok.includes(curId)?curId:ok[0]}
function spotView(){
  const c0=cur(),c=Object.assign({},c0,spotData(c0)),BAITS=Object.keys(BAITINFO),sel=store.get("mm_bait",BAITS[0]);
  const hits=LOC.filter(l=>l.region===region&&spotData(l).bait[sel]).map(l=>({n:l.n,bait:spotData(l).bait}));const fromBait=[...new Set(hits.flatMap(l=>l.bait[sel]))];
  const f=fishSel&&SP[fishSel]?fishSel:null;
  $("#main").innerHTML=`
   <h2>${esc(c.n)}</h2>
   <div class="seg" role="group" aria-label="Cara mancing"><button data-mode="darat" aria-pressed="${mode==="darat"}">🧍 Dari darat</button><button data-mode="perahu" aria-pressed="${mode==="perahu"}">🚤 Pakai perahu</button></div>
   ${mode==="perahu"?`<p class="note" style="margin-top:-4px">Wajib pelampung di perahu. ${c.est?"Mode perahu di perairan dalam/sungai.":"Ikan & umpan di bawah untuk perairan lepas di sekitar spot ini."}</p>`:""}
   ${f?`<div class="card"><div class="illo">${fishSVG(f)}</div><h3 style="margin-top:8px">${f} <span class="note"><i>${SP[f].lat}</i></span></h3><p>${SP[f].ciri}</p><p class="note">Aturan: ${SP[f].lim}</p>
     <p><b>Umpan yang cocok:</b> ${[...new Set(LOC.flatMap(l=>Object.entries(l.bait).filter(([,fs])=>fs.includes(f)).map(([b])=>b)))].join(", ")}</p>
     <h3 style="margin-top:12px">🏆 Spot terbaik untuk ${f}</h3>${rankListHtml(f,5)}
     <p><b>Biasanya berada di:</b> ${(HABITAT[f]||[]).map(k=>FEAT[k]).join(", ")}</p>
     <h3 style="margin-top:12px">${mode==="perahu"?"Posisi perahu & lemparan":"Peta lempar"}</h3>
     <select class="f" id="castSpot" aria-label="Lokasi peta lempar">${LOC.filter(l=>l.region===region&&spotData(l).fish.includes(f)).map(l=>`<option value="${l.id}" ${l.id===castSpot(f)?"selected":""}>${l.n}</option>`).join("")}</select>
     <div style="margin-top:8px">${castMap(castSpot(f),f)}</div>${sideSVG()}
     <p class="note">Skema tidak berskala; sesuaikan dengan kondisi air di lokasi.</p>
     <div class="caCap"><span class="tag" id="caStep">Animasi</span><p id="caTxt" style="margin:2px 0 8px">Tekan putar untuk melihat cara memancing ${f}.</p><button class="btn" id="caPlay" type="button" style="width:100%">▶ Putar animasi</button></div>
     ${videoBlock(f,"how to catch "+f)}
     <button class="btn ghost" id="closeFish" style="margin-top:10px">Tutup</button></div>`:""}
   ${!c.fish?.length?`<div class="card"><p>Spot ini belum punya data ikan. Pakai "Kamu di mana?" di tab Peta untuk mencarinya.</p></div>`:`
   ${(()=>{const n=inSeasonNow(c.fish);return n.length?`<div class="card inseason"><b>🔥 Sedang musim:</b> ${n.map(fishMini).join("")}</div>`:""})()}
   <h3>Ikan di lokasi ini</h3>
   <div class="fishgrid">${c.fish.map(n=>`<button class="fcard" data-f="${n}">${fishSVG(n)}<b>${n}</b><span class="note">${SP[n]?.lim||""}</span></button>`).join("")}</div>
   <div class="card" style="margin-top:12px"><h3>Posisi ikan</h3><p>${c.spots}</p><h3>Waktu & pasang terbaik</h3><p>${c.tide}</p></div>
   <div class="card"><h3>Umpan → ikan yang didapat</h3><table><thead><tr><th>Umpan</th><th>Ikan</th></tr></thead><tbody>${Object.entries(c.bait).map(([b,fs])=>`<tr><td><b>${b}</b><br><span class="note">${BAITINFO[b]||""}</span></td><td>${fs.map(fishMini).join("")}</td></tr>`).join("")}</tbody></table></div>`}
   ${rankCardHtml()}
   <div class="card"><h3>Punya umpan apa?</h3>
     <select class="f" id="baitSel" aria-label="Pilih umpan">${BAITS.map(b=>`<option ${b===sel?"selected":""}>${b}</option>`).join("")}</select>
     <p class="note">${BAITINFO[sel]}</p><div>${fromBait.map(fishMini).join("")}</div>
     <table style="margin-top:8px"><thead><tr><th>Lokasi</th><th>Ikan</th></tr></thead><tbody>${hits.map(l=>`<tr><td>${l.n}</td><td>${l.bait[sel].join(", ")}</td></tr>`).join("")}</tbody></table></div>
   ${region==="AU"?`<p class="note">Fish pictures are for identification. Size & bag limits can change, check <a href="https://www.dpi.nsw.gov.au/fishing/recreational" target="_blank" rel="noopener">NSW DPI</a>.</p>`:""}${promoCardHtml()}${corrCardHtml()}`;
  bindPromo();bindCorr();
  document.querySelectorAll(".fcard").forEach(b=>b.onclick=()=>{fishSel=b.dataset.f;render();$("#main").scrollTop=0});
  const cf=$("#closeFish");if(cf)cf.onclick=()=>{fishSel=null;render()};
  const cs=$("#castSpot");if(cs)cs.onchange=e=>{castPick=e.target.value;render()};
  castAnimStop();const cp=$("#caPlay");if(cp){cp.onclick=castAnimStart;castAnimStart()}
  $("#baitSel").onchange=e=>{store.set("mm_bait",e.target.value);render()};
  bindRank();
  document.querySelectorAll("[data-mode]").forEach(b=>b.onclick=()=>{mode=b.dataset.mode;store.set("mm_mode",mode);fishSel=null;render()});
}

/* ================= KOMUNITAS (Supabase): akun, feed tangkapan, foto, lapor, blokir ================= */
const CFG=window.MM_CONFIG||{};
const sb=(window.supabase&&CFG.SUPABASE_URL&&CFG.SUPABASE_ANON_KEY)?window.supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_ANON_KEY):null;
function recordVisit(){try{if(!sb)return;const d=new Date().toISOString().slice(0,10)+region;if(store.get("mm_vday","")===d)return;
  let id=store.get("mm_dev","");if(!id){id=(crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2,12));store.set("mm_dev",id)}
  const plat=window.Capacitor?"apk":(window.matchMedia&&matchMedia("(display-mode: standalone)").matches||navigator.standalone)?"pwa":"web";
  sb.rpc("record_visit",{p_device:id,p_region:region,p_platform:plat}).then(r=>{if(!r.error)store.set("mm_vday",d)})}catch(e){}}
setTimeout(recordVisit,4000);
let me=null,myName="",isAdmin=false,blocked=new Set(),feed=null,feedErr="",feedFilter="semua";
let pendingPhoto=null,pendingBlob=null,pickFish="",postMsg="";
try{pendingPhoto=sessionStorage.getItem("mm_photo");pickFish=sessionStorage.getItem("mm_fish")||"";if(pendingPhoto)fetch(pendingPhoto).then(r=>r.blob()).then(b=>pendingBlob=b)}catch(e){}
const savePending=()=>{try{pendingPhoto?sessionStorage.setItem("mm_photo",pendingPhoto):sessionStorage.removeItem("mm_photo");sessionStorage.setItem("mm_fish",pickFish||"")}catch(e){}};
let authStep="email",authEmail="",authMsg="";
function shrink(file,max){return new Promise((res,rej)=>{const img=new Image();img.onload=()=>{const k=Math.min(1,max/Math.max(img.width,img.height)),cv=document.createElement("canvas");cv.width=Math.round(img.width*k);cv.height=Math.round(img.height*k);cv.getContext("2d").drawImage(img,0,0,cv.width,cv.height);res(cv);URL.revokeObjectURL(img.src)};img.onerror=rej;img.src=URL.createObjectURL(file)})}
const photoUrl=p=>p&&sb?sb.storage.from("photos").getPublicUrl(p).data.publicUrl:"";
async function initCommunity(){
  if(!sb){feed=[];feedErr="Komunitas belum diaktifkan. Pemilik aplikasi perlu mengisi config.js (lihat PANDUAN).";return}
  const{data}=await sb.auth.getSession();await setUser(data.session?.user||null);
  sb.auth.onAuthStateChange((_e,s)=>{const nu=s?.user||null;if((nu?.id||null)===(me?.id||null))return;setUser(nu).then(()=>{if(["tangkapan","lainnya","peta"].includes(view))render()})});
  await loadFeed();loadPoints();loadListings();loadApproved().then(()=>{fillPick();if(view!=="tangkapan")render()});
}
async function setUser(u){
  me=u;myName="";isAdmin=false;blocked=new Set();
  if(!u)return;
  const[p,a,b]=await Promise.all([sb.from("profiles").select("name").eq("id",u.id).maybeSingle(),sb.from("admins").select("user_id").eq("user_id",u.id).maybeSingle(),sb.from("blocks").select("blocked")]);
  myName=p.data?.name||"";isAdmin=!!a.data;(b.data||[]).forEach(x=>blocked.add(x.blocked));
}
async function loadFeed(){
  if(!sb)return;
  const{data,error}=await sb.from("catches").select("id,user_id,fish,length_cm,bait,released,spot_id,spot_name,area,lat,lon,photo_path,created_at,hidden,profiles(name)").order("created_at",{ascending:false}).limit(200);
  if(error){const fc=store.get("mm_feed_cache",null);if(fc&&!feed){feed=fc.feed;likes=fc.likes||{};comments=fc.comments||{};feedErr=""}else{feedErr="Feed tidak bisa dimuat. Periksa koneksi lalu tarik ulang.";feed=feed||[]}}else{feed=data;feedErr="";loadSocial()}
  if(["tangkapan","peta"].includes(view))render();
}
const ago=t=>{const m=Math.round((Date.now()-Date.parse(t))/6e4);return m<60?Math.max(1,m)+" mnt lalu":m<1440?Math.round(m/60)+" jam lalu":Math.round(m/1440)+" hari lalu"};
function authCard(compact){
  if(!sb)return `<div class="card"><p class="note">Komunitas belum diaktifkan di aplikasi ini.</p></div>`;
  if(me&&!myName)return `<form id="nameF" class="card"><h3>Satu langkah lagi</h3><p class="note">Nama ini terlihat oleh pemancing lain.</p><input id="nm" placeholder="Nama panggilan (2–30 huruf)" minlength="2" maxlength="30" required><button class="btn" type="submit">Simpan nama</button><p class="note" id="nmMsg"></p></form>`;
  if(me)return compact?"":`<div class="card"><span class="tag">Masuk sebagai</span><h3>${esc(myName)}</h3><p class="note">${esc(me.email||"")}</p></div>`;
  return `<form id="authF" class="card"><h3>Masuk untuk berbagi tangkapan</h3>
   ${authStep==="email"?`<p class="note">Kami kirim link masuk ke email kamu. Tanpa kata sandi.</p><input id="em" type="email" placeholder="email@contoh.com" required autocomplete="email"><button class="btn" type="submit">Kirim link masuk</button>`
    :`<p class="note">Link masuk sudah dikirim ke <b>${esc(authEmail)}</b> (cek juga folder Spam).</p>
     <ol class="note" style="margin:4px 0 8px">${window.Capacitor?`<li>Buka email itu, <b>tekan lama</b> tombol/link masuk, lalu pilih <b>Salin link</b>.</li><li>Tempel link-nya di bawah, lalu ketuk Masuk.</li>`:`<li>Buka email itu di HP/komputer ini dan klik link masuk, <b>atau</b></li><li>salin link-nya dan tempel di bawah.</li>`}</ol>
     <input id="otp" placeholder="Tempel link dari email (atau kode)" required autocomplete="off"><div class="two"><button class="btn" type="submit">Masuk</button><button class="btn ghost" type="button" id="authBack">Ganti email</button></div>`}
   <p class="note" style="color:var(--bad)">${esc(authMsg)}</p></form>`;
}
function bindAuth(){
  const f=$("#authF");if(f)f.onsubmit=async e=>{e.preventDefault();authMsg="";const btn=f.querySelector("button[type=submit]");btn.disabled=true;
    if(authStep==="email"){authEmail=$("#em").value.trim();const{error}=await sb.auth.signInWithOtp({email:authEmail,options:window.Capacitor?{}:{emailRedirectTo:location.origin+location.pathname}});
      if(error)authMsg=/rate/i.test(error.message)?"Terlalu sering. Tunggu beberapa menit lalu coba lagi.":"Gagal mengirim kode. Periksa alamat email.";else authStep="kode"}
    else{const v=$("#otp").value.trim();let res;
      if(/token(_hash)?=/.test(v)){let u;try{u=new URL(v)}catch(e){u=null}
        const q=u?new URLSearchParams(u.search+"&"+u.hash.replace(/^#/,"")):new URLSearchParams(v.split("?")[1]||"");
        const th=q.get("token_hash")||q.get("token");res=await sb.auth.verifyOtp({token_hash:th,type:"email"});
        if(res.error)res=await sb.auth.verifyOtp({token_hash:th,type:"magiclink"});}
      else res=await sb.auth.verifyOtp({email:authEmail,token:v,type:"email"});
      if(res.error)authMsg="Link/kode tidak valid atau sudah kedaluwarsa (berlaku 1 jam, sekali pakai). Minta link baru.";else authStep="email"}
    render()};
  const bk=$("#authBack");if(bk)bk.onclick=()=>{authStep="email";authMsg="";render()};
  const nf=$("#nameF");if(nf)nf.onsubmit=async e=>{e.preventDefault();const n=$("#nm").value.trim();const{error}=await sb.from("profiles").upsert({id:me.id,name:n});if(error){$("#nmMsg").textContent="Nama tidak bisa disimpan. Coba nama lain."}else{myName=n;render()}};
}
let cmap=null,cmk=null;
function catchView(){
  if(cmap){try{cmap.remove()}catch(e){}cmap=null;cmk=null}
  const c=cur(),regionFish=[...new Set(LOC.filter(l=>l.region===region).flatMap(l=>spotData(l).fish))].filter(f=>SP[f]),fishList=[...new Set(regionFish.concat(Object.keys(SP).sort()))];
  const rfeed=(feed||[]).filter(inRegion);
  const list=rfeed.filter(x=>!blocked.has(x.user_id)&&(feedFilter==="semua"||(feedFilter==="spot"&&x.spot_id===c.id)||(feedFilter==="saya"&&me&&x.user_id===me.id)));
  const week=rfeed.filter(x=>Date.now()-Date.parse(x.created_at)<7*864e5),top={},hot={};week.forEach(x=>{top[x.fish]=(top[x.fish]||0)+1;if(x.spot_name)hot[x.spot_name]=(hot[x.spot_name]||0)+1});
  const canPost=sb&&me&&myName;
  $("#main").innerHTML=`
   ${offlineBadge()}<h2>Tangkapan</h2>
   ${canPost?`<div class="card"><h3>Foto tangkapanmu</h3>
     <div class="two"><label class="btn" for="cam">📷 Buka kamera</label><label class="btn ghost" for="gal">Pilih dari galeri</label></div>
     <input type="file" id="cam" accept="image/*" capture="environment" hidden><input type="file" id="gal" accept="image/*" hidden>
     ${pendingPhoto?`<img class="preview" src="${pendingPhoto}" alt="Foto tangkapan">`:""}
     <h3 style="margin-top:10px">Ikan apa ini?</h3><p class="note">Bandingkan dengan gambar, lalu ketuk yang paling mirip.</p>
     <div class="pickgrid">${regionFish.map(f=>`<button type="button" class="pick" data-pick="${f}" aria-pressed="${pickFish===f}">${fishSVG(f)}<span>${f}</span></button>`).join("")}</div></div>
   <form id="cf" class="card"><h3>Bagikan ke komunitas</h3>
     <div class="two"><select class="f" id="cfish" aria-label="Ikan">${fishList.map(f=>`<option ${f===pickFish?"selected":""}>${f}</option>`).join("")}<option value="__new">➕ Ikan lain (tulis sendiri)</option></select><input id="clen" type="number" min="1" max="400" placeholder="Panjang (cm)" aria-label="Panjang"></div>
     <div class="two"><input id="cbait" placeholder="Umpan" aria-label="Umpan" maxlength="60"><label class="note" style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="crel" style="width:auto"> Dilepas</label></div>
     <input id="cnewfish" placeholder="Nama ikan (mis. Kakap Batu)" maxlength="40" style="display:none" aria-label="Nama ikan baru">
     <h3 style="margin-top:8px">Lokasi</h3>
     <div class="seg"><button type="button" data-lm="spot" aria-pressed="true">Spot: ${esc(c.n)}</button><button type="button" data-lm="gps" aria-pressed="false">📍 Lokasiku (GPS)</button><button type="button" data-lm="map" aria-pressed="false">🗺️ ${LX("Pilih di peta","Pick on map")}</button><button type="button" data-lm="new" aria-pressed="false">➕ Spot baru</button></div>
     <div id="cmapbox" style="display:none;margin:8px 0"><p class="note">${LX("Ketuk peta atau geser penanda 📍 ke tempat ikan didapat.","Tap the map or drag the 📍 marker to where you caught the fish.")}</p><div id="cmap" class="lmap" style="height:260px;margin-right:22px"></div><p class="note" id="cmapinfo"></p></div>
     <div id="clocx" style="display:none"><input id="cplace" placeholder="Nama tempat (mis. Pantai Kaliantan sisi timur)" maxlength="60" aria-label="Nama tempat"><p class="note" id="cgps">Mengambil lokasi GPS…</p></div>
     <label class="note" style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="chide" style="width:auto"> Rahasiakan spot (hanya tampilkan daerah: ${esc(c.a||"")})</label>
     <p class="note" style="color:var(--good,#1a9e5a);font-weight:600">${esc(postMsg)}</p><p class="note" id="cwarn" style="color:var(--bad)"></p>
     <button class="btn" type="submit" id="postBtn">⬆️ Upload di ${esc(c.n)}${pendingPhoto?" + foto":""}</button></form>`:authCard()}
   <div class="card"><h3>7 hari terakhir</h3><div class="row"><div class="kv"><span class="tag">Tangkapan</span><strong>${week.length}</strong></div><div class="kv"><span class="tag">Ikan terbanyak</span><strong>${Object.entries(top).sort((a,b)=>b[1]-a[1])[0]?.[0]||"–"}</strong></div><div class="kv"><span class="tag">Spot terpanas</span><strong style="font-size:1rem">${Object.entries(hot).sort((a,b)=>b[1]-a[1])[0]?.[0]||"–"}</strong></div></div></div>
   ${statsHtml()}
   ${logbookHtml()}
   ${leaderboardHtml(rfeed.filter(x=>!blocked.has(x.user_id)))}
   <div class="seg"><button data-ff="semua" aria-pressed="${feedFilter==="semua"}">Semua</button><button data-ff="spot" aria-pressed="${feedFilter==="spot"}">Di ${esc(c.n)}</button>${me?`<button data-ff="saya" aria-pressed="${feedFilter==="saya"}">Punyaku</button>`:""}<button id="refresh" aria-label="Muat ulang">↻</button></div>
   <div class="card" id="feedList">${feed===null?`<p class="note">Memuat tangkapan…</p>`:feedErr?`<p class="note">${feedErr}</p>`:list.length?list.map(feedItem).join(""):`<p class="note">Belum ada tangkapan${feedFilter==="spot"?" di spot ini":""}. Jadilah yang pertama!</p>`}</div>`;
  bindAuth();bindFeed();bindLogbook();
  document.querySelectorAll("[data-ff]").forEach(b=>b.onclick=()=>{feedFilter=b.dataset.ff;render()});
  const rf=$("#refresh");if(rf)rf.onclick=()=>{feed=null;render();loadFeed()};
  if(!canPost)return;
  document.querySelectorAll("[data-pick]").forEach(b=>b.onclick=()=>{pickFish=b.dataset.pick;savePending();render()});
  const chk=()=>{const f=$("#cfish").value,l=+$("#clen").value,m=region==="AU"?SP[f]?.min:0;$("#cwarn").textContent=m&&l&&l<m?`Di bawah ukuran minimum ${f} (${m} cm). Wajib dilepas.`:""};
  $("#cfish").onchange=chk;$("#clen").oninput=chk;
  const onPick=async e=>{const f=e.target.files[0];if(!f)return;try{const cv=await shrink(f,1000);const okp=await photoSafe(cv);if(okp===false){$("#cwarn").textContent=LX("❌ Foto ditolak: terdeteksi konten tidak pantas.","❌ Photo rejected: inappropriate content detected.");return}pendingBlob=await new Promise(r=>cv.toBlob(r,"image/jpeg",.78));pendingPhoto=cv.toDataURL("image/jpeg",.6);postMsg="Foto siap. Isi data di bawah lalu tekan tombol Upload.";savePending();render();setTimeout(()=>$("#cf")?.scrollIntoView({behavior:"smooth"}),50)}catch(err){$("#cwarn").textContent="Foto tidak bisa dibaca. Coba foto lain."}};
  let locMode="spot",gpsPos=null,mapPos=null;
  const nearName=(la,lo)=>{let b=null,d=1e9;allSpots().forEach(x=>{const k=km(la,lo,x.lat,x.lon);if(k<d){d=k;b=x}});return b&&d<30?{s:b,d}:null};
  const setPick=(la,lo)=>{mapPos=[la,lo];if(cmk)cmk.setLatLng(mapPos);const n=nearName(la,lo);$("#cmapinfo").textContent=`📍 ${la.toFixed(4)}, ${lo.toFixed(4)}`+(n?` · ${LX("dekat","near")} ${n.s.n} (${n.d} km)`:"")};
  const openMap=()=>{$("#cmapbox").style.display="";if(cmap){setTimeout(()=>cmap.invalidateSize(),50);return}
    if(!window.L){$("#cmapinfo").textContent=LX("Peta butuh internet.","Map needs internet.");return}
    const st=mapPos||(here?[here.lat,here.lon]:[c.lat,c.lon]);
    cmap=L.map("cmap",{zoomControl:true}).setView(st,13);L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap"}).addTo(cmap);
    cmk=L.marker(st,{draggable:true}).addTo(cmap);cmk.on("dragend",()=>{const q=cmk.getLatLng();setPick(q.lat,q.lng)});cmap.on("click",ev=>setPick(ev.latlng.lat,ev.latlng.lng));setPick(st[0],st[1]);setTimeout(()=>cmap.invalidateSize(),80)};
  $("#cfish").addEventListener("change",()=>{$("#cnewfish").style.display=$("#cfish").value==="__new"?"":"none"});
  document.querySelectorAll("[data-lm]").forEach(b=>b.onclick=()=>{locMode=b.dataset.lm;document.querySelectorAll("[data-lm]").forEach(x=>x.setAttribute("aria-pressed",x===b));
    $("#clocx").style.display=locMode==="spot"?"none":"";$("#cmapbox").style.display=locMode==="map"||locMode==="new"?"":"none";$("#cgps").style.display=locMode==="map"?"none":"";if(locMode==="map"||locMode==="new")openMap();$("#cplace").placeholder=locMode==="new"?LX("Nama spot baru (wajib)","New spot name (required)"):LX("Nama tempat (opsional)","Place name (optional)");
    if(locMode==="gps"&&!gpsPos){$("#cgps").textContent="Mengambil lokasi GPS…";navigator.geolocation?navigator.geolocation.getCurrentPosition(p=>{gpsPos=[p.coords.latitude,p.coords.longitude];$("#cgps").textContent=`📍 Lokasi didapat (±${Math.round(p.coords.accuracy)} m). Akan ditampilkan di peta komunitas.`},()=>{$("#cgps").textContent="Lokasi tidak bisa diambil. Izinkan akses lokasi di browser/HP lalu ketuk lagi."},{enableHighAccuracy:true,timeout:15000}):$("#cgps").textContent="HP ini tidak mendukung GPS."}});
  $("#cam").onchange=onPick;$("#gal").onchange=onPick;
  $("#cf").onsubmit=async e=>{e.preventDefault();const btn=$("#postBtn");btn.disabled=true;btn.textContent="Mengupload…";
    try{
      let path=null;
      if(pendingBlob){path=`${me.id}/${Date.now()}.jpg`;const up=await sb.storage.from("photos").upload(path,pendingBlob,{contentType:"image/jpeg",cacheControl:"31536000"});if(up.error)throw up.error}
      const hide=$("#chide").checked;let fish=$("#cfish").value;
      if(fish==="__new"){fish=$("#cnewfish").value.trim();if(fish.length<2)throw new Error("Tulis nama ikannya dulu")}
      let sid=c.id,sname=c.n,la=c.lat,lo=c.lon;
      if(locMode!=="spot"){const pos=locMode==="gps"?gpsPos:(mapPos||gpsPos);if(!pos)throw new Error(locMode==="gps"?"Lokasi GPS belum didapat, izinkan lokasi lalu coba lagi":"Pilih lokasi di peta dulu");const nm=$("#cplace").value.trim();if(locMode==="new"&&nm.length<3)throw new Error("Tulis nama spot barunya dulu");const nn=nearName(pos[0],pos[1]);sid=null;sname=nm||(nn&&nn.d<3?nn.s.n:nn?"Dekat "+nn.s.n:"Lokasi pemancing");la=pos[0];lo=pos[1]}
      const row={fish,length_cm:+$("#clen").value||null,bait:$("#cbait").value.trim().slice(0,60)||null,released:$("#crel").checked,spot_id:hide?null:sid,spot_name:hide?null:sname,area:c.a||null,lat:hide?null:+la.toFixed(3),lon:hide?null:+lo.toFixed(3),photo_path:path};
      const{error}=await sb.from("catches").insert(row);if(error)throw error;
      {const ent={id:"l"+Date.now(),t:Date.now(),fish,len:row.length_cm,bait:row.bait||"",spot:sname||c.n,note:"",photo:null,region,spotId:sid,lat:la,lon:lo,posted:true};logbook.push(ent);saveLog();captureConditions(la,lo,ent.t).then(cd=>{ent.cond=cd;saveLog()})}
      if($("#cfish").value==="__new"&&!SP[fish])submitNew("fish",{name:fish});
      if(locMode==="new")submitNew("spot",{name:sname,lat:+la.toFixed(4),lon:+lo.toFixed(4),area:c.a||null,fish});
      pendingPhoto=pendingBlob=null;pickFish="";savePending();feedFilter="semua";postMsg="✅ Terkirim! Tangkapanmu sudah tampil di daftar di bawah.";await loadFeed();render();setTimeout(()=>$("#feedList")?.scrollIntoView({behavior:"smooth"}),50);
    }catch(err){btn.disabled=false;btn.textContent="Coba upload lagi";$("#cwarn").textContent="Upload gagal: "+(err?.message||err)+". Kirim tangkapan layar ini lewat menu Saran & laporan bila terus terjadi."}};
}
async function deleteAccount(){
  // hapus semua foto milik sendiri, lalu akun (data tangkapan ikut terhapus lewat ON DELETE CASCADE)
  const{data:files}=await sb.storage.from("photos").list(me.id,{limit:1000});
  if(files?.length)await sb.storage.from("photos").remove(files.map(f=>`${me.id}/${f.name}`));
  const{error}=await sb.rpc("delete_my_account");if(error)throw error;
  await sb.auth.signOut();
}

/* ================= TUTORIAL & TIPS ================= */
const svgRig=i=>`<svg viewBox="0 0 280 160" role="img"><g stroke="currentColor" fill="none" stroke-width="2">${i}</g></svg>`;
const T=(x,y,s)=>`<text x="${x}" y="${y}" font-size="11" fill="currentColor" stroke="none">${s}</text>`;
const yt=q=>`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`;
const RIGS=[
 {n:"Running sinker rig",u:"Paling serbaguna: bream, flathead, whiting.",v:"running sinker rig fishing tutorial",svg:svgRig(`<line x1="10" y1="80" x2="130" y2="80"/><circle cx="90" cy="80" r="8" fill="currentColor"/><rect x="128" y="74" width="12" height="12"/><line x1="140" y1="80" x2="240" y2="80" stroke-dasharray="4 3"/><path d="M240 80 q14 0 14 14 q0 10 -10 8"/>${T(60,62,"pemberat bebas")}${T(118,104,"swivel")}${T(160,70,"leader 40–60 cm")}`),s:["Masukkan pemberat bola ke senar utama.","Ikat senar utama ke swivel (improved clinch).","Ikat leader 40–60 cm ke sisi lain swivel.","Ikat kail di ujung leader.","Pemberat bergerak bebas, ikan tidak merasakan beban."]},
 {n:"Paternoster rig",u:"Mancing dasar dari batu/perahu: snapper, trevally.",v:"paternoster rig how to tie",svg:svgRig(`<line x1="140" y1="10" x2="140" y2="130"/><path d="M140 140 l-8 -10 h16z" fill="currentColor"/><line x1="140" y1="50" x2="200" y2="50" stroke-dasharray="4 3"/><line x1="140" y1="90" x2="200" y2="90" stroke-dasharray="4 3"/><path d="M200 50 q12 0 12 12 q0 8 -8 6"/><path d="M200 90 q12 0 12 12 q0 8 -8 6"/>${T(40,54,"dropper loop")}${T(60,148,"pemberat di ujung")}`),s:["Buat 2 dropper loop di leader, jarak ±30 cm.","Pasang kail ke tiap loop.","Ikat pemberat bintang di ujung bawah.","Ikat atas leader ke swivel lalu senar utama.","Turunkan sampai dasar, gulung sedikit agar tegang."]},
 {n:"Float rig",u:"Luderick, yellowtail, garfish di dermaga dan batu.",v:"luderick float rig setup",svg:svgRig(`<line x1="20" y1="50" x2="260" y2="50" stroke-dasharray="2 4"/><ellipse cx="140" cy="45" rx="8" ry="18"/><line x1="140" y1="63" x2="140" y2="140"/><circle cx="140" cy="100" r="3" fill="currentColor"/><path d="M140 140 q10 0 10 10 q0 6 -6 5"/>${T(160,40,"pelampung")}${T(150,104,"split shot")}`),s:["Pasang stopper di senar untuk mengatur kedalaman.","Masukkan pelampung.","Jepit 1–3 split shot agar pelampung tegak.","Ikat kail kecil no. 8–10.","Atur kedalaman 1–2 m untuk luderick."]},
 {n:"Jighead + soft plastic",u:"Flathead, bream, kingfish kecil.",v:"how to rig soft plastic jighead flathead",svg:svgRig(`<line x1="10" y1="80" x2="110" y2="80"/><circle cx="120" cy="80" r="10" fill="currentColor"/><path d="M130 80 q40 -14 80 0 q20 4 40 -6 q-10 14 -40 14 q-40 0 -80 -8"/>${T(80,62,"jighead 1/8–1/4 oz")}${T(160,118,"soft plastic")}`),s:["1/8 oz di air tenang, 1/4–3/8 oz di arus kuat.","Tusuk ujung kepala plastik tepat di tengah.","Dorong sampai kail keluar di punggung, harus lurus.","Ikat ke leader fluorocarbon 8–12 lb dengan loop knot.","Lempar, biarkan ke dasar, angkat joran, ulangi."]},
 {n:"Gang hook (pilchard)",u:"Tailor & salmon dengan pilchard utuh.",v:"how to rig pilchard gang hooks tailor",svg:svgRig(`<line x1="10" y1="80" x2="60" y2="80"/><path d="M60 80 Q140 60 230 78 Q140 98 60 80Z" fill="currentColor" opacity=".2"/><g><path d="M90 74 q10 -14 0 -18"/><path d="M140 72 q10 -14 0 -18"/><path d="M190 74 q10 -14 0 -18"/></g>${T(80,120,"3–4 kail bersambung (gang)")}`),s:["Pakai gang hook 3–4 kail (ukuran 3/0–4/0).","Tusuk kail pertama di mata pilchard.","Kail berikutnya ditusuk di sepanjang badan.","Pastikan pilchard lurus agar tidak berputar.","Lempar dan gulung pelan di permukaan air berbuih."]}
];
const TIPS=[
 {h:"Berley (umpan tabur)",t:"Campur roti basah, pelet ayam, dan pilchard cincang. Tabur sedikit tapi terus-menerus agar ikan bertahan di depanmu.",v:"berley tips fishing australia",svg:svgRig(`<line x1="10" y1="50" x2="270" y2="50" stroke-dasharray="2 4"/><path d="M40 20 q10 -10 20 0 v20 h-20z" fill="currentColor" opacity=".3"/>${[60,80,100,120,140,160].map((x,i)=>`<circle cx="${x+i*4}" cy="${70+i*12}" r="3" fill="currentColor"/>`).join("")}<path d="M210 120 q20 -10 40 0 q-20 10 -40 0z" fill="currentColor"/><path d="M200 100 q20 -10 40 0 q-20 10 -40 0z" fill="currentColor" opacity=".6"/>${T(20,150,"tabur sedikit-sedikit → ikan naik ke kolom air")}`)},
 {h:"Mancing squid",t:"Jig 2.5–3.0 di sekitar rumput laut saat subuh/senja. Lempar, biarkan tenggelam, sentak 2–3 kali lalu diam. Squid menyambar saat jig diam.",v:"squid jigging Sydney tips",svg:svgRig(`<path d="M10 30 Q80 20 140 60 Q190 90 260 70"/>${[[60,26],[120,50],[170,80]].map(([x,y])=>`<path d="M${x} ${y} l12 -14 M${x} ${y} l12 14" stroke-width="1.5"/>`).join("")}<path d="M240 66 l20 -6 -6 14z" fill="currentColor"/>${T(20,140,"sentak – sentak – DIAM (squid menyambar di sini)")}`)},
 {h:"Flathead dengan soft plastic",t:"Lompatkan umpan pelan di dasar pasir saat pasang turun. Flathead menunggu di tepi drop-off.",v:"flathead soft plastic technique",svg:svgRig(`<path d="M10 130 h260" stroke-width="3"/><path d="M20 128 l30 -30 l20 30 l30 -30 l20 30 l30 -30 l20 30" stroke-dasharray="5 3"/><path d="M200 126 Q230 116 260 126" fill="currentColor" opacity=".4"/>${T(20,40,"angkat – jatuh ke dasar – ulangi")}${T(190,112,"flathead")}`)},
 {h:"Bream itu pemalu",t:"Leader fluorocarbon 4–6 lb, kail no. 4–1, pemberat seringan mungkin. Lempar ke tiang dermaga dan bayangan perahu.",v:"bream fishing tips Sydney",svg:svgRig(`${[60,120,180].map(x=>`<rect x="${x}" y="20" width="12" height="130" fill="currentColor" opacity=".25"/>`).join("")}<path d="M10 40 Q90 30 100 100" stroke-dasharray="4 3"/><circle cx="100" cy="100" r="4" fill="currentColor"/>${T(130,80,"umpan jatuh alami")}${T(130,96,"di dekat tiang")}`)},
 {h:"Keselamatan mancing batu",t:"Pakai pelampung (wajib di beberapa area NSW), sepatu anti-licin, amati ombak 15 menit dulu, dan jangan pernah membelakangi laut.",v:"rock fishing safety NSW",svg:svgRig(`<path d="M10 140 L80 90 L140 100 L200 70 L270 80 V150 H10Z" fill="currentColor" opacity=".25"/><path d="M200 60 q20 -40 50 -20 q-10 10 0 20" stroke-width="3"/><rect x="120" y="60" width="16" height="22" rx="4" fill="#e8742a" stroke="none"/><circle cx="128" cy="52" r="6"/>${T(20,30,"ombak set datang tiba-tiba")}`)},
 {h:"Merawat ikan",t:"Mau dibawa pulang: matikan cepat (iki jime), keluarkan darah, simpan di es. Mau dilepas: basahi tangan, lepas kail cepat, pegang horizontal di air sampai berenang sendiri.",v:"ikijime fish humane dispatch",svg:svgRig(`<rect x="30" y="60" width="130" height="80" rx="8"/><path d="M40 60 h110" stroke-width="4"/>${[50,80,110,140].map(x=>`<rect x="${x-8}" y="95" width="16" height="16" fill="currentColor" opacity=".3"/>`).join("")}${T(40,50,"es + air laut (slurry)")}<path d="M180 100 q30 -20 60 0 q-30 20 -60 0z" fill="currentColor" opacity=".5"/>${T(180,135,"lepas di air")}`)},
 {h:"Membaca air",t:"Cari pertemuan arus, air keruh dan jernih, bayangan, dan karang. Burung yang menyelam berarti ikan umpan sedang dikejar ikan predator.",v:"how to read the water fishing",svg:svgRig(`<path d="M10 80 Q70 60 140 80 T270 80"/><path d="M10 100 Q70 80 140 100 T270 100" opacity=".5"/><path d="M150 30 l15 20 l15 -20" stroke-width="3"/>${[150,165,180,170].map((x,i)=>`<circle cx="${x}" cy="${88+i*3}" r="2" fill="currentColor"/>`).join("")}${T(20,140,"burung menyelam = ikan umpan diburu")}`)},
 {h:"Zona marine park",t:"Beberapa area dilarang mancing, misalnya Cabbage Tree Bay di Manly dan sebagian Botany Bay. Cek peta zona NSW sebelum berangkat.",v:"NSW marine park fishing zones",svg:svgRig(`<rect x="30" y="30" width="220" height="100" rx="6" stroke-dasharray="6 4"/><circle cx="140" cy="80" r="30"/><line x1="118" y1="58" x2="162" y2="102" stroke-width="4"/>${T(50,150,"zona larangan: tidak boleh mancing")}`)}
];

/* ================= TUTORIAL ANIMASI ================= */
const LINE='stroke="var(--fg)" stroke-width="2.5" fill="none" stroke-linecap="round"',TAG='stroke="var(--accent)" stroke-width="3" fill="none" stroke-linecap="round"';
const dr=(d,attr,on)=>`<path d="${d}" ${attr} pathLength="1" class="${on?"draw":""}"/>`;
const coilPath=(()=>{let d="M200 92";for(let i=0;i<6;i++){const x=200-i*12;d+=` Q${x-3} 58 ${x-6} 80 Q${x-9} 102 ${x-12} 88`}return d})();
const HOOK=`<g stroke="var(--muted)" stroke-width="4" fill="none" stroke-linecap="round"><circle cx="222" cy="80" r="9"/><path d="M231 82 L262 82 Q292 84 290 112 Q286 138 262 132 Q250 128 254 114"/><path d="M254 114 l-7 -2" stroke-width="3"/></g>`;
const ANIMS=[
 {id:"clinch",n:"Improved clinch knot",u:"Simpul paling umum untuk mengikat kail atau swivel. Kuat dan mudah.",steps:[
  {h:"Masukkan senar ke mata kail",t:"Masukkan ujung senar (hijau) ke lubang mata kail, tarik keluar sekitar 15 cm.",L:on=>dr("M10 80 L213 80",LINE,0)+dr("M213 80 Q240 80 236 94 Q230 100 205 93",TAG,on)},
  {h:"Lilitkan 5–7 kali",t:"Putar ujung senar mengelilingi senar utama 5 sampai 7 kali, menjauhi kail.",L:on=>`<g class="coils">${dr(coilPath,TAG,on)}</g>`},
  {h:"Masuk ke loop kecil",t:"Bawa ujung senar kembali dan masukkan ke loop kecil tepat di depan mata kail.",L:on=>dr("M128 88 C136 122 196 120 212 88",TAG,on)+`<circle cx="212" cy="88" r="8" fill="none" stroke="var(--sand)" stroke-width="2" class="${on?"pulse":""}"/>`},
  {h:"Lalu ke loop besar",t:"Ujung yang sama dimasukkan lagi ke loop besar yang baru terbentuk. Inilah bedanya dengan clinch biasa.",L:on=>dr("M212 88 C206 46 168 46 162 70 L150 66",TAG,on)+`<ellipse cx="180" cy="104" rx="38" ry="14" fill="none" stroke="var(--sand)" stroke-width="2" stroke-dasharray="4 3" class="${on?"pulse":""}"/>`},
  {h:"Basahi lalu tarik",t:"Basahi simpul dengan air liur, tarik senar utama perlahan sampai lilitan rapat ke mata kail.",squeeze:1,L:on=>`<path d="M30 70 l-14 10 l14 10" stroke="var(--sand)" stroke-width="3" fill="none" class="${on?"pulse":""}"/>`},
  {h:"Potong sisa senar",t:"Potong sisa ujung, tinggalkan 2–3 mm. Simpul selesai.",squeeze:1,cut:1,L:on=>`<g class="${on?"pop":""}"><circle cx="140" cy="128" r="6" fill="none" stroke="var(--bad)" stroke-width="2.5"/><circle cx="140" cy="146" r="6" fill="none" stroke="var(--bad)" stroke-width="2.5"/><path d="M145 125 L168 104 M145 149 L168 98" stroke="var(--bad)" stroke-width="2.5"/></g><text x="176" y="140" font-size="11" fill="var(--fg)">sisa 2–3 mm</text>`}
 ]},
 {id:"runsink",n:"Rakitan running sinker",u:"Rakitan dasar serbaguna untuk bream, flathead, whiting, kakap.",steps:[
  {h:"Masukkan pemberat",t:"Masukkan pemberat bola ke senar utama. Pemberat harus bisa bergeser bebas.",L:on=>`<g class="${on?"slide":""}"><circle cx="110" cy="80" r="11" fill="var(--muted)"/></g><text x="92" y="60" font-size="11" fill="var(--fg)">pemberat bola</text>`},
  {h:"Ikat ke swivel",t:"Ikat ujung senar utama ke swivel dengan improved clinch knot. Swivel menahan pemberat.",L:on=>`<g class="${on?"pop":""}"><rect x="160" y="73" width="10" height="14" rx="2" fill="none" stroke="var(--fg)" stroke-width="2.5"/><circle cx="157" cy="80" r="4" fill="none" stroke="var(--fg)" stroke-width="2"/><circle cx="173" cy="80" r="4" fill="none" stroke="var(--fg)" stroke-width="2"/></g><text x="148" y="108" font-size="11" fill="var(--fg)">swivel</text>`},
  {h:"Ikat leader 40–60 cm",t:"Ikat leader (senar fluorocarbon lebih tipis) ke sisi lain swivel, panjang 40–60 cm.",L:on=>dr("M177 80 L292 80",TAG.replace('stroke-width="3"','stroke-width="2.5" stroke-dasharray="0"'),on)+`<text x="200" y="70" font-size="11" fill="var(--accent)">leader 40–60 cm</text>`},
  {h:"Ikat kail",t:"Ikat kail di ujung leader. Ukuran no. 4–1 untuk bream, 1/0–2/0 untuk flathead & kakap.",L:on=>dr("M292 80 Q306 82 304 104 Q300 122 284 116 Q276 112 280 102",'stroke="var(--muted)" stroke-width="3.5" fill="none" stroke-linecap="round"',on)},
  {h:"Pasang umpan",t:"Pasang udang dari ekor sampai mata kail tertutup, ujung kail sedikit keluar.",L:on=>`<g class="${on?"pop":""}"><path d="M282 98 q14 -10 24 2 q4 14 -8 20 q-14 4 -18 -8z" fill="#e58f6c" opacity=".9"/><path d="M304 98 l10 -10 M306 101 l12 -6" stroke="#e58f6c" stroke-width="1.5"/></g>`},
  {h:"Cara kerjanya",t:"Saat ikan menarik umpan, senar meluncur menembus pemberat. Ikan tidak merasa berat, jadi umpan tidak dilepas.",L:on=>`<g class="${on?"swim":""}"><path d="M330 102 q-20 -16 -40 0 q20 16 40 0z M330 102 l12 -8 v16z" fill="var(--accent)" opacity=".8"/></g><text x="40" y="140" font-size="11" fill="var(--fg)">pemberat diam ←  senar bergerak  → ikan menarik</text>`}
 ]}
];
let anim={k:0,i:0,play:false,timer:null};
function animSVG(){
  const A=ANIMS[anim.k],st=A.steps,i=anim.i,sq=st[i].squeeze;
  let body="";
  if(A.id==="clinch"){
    body+=HOOK;
    for(let j=0;j<=i;j++){let lay=st[j].L(j===i);if(j===1)lay=lay.replace('class="coils"',`class="coils${sq?" squeeze":""}"`);if(st[i].cut&&j===3)lay=lay.replace('L150 66','L156 68');body+=lay}
  }else{
    body+=`<path d="M10 80 L155 80" ${LINE}/><text x="10" y="70" font-size="11" fill="var(--muted)">senar utama</text>`;
    for(let j=0;j<=i;j++)body+=st[j].L(j===i);
  }
  return `<svg viewBox="0 0 340 160" role="img" aria-label="${A.n}, langkah ${i+1}">${body}</svg>`;
}
function animStop(){clearInterval(anim.timer);anim.timer=null;anim.play=false}
function animCard(){
  const A=ANIMS[anim.k],s=A.steps[anim.i];
  return `<div class="card"><div class="seg">${ANIMS.map((a,k)=>`<button data-ak="${k}" aria-pressed="${k===anim.k}">${a.n}</button>`).join("")}</div>
   <p class="note">${A.u}</p>
   <div class="stage" id="stage">${animSVG()}</div>
   <div class="dots">${A.steps.map((_,j)=>`<button data-aj="${j}" aria-label="Langkah ${j+1}" aria-pressed="${j===anim.i}"></button>`).join("")}</div>
   <span class="tag">Langkah ${anim.i+1} dari ${A.steps.length}</span><h3>${s.h}</h3><p>${s.t}</p>
   <div class="ctrl"><button class="btn ghost" id="aPrev" ${anim.i?"":"disabled"} aria-label="Sebelumnya">⏮</button><button class="btn" id="aPlay">${anim.play?"❚❚ Jeda":"▶ Putar"}</button><button class="btn ghost" id="aNext" ${anim.i<A.steps.length-1?"":"disabled"} aria-label="Berikutnya">⏭</button><button class="btn ghost" id="aRe" aria-label="Ulangi">↺</button></div></div>`;
}
function animGo(i){const n=ANIMS[anim.k].steps.length;anim.i=Math.max(0,Math.min(n-1,i));if(view==="belajar")render()}
function bindAnim(){
  document.querySelectorAll("[data-ak]").forEach(b=>b.onclick=()=>{animStop();anim.k=+b.dataset.ak;anim.i=0;render()});
  document.querySelectorAll("[data-aj]").forEach(b=>b.onclick=()=>{animStop();animGo(+b.dataset.aj)});
  const g=id=>document.getElementById(id);if(!g("aPlay"))return;
  g("aPrev").onclick=()=>{animStop();animGo(anim.i-1)};g("aNext").onclick=()=>{animStop();animGo(anim.i+1)};
  g("aRe").onclick=()=>{animStop();anim.i=0;anim.play=true;startTimer();render()};
  g("aPlay").onclick=()=>{if(anim.play){animStop();render()}else{if(anim.i>=ANIMS[anim.k].steps.length-1)anim.i=0;anim.play=true;startTimer();render()}};
}
function startTimer(){clearInterval(anim.timer);anim.timer=setInterval(()=>{if(view!=="belajar"){animStop();return}const n=ANIMS[anim.k].steps.length;if(anim.i>=n-1){animStop();render();return}animGo(anim.i+1)},3800)}

function learnView(){
  $("#main").innerHTML=`<h2>Tutorial</h2><div class="seg"><button data-l="animasi" aria-pressed="${learn==="animasi"}">▶ Animasi</button><button data-l="tutorial" aria-pressed="${learn==="tutorial"}">Rakitan & simpul</button><button data-l="tips" aria-pressed="${learn==="tips"}">Tips & trik</button><button data-l="video" aria-pressed="${learn==="video"}">🎬 Video</button></div>`+
   (learn==="animasi"?animCard():learn==="video"?videoListHtml():learn==="tips"?TIPS.map(x=>`<div class="card illo"><h3>${x.h}</h3>${x.svg}<p>${x.t}</p>${videoBlock(x.h,x.v)}</div>`).join(""):
    RIGS.map(r=>`<div class="card illo"><h3>${r.n}</h3><p class="note">${r.u}</p>${r.svg}<ol>${r.s.map(x=>`<li>${x}</li>`).join("")}</ol>${videoBlock(r.n,r.v)}</div>`).join("")+
    `<div class="card"><h3>Simpul wajib</h3><ul><li><b>Improved clinch</b>: kail/swivel ke senar. Lilit 5–7 kali, masuk ke loop kecil lalu loop besar, basahi, tarik.</li><li><b>Uni to uni</b>: menyambung senar braid ke leader.</li><li><b>Loop knot</b>: agar soft plastic bergerak lebih hidup.</li></ul>
     <a class="vid" href="https://www.animatedknots.com/fishing-knots" target="_blank" rel="noopener"><span class="play"></span><span>Animasi simpul (Animated Knots)</span></a></div>`);
  document.querySelectorAll("[data-l]").forEach(b=>b.onclick=()=>{animStop();learn=b.dataset.l;render()});bindAnim();
}


/* ================= SARAN & LAPORAN (Supabase: tabel feedback) ================= */
const FB_KINDS=[["saran","💡 Saran fitur"],["bug","🐞 Laporan bug / error"],["data","🐟 Data spot/ikan salah"],["spot","📍 Usulan spot baru"],["lain","💬 Lainnya"]];
const FB_STATUS={baru:["Terkirim","var(--muted)"],proses:["Diproses","var(--mid)"],selesai:["Selesai","var(--good)"]};
let fbMine=null,fbAll=null,fbBlob=null,fbPrev=null,fbMsg="",fbBusy=false,fbAdminView=false,fbFilter="semua";
async function fbLoad(admin){
  if(!sb||!me)return;
  let q=sb.from("feedback").select("*").order("created_at",{ascending:false}).limit(200);
  if(!admin)q=q.eq("user_id",me.id);
  const{data,error}=await q;
  if(admin){fbAll=error?[]:data;if(data?.length){const ids=[...new Set(data.map(x=>x.user_id))];const{data:ps}=await sb.from("profiles").select("id,name").in("id",ids);(ps||[]).forEach(p=>fbNames[p.id]=p.name)}}
  else fbMine=error?[]:data;
  if(view==="lainnya"&&more==="masukan")moreView();
}
const fbNames={};
function fbItem(x,admin){
  const st=FB_STATUS[x.status]||FB_STATUS.baru,k=(FB_KINDS.find(k=>k[0]===x.kind)||FB_KINDS[4])[1];
  return `<div class="card fbi"><div class="row" style="justify-content:space-between;align-items:center"><span class="tag">${k}</span><span class="badge" style="color:${st[1]}">${st[0]}</span></div>
   <p style="margin:6px 0;white-space:pre-wrap">${esc(x.message)}</p>${x.photo_path?`<img class="preview" src="${photoUrl(x.photo_path)}" alt="Lampiran" loading="lazy">`:""}
   <p class="note">${admin?esc(fbNames[x.user_id]||"Pengguna")+" · ":""}${x.spot_name?esc(x.spot_name)+" · ":""}${new Date(x.created_at).toLocaleString("id-ID",{dateStyle:"medium",timeStyle:"short"})}${admin&&x.app_info?" · "+esc(x.app_info):""}</p>
   ${x.reply?`<div class="idres"><b>Balasan:</b> ${esc(x.reply)}</div>`:""}
   ${admin?`<form class="fbAdm" data-id="${x.id}" style="margin-top:8px"><textarea rows="2" placeholder="Balas pengguna…" aria-label="Balasan" maxlength="600">${esc(x.reply||"")}</textarea><div class="two"><select class="f" aria-label="Status">${Object.entries(FB_STATUS).map(([v,[l]])=>`<option value="${v}" ${x.status===v?"selected":""}>${l}</option>`).join("")}</select><button class="btn" type="submit">Simpan</button></div><button type="button" class="x" data-fbdel="${x.id}" data-p="${esc(x.photo_path||"")}">Hapus masukan</button></form>`:""}</div>`;
}
function feedbackHtml(){
  const c=cur();
  if(!sb)return `<h2>Saran & laporan</h2><div class="card"><p class="note">Fitur ini aktif setelah pemilik aplikasi mengisi config.js.</p></div>`;
  if(!me||!myName)return `<h2>Saran & laporan</h2><p class="note">Masuk dulu supaya kamu bisa melihat balasan dari pengelola.</p>${authCard(false)}`;
  if(fbMine===null&&!fbAdminView)fbLoad(false);
  if(isAdmin&&fbAdminView&&fbAll===null)fbLoad(true);
  const list=(fbAll||[]).filter(x=>fbFilter==="semua"||x.status===fbFilter);
  return `<h2>Saran & laporan</h2>
   ${isAdmin?`<div class="seg"><button data-fv="0" aria-pressed="${!fbAdminView}">Kirim masukan</button><button data-fv="1" aria-pressed="${fbAdminView}">📥 Kotak masuk (admin)</button></div>`:""}
   ${isAdmin&&fbAdminView?(fbAll===null?`<div class="card"><p class="note">Memuat semua masukan…</p></div>`:
     `<div class="card"><div class="row">${Object.entries(FB_STATUS).map(([v,[l]])=>`<div class="kv"><span class="tag">${l}</span><strong>${fbAll.filter(x=>x.status===v).length}</strong></div>`).join("")}</div></div>
      <div class="seg"><button data-ff2="semua" aria-pressed="${fbFilter==="semua"}">Semua</button>${Object.entries(FB_STATUS).map(([v,[l]])=>`<button data-ff2="${v}" aria-pressed="${fbFilter===v}">${l}</button>`).join("")}<button id="fbRef" aria-label="Muat ulang">↻</button></div>
      ${list.length?list.map(x=>fbItem(x,true)).join(""):`<div class="card"><p class="note">Tidak ada masukan di sini.</p></div>`}`)
   :`<form id="fbF" class="card"><p class="note">Ceritakan saran atau masalahmu. Hanya pengelola aplikasi yang bisa membacanya.</p>
     <label class="tag" for="fbK">Jenis</label><select class="f" id="fbK">${FB_KINDS.map(([v,l])=>`<option value="${v}">${l}</option>`).join("")}</select>
     <label class="tag" for="fbT">Pesan</label><textarea id="fbT" rows="4" minlength="3" maxlength="1000" required placeholder="mis. Koordinat Pantai Mawi salah, seharusnya lebih ke barat."></textarea>
     <label class="note" style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="fbS" checked style="width:auto"> Sertakan spot: ${esc(c.n)}</label>
     <div class="two"><label class="btn ghost" for="fbP">📎 Lampirkan foto</label><input type="file" id="fbP" accept="image/*" hidden><span class="note">${fbPrev?"Foto terlampir":"Opsional, mis. screenshot error"}</span></div>
     ${fbPrev?`<img class="preview" src="${fbPrev}" alt="Lampiran"><button type="button" class="x" id="fbPx">Hapus foto</button>`:""}
     <button class="btn" type="submit" ${fbBusy?"disabled":""}>${fbBusy?"Mengirim…":"Kirim"}</button><p class="note" id="fbM">${esc(fbMsg)}</p></form>
     <h3>Masukan saya</h3>${fbMine===null?`<p class="note">Memuat…</p>`:fbMine.length?fbMine.map(x=>fbItem(x,false)).join(""):`<p class="note">Belum ada. Masukanmu dan balasan pengelola akan muncul di sini.</p>`}`}`;
}
function bindFeedback(){
  const c=cur();
  document.querySelectorAll("[data-fv]").forEach(b=>b.onclick=()=>{fbAdminView=b.dataset.fv==="1";if(fbAdminView)fbAll=null;else fbMine=null;moreView()});
  document.querySelectorAll("[data-ff2]").forEach(b=>b.onclick=()=>{fbFilter=b.dataset.ff2;moreView()});
  const rf=$("#fbRef");if(rf)rf.onclick=()=>{fbAll=null;moreView()};
  const fp=$("#fbP");if(fp)fp.onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const cv=await shrink(f,1000);fbBlob=await new Promise(r=>cv.toBlob(r,"image/jpeg",.78));fbPrev=cv.toDataURL("image/jpeg",.5);moreView()}catch(err){$("#fbM").textContent="Foto tidak bisa dibaca."}};
  const px=$("#fbPx");if(px)px.onclick=()=>{fbBlob=fbPrev=null;moreView()};
  const f=$("#fbF");if(f)f.onsubmit=async e=>{e.preventDefault();if(fbBusy)return;fbBusy=true;fbMsg="";const kind=$("#fbK").value,msg=$("#fbT").value.trim(),withSpot=$("#fbS").checked;moreView();
    try{let path=null;if(fbBlob){path=`${me.id}/fb-${Date.now()}.jpg`;const up=await sb.storage.from("photos").upload(path,fbBlob,{contentType:"image/jpeg"});if(up.error)throw up.error}
      const{error}=await sb.from("feedback").insert({kind,message:msg.slice(0,1000),spot_id:withSpot?c.id:null,spot_name:withSpot?c.n:null,photo_path:path,app_info:(navigator.userAgent||"").slice(0,200)});
      if(error)throw error;fbBlob=fbPrev=null;fbMsg="Terkirim. Terima kasih atas masukanmu!";fbMine=null}
    catch(err){fbMsg="Gagal mengirim. Periksa koneksi lalu coba lagi."}
    fbBusy=false;moreView()};
  document.querySelectorAll(".fbAdm").forEach(fm=>fm.onsubmit=async e=>{e.preventDefault();const b=fm.querySelector("button[type=submit]");b.disabled=true;b.textContent="Menyimpan…";
    const{error}=await sb.from("feedback").update({reply:fm.querySelector("textarea").value.trim()||null,status:fm.querySelector("select").value,updated_at:new Date().toISOString()}).eq("id",fm.dataset.id);
    if(error){b.disabled=false;b.textContent="Gagal, coba lagi"}else{fbAll=null;moreView()}});
  document.querySelectorAll("[data-fbdel]").forEach(b=>b.onclick=async()=>{if(b.dataset.c!=="1"){b.dataset.c="1";b.textContent="Yakin hapus?";return}if(b.dataset.p)await sb.storage.from("photos").remove([b.dataset.p]);await sb.from("feedback").delete().eq("id",b.dataset.fbdel);fbAll=null;moreView()});
}

/* ================= LAINNYA: akun, checklist, aturan ================= */
const GEAR0=["Izin mancing","Joran & reel, senar cadangan","Leader 6–20 lb, kail no. 4–4/0, pemberat","Umpan + berley","Penggaris ukur ikan","Tang & pemotong senar","Ember/cool box + es","Pelampung (wajib untuk mancing batu & perahu)","Topi, sunscreen, air minum","Senter kepala untuk subuh/malam","Kantong sampah (bawa pulang senar bekas)"];
Object.defineProperty(window,"GEAR",{get:()=>[region==="AU"?"Izin mancing negara bagian (mis. NSW Fishing Fee, VIC licence)":"Izin/retribusi pengelola kawasan (bila di taman nasional)"].concat(GEAR0.slice(1))});
let more="akun",delStep=0;
function moreView(){
  const ck=store.get("mm_gear",{});
  $("#main").innerHTML=`<div class="seg"><button data-m="akun" aria-pressed="${more==="akun"}">Akun</button><button data-m="masukan" aria-pressed="${more==="masukan"}">Saran & laporan</button><button data-m="cek" aria-pressed="${more==="cek"}">Checklist</button><button data-m="musim" aria-pressed="${more==="musim"}">📅 Musim ikan</button><button data-m="aturan" aria-pressed="${more==="aturan"}">Aturan & darurat</button><button data-m="toko" aria-pressed="${more==="toko"}">🏪 Toko & perahu</button><button data-m="tutorial" aria-pressed="false">📺 Tutorial</button><button data-m="fitur" aria-pressed="${more==="fitur"}">📋 Fitur</button><button data-m="info" aria-pressed="${more==="info"}">Tentang</button>${isAdmin?`<button data-m="admin" aria-pressed="${more==="admin"}">Admin</button>`:""}</div>`+
  (more==="masukan"?feedbackHtml():more==="akun"?`<h2>Akun</h2>${authCard(false)}
     ${me&&myName?`<div class="card"><button class="btn ghost" id="logout" style="width:100%">Keluar</button></div>
     <div class="card" style="border-color:var(--bad)"><h3>Hapus akun</h3><p class="note">Menghapus akun, profil, semua tangkapan, dan foto kamu secara permanen.</p>
       <button class="btn" id="delAcc" style="background:var(--bad)">${delStep?"Ya, hapus permanen":"Hapus akun saya"}</button><p class="note" id="delMsg"></p></div>`:""}
     <div class="card"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="awakeTog" style="width:auto" ${store.get("mm_awake",true)?"checked":""}> ☀️ Layar tetap menyala saat aplikasi dibuka</label><p class="note">Layar HP tidak mati sendiri selama Mancing Mania terbuka. Matikan bila ingin hemat baterai.</p></div>
     <p class="note"><a href="privacy.html" target="_blank" rel="noopener">Kebijakan privasi</a> · <a href="hapus-akun.html" target="_blank" rel="noopener">Cara menghapus akun</a></p>`
  :more==="cek"?`<h2>Checklist sebelum berangkat</h2><div class="card check">${GEAR.map((g,i)=>`<label><input type="checkbox" data-g="${i}" ${ck[i]?"checked":""}> ${g}</label>`).join("")}</div><button class="btn ghost" id="resetG">Reset checklist</button>`
  :more==="aturan"?rulesHtml():more==="toko"?shopsHtml():more==="fitur"?featuresHtml():more==="musim"?seasonHtml():more==="admin"?`<h2>Admin</h2><p class="note">Spot dan ikan baru dari pengguna. Yang kamu setujui otomatis muncul di peta, daftar spot, dan daftar ikan untuk semua orang.</p><h3>📊 Statistik</h3><div class="card" id="statBox"><p class="note">Memuat…</p></div><h3>Kiriman spot & ikan</h3><div class="card" id="adminBox"><p class="note">Memuat…</p></div><h3>Usulan toko & sewa perahu</h3><div class="card" id="adminList"><p class="note">Memuat…</p></div>`:`<h2>Tentang Mancing Mania</h2>
  <div class="card" style="text-align:center"><img src="icons/icon-192.png" alt="" style="width:72px;height:72px;border-radius:16px"><h3 style="margin:8px 0 2px">Mancing Mania</h3>
   <p class="note">${LX("Dibuat & dikembangkan oleh","Created & developed by")}</p><p style="font-size:1.25rem;font-weight:800;margin:0">Moh Amin</p>
   <p class="note">© ${new Date().getFullYear()} Moh Amin · mancingmania.asia</p></div>
  <div class="card"><p>${LX("Mancing Mania adalah aplikasi gratis untuk pemancing di Indonesia dan Australia: cek spot, ikan & umpan yang cocok, cuaca, pasang surut dan waktu terbaik mancing, lalu bagikan tangkapanmu ke komunitas.","Mancing Mania is a free app for anglers in Indonesia and Australia: check spots, the right fish & bait, weather, tides and the best time to fish, then share your catch with the community.")}</p>
   <h3 style="margin-top:8px">⭐ ${LX("Fitur unggulan","Key features")}</h3><ul>
   <li>📍 ${LX("170+ spot mancing Indonesia & Australia, per provinsi/negara bagian","170+ fishing spots across Indonesia & Australia")}</li>
   <li>🐟 ${LX("Ikan & umpan yang cocok di tiap spot","The right fish & bait for every spot")}</li>
   <li>🌊 ${LX("Cuaca, ombak, pasang surut, solunar & peringatan gelombang","Weather, waves, tides, solunar & sea warnings")}</li>
   <li>🎣 ${LX("“Hari bagus mancing” + notifikasi","“Good fishing days” + notifications")}</li>
   <li>🗺️ ${LX("Peta suhu laut, klorofil, radar hujan & angin","Sea temperature, chlorophyll, rain radar & wind maps")}</li>
   <li>👥 ${LX("Komunitas: posting, komentar, grup & ikuti pemancing","Community: posts, comments, groups & follow anglers")}</li>
   <li>📒 ${LX("Logbook tangkapan & statistik pribadi","Catch logbook & personal stats")}</li>
   <li>🆘 ${LX("Tombol darurat SOS & bagikan lokasi","SOS emergency button & location sharing")}</li></ul></div>
  <div class="card"><p>Aplikasi gratis untuk pemancing di Indonesia dan Australia.</p>
     <ul><li>Peta: © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors</li><li>Cuaca, ombak & muka laut: <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo</a> (CC BY 4.0)</li><li>Pencarian tempat: Nominatim / OpenStreetMap</li><li>Foto ikan: <a href="https://commons.wikimedia.org/" target="_blank" rel="noopener">Wikipedia / Wikimedia Commons</a> (lisensi CC, hak cipta pada masing-masing fotografer)</li></ul>
     ${window.Capacitor?"":`<a class="btn" href="mancing-mania.apk" download style="display:block;margin:8px 0">⬇️ Unduh APK Android</a>`}<p class="note">Data ikan, umpan & spot adalah panduan umum dan bisa tidak akurat. Selalu utamakan keselamatan dan aturan setempat.</p></div>`);
  document.querySelectorAll("[data-m]").forEach(b=>b.onclick=()=>{if(b.dataset.m==="tutorial"){view="belajar";$("#main").scrollTop=0;render();return}more=b.dataset.m;delStep=0;render()});
  document.querySelectorAll("[data-g]").forEach(x=>x.onchange=()=>{ck[x.dataset.g]=x.checked;store.set("mm_gear",ck)});
  const rg=$("#resetG");if(rg)rg.onclick=()=>{store.set("mm_gear",{});render()};
  bindAuth();if(more==="masukan")bindFeedback();if(more==="toko")bindShops();if(more==="fitur")bindFeatures();if(more==="admin"){renderAdmin();renderAdminListings();adminStatsHtml().then(h=>{const b=$("#statBox");if(b){b.innerHTML=h;tr(b)}})}
  const aw=$("#awakeTog");if(aw)aw.onchange=()=>setAwake(aw.checked);
  const lo=$("#logout");if(lo)lo.onclick=async()=>{await sb.auth.signOut();render()};
  const da=$("#delAcc");if(da)da.onclick=async()=>{if(!delStep){delStep=1;render();return}da.disabled=true;$("#delMsg").textContent="Menghapus…";try{await deleteAccount();delStep=0;await loadFeed();render()}catch(e){da.disabled=false;$("#delMsg").textContent="Gagal menghapus. Coba lagi atau hubungi pengelola."}};
}

const VID_AU={"Running sinker rig":"xGqRMIFW1PQ","Paternoster rig":"QQykBqBuwvQ","Float rig":"q7Cj0lDKdPQ","Jighead + soft plastic":"1JyA3qb_clo","Gang hook (pilchard)":"Ow6k4btIIK4",
 "Berley (umpan tabur)":"s-2rOokIqn8","Mancing squid":"qnK-EDN_yjQ","Flathead dengan soft plastic":"0XNN1Rbz6nk","Bream itu pemalu":"vMBsOyXZEVI","Keselamatan mancing batu":"nFx43ZHYAKw","Merawat ikan":"IdZU1BpT5GA","Membaca air":"yqjzCW3FuK0",
 "Bream":"FUhlzgeMmrc","Flathead":"uR3ZL5uct3A","Whiting":"Q7FH7W83bco","King George Whiting":"NA8oxKxo9vE","Mulloway":"zF3TZaF5-5A","Snapper":"dlTkCoO8MS4","Kingfish":"BUiL5I3S1NM","Squid":"qnK-EDN_yjQ","Barramundi":"4ZsW6stwBPQ","Coral Trout":"xweQ0YA2UkQ"};
const VID_ID={"GT":"ECTZgH39hbo","Kakap Merah":"gHquM2cCqHQ","Cumi":"cpwAaZ9C4xM","Kerapu":"zcQsBkz_XDk","Kakap Putih":"UanERbk1hq8","Tenggiri":"K2eEcvnGTqQ","Mancing squid":"cpwAaZ9C4xM","Keselamatan mancing batu":"tFuC7GDZirM"};
function vidId(key){const own=region==="AU"?VID_AU:VID_ID,other=region==="AU"?VID_ID:VID_AU;return (CFG.VIDEOS||{})[key]||own[key]||other[key]||null}
function videoBlock(key,q){const id=vidId(key);
  if(!id)return `<a class="vid" href="${yt(q||"how to catch "+key)}" target="_blank" rel="noopener"><span class="play"></span><span>Cari video ${esc(key)} di YouTube</span></a>`;
  return `<div class="yt ytlite" data-yt="${id}" role="button" tabindex="0" aria-label="Putar video ${esc(key)}"><img src="https://i.ytimg.com/vi/${id}/hqdefault.jpg" alt="" loading="lazy"><span class="ytplay">▶</span></div><p class="note" style="margin-top:4px"><a href="https://www.youtube.com/watch?v=${id}" target="_blank" rel="noopener">Buka di YouTube</a></p>`}
document.addEventListener("click",e=>{const v=e.target.closest&&e.target.closest(".ytlite");if(!v)return;v.classList.remove("ytlite");v.innerHTML=`<iframe src="https://www.youtube-nocookie.com/embed/${v.dataset.yt}?autoplay=1&playsinline=1&rel=0" title="Video" allow="autoplay; accelerometer; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>`});
function videoListHtml(){
  const T=Object.fromEntries(TIPS.map(t=>[t.h,1])),R=Object.fromEntries(RIGS.map(r=>[r.n,1]));
  const keys=[...new Set(Object.keys(region==="AU"?VID_AU:VID_ID).concat(Object.keys(VID_AU).filter(k=>R[k])))];
  const grp=[["Ikan",keys.filter(k=>SP[k]&&!R[k]&&!T[k])],["Rakitan & simpul",keys.filter(k=>R[k])],["Tips & trik",keys.filter(k=>T[k])]];
  return grp.filter(g=>g[1].length).map(([h,ks])=>`<h3>${h}</h3>`+ks.map(k=>`<div class="card"><b>${esc(k)}</b>${videoBlock(k)}</div>`).join("")).join("")+`<p class="note">Video milik masing-masing kanal YouTube. Ketuk untuk memutar di dalam aplikasi.</p>`;
}

/* ================= BAHASA: Australia = English, Indonesia = Bahasa Indonesia ================= */
let LANG="id";
const EN=window.MM_EN||{},EN_PH=(window.MM_EN_PHRASES||[]).map(([a,b])=>[new RegExp(a,"g"),b]);
const ORIG=new WeakMap();
function trStr(v){
  const k=v.trim();if(!k||!/[A-Za-z]/.test(k))return v;
  let out=EN[k];
  if(out==null){out=k;for(const[r,b]of EN_PH)out=out.replace(r,b);if(out===k)return v}
  return v.replace(k,out);
}
function tr(root){
  if(LANG!=="en"||!root)return;
  const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT);let n=root;
  while(n){
    if(n.nodeType===3){const p=n.parentNode;if(p&&!/^(SCRIPT|STYLE|TEXTAREA)$/.test(p.nodeName)){const v=n.nodeValue,t=trStr(v);if(t!==v){if(!ORIG.has(n))ORIG.set(n,v);n.nodeValue=t}}}
    else if(n.nodeType===1){if(n.nodeName==="SCRIPT"||n.nodeName==="STYLE"){n=w.nextSibling()||nextUp(w);continue}
      for(const a of["placeholder","aria-label","title","alt"]){const v=n.getAttribute&&n.getAttribute(a);if(v){const t=trStr(v);if(t!==v){if(!n.dataset["o_"+a.replace("-","")])n.dataset["o_"+a.replace("-","")]=v;n.setAttribute(a,t)}}}}
    n=w.nextNode();
  }
}
function nextUp(w){let p;while((p=w.parentNode())){const s=w.nextSibling();if(s)return s}return null}
function untr(){ // kembalikan teks statis (header, tab) ke Bahasa Indonesia
  const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT);let n;
  while((n=w.nextNode())){if(n.nodeType===3){if(ORIG.has(n)){n.nodeValue=ORIG.get(n);ORIG.delete(n)}}else for(const a of["placeholder","aria-label","title","alt"]){const k="o_"+a.replace("-","");if(n.dataset&&n.dataset[k]){n.setAttribute(a,n.dataset[k]);delete n.dataset[k]}}}
}
function setLang(){const l=region==="AU"?"en":"id";if(l!==LANG){LANG=l;document.documentElement.lang=l;if(l==="id")untr()}}
let trBusy=false;
new MutationObserver(ms=>{if(LANG!=="en"||trBusy)return;trBusy=true;try{ms.forEach(m=>{if(m.type==="characterData")tr(m.target.parentNode);else m.addedNodes.forEach(x=>tr(x.nodeType===3?x.parentNode:x))})}finally{trBusy=false}}).observe(document.documentElement,{childList:true,subtree:true,characterData:true});

/* ================= v2: KOMUNITAS LANJUTAN ================= */
// --- wilayah sebuah tangkapan (untuk menyaring feed per negara) ---
const catchRegion=x=>{if(x.lat!=null)return x.lat>-11.5?"ID":"AU";const s=x.spot_id&&everySpot().find(l=>l.id===x.spot_id);if(s)return s.region||regionOf(s.lat,s.lon);const a=everySpot().find(l=>l.a&&l.a===x.area);return a?a.region:null};
const inRegion=x=>{const r=catchRegion(x);return !r||r===region};

// --- suka & komentar ---
let likes={},myLikes=new Set(),comments={};
async function loadSocial(){
  if(!sb||!feed?.length)return;const ids=feed.map(x=>x.id);
  const[l,c]=await Promise.all([sb.from("likes").select("catch_id,user_id").in("catch_id",ids),sb.from("comments").select("id,catch_id,user_id,body,created_at,profiles(name)").in("catch_id",ids).order("created_at").limit(2000)]);
  likes={};myLikes=new Set();comments={};
  (l.data||[]).forEach(r=>{likes[r.catch_id]=(likes[r.catch_id]||0)+1;if(me&&r.user_id===me.id)myLikes.add(r.catch_id)});
  (c.data||[]).forEach(r=>(comments[r.catch_id]=comments[r.catch_id]||[]).push(r));
  try{store.set("mm_feed_cache",{feed,likes,comments,t:Date.now()})}catch(e){}
  if(["tangkapan","peta"].includes(view))render();
}
function feedItem(x){
  const mine=me&&x.user_id===me.id,img=photoUrl(x.photo_path),nm=mine?"Kamu":(x.profiles?.name||"Pemancing"),nc=(comments[x.id]||[]).length;
  return `<div class="log">${img?`<img src="${img}" alt="${esc(x.fish)}" loading="lazy" data-zoom="${img}" style="cursor:zoom-in">`:`<span class="thumb">${fishSVG(x.fish)}</span>`}<span class="grow"><b>${esc(x.fish)}</b> ${x.length_cm?x.length_cm+" cm":""} ${x.released?'<span class="badge">dilepas</span>':""} ${x.hidden?'<span class="badge">disembunyikan</span>':""}<br><span class="note"><button class="x linkish" data-prof="${x.user_id}">${esc(nm)}</button> · ${esc(x.spot_name||x.area||"")} · ${ago(x.created_at)}${x.bait?" · "+esc(x.bait):""}</span>
   <span class="acts"><button class="x" data-like="${x.id}" aria-pressed="${myLikes.has(x.id)}">${myLikes.has(x.id)?"❤️":"🤍"} ${likes[x.id]||0}</button><button class="x" data-com="${x.id}">💬 ${nc}</button><button class="x" data-share="${x.id}" aria-label="Bagikan">📤</button>${mine||isAdmin?`<button class="x" data-del="${x.id}" data-p="${esc(x.photo_path||"")}">Hapus</button>`:""}${!mine&&me?`<button class="x" data-rep="${x.id}">Laporkan</button><button class="x" data-blk="${x.user_id}">Blokir</button>`:""}${isAdmin&&!mine?`<button class="x" data-hide="${x.id}" data-h="${x.hidden?0:1}">${x.hidden?"Tampilkan":"Sembunyikan"}</button>`:""}</span></span></div>`;
}
function bindFeed(){
  document.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{if(b.dataset.c!=="1"){b.dataset.c="1";b.textContent="Yakin hapus?";return}b.disabled=true;if(b.dataset.p)await sb.storage.from("photos").remove([b.dataset.p]);const{error}=await sb.from("catches").delete().eq("id",b.dataset.del);if(error){b.textContent="Gagal";b.disabled=false}else loadFeed()});
  document.querySelectorAll("[data-rep]").forEach(b=>b.onclick=async()=>{b.disabled=true;const{error}=await sb.from("reports").insert({catch_id:b.dataset.rep,reason:"tidak pantas"});b.textContent=error&&!String(error.message).includes("duplicate")?"Gagal":"Dilaporkan"});
  document.querySelectorAll("[data-blk]").forEach(b=>b.onclick=async()=>{if(b.dataset.c!=="1"){b.dataset.c="1";b.textContent="Blokir orang ini?";return}await sb.from("blocks").insert({blocked:b.dataset.blk});blocked.add(b.dataset.blk);render()});
  document.querySelectorAll("[data-hide]").forEach(b=>b.onclick=async()=>{await sb.from("catches").update({hidden:b.dataset.h==="1"}).eq("id",b.dataset.hide);loadFeed()});
  document.querySelectorAll("[data-zoom]").forEach(i=>i.onclick=()=>openSheet(`<img src="${i.dataset.zoom}" alt="Foto tangkapan" style="width:100%;border-radius:10px">`,true));
  document.querySelectorAll("[data-like]").forEach(b=>b.onclick=async()=>{if(!me||!myName){openSheet(`<h3>Masuk dulu</h3><p class="note">Masuk lewat tab Tangkapan untuk memberi suka.</p>`);return}const id=b.dataset.like,on=myLikes.has(id);
    if(on){myLikes.delete(id);likes[id]--;await sb.from("likes").delete().eq("catch_id",id).eq("user_id",me.id)}else{myLikes.add(id);likes[id]=(likes[id]||0)+1;await sb.from("likes").insert({catch_id:id})}
    b.textContent=(myLikes.has(id)?"❤️ ":"🤍 ")+(likes[id]||0);b.setAttribute("aria-pressed",myLikes.has(id));tr(b)});
  document.querySelectorAll("[data-com]").forEach(b=>b.onclick=()=>openComments(b.dataset.com));
  document.querySelectorAll("[data-share]").forEach(b=>b.onclick=()=>{const x=(feed||[]).find(f=>f.id===b.dataset.share);if(x)shareCatch({fish:x.fish,len:x.length_cm,spot:x.spot_name||x.area,bait:x.bait,photo:x.photo_path?photoUrl(x.photo_path):null,t:Date.parse(x.created_at)})});
  document.querySelectorAll("[data-prof]").forEach(b=>b.onclick=()=>openProfile(b.dataset.prof));
}
function openComments(id){
  const x=(feed||[]).find(f=>f.id===id),cs=comments[id]||[];
  openSheet(`<h3>Komentar · ${esc(x?.fish||"")}</h3>
   <div id="comList">${cs.length?cs.map(c=>`<div class="com"><b>${esc(me&&c.user_id===me.id?"Kamu":(c.profiles?.name||"Pemancing"))}</b> <span class="note">${ago(c.created_at)}</span>${me&&(c.user_id===me.id||isAdmin)?` <button class="x" data-cdel="${c.id}">Hapus</button>`:""}<br>${esc(c.body)}</div>`).join(""):`<p class="note">Belum ada komentar. Tanyakan umpan atau tekniknya!</p>`}</div>
   ${me&&myName?`<form id="comF" class="two" style="margin-top:8px"><input id="comT" maxlength="300" placeholder="Tulis komentar…" required><button class="btn" type="submit">Kirim</button></form>`:`<p class="note">Masuk lewat tab Tangkapan untuk berkomentar.</p>`}`);
  const f=$("#comF");if(f)f.onsubmit=async e=>{e.preventDefault();const t=$("#comT").value.trim();if(!t)return;f.querySelector("button").disabled=true;
    const{data,error}=await sb.from("comments").insert({catch_id:id,body:t}).select("id,catch_id,user_id,body,created_at").single();
    if(error){f.querySelector("button").disabled=false;alertNote("Komentar gagal dikirim: "+error.message);return}
    (comments[id]=comments[id]||[]).push({...data,profiles:{name:myName}});openComments(id);if(view==="tangkapan")render()};
  document.querySelectorAll("[data-cdel]").forEach(b=>b.onclick=async()=>{await sb.from("comments").delete().eq("id",b.dataset.cdel);comments[id]=(comments[id]||[]).filter(c=>c.id!==b.dataset.cdel);openComments(id);render()});
}
const alertNote=t=>{const n=document.createElement("p");n.className="note";n.style.color="var(--bad)";n.textContent=t;$("#sheetBody")?.appendChild(n);tr(n)};

// --- lembar pop-up (foto besar, komentar, profil) ---
function openSheet(html,photo){
  let s=$("#sheet");if(!s){s=document.createElement("div");s.id="sheet";s.className="sheet";document.body.appendChild(s);s.onclick=e=>{if(e.target===s)closeSheet()}}
  s.innerHTML=`<div class="sheetbox${photo?" photo":""}" role="dialog" aria-modal="true"><button class="x sheetx" id="sheetX" aria-label="Tutup">✕</button><div id="sheetBody">${html}</div></div>`;
  s.hidden=false;$("#sheetX").onclick=closeSheet;tr(s);
}
function closeSheet(){const s=$("#sheet");if(s)s.hidden=true}
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeSheet()});

// --- profil pemancing ---
function openProfile(uid){
  const xs=(feed||[]).filter(x=>x.user_id===uid),nm=me&&uid===me.id?myName:(xs[0]?.profiles?.name||"Pemancing"),best={};
  xs.forEach(x=>{if(x.length_cm&&(!best[x.fish]||x.length_cm>best[x.fish].length_cm))best[x.fish]=x});
  const spots={};xs.forEach(x=>{if(x.spot_name)spots[x.spot_name]=(spots[x.spot_name]||0)+1});
  const lk=xs.reduce((a,x)=>a+(likes[x.id]||0),0);
  openSheet(`<h3>${esc(nm)}</h3>
   <div class="row"><div class="kv"><span class="tag">Tangkapan</span><strong>${xs.length}</strong></div><div class="kv"><span class="tag">Suka diterima</span><strong>${lk}</strong></div><div class="kv"><span class="tag">Spot favorit</span><strong style="font-size:.95rem">${esc(Object.entries(spots).sort((a,b)=>b[1]-a[1])[0]?.[0]||"–")}</strong></div></div>
   <h3 style="margin-top:10px">Rekor terbesar</h3>${Object.keys(best).length?`<table><tbody>${Object.values(best).sort((a,b)=>b.length_cm-a.length_cm).map(x=>`<tr><td>${fishMini(x.fish)}</td><td><b>${x.length_cm} cm</b></td><td class="note">${esc(x.spot_name||x.area||"")}</td></tr>`).join("")}</tbody></table>`:`<p class="note">Belum ada tangkapan dengan ukuran.</p>`}
   <h3 style="margin-top:10px">Semua tangkapan</h3>${xs.map(feedItem).join("")||`<p class="note">Belum ada.</p>`}`);
  bindFeed();
}

// --- peringkat bulanan ---
function leaderboardHtml(list){
  const m0=new Date();m0.setDate(1);m0.setHours(0,0,0,0);
  const xs=list.filter(x=>x.length_cm&&Date.parse(x.created_at)>=m0.getTime()),best={};
  xs.forEach(x=>{if(!best[x.fish]||x.length_cm>best[x.fish].length_cm)best[x.fish]=x});
  const rows=Object.values(best).sort((a,b)=>b.length_cm-a.length_cm).slice(0,10);
  const bulan=m0.toLocaleDateString(region==="AU"?"en-AU":"id-ID",{month:"long",year:"numeric"});
  return `<div class="card"><h3>🏆 Peringkat bulan ini <span class="note">(${bulan})</span></h3><p class="note">Ikan terbesar per jenis, dari tangkapan yang mencantumkan panjang.</p>
   ${rows.length?`<table><tbody>${rows.map((x,i)=>`<tr><td>${["🥇","🥈","🥉"][i]||i+1}</td><td>${fishMini(x.fish)}</td><td><b>${x.length_cm} cm</b></td><td class="note"><button class="x linkish" data-prof="${x.user_id}">${esc(me&&x.user_id===me.id?"Kamu":(x.profiles?.name||"Pemancing"))}</button></td></tr>`).join("")}</tbody></table>`:`<p class="note">Belum ada tangkapan bulan ini. Isi panjang ikan saat upload supaya masuk peringkat!</p>`}</div>`;
}

// --- kiriman spot & ikan baru (disetujui admin) ---
let subs=[];
async function loadApproved(){
  if(!sb)return;const{data}=await sb.from("submissions").select("*").eq("status","setuju").limit(1000);
  (data||[]).forEach(applySub);try{store.set("mm_subs",data||[])}catch(e){}
}
function applySub(s){
  if(s.kind==="fish"&&!SP[s.name])SP[s.name]={b:"#9fb3b8",d:"#5d7279",fin:"#b9c7c9",h:.32,pat:"",lim:region==="AU"?"Cek aturan negara bagian":"–",ciri:"Ditambahkan oleh komunitas.",community:1};
  if(s.kind==="spot"&&s.lat!=null&&!LOC.some(l=>l.id==="sub_"+s.id)){
    const fish=s.fish?[s.fish]:[];if(s.fish&&!SP[s.fish])applySub({kind:"fish",name:s.fish});
    LOC.push({id:"sub_"+s.id,region:s.region||regionOf(s.lat,s.lon),st:s.region==="AU"?"NSW":undefined,n:s.name,a:s.area||"Kiriman komunitas",lat:s.lat,lon:s.lon,type:"Spot kiriman komunitas",fish,bait:{},community:1,tide:"Belum ada catatan; pakai prakiraan pasang surut."});
  }
}
store.get("mm_subs",[]).forEach(applySub);
async function adminSubsHtml(){
  const{data,error}=await sb.from("submissions").select("*").eq("status","baru").order("created_at",{ascending:false}).limit(100);
  subs=data||[];
  return error?`<p class="note">Gagal memuat: ${esc(error.message)}</p>`:subs.length?subs.map(s=>`<div class="log"><span class="grow"><span class="badge">${s.kind==="spot"?"Spot":"Ikan"}</span> <b>${esc(s.name)}</b><br><span class="note">${s.region==="AU"?"Australia":"Indonesia"}${s.area?" · "+esc(s.area):""}${s.lat!=null?` · <a href="https://www.google.com/maps?q=${s.lat},${s.lon}" target="_blank" rel="noopener">lihat peta</a>`:""}${s.fish?" · ikan: "+esc(s.fish):""} · ${ago(s.created_at)}</span>
    <span class="acts"><button class="x" data-ok="${s.id}">✅ Setujui</button><button class="x" data-no="${s.id}">Tolak</button></span></span></div>`).join(""):`<p class="note">Tidak ada kiriman baru. 👍</p>`;
}
async function renderAdmin(){
  const box=$("#adminBox");if(!box)return;box.innerHTML=await adminSubsHtml();tr(box);
  box.querySelectorAll("[data-ok],[data-no]").forEach(b=>b.onclick=async()=>{const id=b.dataset.ok||b.dataset.no,ok=!!b.dataset.ok;b.disabled=true;
    const{error}=await sb.from("submissions").update({status:ok?"setuju":"tolak"}).eq("id",id);
    if(error){b.textContent="Gagal";return}if(ok)applySub(subs.find(s=>s.id===id));fillPick();renderAdmin()});
}
async function submitNew(kind,o){try{await sb.from("submissions").insert({kind,region,...o})}catch(e){}}

// --- favorit & waktu terbaik ---
let favs=store.get("mm_favs",[]);
const isFav=id=>favs.includes(id);
function toggleFav(id){favs=isFav(id)?favs.filter(f=>f!==id):favs.concat(id);store.set("mm_favs",favs);render()}
function bestWindow(s,off=0){const sc=fishScore(off,s.lat,s.lon);let bi=0,bv=-1;for(let h=4;h<21;h++){const v=sc.hours[h]+sc.hours[h+1];if(v>bv){bv=v;bi=h}}return{from:bi,to:bi+2,total:sc.total}}
function favCardHtml(){
  const fs=favs.map(id=>everySpot().find(s=>s.id===id)).filter(s=>s&&(s.region||regionOf(s.lat,s.lon))===region);
  const perm=typeof Notification!=="undefined"?Notification.permission:"unsupported";
  return `<div class="card"><h3>⭐ Spot favorit · waktu terbaik hari ini</h3>
   ${fs.length?fs.map(s=>{const b=bestWindow(s);return `<button class="favrow" data-id="${s.id}"><span><b>${esc(s.n)}</b><br><span class="note">Terbaik ${fmt(b.from)}–${fmt(b.to)}</span></span><span class="score" style="background:${scoreCol(b.total)}">${b.total}</span></button>`}).join(""):`<p class="note">Belum ada favorit. Ketuk ☆ di kartu spot untuk menambahkan.</p>`}
   ${fs.length&&perm!=="unsupported"?(perm==="granted"?`<p class="note">🔔 Pengingat aktif: tiap pagi saat aplikasi dibuka, kamu dapat ringkasan waktu terbaik.</p>`:`<button class="btn ghost" id="notifOn" style="width:100%">🔔 Aktifkan pengingat waktu terbaik</button>`):""}</div>`;
}
function bindFav(){
  document.querySelectorAll(".favrow").forEach(b=>b.onclick=()=>setSpot(b.dataset.id));
  const fb=$("#favBtn");if(fb)fb.onclick=()=>toggleFav(fb.dataset.fav);
  const n=$("#notifOn");if(n)n.onclick=async()=>{try{await Notification.requestPermission()}catch(e){}store.set("mm_notif_day","");dailyReminder();render()};
}
function dailyReminder(){
  if(typeof Notification==="undefined"||Notification.permission!=="granted")return;
  const today=new Date().toDateString();if(store.get("mm_notif_day","")===today)return;
  const fs=favs.map(id=>everySpot().find(s=>s.id===id)).filter(Boolean).slice(0,4);if(!fs.length)return;
  const gd=(goodCache?.days||[]).filter(x=>x.ok&&x.off===1).sort((a,b)=>b.score-a.score)[0];const en=region==="AU",body=(gd?(en?`🎣 Tomorrow looks good: ${gd.n} ${fmt(gd.from)}–${fmt(gd.to)}\n`:`🎣 Besok bagus: ${gd.n} ${fmt(gd.from)}–${fmt(gd.to)}\n`):"")+fs.map(s=>{const b=bestWindow(s);return `${s.n}: ${fmt(b.from)}–${fmt(b.to)} (${b.total})`}).join("\n");
  const title=en?"Best fishing times today":"Waktu mancing terbaik hari ini";
  const show=()=>navigator.serviceWorker?.ready?navigator.serviceWorker.ready.then(r=>r.showNotification(title,{body,icon:"icons/icon-192.png"})).catch(()=>new Notification(title,{body})):new Notification(title,{body});
  try{show();store.set("mm_notif_day",today)}catch(e){}
}

// --- mode offline ---
function offlineBadge(){return navigator.onLine?"":`<div class="card offline"><b>📴 Sedang offline.</b> <span class="note">Spot, tutorial, aturan dan prakiraan terakhir yang tersimpan tetap bisa dibuka.</span></div>`}
addEventListener("online",()=>{render();loadFeed()});addEventListener("offline",()=>render());
{const fc=store.get("mm_feed_cache",null);if(fc&&!navigator.onLine){feed=fc.feed;likes=fc.likes||{};comments=fc.comments||{}}}

// --- aturan per negara bagian Australia ---
const AU_RULES={
 NSW:{n:"New South Wales",u:"https://www.dpi.nsw.gov.au/fishing/recreational/fishing-rules-and-regs",lic:"NSW Recreational Fishing Fee wajib (usia 18+), mis. 3 hari, 1 bulan, 1 atau 3 tahun.",licU:"https://www.dpi.nsw.gov.au/fishing/recreational/fishing-fee"},
 QLD:{n:"Queensland",u:"https://www.daf.qld.gov.au/business-priorities/fisheries/recreational/rules-regulations",lic:"Tidak perlu izin umum; izin khusus untuk bendungan (SIPS)."},
 VIC:{n:"Victoria",u:"https://vfa.vic.gov.au/recreational-fishing/fishing-regulations",lic:"Recreational Fishing Licence wajib (usia 18–69).",licU:"https://vfa.vic.gov.au/recreational-fishing/recreational-fishing-licence"},
 TAS:{n:"Tasmania",u:"https://fishing.tas.gov.au/recreational-fishing",lic:"Izin hanya untuk jenis tertentu (lobster, abalone, scallop, jaring)."},
 SA:{n:"South Australia",u:"https://www.pir.sa.gov.au/recreational_fishing",lic:"Tidak perlu izin umum; ada batas tangkap harian & per perahu."},
 WA:{n:"Western Australia",u:"https://www.dpird.wa.gov.au/individuals/recreational-fishing/",lic:"Izin wajib untuk mancing dari perahu (RFBL) dan beberapa jenis.",licU:"https://www.fish.wa.gov.au/Fishing-and-Aquaculture/Recreational-Fishing/Recreational-Fishing-Licences"},
 NT:{n:"Northern Territory",u:"https://nt.gov.au/marine/recreational-fishing",lic:"Tidak perlu izin umum; batas tangkap ketat untuk Barramundi & Jewfish."}};
function rulesHtml(){
  if(region!=="AU")return `<h2>Aturan & darurat</h2>
     <div class="card"><h3>Darurat Indonesia</h3><p>Darurat umum: <b>112</b> · Basarnas (SAR): <b>115</b> · Polisi: <b>110</b></p></div>
     <div class="card"><h3>Mancing di Indonesia</h3><p>Tidak ada izin nasional atau batas ukuran untuk pemancing rekreasi. Yang perlu diperhatikan:</p><ul><li>Taman nasional & kawasan konservasi laut (Komodo, Karimunjawa, Kepulauan Seribu, Gili Matra, Bunaken) punya zona larangan dan retribusi. Tanyakan ke pengelola.</li><li>Jangan ambil penyu, hiu, pari manta, dan napoleon (dilindungi).</li><li>Lepaskan ikan kecil supaya stok tetap ada.</li></ul></div>`+conservationHtml();
  const st=cur().st&&AU_RULES[cur().st==="Sydney"?"NSW":cur().st]?(cur().st==="Sydney"?"NSW":cur().st):"NSW",R=AU_RULES[st];
  return `<h2>Aturan & darurat</h2>
   <div class="card"><h3>Darurat Australia</h3><p>Polisi/ambulans/pemadam: <b>000</b> · Penyelamatan laut: VHF channel 16</p></div>
   <div class="card"><span class="tag">Negara bagian spot ini</span><h3>${R.n}</h3><p>${R.lic}${R.licU?` <a href="${R.licU}" target="_blank" rel="noopener">Beli/cek izin</a>`:""}</p>
    <p><a class="btn ghost" href="${R.u}" target="_blank" rel="noopener" style="display:block">Aturan resmi ${R.n} ↗</a></p>
    <div class="seg" style="flex-wrap:wrap">${Object.keys(AU_RULES).map(k=>`<a class="x" href="${AU_RULES[k].u}" target="_blank" rel="noopener">${k}</a>`).join(" ")}</div></div>
   <div class="card"><h3>Ukuran minimum & batas tangkap (acuan NSW)</h3><table><thead><tr><th>Ikan</th><th>Aturan</th></tr></thead><tbody>${Object.entries(SP).filter(([k,v])=>v.lim&&v.lim!=="–"&&!v.community).map(([k,v])=>`<tr><td>${fishMini(k)}</td><td>${v.lim}</td></tr>`).join("")}</tbody></table>
   <p class="note">Ringkasan acuan NSW. Aturan berbeda antar negara bagian dan bisa berubah, jadi selalu cek situs resmi di atas sebelum membawa pulang ikan. Ada juga zona larangan (marine park sanctuary zones).</p></div>`;
}


/* ===== Foto ikan asli (Wikipedia / Wikimedia Commons), gambar kartun jadi cadangan ===== */
const WIKI={"Bream":"Acanthopagrus_australis","Flathead":"Platycephalus_fuscus","Whiting":"Sillago_ciliata","Squid":"Sepioteuthis_australis","Kingfish":"Seriola_lalandi","Mulloway":"Argyrosomus_japonicus","Snapper":"Australasian_snapper","Tailor":"Bluefish","Luderick":"Girella_tricuspidata","Drummer":"Girella_elevata","Salmon Australia":"Arripis_trutta","Trevally":"Pseudocaranx_georgianus","Yellowtail":"Trachurus_novaezelandiae","Tarwhine":"Rhabdosargus_sarba","Estuary Perch":"Percalates_colonorum","Kakap Merah":"Lutjanus_malabaricus","Kakap Putih":"Barramundi","Kerapu":"Epinephelus_coioides","GT":"Giant_trevally","Barakuda":"Great_barracuda","Tenggiri":"Narrow-barred_Spanish_mackerel","Tongkol":"Mackerel_tuna","Baronang":"Siganus_canaliculatus","Bawal":"Silver_pomfret","Belanak":"Flathead_grey_mullet","Cumi":"Bigfin_reef_squid","Barramundi":"Barramundi","Mangrove Jack":"Mangrove_red_snapper","King George Whiting":"King_George_whiting","Spanish Mackerel":"Narrow-barred_Spanish_mackerel","Coral Trout":"Leopard_coral_grouper","Golden Trevally":"Golden_trevally"};
const fpCache=store.get("mm_fp2",{}),fpWait={};
function fetchFP(n){
  if(fpWait[n])return fpWait[n];
  return fpWait[n]=fetch("https://en.wikipedia.org/api/rest_v1/page/summary/"+encodeURIComponent(WIKI[n])).then(r=>r.ok?r.json():null).then(j=>{const u=j?.thumbnail?.source||"";fpCache[n]=u;store.set("mm_fp2",fpCache);return u}).catch(()=>"");
}
function hydrateFish(root){
  if(!root||!root.querySelectorAll)return;
  root.querySelectorAll(".fishpic[data-sp]:not([data-done])").forEach(el=>{
    el.dataset.done="1";const n=el.dataset.sp;if(!WIKI[n])return;
    const set=u=>{if(!u)return;const im=new Image();im.alt=n;im.onload=()=>{el.innerHTML="";el.appendChild(im);el.classList.add("photo")};im.src=u};
    if(fpCache[n]!==undefined&&fpCache[n]!=="")set(fpCache[n]);else if(navigator.onLine)fetchFP(n).then(set);
  });
}
new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(x=>x.nodeType===1&&hydrateFish(x)))).observe(document.documentElement,{childList:true,subtree:true});

/* ================= v3: STATISTIK ADMIN, MUSIM IKAN, LOGBOOK, BAGIKAN ================= */
// --- statistik admin ---
async function adminStatsHtml(){
  const{data,error}=await sb.rpc("admin_stats");
  if(error)return `<p class="note">Statistik gagal dimuat: ${esc(error.message)}</p>`;
  const d=data||{},k=(l,v,sub)=>`<div class="kv"><span class="tag">${l}</span><strong>${v??0}</strong>${sub?`<span class="note">${sub}</span>`:""}</div>`;
  const v=(await sb.rpc("visit_stats")).data;
  const vis=v?`<h3 style="margin-top:4px">👀 ${LX("Pengunjung (termasuk tanpa login)","Visitors (incl. not signed in)")}</h3><div class="row statgrid">${k(LX("Hari ini","Today"),v.today)}${k(LX("7 hari","7 days"),v.d7,`🇮🇩 ${v.id7||0} · 🇦🇺 ${v.au7||0}`)}${k(LX("30 hari","30 days"),v.d30)}${k(LX("Total perangkat","Total devices"),v.all)}${k("APK 7 "+LX("hari","days"),v.apk7)}</div>${(v.days||[]).length?`<div class="vbars">${v.days.map(x=>{const m=Math.max(...v.days.map(y=>y.n));return `<div title="${x.d}: ${x.n}"><i style="height:${Math.max(4,Math.round(x.n/m*60))}px"></i><span>${x.d.slice(8)}</span></div>`}).join("")}</div><p class="note">${LX("Pengunjung per hari, 14 hari terakhir. 1 HP/browser = 1 pengunjung per hari.","Visitors per day, last 14 days. 1 phone/browser = 1 visitor per day.")}</p>`:""}`:`<p class="note">${LX("Penghitung pengunjung belum aktif (jalankan schema-v6-visits.sql).","Visitor counter not active yet.")}</p>`;
  return vis+`<h3 style="margin-top:10px">👤 ${LX("Akun terdaftar","Registered accounts")}</h3><div class="row statgrid">${k("Pengguna terdaftar",d.users,`+${d.new7||0} minggu ini`)}${k("Login 7 hari",d.login7)}${k("Login 30 hari",d.login30)}${k("Tangkapan",d.catches,`+${d.catches7||0} minggu ini`)}${k("Dengan foto",d.photos)}${k("Suka",d.likes)}${k("Komentar",d.comments)}${k("Masukan baru",d.feedback_new)}${k("Kiriman baru",d.subs_new)}${k("Laporan konten",d.reports)}</div>
   <p class="note">${LX("Kotak akun hanya menghitung orang yang login.","Account boxes only count signed-in users.")}</p>`;
}

// --- kalender musim ikan (panduan umum) ---
// p = bulan puncak, s = bulan sepi/tutup (1–12); selain itu = biasa
const SEASON={
 AU:{"Bream":{p:[5,6,7,8]},"Flathead":{p:[10,11,12,1,2,3,4],s:[6,7]},"Whiting":{p:[11,12,1,2,3],s:[6,7,8]},"King George Whiting":{p:[11,12,1,2,3,4]},"Squid":{p:[5,6,7,8,9,10]},"Kingfish":{p:[11,12,1,2,3,4],s:[7,8]},
  "Mulloway":{p:[3,4,5,6,10,11]},"Snapper":{p:[5,6,7,8,9]},"Tailor":{p:[4,5,6,7,8,9]},"Luderick":{p:[4,5,6,7,8,9]},"Drummer":{p:[5,6,7,8,9]},"Salmon Australia":{p:[4,5,6,7,8,9]},"Trevally":{p:[3,4,5,6]},"Yellowtail":{p:[]},"Tarwhine":{p:[10,11,12,1,2,3]},
  "Estuary Perch":{p:[9,10,11,12,1,2,3],s:[6,7,8]},"Barramundi":{p:[9,10,2,3,4],s:[11,12,1]},"Mangrove Jack":{p:[11,12,1,2,3,4],s:[6,7,8]},"Spanish Mackerel":{p:[7,8,9,10]},"Coral Trout":{p:[4,5,6,7,8,9,10]},"GT":{p:[9,10,11,12]},"Golden Trevally":{p:[9,10,11,12,1]}},
 ID:{"GT":{p:[9,10,11],s:[1,2]},"Kakap Merah":{p:[3,4,5,9,10,11],s:[1,2]},"Kakap Putih":{p:[11,12,1,2]},"Kerapu":{p:[4,5,6,7,8,9,10],s:[1,2]},"Tenggiri":{p:[6,7,8,9,10],s:[12,1,2]},"Tongkol":{p:[5,6,7,8]},"Baronang":{p:[4,5,6,7,8]},
  "Belanak":{p:[]},"Barakuda":{p:[4,5,6,7,8,9]},"Cumi":{p:[6,7,8,9],s:[12,1]},"Bawal":{p:[2,3,4,5,6]}}};
const MON_ID=["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"],MON_EN=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const seasonOf=(f,m)=>{const s=SEASON[region]?.[f];if(!s)return null;return s.p.includes(m)?"p":(s.s||[]).includes(m)?"s":"b"};
function inSeasonNow(fishes){const m=new Date().getMonth()+1;return fishes.filter(f=>seasonOf(f,m)==="p")}
const MONF_ID=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"],MONF_EN=["January","February","March","April","May","June","July","August","September","October","November","December"];
let seasonM=new Date().getMonth()+1;
function monthRanges(ms){ // [5,6,7,8] -> "Mei–Agu"; mendukung lintas tahun (Nov–Feb)
  if(!ms||!ms.length)return "";const MON=region==="AU"?MON_EN:MON_ID,set=new Set(ms);if(set.size===12)return LX("sepanjang tahun","all year");
  let st=1;while(set.has(st)&&set.has(st===1?12:st-1))st++;const out=[];
  for(let i=0;i<12;i++){const m=((st-1+i)%12)+1;if(set.has(m)&&!set.has(m===1?12:m-1)){let e=m;while(set.has(e%12+1)&&e%12+1!==m)e=e%12+1;out.push(e===m?MON[m-1]:MON[m-1]+"–"+MON[e-1])}}
  return out.join(", ");
}
function seasonHtml(){
  const now=new Date().getMonth()+1,m=seasonM,MONF=region==="AU"?MONF_EN:MONF_ID,MON=region==="AU"?MON_EN:MON_ID,S=SEASON[region]||{};
  const fs=Object.keys(S).sort(),grp={p:[],b:[],s:[]};fs.forEach(f=>grp[seasonOf(f,m)].push(f));
  return `<h2>Musim ikan</h2>
   <div class="card"><h3>Pilih bulan</h3><div class="mgrid">${MON.map((x,i)=>`<button data-sm="${i+1}" aria-pressed="${i+1===m}" class="${i+1===now?"isnow":""}">${x}${i+1===now?"<small>•</small>":""}</button>`).join("")}</div>
   <p class="note">• = bulan ini</p></div>
   <div class="card sgrp p"><h3>🔥 Puncak musim · ${MONF[m-1]}</h3>${grp.p.length?grp.p.map(fishMini).join(""):`<p class="note">Tidak ada puncak musim khusus bulan ini.</p>`}</div>
   <div class="card sgrp b"><h3>🎣 Bisa didapat · ${MONF[m-1]}</h3>${grp.b.map(fishMini).join("")||`<p class="note">–</p>`}</div>
   ${grp.s.length?`<div class="card sgrp s"><h3>⚠️ Sepi / hindari · ${MONF[m-1]}</h3>${grp.s.map(fishMini).join("")}</div>`:""}
   <h3>Musim tiap ikan</h3>
   <div class="card">${fs.map(f=>{const sx=S[f],v=seasonOf(f,now);return `<div class="srow"><div class="srow-h">${fishMini(f)}<span class="badge ${v}">${v==="p"?LX("Musim sekarang","In season now"):v==="s"?LX("Sepi sekarang","Quiet now"):LX("Biasa","Normal")}</span></div>
     <div class="note">${sx.p.length?`<b>${LX("Puncak","Peak")}:</b> ${monthRanges(sx.p)}`:LX("Bisa didapat sepanjang tahun","Caught all year")}${(sx.s||[]).length?` · <b>${LX("Sepi","Quiet")}:</b> ${monthRanges(sx.s)}`:""}</div>
     <div class="mbar">${MON.map((x,i)=>`<i class="${seasonOf(f,i+1)}${i+1===now?" curm":""}" title="${x}"><span>${x}</span></i>`).join("")}</div></div>`}).join("")}</div>
   <p class="note">${region==="AU"?"Panduan umum untuk pesisir timur (NSW–QLD). Daerah lain bisa bergeser 1–2 bulan. Cek aturan musim tutup di menu Aturan.":"Panduan umum. Musim barat (Des–Mar) biasanya ombak besar; musim timur (Jun–Sep) cocok untuk ikan pelagis seperti tenggiri dan tongkol."}</p>`;
}
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("[data-sm]");if(!b)return;seasonM=+b.dataset.sm;const y=$("#main").scrollTop;render();$("#main").scrollTop=y});

// --- logbook pribadi (tersimpan di HP, tanpa login) ---
let logbook=store.get("mm_log",[]);
const saveLog=()=>{let ok=store.set("mm_log",logbook);while(!ok&&logbook.some(e=>e.photo)){const e=logbook.slice().reverse().find(e=>e.photo);e.photo=null;ok=store.set("mm_log",logbook)}return ok};
let logPhoto=null;
function logbookHtml(){
  const xs=logbook.filter(e=>(e.region||region)===region);
  return `<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h3 style="margin:0">📒 Logbook pribadi</h3><button class="btn" id="logAdd">+ Catat</button></div>
   <p class="note">Tersimpan di HP ini saja, bisa tanpa login & tanpa sinyal.</p>
   ${xs.length?xs.slice().reverse().map(e=>`<div class="log">${e.photo?`<img src="${e.photo}" alt="${esc(e.fish)}" data-zoom="${e.photo}">`:`<span class="thumb">${fishSVG(e.fish)}</span>`}<span class="grow"><b>${esc(e.fish)}</b> ${e.len?e.len+" cm":""}<br><span class="note">${esc(e.spot||"")} · ${new Date(e.t).toLocaleDateString(region==="AU"?"en-AU":"id-ID",{day:"numeric",month:"short",year:"numeric"})}${e.bait?" · "+esc(e.bait):""}</span>${e.note?`<br><span class="note">${esc(e.note)}</span>`:""}${e.cond?"<br>"+condLine(e.cond):""}
     <span class="acts"><button class="x" data-lshare="${e.id}">📤 Bagikan</button>${me&&myName&&!e.posted?`<button class="x" data-lpost="${e.id}">⬆️ Ke komunitas</button>`:e.posted?`<span class="badge">sudah dibagikan</span>`:""}<button class="x" data-ldel="${e.id}">Hapus</button></span></span></div>`).join(""):`<p class="note">Belum ada catatan.</p>`}</div>`;
}
function openLogForm(){
  const c=cur(),fl=[...new Set(LOC.filter(l=>l.region===region).flatMap(l=>spotData(l).fish))].filter(f=>SP[f]).concat(Object.keys(SP).sort());
  logPhoto=null;
  openSheet(`<h3>Catat tangkapan</h3><form id="logF">
   <select class="f" id="lfish">${[...new Set(fl)].map(f=>`<option>${esc(f)}</option>`).join("")}<option value="__new">➕ Ikan lain (tulis sendiri)</option></select>
   <input id="lnew" placeholder="Nama ikan" maxlength="40" style="display:none;margin-top:6px">
   <div class="two" style="margin-top:6px"><input id="llen" type="number" min="1" max="400" placeholder="Panjang (cm)"><input id="lbait" placeholder="Umpan" maxlength="60"></div>
   <input id="lspot" value="${esc(c.n)}" maxlength="60" style="margin-top:6px" aria-label="Spot">
   <textarea id="lnote" rows="2" maxlength="300" placeholder="Catatan (cuaca, teknik, dll.)" style="margin-top:6px"></textarea>
   <label class="btn ghost" for="lpic" style="display:block;margin-top:6px">📷 Tambah foto</label><input type="file" id="lpic" accept="image/*" hidden><div id="lprev"></div>
   <button class="btn" type="submit" style="width:100%;margin-top:8px">Simpan ke logbook</button></form>`);
  $("#lfish").onchange=()=>{$("#lnew").style.display=$("#lfish").value==="__new"?"":"none"};
  $("#lpic").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const cv=await shrink(f,700);logPhoto=cv.toDataURL("image/jpeg",.6);$("#lprev").innerHTML=`<img class="preview" src="${logPhoto}" alt="">`}catch(x){}};
  $("#logF").onsubmit=e=>{e.preventDefault();let fish=$("#lfish").value;if(fish==="__new")fish=$("#lnew").value.trim();if(!fish)return;
    const ent={id:"l"+Date.now(),t:Date.now(),fish,len:+$("#llen").value||null,bait:$("#lbait").value.trim(),spot:$("#lspot").value.trim(),note:$("#lnote").value.trim(),photo:logPhoto,region,spotId:c.id,lat:here&&km(here.lat,here.lon,c.lat,c.lon)<5?here.lat:c.lat,lon:here&&km(here.lat,here.lon,c.lat,c.lon)<5?here.lon:c.lon};
    logbook.push(ent);
    if(!saveLog())alertNote("Memori HP penuh: foto lama tidak disimpan.");closeSheet();render();
    captureConditions(ent.lat,ent.lon,ent.t).then(cond=>{ent.cond=cond;saveLog();if(view==="tangkapan")render()})};
}
function bindLogbook(){
  const a=$("#logAdd");if(a)a.onclick=openLogForm;
  document.querySelectorAll("[data-ldel]").forEach(b=>b.onclick=()=>{if(b.dataset.c!=="1"){b.dataset.c="1";b.textContent="Yakin hapus?";tr(b);return}logbook=logbook.filter(e=>e.id!==b.dataset.ldel);saveLog();render()});
  document.querySelectorAll("[data-lshare]").forEach(b=>b.onclick=()=>{const e=logbook.find(x=>x.id===b.dataset.lshare);if(e)shareCatch({fish:e.fish,len:e.len,spot:e.spot,photo:e.photo,bait:e.bait,t:e.t})});
  document.querySelectorAll("[data-lpost]").forEach(b=>b.onclick=async()=>{const e=logbook.find(x=>x.id===b.dataset.lpost);if(!e)return;b.disabled=true;b.textContent="Mengupload…";tr(b);
    try{let path=null;if(e.photo){const blob=await (await fetch(e.photo)).blob();path=`${me.id}/${Date.now()}.jpg`;const up=await sb.storage.from("photos").upload(path,blob,{contentType:"image/jpeg"});if(up.error)throw up.error}
      const s=everySpot().find(x=>x.id===e.spotId);
      const{error}=await sb.from("catches").insert({fish:e.fish,length_cm:e.len,bait:e.bait||null,released:false,spot_id:s?s.id:null,spot_name:e.spot||null,area:s?.a||null,lat:e.lat!=null?+(+e.lat).toFixed(3):null,lon:e.lon!=null?+(+e.lon).toFixed(3):null,photo_path:path});if(error)throw error;
      e.posted=true;saveLog();await loadFeed();render()}catch(err){b.disabled=false;b.textContent="Gagal: "+(err.message||err)}});
}

// --- bagikan tangkapan sebagai gambar (WhatsApp, dll.) ---
const loadImg=src=>new Promise((res,rej)=>{const i=new Image();i.crossOrigin="anonymous";i.onload=()=>res(i);i.onerror=rej;i.src=src});
async function shareCatch(x){
  const W=1080,H=1350,cv=document.createElement("canvas");cv.width=W;cv.height=H;const g=cv.getContext("2d");
  g.fillStyle="#0b1e33";g.fillRect(0,0,W,H);
  let src=x.photo||(WIKI[x.fish]?(fpCache[x.fish]||await fetchFP(x.fish)):"");
  if(src&&!x.photo)src=src.replace(/\/(\d+)px-/,"/800px-");
  try{if(src){const im=await loadImg(src).catch(()=>loadImg(x.photo||fpCache[x.fish]));const r=Math.max(W/im.width,1000/im.height),w=im.width*r,h=im.height*r;g.drawImage(im,(W-w)/2,(1000-h)/2,w,h)}}catch(e){}
  const gr=g.createLinearGradient(0,700,0,H);gr.addColorStop(0,"rgba(11,30,51,0)");gr.addColorStop(.35,"rgba(11,30,51,.92)");gr.addColorStop(1,"#0b1e33");g.fillStyle=gr;g.fillRect(0,700,W,H-700);
  try{const lg=await loadImg("icons/header-logo-dark.png");const lh=120,lw=lg.width*lh/lg.height;g.fillStyle="rgba(11,30,51,.55)";g.fillRect(30,30,lw+40,lh+30);g.drawImage(lg,50,45,lw,lh)}catch(e){}
  g.fillStyle="#fff";g.font="bold 96px system-ui,sans-serif";g.fillText(x.fish,60,1060);
  g.fillStyle="#f2a33a";g.font="bold 72px system-ui,sans-serif";if(x.len)g.fillText(x.len+" cm",60,1150);
  g.fillStyle="#cfe3f5";g.font="44px system-ui,sans-serif";
  const line=[x.spot,x.bait?(region==="AU"?"Bait: ":"Umpan: ")+x.bait:"",x.t?new Date(x.t).toLocaleDateString(region==="AU"?"en-AU":"id-ID",{day:"numeric",month:"long",year:"numeric"}):""].filter(Boolean).join(" · ");
  g.fillText(line.slice(0,48),60,x.len?1225:1150);
  g.fillStyle="#8fb3d1";g.font="34px system-ui,sans-serif";g.fillText("mancingmania.asia",60,1300);
  let blob=null;try{blob=await new Promise(r=>cv.toBlob(r,"image/jpeg",.88))}catch(e){}
  const text=(region==="AU"?`My catch: ${x.fish}${x.len?" "+x.len+" cm":""}${x.spot?" at "+x.spot:""} 🎣 via Mancing Mania`:`Tangkapanku: ${x.fish}${x.len?" "+x.len+" cm":""}${x.spot?" di "+x.spot:""} 🎣 lewat Mancing Mania`)+"\nhttps://mancingmania.asia/";
  const file=blob&&new File([blob],"mancing-mania.jpg",{type:"image/jpeg"});
  if(file&&navigator.canShare&&navigator.canShare({files:[file]})){try{await navigator.share({files:[file],text});return}catch(e){if(e.name==="AbortError")return}}
  const url=blob?URL.createObjectURL(blob):"";
  openSheet(`<h3>Bagikan tangkapan</h3>${url?`<img src="${url}" alt="" style="width:100%;border-radius:10px">`:""}
   <div class="two" style="margin-top:8px">${url?`<a class="btn ghost" href="${url}" download="mancing-mania.jpg">⬇️ Simpan gambar</a>`:""}<a class="btn" href="https://wa.me/?text=${encodeURIComponent(text)}" target="_blank" rel="noopener">WhatsApp</a></div>
   <p class="note">Simpan gambarnya dulu, lalu lampirkan di WhatsApp bersama pesannya.</p>`);
}

/* ================= v4: LAPISAN PETA, SOLUNAR, JEJAK GPS, STATISTIK, KONDISI OTOMATIS ================= */
// ---------- Solunar (posisi bulan, disederhanakan dari SunCalc / Meeus) ----------
const RAD=Math.PI/180,J2000=2451545;
const toDays=t=>t/864e5-0.5+2440588-J2000;
function moonCoords(d){const L=RAD*(218.316+13.176396*d),M=RAD*(134.963+13.064993*d),F=RAD*(93.272+13.229350*d),l=L+RAD*6.289*Math.sin(M),b=RAD*5.128*Math.sin(F),dt=385001-20905*Math.cos(M),e=RAD*23.4397;
  return{ra:Math.atan2(Math.sin(l)*Math.cos(e)-Math.tan(b)*Math.sin(e),Math.cos(l)),dec:Math.asin(Math.sin(b)*Math.cos(e)+Math.cos(b)*Math.sin(e)*Math.sin(l))}}
function moonAlt(t,lat,lon){const d=toDays(t),c=moonCoords(d),lw=RAD*-lon,phi=RAD*lat,H=RAD*(280.16+360.9856235*d)-lw-c.ra;
  return Math.asin(Math.sin(phi)*Math.sin(c.dec)+Math.cos(phi)*Math.cos(c.dec)*Math.cos(H))}
function moonHA(t,lon){const d=toDays(t),c=moonCoords(d);let H=(RAD*(280.16+360.9856235*d)+RAD*lon-c.ra)%(2*Math.PI);if(H>Math.PI)H-=2*Math.PI;if(H<-Math.PI)H+=2*Math.PI;return H}
function solunar(ds,lat,lon){ // ds = awal hari (ms UTC); hasil jam lokal relatif awal hari
  const step=6e5,ev=[];let pa=moonAlt(ds,lat,lon),ph=moonHA(ds,lon);
  for(let t=ds+step;t<=ds+864e5;t+=step){const a=moonAlt(t,lat,lon),h=moonHA(t,lon),hr=(t-ds)/36e5;
    if(pa<0&&a>=0)ev.push({k:"minor",h:hr,n:LX("Bulan terbit","Moonrise")});
    if(pa>=0&&a<0)ev.push({k:"minor",h:hr,n:LX("Bulan terbenam","Moonset")});
    if(ph<0&&h>=0)ev.push({k:"major",h:hr,n:LX("Bulan di atas","Moon overhead")});
    if(Math.abs(ph)>2.5&&Math.abs(h)>2.5&&Math.sign(ph)!==Math.sign(h))ev.push({k:"major",h:hr,n:LX("Bulan di bawah","Moon underfoot")});
    pa=a;ph=h}
  return ev.sort((a,b)=>a.h-b.h);
}
function solunarHtml(ds,lat,lon){
  const ev=solunar(ds,lat,lon),nowH=(Date.now()-ds)/36e5;
  return `<div class="card"><h3>🌙 ${LX("Jam makan Solunar","Solunar feeding times")}</h3>
   <p class="note">${LX("Major ±1 jam saat bulan tepat di atas/bawah; Minor ±30 menit saat bulan terbit/terbenam. Ikan cenderung lebih aktif di jam-jam ini.","Major ±1 h when the moon is overhead/underfoot; Minor ±30 min at moonrise/moonset. Fish tend to feed more at these times.")}</p>
   <div class="soltl">${ev.map(e=>{const w=e.k==="major"?1:.5,on=nowH>=e.h-w&&nowH<=e.h+w;return `<div class="solrow ${e.k}${on?" now":""}"><span class="badge ${e.k==="major"?"p":""}">${e.k==="major"?"Major":"Minor"}</span><b>${fmt(e.h-w)}–${fmt(e.h+w)}</b><span class="note">${e.n}${on?" · "+LX("sedang berlangsung","happening now"):""}</span></div>`}).join("")||`<p class="note">–</p>`}</div></div>`;
}
function solunarNow(t,lat,lon){const tz=tzLL(lat,lon),l=new Date(t+tz*36e5),ds=Date.UTC(l.getUTCFullYear(),l.getUTCMonth(),l.getUTCDate())-tz*36e5,h=(t-ds)/36e5;
  const e=solunar(ds,lat,lon).find(e=>Math.abs(h-e.h)<=(e.k==="major"?1:.5));return e?e.k:null}

// ---------- Lapisan peta: suhu laut, klorofil, radar hujan, angin ----------
let mapLayer=store.get("mm_layer","none"),rvMeta=null,windMarkers=[];
const gibsDate=()=>new Date(Date.now()-2*864e5).toISOString().slice(0,10);
const LAYERS={none:["Peta biasa","Normal map"],sst:["🌡️ Suhu laut","🌡️ Sea temperature"],chl:["🌿 Klorofil (plankton)","🌿 Chlorophyll (plankton)"],rain:["🌧️ Radar hujan","🌧️ Rain radar"],wind:["💨 Angin sekarang","💨 Wind now"]};
const LAYER_NOTE={sst:["Merah = air hangat, biru = dingin. Ikan pelagis (tenggiri, tongkol, GT) sering berkumpul di garis pertemuan air hangat dan dingin. Data satelit NASA, 1–2 hari lalu.","Red = warm water, blue = cold. Pelagic fish (mackerel, tuna, GT) often gather along warm/cold water edges. NASA satellite data, 1–2 days old."],
  chl:["Hijau/kuning = banyak plankton, berarti ikan kecil dan predator datang. Area kosong = tertutup awan. Data satelit NASA.","Green/yellow = lots of plankton, which attracts baitfish and predators. Blank areas = cloud cover. NASA satellite data."],
  rain:["Radar hujan terbaru dari RainViewer (detail terbatas saat diperbesar). Hindari laut bila ada sel hujan lebat mendekat. Area tanpa stasiun radar tampil kosong.","Latest rain radar from RainViewer (less detail when zoomed in). Avoid the water if heavy cells are approaching. Areas without radar coverage stay blank."],
  wind:["Panah = arah angin bertiup, angka = km/jam. Di atas 25 km/jam berbahaya untuk perahu kecil.","Arrows = wind direction, numbers = km/h. Above 25 km/h is risky for small boats."]};
function layerBarHtml(){return `<div class="seg layerbar">${Object.keys(LAYERS).map(k=>`<button data-ly="${k}" aria-pressed="${mapLayer===k}">${LX(...LAYERS[k])}</button>`).join("")}</div>${mapLayer!=="none"?`<p class="note">${LX(...LAYER_NOTE[mapLayer])}</p>`:""}`}
async function applyMapLayer(){
  if(!lmap||!window.L)return;windMarkers.forEach(m=>m.remove());windMarkers=[];
  if(mapLayer==="sst"||mapLayer==="chl"){
    const id=mapLayer==="sst"?"GHRSST_L4_MUR_Sea_Surface_Temperature":"VIIRS_NOAA20_Chlorophyll_a";
    L.tileLayer(`https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/${id}/default/${gibsDate()}/GoogleMapsCompatible_Level7/{z}/{y}/{x}.png`,{maxNativeZoom:7,maxZoom:18,opacity:.65,attribution:"NASA GIBS"}).addTo(lmap);
  }else if(mapLayer==="rain"){
    try{rvMeta=rvMeta&&Date.now()-rvMeta.t<6e5?rvMeta:{...(await fetch("https://api.rainviewer.com/public/weather-maps.json").then(r=>r.json())),t:Date.now()};
      const f=rvMeta.radar.past[rvMeta.radar.past.length-1];
      if(lmap)L.tileLayer(`${rvMeta.host}${f.path}/256/{z}/{x}/{y}/2/1_1.png`,{maxNativeZoom:7,maxZoom:18,opacity:.7,attribution:"RainViewer"}).addTo(lmap)}catch(e){}
  }else if(mapLayer==="wind"){drawWind()}
}
async function drawWind(){
  if(!lmap)return;const b=lmap.getBounds(),pts=[];
  for(let i=0;i<5;i++)for(let j=0;j<5;j++)pts.push([b.getSouth()+(b.getNorth()-b.getSouth())*(i+.5)/5,b.getWest()+(b.getEast()-b.getWest())*(j+.5)/5]);
  try{const j=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${pts.map(p=>p[0].toFixed(3)).join(",")}&longitude=${pts.map(p=>p[1].toFixed(3)).join(",")}&current=wind_speed_10m,wind_direction_10m&wind_speed_unit=kmh`).then(r=>r.json());
    const arr=Array.isArray(j)?j:[j];if(!lmap||mapLayer!=="wind")return;
    arr.forEach((r,i)=>{const s=Math.round(r.current?.wind_speed_10m??0),d=r.current?.wind_direction_10m??0,col=s>35?"#c4473a":s>25?"#d99a1e":"#1565c0";
      const ic=L.divIcon({className:"windpin",html:`<div style="transform:rotate(${d+180}deg);color:${col}">➤</div><span style="color:${col}">${s}</span>`,iconSize:[34,34]});
      windMarkers.push(L.marker(pts[i],{icon:ic,interactive:false}).addTo(lmap))})}catch(e){}
}
function bindLayerBar(){document.querySelectorAll("[data-ly]").forEach(b=>b.onclick=()=>{mapLayer=b.dataset.ly;store.set("mm_layer",mapLayer);render()})}

// ---------- Jejak GPS & titik (waypoint) ----------
let wpts=store.get("mm_wpts",[]),tracks=store.get("mm_tracks",[]),rec=null;
function startTrack(){
  if(!navigator.geolocation){alertBox(LX("HP ini tidak mendukung GPS.","This phone doesn't support GPS."));return}
  rec={id:"t"+Date.now(),t0:Date.now(),pts:[],watch:null};
  rec.watch=navigator.geolocation.watchPosition(p=>{if(!rec)return;const q=[+p.coords.latitude.toFixed(5),+p.coords.longitude.toFixed(5)],l=rec.pts[rec.pts.length-1];
    if(!l||km(l[0],l[1],q[0],q[1])>0.01){rec.pts.push(q);if(lmap&&rec.line)rec.line.addLatLng(q);updRec()}},()=>{},{enableHighAccuracy:true,maximumAge:5000});
  render();
}
function stopTrack(){if(!rec)return;navigator.geolocation.clearWatch(rec.watch);
  if(rec.pts.length>1){const dist=rec.pts.reduce((a,p,i)=>i?a+km(rec.pts[i-1][0],rec.pts[i-1][1],p[0],p[1]):0,0);
    tracks.unshift({id:rec.id,t0:rec.t0,t1:Date.now(),pts:rec.pts,km:+dist.toFixed(2),name:LX("Jejak ","Track ")+new Date(rec.t0).toLocaleDateString(LOC_(),{day:"numeric",month:"short"})});tracks=tracks.slice(0,30);store.set("mm_tracks",tracks)}
  rec=null;render()}
function updRec(){const e=$("#recInfo");if(e&&rec){const d=rec.pts.reduce((a,p,i)=>i?a+km(rec.pts[i-1][0],rec.pts[i-1][1],p[0],p[1]):0,0);e.textContent=`${LX("Merekam","Recording")} · ${rec.pts.length} ${LX("titik","points")} · ${d.toFixed(2)} km`}}
function addWaypoint(lat,lon){
  openSheet(`<h3>📌 ${LX("Tandai titik","Mark this point")}</h3><p class="note">${lat.toFixed(5)}, ${lon.toFixed(5)}</p><form id="wpF"><input id="wpN" maxlength="40" value="${LX("Titik ","Mark ")+(wpts.length+1)}" aria-label="${LX("Nama titik","Mark name")}"><p class="note">${LX("Contoh: Rumpon 1, Karang dalam, Spot GT","e.g. FAD 1, Deep reef, GT spot")}</p><button class="btn" type="submit" style="width:100%">${LX("Simpan titik","Save mark")}</button></form>`);
  const f=$("#wpF");f.onsubmit=e=>{e.preventDefault();wpts.push({id:"w"+Date.now(),n:$("#wpN").value.trim().slice(0,40)||LX("Titik","Mark"),lat:+lat.toFixed(5),lon:+lon.toFixed(5),t:Date.now()});store.set("mm_wpts",wpts);closeSheet();render()}}
function gpsToolsHtml(){
  return `<div class="card"><h3>🧭 ${LX("Jejak & titik GPS","GPS tracks & marks")}</h3>
   <p class="note">${LX("Rekam rute perahu/trolling dan tandai titik rumpon, karang, atau spot rahasia. Tersimpan di HP saja.","Record your boat/trolling route and mark FADs, reefs or secret spots. Saved on this phone only.")}</p>
   <div class="two">${rec?`<button class="btn" id="recStop" style="background:var(--bad)">⏹ ${LX("Stop rekam","Stop recording")}</button>`:`<button class="btn" id="recStart">⏺ ${LX("Rekam jejak","Record track")}</button>`}<button class="btn ghost" id="wpHere">📌 ${LX("Tandai di sini","Mark here")}</button></div>
   ${rec?`<p class="note" id="recInfo">${LX("Merekam","Recording")}…</p>`:""}
   ${wpts.length?`<h3 style="margin-top:10px">${LX("Titik tersimpan","Saved marks")}</h3>${wpts.slice().reverse().map(w=>`<div class="log"><span class="grow"><b>📌 ${esc(w.n)}</b><br><span class="note">${w.lat}, ${w.lon}${here?" · "+km(here.lat,here.lon,w.lat,w.lon)+" km":""}</span>
     <span class="acts"><a class="x" href="https://www.google.com/maps/dir/?api=1&destination=${w.lat},${w.lon}" target="_blank" rel="noopener">${LX("Navigasi","Navigate")}</a><button class="x" data-wpshare="${w.id}">🌐 ${LX("Bagikan","Share")}</button><button class="x" data-wpgo="${w.id}">${LX("Lihat di peta","Show on map")}</button><button class="x" data-wpdel="${w.id}">${LX("Hapus","Delete")}</button></span></span></div>`).join("")}`:""}
   ${tracks.length?`<h3 style="margin-top:10px">${LX("Jejak tersimpan","Saved tracks")}</h3>${tracks.map(t=>`<div class="log"><span class="grow"><b>〰️ ${esc(t.name)}</b><br><span class="note">${t.km} km · ${Math.round((t.t1-t.t0)/6e4)} ${LX("menit","min")}</span>
     <span class="acts"><button class="x" data-trgo="${t.id}">${LX("Lihat di peta","Show on map")}</button><button class="x" data-trdel="${t.id}">${LX("Hapus","Delete")}</button></span></span></div>`).join("")}`:""}</div>`;
}
let showTrack=null;
function drawGps(){
  if(!lmap||!window.L)return;
  wpts.forEach(w=>L.marker([w.lat,w.lon],{icon:L.divIcon({className:"wppin",html:"📌",iconSize:[22,22]})}).addTo(lmap).bindTooltip(w.n,{direction:"top"}));
  if(rec){rec.line=L.polyline(rec.pts,{color:"#e74c3c",weight:4}).addTo(lmap)}
  const t=showTrack&&tracks.find(x=>x.id===showTrack);if(t){const pl=L.polyline(t.pts,{color:"#8e44ad",weight:4}).addTo(lmap);lmap.fitBounds(pl.getBounds(),{padding:[20,20]})}
}
function bindGps(){
  const a=$("#recStart");if(a)a.onclick=startTrack;const b=$("#recStop");if(b)b.onclick=stopTrack;
  const w=$("#wpHere");if(w)w.onclick=()=>{if(!navigator.geolocation)return;w.disabled=true;navigator.geolocation.getCurrentPosition(p=>addWaypoint(p.coords.latitude,p.coords.longitude),()=>{w.disabled=false;alertBox(LX("Lokasi tidak bisa diambil. Izinkan akses lokasi.","Couldn't get location. Allow location access."))},{enableHighAccuracy:true,timeout:15000})};
  document.querySelectorAll("[data-wpdel]").forEach(x=>x.onclick=()=>{wpts=wpts.filter(w=>w.id!==x.dataset.wpdel);store.set("mm_wpts",wpts);render()});
  document.querySelectorAll("[data-trdel]").forEach(x=>x.onclick=()=>{tracks=tracks.filter(t=>t.id!==x.dataset.trdel);store.set("mm_tracks",tracks);if(showTrack===x.dataset.trdel)showTrack=null;render()});
  document.querySelectorAll("[data-trgo]").forEach(x=>x.onclick=()=>{showTrack=x.dataset.trgo;render();$("#main").scrollTop=0});
  document.querySelectorAll("[data-wpshare]").forEach(x=>x.onclick=()=>{const p=wpts.find(w=>w.id===x.dataset.wpshare);if(p)sharePointForm(p.lat,p.lon,p.n)});
  document.querySelectorAll("[data-wpgo]").forEach(x=>x.onclick=()=>{const p=wpts.find(w=>w.id===x.dataset.wpgo);if(p&&lmap){$("#main").scrollTop=0;lmap.setView([p.lat,p.lon],15)}});
  updRec();
}
const alertBox=t=>openSheet(`<p>${esc(t)}</p>`);

// ---------- Kondisi otomatis saat mencatat tangkapan ----------
async function captureConditions(lat,lon,t=Date.now()){
  const c={moon:null,illum:null,sol:solunarNow(t,lat,lon)};
  const age=moonAge(t),pi=Math.floor(age/SYN*8+.5)%8;c.moon=pi;c.illum=Math.round((1-Math.cos(2*Math.PI*age/SYN))/2*100);
  const v1=tideMs(t),v2=tideMs(t+18e5);c.tide=v2>v1?"up":"down";c.tideSrc="est";
  try{const ac=new AbortController();setTimeout(()=>ac.abort(),8000);
    const q=`latitude=${lat}&longitude=${lon}&timezone=auto`;
    const [w,m]=await Promise.all([fetch(`https://api.open-meteo.com/v1/forecast?${q}&current=temperature_2m,wind_speed_10m,wind_direction_10m,weather_code,pressure_msl,cloud_cover&wind_speed_unit=kmh`,{signal:ac.signal}).then(r=>r.json()),
      fetch(`https://marine-api.open-meteo.com/v1/marine?${q}&current=wave_height,sea_surface_temperature&hourly=sea_level_height_msl&forecast_days=1&past_days=0`,{signal:ac.signal}).then(r=>r.json()).catch(()=>null)]);
    const cu=w.current||{};Object.assign(c,{temp:cu.temperature_2m,wind:cu.wind_speed_10m,wdir:cu.wind_direction_10m,code:cu.weather_code,press:cu.pressure_msl,cloud:cu.cloud_cover});
    if(m?.current){c.wave=m.current.wave_height;c.sst=m.current.sea_surface_temperature}
    const sl=m?.hourly?.sea_level_height_msl,tm=m?.hourly?.time;if(sl&&tm){const h=new Date(t).getHours();if(sl[h]!=null&&sl[h+1]!=null){c.tide=sl[h+1]>sl[h]?"up":"down";c.tideSrc="live"}}
  }catch(e){}
  return c;
}
const tideTxt=t=>t==="up"?LX("pasang naik","rising tide"):t==="down"?LX("pasang turun","falling tide"):"";
function condLine(c){if(!c)return "";const p=[];
  if(c.temp!=null)p.push(WCODE(c.code)+" "+Math.round(c.temp)+"°");
  if(c.wind!=null)p.push("💨 "+Math.round(c.wind)+" "+LX("km/j","km/h")+(c.wdir!=null?" "+dirTxt(c.wdir):""));
  if(c.wave!=null)p.push("🌊 "+c.wave.toFixed(1)+" m");
  if(c.sst!=null)p.push("💧 "+Math.round(c.sst)+"°");
  if(c.tide)p.push((c.tide==="up"?"▲ ":"▼ ")+tideTxt(c.tide));
  if(c.moon!=null)p.push("🌙 "+LX(PHASE[c.moon],PHASE_EN[c.moon]));
  if(c.sol)p.push("⭐ Solunar "+(c.sol==="major"?"Major":"Minor"));
  return `<span class="note cond">${p.join(" · ")}</span>`;
}

// ---------- Statistik pribadi ----------
function myCatches(){
  const a=logbook.filter(e=>(e.region||region)===region).map(e=>({fish:e.fish,len:e.len,bait:e.bait,spot:e.spot,t:e.t,cond:e.cond}));
  const b=(feed||[]).filter(x=>me&&x.user_id===me.id&&inRegion(x)&&!logbook.some(e=>e.posted&&Math.abs(e.t-Date.parse(x.created_at))<36e5*6&&e.fish===x.fish)).map(x=>({fish:x.fish,len:x.length_cm,bait:x.bait,spot:x.spot_name||x.area,t:Date.parse(x.created_at),cond:null}));
  return a.concat(b);
}
function statsHtml(){
  const xs=myCatches();if(!xs.length)return "";
  const cnt=(arr)=>{const m={};arr.forEach(k=>{if(k)m[k]=(m[k]||0)+1});return Object.entries(m).sort((a,b)=>b[1]-a[1])};
  const bar=(rows,max)=>rows.slice(0,6).map(([k,v])=>`<div class="sbar"><span>${esc(k)}</span><i style="width:${Math.max(6,v/max*100)}%"></i><b>${v}</b></div>`).join("");
  const fish=cnt(xs.map(x=>x.fish)),bait=cnt(xs.map(x=>x.bait)),spot=cnt(xs.map(x=>x.spot));
  const hrs=cnt(xs.map(x=>{const h=new Date(x.t).getHours();return h<5?LX("Malam (00–05)","Night (00–05)"):h<8?LX("Subuh (05–08)","Dawn (05–08)"):h<11?LX("Pagi (08–11)","Morning (08–11)"):h<15?LX("Siang (11–15)","Midday (11–15)"):h<18?LX("Sore (15–18)","Afternoon (15–18)"):h<20?LX("Senja (18–20)","Dusk (18–20)"):LX("Malam (20–24)","Night (20–24)")}));
  const tide=cnt(xs.map(x=>x.cond?.tide&&tideTxt(x.cond.tide))),moon=cnt(xs.map(x=>x.cond?.moon!=null&&LX(PHASE[x.cond.moon],PHASE_EN[x.cond.moon]))),sol=cnt(xs.map(x=>x.cond&&(x.cond.sol?"Solunar "+(x.cond.sol==="major"?"Major":"Minor"):LX("Di luar jam Solunar","Outside solunar"))));
  const months={};xs.forEach(x=>{const d=new Date(x.t),k=d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0");months[k]=(months[k]||0)+1});
  const mk=Object.keys(months).sort().slice(-12),mmax=Math.max(...mk.map(k=>months[k]),1);
  const big=xs.filter(x=>x.len).sort((a,b)=>b.len-a.len)[0];
  const sec=(t,rows)=>rows.length?`<h4>${t}</h4>${bar(rows,rows[0][1])}`:"";
  return `<div class="card stats"><h3>📊 ${LX("Statistik pribadi","My stats")}</h3>
   <div class="row"><div class="kv"><span class="tag">${LX("Total tangkapan","Total catches")}</span><strong>${xs.length}</strong></div><div class="kv"><span class="tag">${LX("Jenis ikan","Species")}</span><strong>${fish.length}</strong></div><div class="kv"><span class="tag">${LX("Terbesar","Biggest")}</span><strong style="font-size:.95rem">${big?esc(big.fish)+" "+big.len+" cm":"–"}</strong></div></div>
   ${mk.length>1?`<h4>${LX("Per bulan","Per month")}</h4><div class="mchart">${mk.map(k=>`<div><i style="height:${months[k]/mmax*100}%"></i><span>${(region==="AU"?MON_EN:MON_ID)[+k.slice(5)-1]}</span></div>`).join("")}</div>`:""}
   ${sec(LX("Ikan paling sering","Most caught"),fish)}${sec(LX("Umpan paling sukses","Best baits"),bait)}${sec(LX("Jam paling sukses","Best times of day"),hrs)}${sec(LX("Kondisi pasang","Tide"),tide)}${sec(LX("Fase bulan","Moon phase"),moon)}${sec("Solunar",sol)}${sec(LX("Spot paling sukses","Best spots"),spot)}
   <p class="note">${LX("Dari logbook pribadi dan postinganmu di komunitas. Kondisi (pasang, bulan, solunar) hanya dari catatan yang punya data kondisi.","From your personal logbook and your community posts. Conditions (tide, moon, solunar) only come from entries that recorded them.")}</p></div>`;
}

/* ================= v5: KESELAMATAN & FITUR INDONESIA ================= */
// ---------- A. Peringatan cuaca maritim (kategori gelombang BMKG, dari prakiraan Open-Meteo) ----------
const WAVECAT=[[.5,"Tenang","Calm"],[1.25,"Rendah","Slight"],[2.5,"Sedang","Moderate"],[4,"Tinggi","Rough"],[6,"Sangat tinggi","Very rough"],[99,"Ekstrem","Extreme"]];
const waveCat=h=>{const c=WAVECAT.find(c=>h<c[0])||WAVECAT[5];return LX(c[1],c[2])};
function marineWarnHtml(s){
  const W=wx[wxKey(s)];if(!W||!W.w)return "";
  const now=Date.now(),t=W.w.hourly.time.map(x=>Date.parse(x+":00Z")-(W.w.utc_offset_seconds||0)*1e3);
  const idx=t.map((x,i)=>x>=now-36e5&&x<=now+24*36e5?i:-1).filter(i=>i>=0);
  const wave=W.m?.hourly?.wave_height?Math.max(0,...idx.map(i=>W.m.hourly.wave_height[i]||0)):null;
  const wind=Math.max(0,...idx.map(i=>W.w.hourly.wind_speed_10m[i]||0));
  const lvl=(wave!=null&&wave>=4)||wind>=50?2:(wave!=null&&wave>=2.5)||wind>=30?1:0;
  const off=region==="AU"?`<a href="https://www.bom.gov.au/marine/" target="_blank" rel="noopener">BOM Marine</a>`:`<a href="https://maritim.bmkg.go.id/" target="_blank" rel="noopener">BMKG Maritim</a>`;
  if(!lvl)return `<div class="card mwarn ok"><b>✅ ${LX("Laut 24 jam ke depan","Sea next 24 h")}:</b> ${wave!=null?LX("ombak ","waves ")+wave.toFixed(1)+" m ("+waveCat(wave)+") · ":""}${LX("angin maks ","max wind ")}${Math.round(wind)} ${LX("km/j","km/h")}. <span class="note">${LX("Tetap cek","Always check")} ${off}.</span></div>`;
  return `<div class="card mwarn ${lvl===2?"bad":"mid"}"><b>${lvl===2?"⛔":"⚠️"} ${lvl===2?LX("BAHAYA – jangan melaut","DANGER – stay ashore"):LX("Waspada gelombang/angin","Caution: waves/wind")}</b><br>
   ${wave!=null?LX("Ombak hingga ","Waves up to ")+wave.toFixed(1)+" m ("+waveCat(wave)+") · ":""}${LX("angin hingga ","wind up to ")}${Math.round(wind)} ${LX("km/j","km/h")} ${LX("dalam 24 jam","in the next 24 h")}.
   <span class="note">${lvl===2?LX("Berbahaya untuk semua perahu kecil dan mancing batu.","Dangerous for all small boats and rock fishing."):LX("Hindari perahu kecil & mancing di batu terbuka.","Avoid small boats & exposed rock fishing.")} ${LX("Peringatan resmi:","Official warnings:")} ${off}</span></div>`;
}
function fillMarineWarn(){const c=cur(),el=$("#mwarn");if(!el)return;const go=()=>{const e=$("#mwarn");if(e){e.innerHTML=marineWarnHtml(c);tr(e)}};if(wx[wxKey(c)]?.w)go();else loadWx(c).then(go)}

// ---------- B. SOS & bagikan lokasi ----------
const sosNums=()=>region==="AU"?[["000",LX("Polisi/ambulans/SAR","Police/ambulance/rescue")],["112",LX("Darurat (HP)","Emergency (mobile)")]]:[["115","Basarnas (SAR)"],["112",LX("Darurat umum","General emergency")],["110",LX("Polisi","Police")]];
function sosHtml(){const ec=store.get("mm_ec","");
  return `<div class="card sos"><h3>🆘 ${LX("Darurat & bagikan lokasi","Emergency & share location")}</h3>
   <button class="btn" id="sosBtn" style="width:100%;background:var(--bad)">🆘 ${LX("KIRIM LOKASI DARURAT","SEND EMERGENCY LOCATION")}</button>
   <p class="note">${LX("Mengambil GPS lalu membuka WhatsApp berisi pesan darurat + link peta lokasimu.","Gets your GPS and opens WhatsApp with an emergency message + map link.")}</p>
   <div class="two"><button class="btn ghost" id="tripBtn">📤 ${LX("Bagikan lokasi trip","Share trip location")}</button>${sosNums().map(n=>`<a class="btn ghost" href="tel:${n[0]}">📞 ${n[0]} <small>${n[1]}</small></a>`).join("")}</div>
   <label class="note" style="display:block;margin-top:8px">${LX("Nomor WhatsApp keluarga/teman (opsional, mis. 62812…)","Family/friend WhatsApp number (optional, e.g. 61412…)")}<input id="ecNum" inputmode="tel" value="${esc(ec)}" placeholder="62812xxxxxxx"></label><p class="note" id="sosMsg"></p></div>`}
function bindSos(){
  const n=$("#ecNum");if(n)n.onchange=()=>store.set("mm_ec",n.value.replace(/[^\d]/g,""));
  const send=(emerg)=>{const m=$("#sosMsg");if(m)m.textContent=LX("Mengambil lokasi GPS…","Getting GPS location…");
    const go=(lat,lon,acc)=>{const link=`https://maps.google.com/?q=${lat.toFixed(5)},${lon.toFixed(5)}`,time=new Date().toLocaleString(LOC_());
      const txt=emerg?LX(`🆘 DARURAT! Saya butuh bantuan.\nLokasi: ${link}\nAkurasi ±${acc} m · ${time}\n(dikirim dari Mancing Mania)`,`🆘 EMERGENCY! I need help.\nLocation: ${link}\nAccuracy ±${acc} m · ${time}\n(sent from Mancing Mania)`)
        :LX(`🎣 Saya sedang mancing di sini: ${link}\n${time}. Kalau belum ada kabar sampai malam, tolong hubungi saya.`,`🎣 I'm fishing here: ${link}\n${time}. If you haven't heard from me by tonight, please check on me.`);
      let num=String(store.get("mm_ec","")).replace(/\D/g,"");if(num.startsWith("0"))num=(region==="AU"?"61":"62")+num.slice(1);if(num.length<9||num.length>15)num="";if(navigator.share&&!num){navigator.share({text:txt}).catch(e=>{if(e&&e.name!=="AbortError")location.href="https://api.whatsapp.com/send?text="+encodeURIComponent(txt)});if(m)m.textContent=LX("Pilih WhatsApp di menu bagikan.","Choose WhatsApp in the share menu.");return}
      const q=(num?`phone=${num}&`:"")+"text="+encodeURIComponent(txt);try{navigator.clipboard&&navigator.clipboard.writeText(txt).catch(()=>{})}catch(e){}
      if(m)m.innerHTML=`${LX("Pesan juga disalin — kalau WhatsApp kosong, tekan lama lalu Tempel.","Message also copied — if WhatsApp is empty, long-press and Paste.")}<br><a href="https://api.whatsapp.com/send?${q}" target="_blank" rel="noopener">${LX("Buka WhatsApp lagi","Open WhatsApp again")}</a><textarea readonly style="width:100%;margin-top:6px" rows="4">${esc(txt)}</textarea>`;
      location.href="https://api.whatsapp.com/send?"+q};
    if(!navigator.geolocation){if(here)go(here.lat,here.lon,here.acc||"?");return}
    navigator.geolocation.getCurrentPosition(p=>go(p.coords.latitude,p.coords.longitude,Math.round(p.coords.accuracy)),()=>{if(here)go(here.lat,here.lon,here.acc||"?");else if(m)m.textContent=LX("GPS tidak bisa diambil. Nyalakan lokasi lalu coba lagi, atau telepon nomor darurat.","Couldn't get GPS. Turn on location and try again, or call the emergency number.")},{enableHighAccuracy:true,timeout:15000,maximumAge:60000})};
  const s=$("#sosBtn");if(s)s.onclick=()=>send(true);const t=$("#tripBtn");if(t)t.onclick=()=>send(false);
}

// ---------- C. Titik komunitas (rumpon, karang, spot, bahaya) ----------
let points=store.get("mm_points",[]);
const PKIND={rumpon:["⚓","Rumpon","FAD"],karang:["🪸","Karang","Reef"],spot:["🎣","Spot mancing","Fishing spot"],bahaya:["⚠️","Bahaya (karang dangkal, arus)","Hazard (shallow reef, current)"]};
async function loadPoints(){if(!sb)return;const{data}=await sb.from("points").select("id,user_id,name,kind,note,lat,lon,depth_m,public,created_at,profiles(name)").limit(2000);if(data){points=data;store.set("mm_points",points);if(view==="peta"&&lmap)points.forEach(addPointMarker)}}
function addPointMarker(p){if(!lmap||!window.L||regionOf(p.lat,p.lon)!==region)return;
  const k=PKIND[p.kind]||PKIND.spot,mine=me&&p.user_id===me.id;
  L.marker([p.lat,p.lon],{icon:L.divIcon({className:"ptpin",html:k[0],iconSize:[24,24]})}).addTo(lmap)
   .bindPopup(`<b>${k[0]} ${esc(p.name)}</b><br>${LX(k[1],k[2])}${p.depth_m?` · ${p.depth_m} m`:""}${p.public?"":" · 🔒 "+LX("pribadi","private")}<br>${p.note?esc(p.note)+"<br>":""}<span style="color:#888">${esc(mine?LX("Kamu","You"):(p.profiles?.name||LX("Pemancing","Angler")))}</span><br><a href="https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lon}" target="_blank" rel="noopener">${LX("Navigasi","Navigate")}</a>${mine||isAdmin?` · <a href="#" data-ptdel="${p.id}">${LX("Hapus","Delete")}</a>`:""}`)
   .on("popupopen",e=>{const el=e.popup.getElement();tr(el);const d=el.querySelector("[data-ptdel]");if(d)d.onclick=async ev=>{ev.preventDefault();await sb.from("points").delete().eq("id",p.id);points=points.filter(x=>x.id!==p.id);store.set("mm_points",points);render()}})}
function sharePointForm(lat,lon,name){
  if(!sb||!me||!myName){openSheet(`<h3>${LX("Masuk dulu","Sign in first")}</h3><p class="note">${LX("Masuk lewat tab Tangkapan untuk membagikan titik.","Sign in on the Catches tab to share marks.")}</p>`);return}
  openSheet(`<h3>🌐 ${LX("Bagikan titik ke komunitas","Share a mark with the community")}</h3><p class="note">${lat.toFixed(5)}, ${lon.toFixed(5)}</p>
   <form id="ptF"><input id="ptN" maxlength="50" value="${esc(name||"")}" placeholder="${LX("Nama, mis. Rumpon Tanjung Ringgit","Name, e.g. North Head FAD")}" required>
   <select class="f" id="ptK" style="margin-top:6px">${Object.entries(PKIND).map(([k,v])=>`<option value="${k}">${v[0]} ${LX(v[1],v[2])}</option>`).join("")}</select>
   <div class="two" style="margin-top:6px"><input id="ptD" type="number" min="0" max="2000" placeholder="${LX("Kedalaman (m)","Depth (m)")}"><label class="note" style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="ptP" style="width:auto" checked> ${LX("Publik","Public")}</label></div>
   <textarea id="ptNote" rows="2" maxlength="200" placeholder="${LX("Catatan (ikan, umpan, waktu terbaik)","Notes (fish, bait, best time)")}" style="margin-top:6px"></textarea>
   <p class="note">${LX("Publik = terlihat semua orang. Tidak dicentang = hanya kamu (tersimpan di akunmu).","Public = everyone can see it. Unticked = only you (saved to your account).")}</p>
   <button class="btn" type="submit" style="width:100%">${LX("Simpan titik","Save mark")}</button><p class="note" id="ptMsg"></p></form>`);
  $("#ptF").onsubmit=async e=>{e.preventDefault();const row={name:$("#ptN").value.trim(),kind:$("#ptK").value,depth_m:+$("#ptD").value||null,public:$("#ptP").checked,note:$("#ptNote").value.trim()||null,lat:+lat.toFixed(5),lon:+lon.toFixed(5)};
    const{data,error}=await sb.from("points").insert(row).select("id,user_id,name,kind,note,lat,lon,depth_m,public,created_at").single();
    if(error){$("#ptMsg").textContent=LX("Gagal: ","Failed: ")+error.message;return}points.push({...data,profiles:{name:myName}});store.set("mm_points",points);closeSheet();render()};
}

// ---------- D & E. Toko pancing/umpan & sewa perahu/pemandu ----------
let shopsOsm=store.get("mm_shops",[]),listings=store.get("mm_list",[]),shopLast="";
async function loadListings(){if(!sb)return;const{data}=await sb.from("listings").select("*").eq("status","setuju").limit(1000);if(data){listings=data;store.set("mm_list",listings);if(view==="lainnya"&&more==="toko")render()}}
async function loadShops(lat,lon){const key=lat.toFixed(1)+","+lon.toFixed(1);if(shopLast===key)return;shopLast=key;
  const q=`[out:json][timeout:20];(nwr(around:40000,${lat},${lon})["shop"="fishing"];nwr(around:40000,${lat},${lon})["shop"="outdoor"]["fishing"];nwr(around:40000,${lat},${lon})["shop"~"^(bait|fishing_tackle)$"];);out center 60;`;
  for(const ep of ["https://overpass-api.de/api/interpreter","https://overpass.private.coffee/api/interpreter","https://overpass.kumi.systems/api/interpreter"]){
    try{const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),20000);const r=await fetch(ep+"?data="+encodeURIComponent(q),{signal:ac.signal});clearTimeout(tm);
      if(r.ok){const j=await r.json();const got=(j.elements||[]).map(e=>({id:"o"+e.id,lat:e.lat??e.center?.lat,lon:e.lon??e.center?.lon,name:e.tags?.name||LX("Toko pancing","Tackle shop"),phone:e.tags?.phone||e.tags?.["contact:phone"]||e.tags?.["contact:whatsapp"]||"",hours:e.tags?.opening_hours||""})).filter(x=>x.lat!=null);
        const ids=new Set(shopsOsm.map(s=>s.id));got.forEach(s=>{if(!ids.has(s.id))shopsOsm.push(s)});store.set("mm_shops",shopsOsm.slice(-500));if(view==="lainnya"&&more==="toko")render();return}}catch(e){}
  }shopLast="";
}
const waLink=p=>{let d=(p||"").replace(/[^\d+]/g,"");if(!d)return "";if(d.startsWith("+"))d=d.slice(1);else if(d.startsWith("0"))d=(region==="AU"?"61":"62")+d.slice(1);return "https://wa.me/"+d};
function shopsHtml(){
  const ref=here||cur(),dist=x=>x.lat!=null?km(ref.lat,ref.lon,x.lat,x.lon):9999;
  const shops=shopsOsm.map(s=>({...s,src:"osm"})).concat(listings.filter(l=>l.kind==="toko").map(l=>({...l,src:"app"}))).filter(s=>s.lat==null?s.region===region:regionOf(s.lat,s.lon)===region).map(s=>({...s,d:dist(s)})).sort((a,b)=>a.d-b.d).slice(0,25);
  const boats=listings.filter(l=>l.kind==="sewa"&&(l.region||region)===region).map(s=>({...s,d:dist(s)})).sort((a,b)=>a.d-b.d);
  const row=s=>`<div class="log"><span class="grow"><b>${esc(s.name)}</b>${s.src==="app"?` <span class="badge">${LX("dari komunitas","from community")}</span>`:""}<br><span class="note">${s.area?esc(s.area)+" · ":""}${s.d<9999?s.d+" km":""}${s.hours?" · "+esc(s.hours):""}</span>${s.note?`<br><span class="note">${esc(s.note)}</span>`:""}
    <span class="acts">${s.lat!=null?`<a class="x" href="https://www.google.com/maps/dir/?api=1&destination=${s.lat},${s.lon}" target="_blank" rel="noopener">${LX("Navigasi","Navigate")}</a>`:""}${waLink(s.phone)?`<a class="x" href="${waLink(s.phone)}" target="_blank" rel="noopener">WhatsApp</a><a class="x" href="tel:${esc(s.phone)}">${LX("Telepon","Call")}</a>`:""}</span></span></div>`;
  return `<h2>${LX("Toko & sewa perahu","Shops & boat hire")}</h2>
   <div class="card"><h3>🏪 ${LX("Toko pancing & umpan terdekat","Nearest tackle & bait shops")}</h3><p class="note">${LX("Dari OpenStreetMap dan usulan pemancing. Jarak dihitung dari","From OpenStreetMap and angler suggestions. Distance from")} ${esc(here?LX("lokasimu","your location"):cur().n)}.</p>
    ${shops.length?shops.map(row).join(""):`<p class="note">${LX("Belum ada data toko di sekitar sini. Bantu tambahkan di bawah!","No shops listed nearby yet. Help add one below!")}</p>`}</div>
   <div class="card"><h3>🚤 ${LX("Sewa perahu & pemandu (tekong)","Boat hire & fishing guides")}</h3>
    ${boats.length?boats.map(row).join(""):`<p class="note">${LX("Belum ada. Kenal tekong atau charter yang bagus? Usulkan di bawah.","None yet. Know a good guide or charter? Suggest one below.")}</p>`}
    <p class="note">${LX("Daftar ini diisi pengguna dan diperiksa admin. Selalu sepakati harga & keselamatan (pelampung, radio) sebelum berangkat.","Listings come from users and are checked by the admin. Always agree on price & safety gear (life jackets, radio) before you go.")}</p></div>
   <div class="card"><h3>➕ ${LX("Usulkan toko / sewa perahu","Suggest a shop / boat hire")}</h3>${me&&myName?`<form id="lsF">
    <select class="f" id="lsK"><option value="toko">🏪 ${LX("Toko pancing / umpan","Tackle / bait shop")}</option><option value="sewa">🚤 ${LX("Sewa perahu / pemandu","Boat hire / guide")}</option></select>
    <input id="lsN" maxlength="60" required placeholder="${LX("Nama","Name")}" style="margin-top:6px"><input id="lsA" maxlength="80" placeholder="${LX("Daerah, mis. Tanjung Luar, Lombok Timur","Area, e.g. Botany Bay, Sydney")}" style="margin-top:6px">
    <input id="lsP" maxlength="25" inputmode="tel" placeholder="${LX("No. WhatsApp / telepon","WhatsApp / phone")}" style="margin-top:6px"><textarea id="lsNote" rows="2" maxlength="300" placeholder="${LX("Keterangan (harga, jenis perahu, jam buka)","Details (price, boat type, opening hours)")}" style="margin-top:6px"></textarea>
    <label class="note" style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="lsG" style="width:auto" checked> ${LX("Pakai lokasiku sekarang sebagai lokasinya","Use my current location for it")}</label>
    <button class="btn" type="submit" style="width:100%;margin-top:6px">${LX("Kirim usulan","Send suggestion")}</button><p class="note" id="lsMsg"></p></form>`:`<p class="note">${LX("Masuk lewat tab Tangkapan untuk mengusulkan.","Sign in on the Catches tab to suggest one.")}</p>`}</div>`;
}
function bindShops(){const ref=here||cur();loadShops(ref.lat,ref.lon);loadListings();
  const f=$("#lsF");if(f)f.onsubmit=async e=>{e.preventDefault();const g=$("#lsG").checked&&here;const row={kind:$("#lsK").value,name:$("#lsN").value.trim(),area:$("#lsA").value.trim()||null,phone:$("#lsP").value.trim()||null,note:$("#lsNote").value.trim()||null,region,lat:g?+here.lat.toFixed(5):null,lon:g?+here.lon.toFixed(5):null};
    const{error}=await sb.from("listings").insert(row);$("#lsMsg").textContent=error?LX("Gagal: ","Failed: ")+error.message:LX("✅ Terkirim! Akan tampil setelah disetujui admin.","✅ Sent! It will appear once the admin approves it.");if(!error)f.reset();tr($("#lsMsg"))}}
async function adminListingsHtml(){const{data,error}=await sb.from("listings").select("*").eq("status","baru").order("created_at",{ascending:false}).limit(100);if(error)return `<p class="note">${esc(error.message)}</p>`;
  return (data||[]).length?data.map(l=>`<div class="log"><span class="grow"><span class="badge">${l.kind==="toko"?"🏪 Toko":"🚤 Sewa"}</span> <b>${esc(l.name)}</b><br><span class="note">${esc(l.area||"")} · ${esc(l.phone||"")} · ${l.region}</span>${l.note?`<br><span class="note">${esc(l.note)}</span>`:""}<span class="acts"><button class="x" data-lok="${l.id}">✅ Setujui</button><button class="x" data-lno="${l.id}">Tolak</button></span></span></div>`).join(""):`<p class="note">Tidak ada usulan baru. 👍</p>`}
async function renderAdminListings(){const b=$("#adminList");if(!b)return;b.innerHTML=await adminListingsHtml();tr(b);
  b.querySelectorAll("[data-lok],[data-lno]").forEach(x=>x.onclick=async()=>{x.disabled=true;await sb.from("listings").update({status:x.dataset.lok?"setuju":"tolak"}).eq("id",x.dataset.lok||x.dataset.lno);renderAdminListings();loadListings()})}

// ---------- F. Musim angin Indonesia ----------
function monsoonHtml(){if(region!=="ID")return "";const m=new Date().getMonth()+1;
  const M=m===12||m<=3?["🌧️ Musim barat (Des–Mar)","Musim hujan. Angin barat–barat laut kencang dan sering badai petir. Laut Jawa, Selat Karimata dan perairan yang menghadap barat/utara sering berombak. Pilih teluk atau sisi timur pulau yang terlindung, dan pulang sebelum sore bila awan gelap.","bad"]
   :m>=6&&m<=9?["☀️ Musim timur (Jun–Sep)","Musim kemarau. Angin timur–tenggara kencang. Pantai selatan Jawa, Bali, Lombok dan NTT sering diterjang swell besar dari Samudra Hindia. Sisi utara dan barat pulau lebih tenang. Musim ikan pelagis (tenggiri, tongkol, cakalang).","mid"]
   :["🍃 Musim peralihan ("+(m<=5?"Apr–Mei":"Okt–Nov")+")","Angin lemah dan berubah-ubah, laut sering tenang. Biasanya waktu terbaik untuk melaut, tapi waspada badai petir lokal di sore hari.","good"];
  return `<div class="card monsoon ${M[2]}"><h3>${M[0]}</h3><p>${M[1]}</p></div>`}

// ---------- G. Kawasan konservasi & ikan dilindungi (Indonesia) ----------
const MPA=[["Taman Nasional Komodo",-8.55,119.49,35],["TN Karimunjawa",-5.84,110.43,25],["TN Kepulauan Seribu",-5.6,106.55,22],["TWP Gili Matra (Gili Trawangan, Meno, Air)",-8.35,116.06,4],["TN Bunaken",1.62,124.76,12],["TN Wakatobi",-5.5,123.75,60],["TN Taka Bonerate",-6.83,121.1,35],["TN Teluk Cenderawasih",-2.6,134.6,80],["KKP Raja Ampat",-0.6,130.5,90],["KKP Nusa Penida",-8.73,115.54,12],["TN Bali Barat",-8.13,114.48,12],["KKP Gili Balu, Sumbawa Barat",-8.62,116.78,8],["TWP Gita Nada, Lombok Barat",-8.68,115.97,10]];
const PROTECTED=["Penyu (semua jenis)","Hiu paus","Pari manta","Dugong (duyung)","Kima (kerang raksasa)","Ikan napoleon (dilindungi terbatas, dilarang ditangkap kecil/dijual)","Hiu martil & hiu koboi (dilarang ekspor)","Banggai cardinalfish","Terumbu karang hidup (jangan diambil / dijangkar)"];
function drawMpa(){if(!lmap||!window.L||region!=="ID")return;MPA.forEach(([n,la,lo,r])=>L.circle([la,lo],{radius:r*1000,color:"#c4473a",weight:1.5,dashArray:"6 6",fillOpacity:.04}).addTo(lmap).bindTooltip("🛑 "+n+" (kawasan konservasi, batas perkiraan)",{sticky:true}))}
function mpaNear(lat,lon){return MPA.map(([n,la,lo,r])=>({n,d:km(lat,lon,la,lo),r})).filter(x=>x.d<=x.r+5).sort((a,b)=>a.d-b.d)[0]}
function conservationHtml(){return `<div class="card"><h3>🛑 Kawasan konservasi laut</h3><p class="note">Di dalam taman nasional/kawasan konservasi ada zona inti (dilarang mancing) dan zona pemanfaatan (boleh, kadang perlu tiket/izin). Garis merah putus-putus di peta = batas perkiraan. Selalu tanya pengelola atau pos jaga setempat.</p>
   <ul>${MPA.map(m=>`<li>${m[0]}</li>`).join("")}</ul></div>
   <div class="card"><h3>🐢 Ikan & biota dilindungi</h3><p class="note">Bila tertangkap, lepaskan segera dengan hati-hati.</p><ul>${PROTECTED.map(x=>`<li>${x}</li>`).join("")}</ul></div>`}

// ---------- H. Jadwal sholat di spot (metode Kemenag: Subuh 20°, Isya 18°, ihtiyat 2 menit) ----------
function prayerTimes(ds,lat,lon,tz){
  const d=new Date(ds+12*36e5),jd=d/864e5+2440587.5,n=jd-2451545,g=(357.529+.98560028*n)*RAD,q=280.459+.98564736*n,L=(q+1.915*Math.sin(g)+.02*Math.sin(2*g))*RAD,e=(23.439-.00000036*n)*RAD;
  const dec=Math.asin(Math.sin(e)*Math.sin(L)),ra=Math.atan2(Math.cos(e)*Math.sin(L),Math.cos(L))/RAD/15,eqt=q/15-((ra%24)+24)%24;const EqT=((eqt+12)%24+24)%24-12;
  const noon=12+tz-lon/15-EqT,phi=lat*RAD;
  const T=a=>Math.acos((-Math.sin(a*RAD)-Math.sin(phi)*Math.sin(dec))/(Math.cos(phi)*Math.cos(dec)))/RAD/15;
  const asrA=-Math.atan(1/(1+Math.tan(Math.abs(phi-dec))))/RAD;
  const ih=2/60;
  return [["Subuh",noon-T(20)+ih],["Terbit",noon-T(.833)],["Dzuhur",noon+ih],["Ashar",noon+T(asrA)+ih],["Maghrib",noon+T(.833)+ih],["Isya",noon+T(18)+ih]];
}
function prayerHtml(ds,lat,lon){if(region!=="ID")return "";const tz=tzLL(lat,lon),p=prayerTimes(ds,lat,lon,tz),zn=tz===7?"WIB":tz===8?"WITA":"WIT";
  return `<div class="card"><h3>🕌 Jadwal sholat di spot ini</h3><div class="row prayer">${p.map(([n,h])=>`<div class="kv"><span class="tag">${n}</span><strong>${fmt(h)}</strong></div>`).join("")}</div><p class="note">${zn} · dihitung dari koordinat spot (metode Kemenag), bisa berbeda 1–2 menit dari jadwal masjid setempat.</p></div>`}

// ---------- Daftar fitur aplikasi ----------
function featuresHtml(){
  const G=[
   ["🗺️",LX("Peta","Map"),[LX("Spot mancing Indonesia & Australia + spot dari OpenStreetMap (dermaga, pemecah ombak)","Fishing spots in Indonesia & Australia + OpenStreetMap spots (wharves, breakwalls)"),LX("Deteksi lokasi otomatis & spot terdekat","Automatic location & nearest spot"),LX("Lapisan peta: suhu laut, klorofil, radar hujan, angin","Map layers: sea temperature, chlorophyll, rain radar, wind"),LX("Peringatan gelombang & angin 24 jam","24-hour wave & wind warning"),LX("Spot favorit & waktu terbaik hari ini","Favourite spots & today's best times"),LX("Jejak GPS, titik rumpon/karang, dan titik komunitas","GPS tracks, FAD/reef marks and community marks"),LX("Tombol darurat SOS & bagikan lokasi trip","SOS emergency button & share trip location"),LX("Tangkapan komunitas 7 hari di peta","Community catches from the last 7 days on the map")]],
   ["🌊",LX("Pasang & cuaca","Tides & weather"),[LX("Prakiraan 7 hari: cuaca, angin, ombak, suhu air","7-day forecast: weather, wind, waves, water temperature"),LX("Grafik pasang surut","Tide chart"),LX("Skor aktivitas ikan & jam terbaik","Fish activity score & best hours"),LX("Jam makan Solunar (Major/Minor)","Solunar feeding times (Major/Minor)"),LX("Matahari & fase bulan","Sun & moon phase")].concat(region==="ID"?["Musim angin barat/timur/peralihan","Jadwal sholat di spot"]:[])],
   ["🐟",LX("Ikan & umpan","Fish & bait"),[LX("Foto ikan asli & ciri-ciri","Real fish photos & identification"),LX("Umpan yang cocok per spot","Suitable bait per spot"),LX("Peta lempar & cara mancing (darat/perahu)","Cast map & how to fish (shore/boat)"),LX("Peringkat spot terbaik per ikan","Best spots ranking per fish"),LX("Sedang musim di spot ini","What's in season at this spot")]],
   ["📷",LX("Tangkapan","Catches"),[LX("Upload foto tangkapan ke komunitas","Post catch photos to the community"),LX("Suka, komentar, profil pemancing","Likes, comments, angler profiles"),LX("Peringkat bulanan","Monthly leaderboard"),LX("Logbook pribadi (tanpa login & offline)","Personal logbook (no sign-in, works offline)"),LX("Cuaca, pasang, bulan & Solunar tercatat otomatis","Weather, tide, moon & solunar recorded automatically"),LX("Statistik pribadi","Personal stats"),LX("Bagikan tangkapan ke WhatsApp sebagai gambar","Share catches to WhatsApp as an image")]],
   ["🎬",LX("Tutorial","Tutorials"),[LX("Animasi cara memancing","Fishing animations"),LX("Rakitan & simpul","Rigs & knots"),LX("Tips & trik","Tips & tricks"),LX("Video YouTube di dalam aplikasi","YouTube videos inside the app")]],
   ["⋯",LX("Lainnya","More"),[LX("Kalender musim ikan","Fish season calendar"),LX("Toko pancing & umpan terdekat","Nearest tackle & bait shops"),LX("Sewa perahu & pemandu","Boat hire & guides"),LX("Aturan & nomor darurat","Rules & emergency numbers")].concat(region==="ID"?["Kawasan konservasi & ikan dilindungi"]:[LX("Aturan per negara bagian","Rules per state")]).concat([LX("Checklist sebelum berangkat","Pre-trip checklist"),LX("Saran & laporan ke pengelola","Feedback to the app owner"),LX("Tema terang/gelap, layar tetap menyala","Light/dark theme, keep screen on"),LX("Bahasa otomatis: Indonesia / English","Automatic language: Indonesian / English")])]];
  return `<h2>${LX("Fitur aplikasi","App features")}</h2><p class="note">${LX("Semua fitur gratis. Ketuk judul untuk membuka tab-nya.","All features are free. Tap a heading to open its tab.")}</p>`+
   G.map(([ic,t,xs],i)=>`<div class="card"><h3><button class="linkish" data-goto="${["peta","prakiraan","spot","tangkapan","belajar","lainnya"][i]}">${ic} ${t}</button></h3><ul>${xs.map(x=>`<li>${x}</li>`).join("")}</ul></div>`).join("");
}
function bindFeatures(){document.querySelectorAll("[data-goto]").forEach(b=>b.onclick=()=>{const v=b.dataset.goto;if(v==="lainnya")return;if(v==="belajar"){view="belajar";render();return}document.querySelector(`.tabbar button[data-v="${v}"]`)?.click()})}

/* ================= SHELL ================= */
function setSpot(id){if(!id)return;curId=id;mapRecenter=true;store.set("mm_cur",id);fishSel=null;castPick=null;fillPick();render()}
function fillPick(){const o=s=>`<option value="${s.id}" ${s.id===curId?"selected":""}>${esc(s.n)}</option>`,a=allSpots();$("#spotPick").innerHTML=region==="AU"?["Sydney","NSW","QLD","NT","WA","SA","VIC","TAS"].map(g=>{const xs=a.filter(x=>(x.st||(x.custom?"Spot pribadi":"Sydney"))===g).sort((p,q)=>p.n.localeCompare(q.n));return xs.length?`<optgroup label="${g==="Sydney"?"Sydney":g==="NSW"?"New South Wales":g==="QLD"?"Queensland":g==="NT"?"Northern Territory":g==="WA"?"Western Australia":g==="SA"?"South Australia":g==="VIC"?"Victoria":"Tasmania"}">${xs.map(o).join("")}</optgroup>`:""}).join("")+(a.some(x=>x.custom)?`<optgroup label="Spot pribadi">${a.filter(x=>x.custom).map(o).join("")}</optgroup>`:""):region==="ID"?(()=>{const ps=[...new Set(a.map(provOf).filter(Boolean))].sort((p,q)=>p.localeCompare(q,"id"));const rest=a.filter(x=>!provOf(x));return ps.map(g=>`<optgroup label="${g}">${a.filter(x=>provOf(x)===g).sort((p,q)=>p.n.localeCompare(q.n,"id")).map(o).join("")}</optgroup>`).join("")+(rest.length?`<optgroup label="Spot pribadi & komunitas">${rest.map(o).join("")}</optgroup>`:"")})():a.map(o).join("")}
$("#spotPick").onchange=e=>setSpot(e.target.value);
$("#region").value=region;$("#region").onchange=e=>setRegion(e.target.value);
function render(){killMap();castAnimStop();setLang();({peta:mapView,prakiraan:forecastView,spot:spotView,tangkapan:catchView,belajar:learnView,lainnya:moreView,komunitas:communityView})[view]();if(view==="prakiraan"||(view==="peta"&&remBanner)){$("#main").insertAdjacentHTML("afterbegin",remBannerHtml()+(view==="prakiraan"?calendarHtml():""));bindCalendar()}if(view==="belajar"){$("#main").insertAdjacentHTML("afterbegin",`<button class="linkish" id="backMore" style="margin-bottom:8px">← ${LX("Lainnya","More")}</button>`);$("#backMore").onclick=()=>{view="lainnya";render()}}tr(document.body);hydrateFish(document.body)}
document.querySelectorAll(".tabbar button").forEach(b=>b.onclick=()=>{view=b.dataset.v;document.querySelectorAll(".tabbar button").forEach(x=>x.setAttribute("aria-selected",x===b));$("#main").scrollTop=0;render()});
/* ================= v7: KOREKSI DATA SPOT, HARI BAGUS MANCING, KARTU PROMOSI ================= */
// --- 7. koreksi data spot oleh komunitas (masuk ke kotak masuk admin sebagai "Data spot/ikan salah") ---
let corrOpen=false,corrMsg="";
const CORR_F=[["ikan","Ikan yang ada","Fish list"],["umpan","Umpan","Bait"],["titik","Titik / koordinat di peta","Location on the map"],["waktu","Waktu terbaik","Best time"],["nama","Nama / daerah","Name / area"],["lain","Lainnya","Other"]];
function corrCardHtml(){
  const c=cur();if(!c||c.custom)return "";
  const head=`<div class="card"><h3>✏️ ${LX("Data spot ini salah atau kurang?","Is this spot's info wrong or missing?")}</h3>`;
  if(corrMsg&&!corrOpen)return head+`<p class="note" style="color:var(--good,#1a9e5a);font-weight:600">${esc(corrMsg)}</p></div>`;
  if(!corrOpen)return head+`<p class="note">${LX("Kamu pemancing lokal? Bantu perbaiki ikan, umpan, titik atau waktu terbaik di","Fish here often? Help fix the fish, bait, location or best times for")} <b>${esc(c.n)}</b>.</p><button class="btn ghost" id="corrBtn" style="width:100%">${LX("Usulkan koreksi","Suggest a correction")}</button></div>`;
  if(!(sb&&me))return head+`<p class="note">${LX("Masuk dulu di tab Tangkapan supaya usulanmu bisa dicek admin.","Sign in on the Catches tab first so an admin can review your suggestion.")}</p></div>`;
  return head+`<form id="corrF"><select class="f" id="corrK" aria-label="${LX("Bagian","Section")}">${CORR_F.map(f=>`<option value="${f[0]}">${LX(f[1],f[2])}</option>`).join("")}</select>
   <textarea id="corrT" rows="4" maxlength="800" placeholder="${LX("Contoh: di sini juga banyak kakap merah saat malam, umpan terbaik udang hidup","E.g. lots of snapper here at night too, best bait is live prawn")}" style="width:100%;margin-top:6px"></textarea>
   <p class="note" id="corrW" style="color:var(--bad)"></p>
   <div class="two"><button class="btn" type="submit" id="corrS">${LX("Kirim usulan","Send suggestion")}</button><button class="btn ghost" type="button" id="corrX">${LX("Batal","Cancel")}</button></div></form></div>`;
}
function bindCorr(){
  const b=$("#corrBtn");if(b)b.onclick=()=>{corrOpen=true;corrMsg="";render();setTimeout(()=>$("#corrT")?.focus(),50)};
  const x=$("#corrX");if(x)x.onclick=()=>{corrOpen=false;render()};
  const f=$("#corrF");if(!f)return;
  f.onsubmit=async e=>{e.preventDefault();const c=cur(),t=$("#corrT").value.trim(),k=$("#corrK").value,lab=CORR_F.find(z=>z[0]===k)[1];
    if(t.length<5){$("#corrW").textContent=LX("Tulis koreksinya dulu (minimal 5 huruf).","Please describe the correction (at least 5 characters).");return}
    const s=$("#corrS");s.disabled=true;
    try{const{error}=await sb.from("feedback").insert({kind:"data",message:`[Koreksi spot · ${lab}] ${t}`.slice(0,1000),spot_id:c.id,spot_name:c.n,photo_path:null,app_info:(navigator.userAgent||"").slice(0,200)});if(error)throw error;
      corrOpen=false;corrMsg=LX("✅ Terima kasih! Usulanmu terkirim ke admin dan akan dicek.","✅ Thanks! Your suggestion was sent to the admin for review.");render()}
    catch(err){s.disabled=false;$("#corrW").textContent=LX("Gagal mengirim: ","Couldn't send: ")+(err?.message||err)}};
}

// --- 4. hari bagus mancing (3 hari ke depan) + notifikasi ---
let goodCache=store.get("mm_good",null),goodBusy=false;
const LN=()=>window.Capacitor?.Plugins?.LocalNotifications||null;
function goodSpots(){const f=favs.map(id=>everySpot().find(s=>s.id===id)).filter(s=>s&&(s.region||regionOf(s.lat,s.lon))===region);return (f.length?f:[cur()]).filter(Boolean).slice(0,5)}
async function loadGoodDays(force){
  const fs=goodSpots();if(!fs.length||goodBusy||!navigator.onLine)return;const key=region+":"+fs.map(s=>s.id).join(",");
  if(!force&&goodCache&&goodCache.key===key&&Date.now()-goodCache.t<3*36e5)return;
  goodBusy=true;const la=fs.map(s=>(+s.lat).toFixed(3)).join(","),lo=fs.map(s=>(+s.lon).toFixed(3)).join(",");
  try{
    const[w,m]=await Promise.all([fetch(`https://api.open-meteo.com/v1/forecast?latitude=${la}&longitude=${lo}&daily=wind_speed_10m_max,precipitation_sum&wind_speed_unit=kmh&timezone=auto&forecast_days=4`).then(r=>r.ok?r.json():null),
      fetch(`https://marine-api.open-meteo.com/v1/marine?latitude=${la}&longitude=${lo}&daily=wave_height_max&timezone=auto&forecast_days=4`).then(r=>r.ok?r.json():null).catch(()=>null)]);
    if(!w)throw 0;const W=Array.isArray(w)?w:[w],M=m?(Array.isArray(m)?m:[m]):[],days=[];
    fs.forEach((s,i)=>{const d=W[i]?.daily;if(!d)return;for(let k=1;k<=3;k++){const b=bestWindow(s,k),wind=d.wind_speed_10m_max?.[k],rain=d.precipitation_sum?.[k],wave=M[i]?.daily?.wave_height_max?.[k];
      if(wind==null)continue;const ok=b.total>=45&&wind<25&&(wave==null||wave<1.5)&&(rain==null||rain<6);
      days.push({id:s.id,n:s.n,date:d.time[k],off:k,score:b.total,from:b.from,to:b.to,wind:Math.round(wind),wave:wave==null?null:Math.round(wave*10)/10,rain:rain==null?0:Math.round(rain),ok})}});
    goodCache={t:Date.now(),key,days};store.set("mm_good",goodCache);scheduleGood();if(view==="peta")render();
  }catch(e){}finally{goodBusy=false}
}
const dayLab=(d,off)=>off===1?LX("Besok","Tomorrow"):new Date(d+"T12:00").toLocaleDateString(LOC_(),{weekday:"long",day:"numeric",month:"short"});
function goodCardHtml(){
  const fs=goodSpots();if(!fs.length)return "";
  const all=(goodCache&&goodCache.key===region+":"+fs.map(s=>s.id).join(",")?goodCache.days:null),ok=(all||[]).filter(x=>x.ok).sort((a,b)=>a.off-b.off||b.score-a.score).slice(0,5);
  const ln=LN(),lnOn=store.get("mm_ln_on",false);
  return `<div class="card goodcard"><h3>🎣 ${LX("Hari bagus mancing","Good fishing days")}</h3><p class="note">${LX("3 hari ke depan di","Next 3 days at")} ${favs.length?LX("spot favoritmu","your favourite spots"):esc(fs[0].n)} · ${LX("skor ≥ 45, angin < 25 km/j, ombak < 1,5 m, tidak hujan lebat.","score ≥ 45, wind < 25 km/h, waves < 1.5 m, no heavy rain.")}</p>
   ${all===null?`<p class="note">${navigator.onLine?LX("Mengecek prakiraan…","Checking the forecast…"):LX("Butuh internet untuk mengecek prakiraan.","Needs internet to check the forecast.")}</p>`:ok.length?ok.map(x=>`<button class="favrow" data-id="${x.id}"><span><b>${esc(dayLab(x.date,x.off))} · ${esc(x.n)}</b><br><span class="note">${fmt(x.from)}–${fmt(x.to)} · 💨 ${x.wind} km/j${x.wave!=null?` · 🌊 ${x.wave} m`:""}${x.rain?` · 🌧️ ${x.rain} mm`:""}</span></span><span class="score" style="background:${scoreCol(x.score)}">${x.score}</span></button>`).join(""):`<p class="note">${LX("Belum ada hari yang ideal dalam 3 hari ke depan (angin, ombak atau skor kurang bagus). Dicek ulang otomatis.","No ideal day in the next 3 days (wind, waves or score not great). Re-checked automatically.")}</p>`}
   ${ln?(lnOn?`<p class="note">🔔 ${LX("Notifikasi aktif: kamu dikabari jam 18:00 sehari sebelum hari bagus.","Notifications on: you'll get a heads-up at 6 pm the day before a good day.")} <a href="#" id="lnOff">${LX("Matikan","Turn off")}</a></p>`:`<button class="btn ghost" id="lnOn" style="width:100%">🔔 ${LX("Kabari aku kalau ada hari bagus","Notify me about good days")}</button>`):""}
  </div>`;
}
function bindGood(){
  const on=$("#lnOn");if(on)on.onclick=async()=>{const p=LN();if(!p)return;try{let r=await p.checkPermissions();if(r.display!=="granted")r=await p.requestPermissions();if(r.display==="granted"){store.set("mm_ln_on",true);await scheduleGood();render()}else goodNote(LX("Izin notifikasi ditolak. Aktifkan di Pengaturan HP → Aplikasi → Mancing Mania.","Notification permission denied. Enable it in phone Settings → Apps → Mancing Mania."))}catch(e){}};
  const off=$("#lnOff");if(off)off.onclick=async e=>{e.preventDefault();store.set("mm_ln_on",false);try{await LN()?.cancel({notifications:Array.from({length:12},(_,i)=>({id:7000+i}))})}catch(e){}render()};
  loadGoodDays(false);
}
function goodNote(t){const n=document.querySelector(".goodcard .note,.today .note");if(n)n.textContent=t}
async function scheduleGood(){
  const p=LN();if(!p||!store.get("mm_ln_on",false)||!goodCache)return;
  try{await p.cancel({notifications:Array.from({length:12},(_,i)=>({id:7000+i}))});
    const ok=goodCache.days.filter(x=>x.ok),byDay={};ok.forEach(x=>{(byDay[x.date]=byDay[x.date]||[]).push(x)});
    const list=[];Object.entries(byDay).forEach(([d,xs],i)=>{const at=new Date(d+"T18:00");at.setDate(at.getDate()-1);if(at.getTime()<Date.now()+6e4)return;
      xs.sort((a,b)=>b.score-a.score);const t=xs[0];
      list.push({id:7000+i,title:LX(`🎣 Besok hari bagus mancing di ${t.n}`,`🎣 Tomorrow looks good at ${t.n}`),body:xs.slice(0,3).map(x=>`${x.n}: ${fmt(x.from)}–${fmt(x.to)} · 💨 ${x.wind} km/j${x.wave!=null?` · 🌊 ${x.wave} m`:""} · ${LX("skor","score")} ${x.score}`).join("\n"),schedule:{at,allowWhileIdle:true},extra:{spot:t.id}})});
    if(list.length)await p.schedule({notifications:list});
  }catch(e){}
}
try{LN()?.addListener?.("localNotificationActionPerformed",a=>{const id=a?.notification?.extra?.spot;if(id){view="peta";setSpot(id)}})}catch(e){}

// --- 1. kartu promosi spot (gambar siap bagikan ke WA / Instagram) ---
async function spotCardBlob(){
  const c=cur(),d=spotData(c),b=bestWindow(c),W=1080,H=1350,cv=document.createElement("canvas");cv.width=W;cv.height=H;const g=cv.getContext("2d");
  const grd=g.createLinearGradient(0,0,0,H);grd.addColorStop(0,"#0b2a4a");grd.addColorStop(1,"#06182b");g.fillStyle=grd;g.fillRect(0,0,W,H);
  g.fillStyle="rgba(63,208,181,.12)";for(let i=0;i<6;i++){g.beginPath();g.ellipse(W*(.2+i*.15),H-120+i*8,260,60,0,0,7);g.fill()}
  const img=await new Promise(r=>{const im=new Image();im.onload=()=>r(im);im.onerror=()=>r(null);im.src="icons/icon-192.png"});
  if(img)g.drawImage(img,70,70,120,120);
  g.fillStyle="#e8f1ff";g.font="800 54px 'Bricolage Grotesque',system-ui,sans-serif";g.fillText("MANCING MANIA",215,150);
  const wrap=(t,x,y,max,lh)=>{const ws=String(t).split(" ");let l="";for(const w of ws){const tt=l?l+" "+w:w;if(g.measureText(tt).width>max&&l){g.fillText(l,x,y);y+=lh;l=w}else l=tt}if(l)g.fillText(l,x,y);return y+lh};
  g.fillStyle="#3fd0b5";g.font="700 40px system-ui,sans-serif";g.fillText(LX("SPOT MANCING","FISHING SPOT"),70,300);
  g.fillStyle="#ffffff";g.font="800 92px 'Bricolage Grotesque',system-ui,sans-serif";let y=wrap(c.n,70,400,W-140,100);
  g.fillStyle="#a9bdd6";g.font="500 40px system-ui,sans-serif";y=wrap(c.a||"",70,y-30,W-140,50)+20;
  g.fillStyle="#3fd0b5";g.font="700 38px system-ui,sans-serif";g.fillText("🐟 "+LX("Ikan","Fish"),70,y);y+=58;
  g.fillStyle="#e8f1ff";g.font="600 44px system-ui,sans-serif";y=wrap((d.fish||[]).slice(0,6).join(" · "),70,y,W-140,58)+20;
  g.fillStyle="#3fd0b5";g.font="700 38px system-ui,sans-serif";g.fillText("🪱 "+LX("Umpan terbaik","Best bait"),70,y);y+=58;
  g.fillStyle="#e8f1ff";g.font="600 40px system-ui,sans-serif";Object.entries(d.bait||{}).slice(0,4).forEach(([k,v])=>{y=wrap(`${k} → ${v.slice(0,3).join(", ")}`,70,y,W-140,54)});y+=20;
  g.fillStyle="#3fd0b5";g.font="700 38px system-ui,sans-serif";g.fillText("⏰ "+LX("Waktu terbaik hari ini","Best time today"),70,y);y+=62;
  g.fillStyle="#ffffff";g.font="800 64px system-ui,sans-serif";g.fillText(`${fmt(b.from)}–${fmt(b.to)}`,70,y);
  g.fillStyle=b.total>=65?"#2ecc71":b.total>=45?"#f2b33d":"#e05a4f";g.beginPath();g.arc(W-150,y-22,70,0,7);g.fill();g.fillStyle="#06222a";g.font="800 56px system-ui,sans-serif";g.textAlign="center";g.fillText(b.total,W-150,y-2);g.textAlign="left";
  g.fillStyle="#3fd0b5";g.fillRect(0,H-150,W,150);g.fillStyle="#06222a";g.font="800 50px system-ui,sans-serif";g.textAlign="center";g.fillText("mancingmania.asia",W/2,H-80);
  g.font="600 30px system-ui,sans-serif";g.fillText(LX("Cuaca, pasang surut & umpan · gratis","Weather, tides & bait · free"),W/2,H-35);g.textAlign="left";
  return await new Promise(r=>cv.toBlob(r,"image/jpeg",.9));
}
function promoCardHtml(){const c=cur();if(!c||c.custom)return "";return `<div class="card"><h3>📣 ${LX("Bagikan spot ini","Share this spot")}</h3><p class="note">${LX("Gambar siap posting (WhatsApp, Status, Instagram, Facebook) berisi ikan, umpan & waktu terbaik hari ini, plus link spotnya.","A ready-to-post image (WhatsApp, Instagram, Facebook) with fish, bait & today's best time, plus the spot link.")}</p><button class="btn" id="promoBtn" style="width:100%">🖼️ ${LX("Buat & bagikan gambar","Create & share image")}</button><p class="note" id="promoMsg"></p></div>`}
function bindPromo(){const b=$("#promoBtn");if(!b)return;b.onclick=async()=>{const c=cur(),m=$("#promoMsg");b.disabled=true;m.textContent=LX("Membuat gambar…","Creating image…");
  try{const blob=await spotCardBlob(),url=`https://mancingmania.asia/spot/${c.id}.html`,text=LX(`🎣 Spot mancing ${c.n}: ikan, umpan & waktu terbaik hari ini → ${url}`,`🎣 Fishing at ${c.n}: fish, bait & best time today → ${url}`);
    const file=new File([blob],`mancing-${c.id}.jpg`,{type:"image/jpeg"});
    if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file],text});m.textContent=""}
    else{const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=file.name;document.body.appendChild(a);a.click();a.remove();try{await navigator.clipboard.writeText(text)}catch(e){}m.innerHTML=LX("Gambar tersimpan. Teks + link sudah disalin, tinggal tempel saat posting.","Image saved. Caption + link copied, just paste it when posting.")+` <a href="https://wa.me/?text=${encodeURIComponent(text)}" target="_blank" rel="noopener">WhatsApp</a>`}}
  catch(e){if(e?.name!=="AbortError")m.textContent=LX("Gagal membuat gambar.","Couldn't create the image.")}finally{b.disabled=false}}}

/* ================= v8: KOMUNITAS (grup ala Facebook) ================= */
// --- saringan konten ---
const BAD_RX=/(^|[^a-z])(anjing|anjg|ajg|bangsat|bgst|kontol|kntl|memek|mmk|ngentot|ngntt|jembut|pepek|perek|pelacur|lonte|bokep|porno|sange|coli|goblok|tolol|kafir|babi lu|cina lo|judi online|judol|slot gacor|togel|pinjol|pinjaman online|fuck|fucking|shit|bitch|cunt|dick|pussy|porn|nude|nudes|xxx|nigger|faggot|onlyfans)([^a-z]|$)/i;
const badText=t=>BAD_RX.test(String(t||"").toLowerCase().replace(/[4@]/g,"a").replace(/[1!]/g,"i").replace(/0/g,"o").replace(/3/g,"e").replace(/5/g,"s"));
let nsfwModel=null,nsfwLoading=null;
const loadScript=src=>new Promise((res,rej)=>{const s=document.createElement("script");s.src=src;s.onload=res;s.onerror=rej;document.head.appendChild(s)});
async function getNsfw(){
  if(nsfwModel)return nsfwModel;
  if(!nsfwLoading)nsfwLoading=(async()=>{const B="https://cdn.jsdelivr.net/npm/nsfwjs@4.2.1/dist/";
    if(!window.nsfwjs)await loadScript(B+"browser/nsfwjs.min.js");await loadScript(B+"models/mobilenet_v2/model.min.js");await loadScript(B+"models/mobilenet_v2/group1-shard1of1.min.js");
    nsfwModel=await window.nsfwjs.load("MobileNetV2");return nsfwModel})().catch(e=>{nsfwLoading=null;throw e});
  return nsfwLoading;
}
// true = aman, false = terdeteksi porno, null = pemeriksa tidak bisa dimuat (offline)
async function photoSafe(canvasOrImg){
  try{const m=await getNsfw(),p=await m.classify(canvasOrImg),g=k=>(p.find(x=>x.className===k)||{}).probability||0;
    return !(g("Porn")+g("Hentai")>0.5||g("Sexy")>0.75)}catch(e){return null}
}

// --- data & state ---
const CGROUPS={ID:["Lombok","Bali & Nusa Tenggara","Jawa","Sumatra","Kalimantan","Sulawesi","Maluku & Papua","Casting","Jigging & Popping","Mancing Dasar","Mancing Perahu","Cumi / Eging","Jual-Beli Alat"],
  AU:["Sydney","NSW","Queensland","Victoria","Western Australia","South Australia","Tasmania","Northern Territory","Land-based","Boat & Offshore","Lures & Soft Plastics","Squid","Buy & Sell"]};
const CKINDS=[["tangkapan","🎣","Tangkapan","Catch"],["tanya","❓","Tanya","Question"],["info","📍","Info spot","Spot info"],["jual","🛒","Jual-beli","Buy & sell"]];
const REACT=[["like","👍"],["love","❤️"],["fire","🔥"]];
let cpMap=null,cpMk=null,cpMapPos=null;
let ctab=store.get("mm_ctab","baru"),cgrp=null,cposts=null,cerr="",cOpen=new Set(),cComments={},cCompose=false,cPhotos=[],cMsg="",cProfile=null,myFollows=null;
const ckind=k=>CKINDS.find(x=>x[0]===k)||CKINDS[0];
async function loadMyFollows(){if(!(sb&&me)){myFollows=[];return}const{data}=await sb.from("follows").select("kind,target").eq("user_id",me.id);myFollows=data||[]}
const follows=(k,t)=>(myFollows||[]).some(f=>f.kind===k&&f.target===String(t));
async function toggleFollow(k,t){if(!(sb&&me))return;t=String(t);if(follows(k,t)){await sb.from("follows").delete().eq("user_id",me.id).eq("kind",k).eq("target",t);myFollows=myFollows.filter(f=>!(f.kind===k&&f.target===t))}else{const{error}=await sb.from("follows").insert({kind:k,target:t});if(!error)myFollows.push({kind:k,target:t})}render()}
async function loadCPosts(){
  if(!sb){cerr=LX("Komunitas butuh koneksi ke server.","Community needs a server connection.");cposts=[];render();return}
  cerr="";let q=sb.from("cposts").select("id,user_id,kind,body,photos,grp,region,spot_id,spot_name,lat,lon,fish,length_cm,answered,hidden,report_count,created_at,profiles(name),creactions(emoji,user_id),ccomments(count)").eq("region",region).order("created_at",{ascending:false}).limit(60);
  if(cgrp)q=q.eq("grp",cgrp);
  const{data,error}=await q;if(error){cerr=LX("Gagal memuat: ","Couldn't load: ")+error.message;cposts=[]}else cposts=(data||[]).filter(x=>!blocked.has(x.user_id));
  if(me&&myFollows===null)await loadMyFollows();
  if(view==="komunitas")render();
  markSeen();
}
// --- titik merah: komentar baru di postinganku ---
async function checkCNotif(){
  if(!(sb&&me))return;const since=store.get("mm_cseen","1970-01-01T00:00:00Z");
  const{data}=await sb.from("ccomments").select("id,created_at,user_id,cposts!inner(user_id)").eq("cposts.user_id",me.id).neq("user_id",me.id).gt("created_at",since).limit(20);
  const n=(data||[]).length;cNew=n;
  // Tahap 2: postingan baru dari orang/spot/ikan yang diikuti (+ ikan besar)
  if(myFollows===null)await loadMyFollows();const f=myFollows||[],fs=store.get("mm_fseen","1970-01-01T00:00:00Z");fNew=0;fBig=null;
  if(f.length){const{data:ps}=await sb.from("cposts").select("id,user_id,spot_id,spot_name,fish,length_cm,created_at,profiles(name)").eq("region",region).neq("user_id",me.id).gt("created_at",fs).order("created_at",{ascending:false}).limit(50);
    const hit=(ps||[]).filter(x=>f.some(z=>(z.kind==="user"&&z.target===x.user_id)||(z.kind==="spot"&&z.target===x.spot_id)||(z.kind==="fish"&&z.target===x.fish)));
    fNew=hit.length;fBig=hit.filter(x=>x.length_cm&&x.length_cm>=(SP[x.fish]?.min?SP[x.fish].min*1.6:50)).sort((a,b)=>b.length_cm-a.length_cm)[0]||null;
    if(fBig&&store.get("mm_fbig","")!==fBig.id){store.set("mm_fbig",fBig.id);const t=LX(`🐟 Ikan besar! ${fBig.fish} ${fBig.length_cm} cm`,`🐟 Big fish! ${fBig.fish} ${fBig.length_cm} cm`),body=`${fBig.profiles?.name||""}${fBig.spot_name?" · "+fBig.spot_name:""}`;
      try{if(LN()&&store.get("mm_ln_on",false))LN().schedule({notifications:[{id:7100,title:t,body,schedule:{at:new Date(Date.now()+1500)}}]});else if(typeof Notification!=="undefined"&&Notification.permission==="granted")navigator.serviceWorker?.ready.then(r=>r.showNotification(t,{body,icon:"icons/icon-192.png"}))}catch(e){}}}
  const b=document.querySelector('.tabbar button[data-v="komunitas"]');if(b)b.classList.toggle("dot",n+fNew>0);
}
let fNew=0,fBig=null;
let cNew=0;
function markSeen(){if(view==="komunitas"&&ctab==="untukmu"){store.set("mm_fseen",new Date().toISOString());fNew=0;if(!cNew)document.querySelector('.tabbar button[data-v="komunitas"]')?.classList.remove("dot")}if(view==="komunitas"&&ctab==="saya"){store.set("mm_cseen",new Date().toISOString());cNew=0;document.querySelector('.tabbar button[data-v="komunitas"]')?.classList.remove("dot")}}

// --- tampilan ---
function postCard(x){
  const k=ckind(x.kind),mine=me&&x.user_id===me.id,rx=x.creactions||[],mineR=me?rx.find(r=>r.user_id===me.id)?.emoji:null,nc=x.ccomments?.[0]?.count||0;
  const cnt=e=>rx.filter(r=>r.emoji===e).length,open=cOpen.has(x.id),name=x.profiles?.name||LX("Pemancing","Angler");
  const ph=(x.photos||[]).filter(Boolean);
  return `<article class="card cpost" data-pid="${x.id}">
   <div class="cphead"><button class="cpname linkish" data-prof="${x.user_id}">${esc(name)}</button><span class="note">${ago(x.created_at)}${x.grp?` · <button class="linkish" data-cg="${esc(x.grp)}">${esc(x.grp)}</button>`:""}</span>
     <span class="badge">${k[1]} ${LX(k[2],k[3])}${x.kind==="tanya"&&x.answered?" · ✅ "+LX("terjawab","answered"):""}</span>${x.hidden?`<span class="badge" style="background:var(--bad)">${LX("disembunyikan","hidden")}</span>`:""}</div>
   <p class="cpbody">${esc(x.body).replace(/\n/g,"<br>")}</p>
   ${x.fish||x.spot_name||x.lat!=null?`<p class="note">${x.fish?`🐟 <b>${esc(x.fish)}</b>${x.length_cm?` ${x.length_cm} cm`:""}`:""}${x.spot_name?` · 📍 ${x.spot_id?`<button class="linkish" data-gospot="${esc(x.spot_id)}">${esc(x.spot_name)}</button>`:esc(x.spot_name)}`:""}${x.lat!=null?` · <a href="https://www.google.com/maps?q=${x.lat},${x.lon}" target="_blank" rel="noopener">🗺️ ${LX("peta","map")}</a>`:""}</p>`:""}
   ${ph.length?`<div class="cpgrid n${ph.length}">${ph.map(p=>`<img src="${photoUrl(p)}" alt="" loading="lazy" data-zoom="${photoUrl(p)}">`).join("")}</div>`:""}
   <div class="cpbar">${REACT.map(([e,ic])=>`<button class="x${mineR===e?" on":""}" data-react="${e}" data-id="${x.id}">${ic} ${cnt(e)||""}</button>`).join("")}
     <button class="x" data-cmt="${x.id}">💬 ${nc||""}</button>
     <button class="x" data-cshare="${x.id}">↗️</button>
     ${mine&&x.kind==="tanya"?`<button class="x" data-answered="${x.id}">${x.answered?"↩️":"✅"}</button>`:""}
     ${mine||isAdmin?`<button class="x" data-cdelp="${x.id}">🗑️</button>`:""}
     ${!mine&&me?`<button class="x" data-crep="${x.id}" title="${LX("Laporkan","Report")}">🚩</button>`:""}
     ${isAdmin&&!mine?`<button class="x" data-ban="${x.user_id}" title="${LX("Blokir pengguna","Ban user")}">⛔</button>`:""}
     ${isAdmin&&x.hidden?`<button class="x" data-unhide="${x.id}">👁️</button>`:""}</div>
   ${open?commentsHtml(x.id):""}
  </article>`;
}
function commentsHtml(pid){
  const cs=cComments[pid];if(!cs)return `<p class="note">${LX("Memuat komentar…","Loading comments…")}</p>`;
  const top=cs.filter(c=>!c.parent_id),kids=id=>cs.filter(c=>c.parent_id===id);
  const one=(c,lvl)=>`<div class="ccmt" style="margin-left:${lvl*18}px"><b>${esc(c.profiles?.name||"?")}</b> <span class="note">${ago(c.created_at)}</span><br>${esc(c.body)}<div>${me&&lvl===0?`<button class="linkish" data-reply="${c.id}" data-pid="${pid}">${LX("Balas","Reply")}</button>`:""} ${me&&(c.user_id===me.id||isAdmin)?`<button class="linkish" data-cdelc="${c.id}" data-pid="${pid}">${LX("Hapus","Delete")}</button>`:""}</div></div>`;
  return `<div class="ccmts">${top.map(c=>one(c,0)+kids(c.id).map(k=>one(k,1)).join("")).join("")||`<p class="note">${LX("Belum ada komentar.","No comments yet.")}</p>`}
   ${me&&myName?`<form class="cform" data-pid="${pid}"><input name="b" maxlength="1000" placeholder="${LX("Tulis komentar…","Write a comment…")}" aria-label="${LX("Komentar","Comment")}"><input type="hidden" name="p"><button class="btn" type="submit">${LX("Kirim","Send")}</button></form><p class="note cfw" style="color:var(--bad)"></p>`:`<p class="note">${LX("Masuk dulu untuk berkomentar.","Sign in to comment.")}</p>`}</div>`;
}
function composerHtml(){
  if(!(sb&&me&&myName))return `<div class="card"><h3>👥 ${LX("Gabung ngobrol","Join the conversation")}</h3><p class="note">${LX("Masuk atau daftar dulu supaya bisa posting, berkomentar dan memberi reaksi.","Sign in or register to post, comment and react.")}</p>${authCard()}</div>`;
  if(!cCompose)return `<button class="btn" id="cNew" style="width:100%;margin-bottom:10px">✍️ ${LX("Buat postingan","Create a post")}</button>`;
  const c=cur(),grps=CGROUPS[region]||[];
  return `<form class="card" id="cpF"><h3>✍️ ${LX("Postingan baru","New post")}</h3>
   <div class="seg" id="cpKind">${CKINDS.map((k,i)=>`<button type="button" data-ck="${k[0]}" aria-pressed="${i===0}">${k[1]} ${LX(k[2],k[3])}</button>`).join("")}</div>
   <textarea id="cpBody" rows="4" maxlength="2000" style="width:100%;margin-top:8px" placeholder="${LX("Cerita tangkapan, tanya umpan, info spot…","Share a catch, ask about bait, spot info…")}"></textarea>
   <div class="two" style="margin-top:6px"><select class="f" id="cpGrp" aria-label="${LX("Grup","Group")}"><option value="">${LX("— Tanpa grup —","— No group —")}</option>${grps.map(g=>`<option ${g===cgrp?"selected":""}>${esc(g)}</option>`).join("")}</select>
     <span></span></div>
   <h3 style="margin-top:10px">📍 ${LX("Lokasi","Location")}</h3>
   <div class="seg" id="cpLocSeg"><button type="button" data-cl="spot" aria-pressed="true">📍 ${esc(c?.n||LX("Spot","Spot"))}</button><button type="button" data-cl="map" aria-pressed="false">🗺️ ${LX("Pilih di peta","Pick on map")}</button><button type="button" data-cl="none" aria-pressed="false">🚫 ${LX("Tanpa lokasi","No location")}</button></div>
   <div id="cpMapBox" style="display:none;margin-top:6px"><p class="note">${LX("Ketuk peta atau geser penanda 📍 ke lokasi.","Tap the map or drag the 📍 marker to the location.")}</p><div id="cpMap" class="lmap" style="height:240px;margin-right:22px"></div><p class="note" id="cpMapInfo"></p><input id="cpPlace" maxlength="60" placeholder="${LX("Nama tempat (opsional)","Place name (optional)")}"></div>
   <div class="two" style="margin-top:6px"><input id="cpFish" maxlength="40" placeholder="${LX("Ikan (opsional)","Fish (optional)")}" list="cpFishL"><input id="cpLen" type="number" min="1" max="400" placeholder="${LX("Panjang cm","Length cm")}"></div>
   <datalist id="cpFishL">${Object.keys(SP).map(f=>`<option value="${esc(f)}">`).join("")}</datalist>
   <h3 style="margin-top:10px">📷 ${LX("Foto","Photos")} (${cPhotos.length}/4)</h3>
   <div class="cpgrid n${Math.max(1,cPhotos.length)}">${cPhotos.map((p,i)=>`<div class="cpthumb"><img src="${p.url}" alt=""><button type="button" class="x" data-rmph="${i}">✕</button></div>`).join("")}</div>
   ${cPhotos.length<4?`<div class="two" style="margin-top:6px"><label class="btn ghost" for="cpFile">${LX("+ Dari galeri / kamera","+ From gallery / camera")}</label><button type="button" class="btn ghost" id="cpFromCatch">🎣 ${LX("Dari Tangkapanku","From my catches")}</button></div><input type="file" id="cpFile" accept="image/*" multiple hidden>`:""}
   <div id="cpCatchPick"></div>
   <p class="note">🛡️ ${LX("Foto dicek otomatis sebelum di-upload. Konten porno, SARA, kasar, judi & pinjol diblokir.","Photos are checked automatically before upload. Porn, hate, abusive, gambling & loan-shark content is blocked.")}</p>
   <p class="note" id="cpMsg" style="color:var(--bad)"></p>
   <div class="two"><button class="btn" type="submit" id="cpSend">${LX("Posting","Post")}</button><button class="btn ghost" type="button" id="cpCancel">${LX("Batal","Cancel")}</button></div></form>`;
}
function communityView(){
  if(cpMap){try{cpMap.remove()}catch(e){}cpMap=null;cpMk=null}
  if(cposts===null&&!cerr)loadCPosts();loadWeekChamp();
  const grps=CGROUPS[region]||[];
  let list=cposts||[];
  if(ctab==="untukmu"){const f=myFollows||[];list=list.filter(x=>f.some(z=>(z.kind==="user"&&z.target===x.user_id)||(z.kind==="spot"&&z.target===x.spot_id)||(z.kind==="fish"&&z.target===x.fish)))}
  if(ctab==="saya")list=list.filter(x=>me&&x.user_id===me.id);
  const prof=cProfile?profileHtml():"";
  $("#main").innerHTML=`${offlineBadge()}<h2>👥 ${LX("Komunitas","Community")} ${region==="AU"?"🇦🇺":"🇮🇩"}</h2>
   <div class="seg">${[["baru",LX("Terbaru","Latest")],["untukmu",LX("Untukmu","For you")+(fNew?` 🔴${fNew}`:"")],["grup",LX("Grup","Groups")],["saya",LX("Postinganku","My posts")+(cNew?` 🔴${cNew}`:"")]].map(([k,l])=>`<button data-ct="${k}" aria-pressed="${ctab===k}">${l}</button>`).join("")}<button id="cRefresh" aria-label="${LX("Muat ulang","Refresh")}">↻</button></div>
   ${prof}${weekChamp&&ctab==="baru"?`<div class="card"><b>🥇 ${LX("Juara minggu lalu","Last week's champion")}: ${esc(weekChamp.profiles?.name||"")}</b> · ${esc(weekChamp.fish)} ${weekChamp.length_cm} cm</div>`:""}
   ${ctab==="grup"?`<div class="card"><h3>${LX("Grup","Groups")}</h3><div class="cgroups">${grps.map(g=>`<button class="x${g===cgrp?" on":""}" data-cg="${esc(g)}">${esc(g)}</button>`).join("")}</div>${cgrp?`<p class="note" style="margin-top:8px">${LX("Menampilkan grup","Showing group")} <b>${esc(cgrp)}</b> · <button class="linkish" data-cg="">${LX("semua grup","all groups")}</button></p>`:`<p class="note" style="margin-top:8px">${LX("Pilih grup untuk melihat postingannya.","Pick a group to see its posts.")}</p>`}</div>`:""}
   ${ctab==="untukmu"&&!(myFollows||[]).length?`<div class="card"><p class="note">${LX("Belum mengikuti apa pun. Ketuk nama pemancing lalu “Ikuti”, atau ikuti spot & ikan di bawah.","You're not following anything yet. Tap an angler's name then “Follow”, or follow a spot & fish below.")}</p>${followQuickHtml()}</div>`:ctab==="untukmu"?`<div class="card">${followQuickHtml()}</div>`:""}
   ${ctab!=="saya"?composerHtml():""}
   ${cMsg?`<p class="note" style="color:var(--good,#1a9e5a);font-weight:600">${esc(cMsg)}</p>`:""}
   <div id="cList">${cposts===null?`<p class="note">${LX("Memuat…","Loading…")}</p>`:cerr?`<p class="note">${esc(cerr)}</p>`:list.length?list.map(postCard).join(""):`<div class="card"><p class="note">${ctab==="grup"&&!cgrp?"":LX("Belum ada postingan di sini. Jadilah yang pertama!","No posts here yet. Be the first!")}</p></div>`}</div>`;
  bindCommunity();
}
function followQuickHtml(){const c=cur(),d=c?spotData(c):null;if(!me||!c)return "";
  return `<p class="note">${LX("Ikuti cepat:","Quick follow:")}</p><div class="cgroups"><button class="x${follows("spot",c.id)?" on":""}" data-fol="spot" data-t="${esc(c.id)}">📍 ${esc(c.n)}</button>${(d?.fish||[]).slice(0,6).map(f=>`<button class="x${follows("fish",f)?" on":""}" data-fol="fish" data-t="${esc(f)}">🐟 ${esc(f)}</button>`).join("")}</div>`}
function profileHtml(){const p=cProfile;if(!p)return "";const mine=me&&p.id===me.id;
  return `<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h3>👤 ${esc(p.name||LX("Pemancing","Angler"))}</h3><button class="x" id="cProfX">✕</button></div>
   ${p.stats?`<div class="row statgrid"><div class="kv"><span class="tag">${LX("Postingan","Posts")}</span><strong>${p.stats.posts}</strong></div><div class="kv"><span class="tag">${LX("Tangkapan","Catches")}</span><strong>${p.stats.catches}</strong></div><div class="kv"><span class="tag">${LX("Pengikut","Followers")}</span><strong>${p.stats.followers}</strong></div><div class="kv"><span class="tag">${LX("Ikan terbesar","Biggest fish")}</span><strong style="font-size:1rem">${p.stats.best||"–"}</strong></div></div>`:`<p class="note">${LX("Memuat…","Loading…")}</p>`}
   ${me&&!mine?`<button class="btn${follows("user",p.id)?" ghost":""}" data-fol="user" data-t="${p.id}" style="width:100%;margin-top:8px">${follows("user",p.id)?LX("✓ Diikuti","✓ Following"):LX("+ Ikuti","+ Follow")}</button>`:""}</div>`}
async function openProfile(uid){
  cProfile={id:uid,name:(cposts||[]).find(x=>x.user_id===uid)?.profiles?.name||""};render();
  const[a,b,c,d]=await Promise.all([sb.from("cposts").select("id",{count:"exact",head:true}).eq("user_id",uid),sb.from("catches").select("id",{count:"exact",head:true}).eq("user_id",uid),sb.from("follows").select("user_id",{count:"exact",head:true}).eq("kind","user").eq("target",uid),sb.from("catches").select("fish,length_cm").eq("user_id",uid).not("length_cm","is",null).order("length_cm",{ascending:false}).limit(1)]);
  if(cProfile?.id!==uid)return;const bf=d.data?.[0];cProfile.stats={posts:a.count||0,catches:b.count||0,followers:c.count||0,best:bf?`${bf.fish} ${bf.length_cm} cm`:""};render();
}
async function loadComments(pid){const{data}=await sb.from("ccomments").select("id,post_id,parent_id,user_id,body,created_at,profiles(name)").eq("post_id",pid).order("created_at");cComments[pid]=(data||[]).filter(c=>!blocked.has(c.user_id));render()}
function bindCommunity(){
  const q=s=>document.querySelectorAll(s);
  q("[data-ct]").forEach(b=>b.onclick=()=>{ctab=b.dataset.ct;store.set("mm_ctab",ctab);cProfile=null;if(ctab!=="grup"&&cgrp){cgrp=null;cposts=null}render();markSeen()});
  const rf=$("#cRefresh");if(rf)rf.onclick=()=>{cposts=null;cComments={};render();checkCNotif()};
  q("[data-cg]").forEach(b=>b.onclick=()=>{cgrp=b.dataset.cg||null;ctab="grup";cposts=null;render()});
  q("[data-gospot]").forEach(b=>b.onclick=()=>{view="spot";document.querySelectorAll(".tabbar button").forEach(x=>x.setAttribute("aria-selected",x.dataset.v==="spot"));setSpot(b.dataset.gospot)});
  q("[data-prof]").forEach(b=>b.onclick=()=>{if(view==="komunitas"&&sb){openProfile(b.dataset.prof);$("#main").scrollTop=0}});
  const px=$("#cProfX");if(px)px.onclick=()=>{cProfile=null;render()};
  q("[data-fol]").forEach(b=>b.onclick=()=>toggleFollow(b.dataset.fol,b.dataset.t));
  q("[data-zoom]").forEach(i=>i.onclick=()=>window.open(i.dataset.zoom,"_blank","noopener"));
  q("[data-react]").forEach(b=>b.onclick=async()=>{if(!(sb&&me))return;const id=b.dataset.id,e=b.dataset.react,p=cposts.find(x=>x.id===id),cur0=p.creactions.find(r=>r.user_id===me.id);
    if(cur0&&cur0.emoji===e){await sb.from("creactions").delete().eq("post_id",id).eq("user_id",me.id);p.creactions=p.creactions.filter(r=>r.user_id!==me.id)}
    else{const{error}=await sb.from("creactions").upsert({post_id:id,user_id:me.id,emoji:e});if(!error){p.creactions=p.creactions.filter(r=>r.user_id!==me.id);p.creactions.push({emoji:e,user_id:me.id})}}render()});
  q("[data-cmt]").forEach(b=>b.onclick=()=>{const id=b.dataset.cmt;if(cOpen.has(id))cOpen.delete(id);else{cOpen.add(id);loadComments(id)}render()});
  q("[data-reply]").forEach(b=>b.onclick=()=>{const f=document.querySelector(`.cform[data-pid="${b.dataset.pid}"]`);if(!f)return;f.p.value=b.dataset.reply;f.b.placeholder=LX("Balas komentar…","Reply…");f.b.focus()});
  q(".cform").forEach(f=>f.onsubmit=async e=>{e.preventDefault();const pid=f.dataset.pid,t=f.b.value.trim(),w=f.nextElementSibling;if(!t)return;
    if(badText(t)){w.textContent=LX("Komentar mengandung kata yang tidak diizinkan.","Comment contains words that aren't allowed.");return}
    const{error}=await sb.from("ccomments").insert({post_id:pid,parent_id:f.p.value||null,body:t.slice(0,1000)});
    if(error){w.textContent=LX("Gagal: ","Failed: ")+error.message;return}const p=cposts.find(x=>x.id===pid);if(p)p.ccomments=[{count:(p.ccomments?.[0]?.count||0)+1}];loadComments(pid)});
  q("[data-cdelc]").forEach(b=>b.onclick=async()=>{await sb.from("ccomments").delete().eq("id",b.dataset.cdelc);loadComments(b.dataset.pid)});
  q("[data-cdelp]").forEach(b=>b.onclick=async()=>{if(b.dataset.sure!=="1"){b.dataset.sure="1";b.textContent=LX("Hapus?","Delete?");return}const p=cposts.find(x=>x.id===b.dataset.cdelp);
    await sb.from("cposts").delete().eq("id",p.id);const mine=(p.photos||[]).filter(x=>me&&x.startsWith(me.id+"/c/"));if(mine.length)sb.storage.from("photos").remove(mine);cposts=cposts.filter(x=>x.id!==p.id);render()});
  q("[data-crep]").forEach(b=>b.onclick=async()=>{b.disabled=true;const{error}=await sb.from("creports").insert({post_id:b.dataset.crep,reason:"tidak pantas"});b.textContent=error&&!String(error.message).includes("duplicate")?"!":"✓ "+LX("dilaporkan","reported")});
  q("[data-ban]").forEach(b=>b.onclick=async()=>{if(b.dataset.sure!=="1"){b.dataset.sure="1";b.textContent=LX("Blokir?","Ban?");return}await sb.from("banned_users").upsert({user_id:b.dataset.ban,reason:"komunitas"});b.textContent="⛔ ✓"});
  q("[data-unhide]").forEach(b=>b.onclick=async()=>{await sb.from("cposts").update({hidden:false}).eq("id",b.dataset.unhide);cposts=null;render()});
  q("[data-answered]").forEach(b=>b.onclick=async()=>{const p=cposts.find(x=>x.id===b.dataset.answered);await sb.from("cposts").update({answered:!p.answered}).eq("id",p.id);p.answered=!p.answered;render()});
  q("[data-cshare]").forEach(b=>b.onclick=()=>{const p=cposts.find(x=>x.id===b.dataset.cshare),u=p.spot_id?`https://mancingmania.asia/spot/${p.spot_id}.html`:"https://mancingmania.asia/",t=`${p.body.slice(0,200)}${p.fish?` · 🐟 ${p.fish}${p.length_cm?" "+p.length_cm+" cm":""}`:""}\n${LX("di komunitas Mancing Mania","on the Mancing Mania community")}: ${u}`;
    if(navigator.share)navigator.share({text:t}).catch(()=>{});else window.open("https://wa.me/?text="+encodeURIComponent(t),"_blank","noopener")});
  bindAuth&&bindAuth();
  const nb=$("#cNew");if(nb)nb.onclick=()=>{cCompose=true;cMsg="";render()};
  bindComposer();
}
function bindComposer(){
  const f=$("#cpF");if(!f)return;let kind=f.dataset.kind||"tangkapan";
  document.querySelectorAll("[data-ck]").forEach(b=>b.onclick=()=>{kind=b.dataset.ck;f.dataset.kind=kind;document.querySelectorAll("[data-ck]").forEach(x=>x.setAttribute("aria-pressed",x===b))});
  $("#cpCancel").onclick=()=>{cCompose=false;cPhotos=[];cpMapPos=null;store.set("mm_cdraft",{});render()};
  document.querySelectorAll("[data-rmph]").forEach(b=>b.onclick=()=>{keep();cPhotos.splice(+b.dataset.rmph,1);render();restore()});
  const keepV={};const keep=()=>{["cpBody","cpGrp","cpFish","cpLen"].forEach(i=>keepV[i]=$("#"+i)?.value);keepV.kind=kind;keepV.loc=f.dataset.loc||"spot";keepV.place=$("#cpPlace")?.value;store.set("mm_cdraft",keepV)};
  const restore=()=>{const v=store.get("mm_cdraft",{});["cpBody","cpGrp","cpFish","cpLen"].forEach(i=>{if($("#"+i)&&v[i]!=null)$("#"+i).value=v[i]});if($("#cpPlace")&&v.place)$("#cpPlace").value=v.place;if(v.kind){const b=document.querySelector(`[data-ck="${v.kind}"]`);if(b)b.click()}};
  restore();
  let locMode=store.get("mm_cdraft",{}).loc||"spot";
  const nearSp=(la,lo)=>{let b=null,d=1e9;allSpots().forEach(x=>{const k=km(la,lo,x.lat,x.lon);if(k<d){d=k;b=x}});return b?{s:b,d}:null};
  const setCp=(la,lo)=>{cpMapPos=[la,lo];if(cpMk)cpMk.setLatLng(cpMapPos);const n=nearSp(la,lo);const i=$("#cpMapInfo");if(i)i.textContent=`📍 ${la.toFixed(4)}, ${lo.toFixed(4)}`+(n&&n.d<30?` · ${LX("dekat","near")} ${n.s.n} (${n.d} km)`:"")};
  const openCpMap=()=>{const box=$("#cpMapBox");box.style.display="";if(!window.L){$("#cpMapInfo").textContent=LX("Peta butuh internet.","Map needs internet.");return}
    if(cpMap){try{cpMap.remove()}catch(e){}cpMap=null}
    const c=cur(),st=cpMapPos||(here?[here.lat,here.lon]:[c.lat,c.lon]);
    cpMap=L.map("cpMap").setView(st,13);L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap"}).addTo(cpMap);
    cpMk=L.marker(st,{draggable:true}).addTo(cpMap);cpMk.on("dragend",()=>{const q=cpMk.getLatLng();setCp(q.lat,q.lng)});cpMap.on("click",ev=>setCp(ev.latlng.lat,ev.latlng.lng));setCp(st[0],st[1]);setTimeout(()=>cpMap.invalidateSize(),80)};
  const setLoc=m=>{locMode=m;f.dataset.loc=m;document.querySelectorAll("[data-cl]").forEach(x=>x.setAttribute("aria-pressed",x.dataset.cl===m));if(m==="map")openCpMap();else $("#cpMapBox").style.display="none";const v=store.get("mm_cdraft",{});v.loc=m;store.set("mm_cdraft",v)};
  document.querySelectorAll("[data-cl]").forEach(b=>b.onclick=()=>setLoc(b.dataset.cl));
  if(locMode!=="spot")setLoc(locMode);
  const fi=$("#cpFile");if(fi)fi.onchange=async()=>{keep();const m=$("#cpMsg");m.style.color="";m.textContent=LX("Memeriksa foto…","Checking photos…");
    for(const file of [...fi.files].slice(0,4-cPhotos.length)){try{const cv=await shrink(file,1200),ok=await photoSafe(cv);
      if(ok===false){m.style.color="var(--bad)";m.textContent=LX("❌ Foto ditolak: terdeteksi konten tidak pantas.","❌ Photo rejected: inappropriate content detected.");continue}
      const blob=await new Promise(r=>cv.toBlob(r,"image/jpeg",.8));cPhotos.push({blob,url:cv.toDataURL("image/jpeg",.5),checked:ok})}catch(e){}}
    render();restore();const mm=$("#cpMsg");if(mm&&!mm.textContent)mm.textContent=""};
  const fc=$("#cpFromCatch");if(fc)fc.onclick=async()=>{keep();const box=$("#cpCatchPick");box.innerHTML=`<p class="note">${LX("Memuat foto tangkapanmu…","Loading your catch photos…")}</p>`;
    const{data}=await sb.from("catches").select("id,fish,length_cm,photo_path,spot_name,spot_id").eq("user_id",me.id).not("photo_path","is",null).order("created_at",{ascending:false}).limit(12);
    box.innerHTML=(data||[]).length?`<div class="cpick">${data.map(c=>`<button type="button" data-pickc="${c.id}"><img src="${photoUrl(c.photo_path)}" alt=""><span>${esc(c.fish)}${c.length_cm?" "+c.length_cm+"cm":""}</span></button>`).join("")}</div>`:`<p class="note">${LX("Belum ada tangkapan berfoto. Upload dulu di tab Tangkapan.","No catches with photos yet. Upload one in the Catches tab first.")}</p>`;
    box.querySelectorAll("[data-pickc]").forEach(b=>b.onclick=()=>{const c=data.find(z=>z.id===b.dataset.pickc);if(cPhotos.length>=4)return;keep();cPhotos.push({path:c.photo_path,url:photoUrl(c.photo_path)});
      const v=store.get("mm_cdraft",{});if(!v.cpFish)v.cpFish=c.fish;if(!v.cpLen&&c.length_cm)v.cpLen=c.length_cm;store.set("mm_cdraft",v);render();restore()})};
  f.onsubmit=async e=>{e.preventDefault();const m=$("#cpMsg"),body=$("#cpBody").value.trim(),btn=$("#cpSend");m.style.color="var(--bad)";
    if(body.length<2&&!cPhotos.length){m.textContent=LX("Tulis sesuatu atau tambahkan foto.","Write something or add a photo.");return}
    if(badText(body)||badText($("#cpFish").value)){m.textContent=LX("Postingan mengandung kata yang tidak diizinkan.","Your post contains words that aren't allowed.");return}
    btn.disabled=true;btn.textContent=LX("Mengupload…","Uploading…");
    try{
      const paths=[];for(const p of cPhotos){if(p.path){paths.push(p.path);continue}
        const path=`${me.id}/c/${Date.now()}-${Math.random().toString(36).slice(2,7)}.jpg`;const up=await sb.storage.from("photos").upload(path,p.blob,{contentType:"image/jpeg",cacheControl:"31536000"});if(up.error)throw up.error;paths.push(path)}
      const c=cur(),lm=f.dataset.loc||"spot";let sid=null,sname=null,la=null,lo=null;
      if(lm==="spot"&&c){sid=c.custom?null:c.id;sname=c.n;la=+(+c.lat).toFixed(4);lo=+(+c.lon).toFixed(4)}
      if(lm==="map"){if(!cpMapPos)throw new Error(LX("Pilih lokasi di peta dulu","Pick a location on the map first"));const n=nearSp(cpMapPos[0],cpMapPos[1]),nm=($("#cpPlace")?.value||"").trim();if(badText(nm))throw new Error(LX("Nama tempat tidak diizinkan","Place name not allowed"));
        la=+cpMapPos[0].toFixed(4);lo=+cpMapPos[1].toFixed(4);sid=n&&n.d<3?n.s.id:null;sname=(nm||(n&&n.d<30?(n.d<3?n.s.n:LX("Dekat ","Near ")+n.s.n):LX("Lokasi pemancing","Angler's spot"))).slice(0,60)}
      const row={kind,body:(body||"📷").slice(0,2000),photos:paths,grp:$("#cpGrp").value||null,region,spot_id:sid,spot_name:sname,lat:la,lon:lo,fish:$("#cpFish").value.trim()||null,length_cm:+$("#cpLen").value||null};
      const{error}=await sb.from("cposts").insert(row);if(error)throw error;
      cPhotos=[];cCompose=false;cpMapPos=null;store.set("mm_cdraft",{});cMsg=LX("✅ Terposting!","✅ Posted!");cposts=null;render();setTimeout(()=>{cMsg=""},4000);
    }catch(err){btn.disabled=false;btn.textContent=LX("Coba lagi","Try again");m.textContent=LX("Gagal posting: ","Couldn't post: ")+(err?.message||err)}};
}
setTimeout(()=>{checkCNotif();setInterval(checkCNotif,120000)},5000);

/* ================= v9: KONTEN MINGGUAN OTOMATIS (berganti tiap Senin) ================= */
const weekNo=(d=new Date())=>{const t=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));const day=(t.getUTCDay()+6)%7;t.setUTCDate(t.getUTCDate()-day);return Math.floor(t.getTime()/6048e5)};
const pickW=(arr,salt)=>arr.length?arr[(weekNo()*7+salt)%arr.length]:null;
let weekChamp=null,weekChampT=0;
async function loadWeekChamp(){
  if(!sb||Date.now()-weekChampT<30*6e4)return;weekChampT=Date.now();
  const now=new Date(),mon=new Date(now);mon.setDate(now.getDate()-((now.getDay()+6)%7));mon.setHours(0,0,0,0);const prev=new Date(mon.getTime()-7*864e5);
  const{data}=await sb.from("catches").select("id,fish,length_cm,spot_name,photo_path,user_id,lat,lon,profiles(name)").gte("created_at",prev.toISOString()).lt("created_at",mon.toISOString()).not("length_cm","is",null).eq("hidden",false).order("length_cm",{ascending:false}).limit(20);
  weekChamp=(data||[]).find(x=>inRegion(x))||null;if(view==="peta"||view==="komunitas")render();
}
function weeklyHtml(){
  const spots=LOC.filter(s=>s.region===region&&!s.custom&&!/^sub_/.test(s.id)),sp=pickW(spots,1);
  const fishes=[...new Set(spots.flatMap(s=>s.fish||[]))].filter(f=>SP[f]),fi=pickW(fishes,3),tip=pickW(TIPS,5);
  const d=sp?spotData(sp):null,fd=fi?SP[fi]:null;
  loadWeekChamp();
  return `<div class="card weekly"><h3>📅 ${LX("Minggu ini di Mancing Mania","This week on Mancing Mania")}</h3>
   ${sp?`<button class="favrow" data-id="${sp.id}"><span><b>🏆 ${LX("Spot minggu ini","Spot of the week")}: ${esc(sp.n)}</b><br><span class="note">${esc(sp.a||"")} · ${(d.fish||[]).slice(0,4).map(esc).join(", ")}</span></span><span class="badge">›</span></button>`:""}
   ${fi?`<button class="favrow" data-wfish="${esc(fi)}"><span><b>🐟 ${LX("Ikan minggu ini","Fish of the week")}: ${esc(fi)}</b><br><span class="note">${esc((fd?.ciri||"").slice(0,90))}${(fd?.ciri||"").length>90?"…":""}</span></span>${fishSVG(fi)}</button>`:""}
   ${tip?`<div class="favrow" style="cursor:default"><span><b>💡 ${LX("Tips minggu ini","Tip of the week")}: ${esc(tip.h)}</b><br><span class="note">${esc(tip.t)}</span></span></div>`:""}
   ${weekChamp?`<div class="favrow" style="cursor:default"><span><b>🥇 ${LX("Juara minggu lalu","Last week's champion")}: ${esc(weekChamp.profiles?.name||LX("Pemancing","Angler"))}</b><br><span class="note">${esc(weekChamp.fish)} ${weekChamp.length_cm} cm${weekChamp.spot_name?" · "+esc(weekChamp.spot_name):""}</span></span>${weekChamp.photo_path?`<img src="${photoUrl(weekChamp.photo_path)}" alt="" style="width:56px;height:56px;object-fit:cover;border-radius:8px">`:"🏅"}</div>`:""}
   <p class="note">${LX("Berganti otomatis setiap Senin.","Changes automatically every Monday.")}</p></div>`;
}
function bindWeekly(){document.querySelectorAll("[data-wfish]").forEach(b=>b.onclick=()=>{fishSel=b.dataset.wfish;view="spot";document.querySelectorAll(".tabbar button").forEach(x=>x.setAttribute("aria-selected",x.dataset.v==="spot"));render();$("#main").scrollTop=0})}

/* ================= v10: KALENDER MANCING BULANAN ================= */
let calOpen=store.get("mm_cal_open",true),calMonth=0,calSel=null,calWx=null,calWxKey="",calWxBusy=false;
const calKey=()=>{const c=cur();return c.id+":"+(+c.lat).toFixed(2)+","+(+c.lon).toFixed(2)};
async function loadCalWx(){
  const c=cur(),k=calKey();if(calWxBusy||(calWx&&calWxKey===k&&Date.now()-calWx.t<3*36e5)||!navigator.onLine)return;
  calWxBusy=true;const q=`latitude=${(+c.lat).toFixed(3)}&longitude=${(+c.lon).toFixed(3)}&timezone=auto&forecast_days=14`;
  try{const[w,m]=await Promise.all([fetch(`https://api.open-meteo.com/v1/forecast?${q}&daily=wind_speed_10m_max,precipitation_sum&wind_speed_unit=kmh`).then(r=>r.ok?r.json():null),
      fetch(`https://marine-api.open-meteo.com/v1/marine?${q}&daily=wave_height_max`).then(r=>r.ok?r.json():null).catch(()=>null)]);
    if(!w?.daily)throw 0;const d={};w.daily.time.forEach((t,i)=>{d[t]={wind:w.daily.wind_speed_10m_max[i],rain:w.daily.precipitation_sum[i],wave:m?.daily?.wave_height_max?.[i]??null}});
    calWx={t:Date.now(),d};calWxKey=k;if(view==="prakiraan")render();
  }catch(e){}finally{calWxBusy=false}
}
// skor 1 hari: skor ikan (bulan, pasang, matahari) + koreksi cuaca bila prakiraan tersedia
function calDay(off){
  const c=cur(),sc=fishScore(off,c.lat,c.lon),tz=tzLL(c.lat,c.lon),date=new Date(sc.ds+tz*36e5).toISOString().slice(0,10);
  let bi=4,bv=-1;for(let h=4;h<21;h++){const v=sc.hours[h]+sc.hours[h+1];if(v>bv){bv=v;bi=h}}
  const wx=calWx&&calWxKey===calKey()?calWx.d[date]:null;let pen=0,bad=false;
  if(wx){if(wx.wind>30||(wx.wave!=null&&wx.wave>2)||wx.rain>15)bad=true;
    pen+=wx.wind>25?20:wx.wind>18?8:0;pen+=wx.wave==null?0:wx.wave>1.5?20:wx.wave>1?8:0;pen+=wx.rain>10?12:wx.rain>4?5:0}
  const ph=Math.round(sc.age/SYN*8)%8,dn=Math.min(sc.age,SYN-sc.age),df=Math.abs(sc.age-SYN/2),moon=dn<.75?"🌑":df<.75?"🌕":"";
  return{off,date,raw:sc.total,pen,score:sc.total,from:bi,to:bi+2,wx,bad,ph,moon,age:sc.age,sun:sc.sun,ds:sc.ds};
}
function calTides(ds){const x=[];let prev=tideMs(ds-9e5),cur0=tideMs(ds);for(let m=15;m<=24*60;m+=15){const nx=tideMs(ds+m*6e4);if((cur0>prev&&cur0>=nx)||(cur0<prev&&cur0<=nx))x.push({h:(m-15)/60,hi:cur0>prev});prev=cur0;cur0=nx}return x}
const calName=(date,long)=>new Date(date+"T12:00:00").toLocaleDateString(LOC_(),long?{weekday:"long",day:"numeric",month:"long"}:{weekday:"short",day:"numeric",month:"short"});
function calendarHtml(){
  loadCalWx();
  const c=cur(),tz=tzLL(c.lat,c.lon),now=new Date(Date.now()+tz*36e5),Y=now.getUTCFullYear(),M=now.getUTCMonth()+calMonth,first=new Date(Date.UTC(Y,M,1)),ym=first.toISOString().slice(0,7);
  const today0=Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()),nDays=new Date(Date.UTC(Y,M+1,0)).getUTCDate();
  const days=[];for(let d=1;d<=nDays;d++){const off=Math.round((Date.UTC(Y,M,d)-today0)/864e5);days.push(calDay(off))}
  const week=[];for(let o=0;o<7;o++)week.push(calDay(o));
  const fw=[...days,...week].filter(x=>x.wx),avgPen=fw.length?fw.reduce((a,x)=>a+x.pen,0)/fw.length:0;
  [...days,...week].forEach(x=>{x.score=Math.round(x.raw-(x.wx?x.pen:avgPen))});
  const fut=days.filter(x=>x.off>=0),sorted=[...fut].map(x=>x.score).sort((a,b)=>a-b),q=p=>sorted.length?sorted[Math.min(sorted.length-1,Math.floor(p*sorted.length))]:0,hi=q(.7),lo=q(.3);
  const col=x=>x.off<0?"past":x.bad?"red":(best&&x.date===best.date)||(bestMonth&&x.date===bestMonth.date)||x.score>=hi?"green":x.score>lo?"yellow":"red";
  const wk=[...week].filter(x=>!x.bad).sort((a,b)=>b.score-a.score),best=wk[0],top3=wk.slice(0,3);
  const bestMonth=[...fut].filter(x=>!x.bad).sort((a,b)=>b.score-a.score)[0];
  const sel=calSel&&calSel.slice(0,7)===ym?days.find(x=>x.date===calSel):null;
  const rem=store.get("mm_rem",[]),hasRem=d=>rem.some(r=>r.date===d&&r.id===c.id);
  const lead=(new Date(Date.UTC(Y,M,1)).getUTCDay()+6)%7,wd=region==="AU"?["Mo","Tu","We","Th","Fr","Sa","Su"]:["Sen","Sel","Rab","Kam","Jum","Sab","Min"];
  const moonIc=x=>x.moon;
  const cell=x=>`<button class="calc ${col(x)}${x.date===calSel?" sel":""}${x.off===0?" today":""}" data-cday="${x.date}"${x.off<0?" disabled":""}><b>${+x.date.slice(8)}</b><i>${best&&x.date===best.date?"⭐":bestMonth&&x.date===bestMonth.date?"🏆":moonIc(x)}${x.wx?"":x.off>=0?"<u>~</u>":""}</i></button>`;
  const head=`<div class="calhead"><button class="x" data-cm="-1"${calMonth<=0?" disabled":""} aria-label="${LX("Bulan sebelumnya","Previous month")}">‹</button><b>${first.toLocaleDateString(LOC_(),{month:"long",year:"numeric",timeZone:"UTC"})}</b><button class="x" data-cm="1"${calMonth>=2?" disabled":""} aria-label="${LX("Bulan berikutnya","Next month")}">›</button></div>`;
  return `<div class="card cal"><button class="calt" id="calTog"><h3>📅 ${LX("Kalender mancing","Fishing calendar")} · ${esc(c.n)}</h3><span>${calOpen?"▲":"▼"}</span></button>
   ${best?`<div class="calbest">⭐ <b>${LX("Hari terbaik minggu ini","Best day this week")}:</b> ${esc(calName(best.date,true))}, ${fmt(best.from)}–${fmt(best.to)}</div>`:""}
   ${calOpen?`
   ${top3.length>1?`<ol class="caltop">${top3.map(x=>`<li><button class="linkish" data-cday="${x.date}">${esc(calName(x.date))}</button> · ${fmt(x.from)}–${fmt(x.to)}</li>`).join("")}</ol>`:""}
   ${head}
   <div class="calgrid">${wd.map(w=>`<span class="calw">${w}</span>`).join("")}${"<span></span>".repeat(lead)}${days.map(cell).join("")}</div>
   <div class="callegend"><span><i class="dot green"></i>${LX("Bagus","Good")}</span><span><i class="dot yellow"></i>${LX("Sedang","Fair")}</span><span><i class="dot red"></i>${LX("Kurang","Poor")}</span><span>⭐ ${LX("terbaik minggu ini","best this week")}</span><span>🏆 ${LX("terbaik bulan ini","best this month")}</span><span>🌑🌕 ${LX("bulan baru / purnama","new / full moon")}</span><span><u>~</u> ${LX("perkiraan kasar (belum ada prakiraan cuaca)","rough estimate (no weather forecast yet)")}</span></div>
   ${sel?calDetailHtml(sel,hasRem(sel.date)):`<p class="note">${LX("Ketuk tanggal untuk melihat jam terbaik.","Tap a date to see the best times.")}</p>`}`:""}
  </div>`;
}
function calDetailHtml(x,on){
  const t=calTides(x.ds),w=x.wx,ln=window.Capacitor?.Plugins?.LocalNotifications;
  return `<div class="caldet"><h3>${esc(calName(x.date,true))}</h3>
   <p class="calbig">🎣 ${LX("Jam terbaik","Best time")}: <b>${fmt(x.from)}–${fmt(x.to)}</b></p>
   <p>🌙 ${LX(PHASE[x.ph],PHASE_EN[x.ph])} · 🌅 ${fmt(x.sun.rise)} · 🌇 ${fmt(x.sun.set)}</p>
   ${t.length?`<p>🌊 ${t.map(e=>`${e.hi?LX("Pasang","High"):LX("Surut","Low")} ${fmt(e.h)}`).join(" · ")}</p>`:""}
   ${w?`<p>💨 ${Math.round(w.wind)} ${LX("km/j","km/h")}${w.wave!=null?` · 🌊 ${LX("ombak","waves")} ${(+w.wave).toFixed(1)} m`:""} · 🌧️ ${Math.round(w.rain)} mm${x.bad?` · ⚠️ <b>${LX("cuaca buruk, tidak disarankan","bad weather, not advised")}</b>`:""}</p>`:`<p class="note">~ ${LX("Perkiraan dari bulan & pasang surut saja. Cuaca belum bisa diprakirakan untuk tanggal ini.","Estimate from moon & tides only. Weather can't be forecast this far ahead yet.")}</p>`}
   <button class="btn${on?" ghost":""}" data-crem="${x.date}" style="width:100%">${on?"✓ "+LX("Pengingat aktif (ketuk untuk batal)","Reminder set (tap to cancel)"):"🔔 "+LX("Ingatkan aku","Remind me")}</button>
   ${ln?"":`<p class="note">${LX("Di iPhone/browser, pengingat muncul saat aplikasi dibuka. Notifikasi penuh tersedia di aplikasi Android.","On iPhone/browser, reminders show when you open the app. Full notifications are available in the Android app.")}</p>`}</div>`;
}
async function toggleRem(date){
  const c=cur(),x=calDay(Math.round((Date.parse(date+"T12:00:00Z")-Date.parse(new Date(Date.now()+tzLL(c.lat,c.lon)*36e5).toISOString().slice(0,10)+"T12:00:00Z"))/864e5));
  let rem=store.get("mm_rem",[]);const i=rem.findIndex(r=>r.date===date&&r.id===c.id),nid=9000+Math.abs([...(c.id+date)].reduce((a,ch)=>(a*31+ch.charCodeAt(0))|0,7))%900;
  const ln=window.Capacitor?.Plugins?.LocalNotifications;
  if(i>=0){rem.splice(i,1);store.set("mm_rem",rem);try{await ln?.cancel({notifications:[{id:nid}]})}catch(e){}render();return}
  rem.push({date,id:c.id,n:c.n,from:x.from,to:x.to,nid});store.set("mm_rem",rem.slice(-30));
  if(ln){try{let p=await ln.checkPermissions();if(p.display!=="granted")p=await ln.requestPermissions();
      if(p.display==="granted"){let at=new Date(date+"T00:00:00");at.setDate(at.getDate()-1);at.setHours(19,0,0,0);if(at.getTime()<Date.now()+6e4){at=new Date(Date.now()+5e3)}
        await ln.schedule({notifications:[{id:nid,title:LX(`🎣 Besok mancing di ${c.n}`,`🎣 Fishing tomorrow at ${c.n}`),body:LX(`Jam terbaik ${fmt(x.from)}–${fmt(x.to)}. Cek cuaca di aplikasi.`,`Best time ${fmt(x.from)}–${fmt(x.to)}. Check the weather in the app.`),schedule:{at,allowWhileIdle:true},extra:{spot:c.id}}]})}}catch(e){}}
  else if(typeof Notification!=="undefined"&&Notification.permission==="default"){try{await Notification.requestPermission()}catch(e){}}
  render();
}
// pengingat web/iPhone: tampil saat aplikasi dibuka sehari sebelum / hari H
function checkReminders(){
  const rem=store.get("mm_rem",[]);if(!rem.length)return;const t=new Date(),iso=d=>new Date(d.getTime()-d.getTimezoneOffset()*6e4).toISOString().slice(0,10),today=iso(t),tom=iso(new Date(t.getTime()+864e5));
  const keep=rem.filter(r=>r.date>=today);if(keep.length!==rem.length)store.set("mm_rem",keep);
  const due=keep.filter(r=>r.date===today||r.date===tom);if(!due.length||window.Capacitor?.Plugins?.LocalNotifications)return;
  const shown=store.get("mm_rem_shown",{}),r=due.find(x=>!shown[x.date+x.id]);if(!r)return;shown[r.date+r.id]=1;store.set("mm_rem_shown",shown);
  const title=r.date===today?LX(`🎣 Hari ini mancing di ${r.n}`,`🎣 Fishing today at ${r.n}`):LX(`🎣 Besok mancing di ${r.n}`,`🎣 Fishing tomorrow at ${r.n}`),body=LX(`Jam terbaik ${fmt(r.from)}–${fmt(r.to)}`,`Best time ${fmt(r.from)}–${fmt(r.to)}`);
  try{if(typeof Notification!=="undefined"&&Notification.permission==="granted")navigator.serviceWorker?.ready.then(s=>s.showNotification(title,{body,icon:"icons/icon-192.png"}))}catch(e){}
  remBanner={title,body,id:r.id};
}
let remBanner=null;
function remBannerHtml(){return remBanner?`<div class="card calbest" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><span><b>${esc(remBanner.title)}</b><br>${esc(remBanner.body)}</span><button class="x" id="remX">✕</button></div>`:""}
function bindCalendar(){
  const tg=$("#calTog");if(tg)tg.onclick=()=>{calOpen=!calOpen;store.set("mm_cal_open",calOpen);render()};
  document.querySelectorAll("[data-cm]").forEach(b=>b.onclick=()=>{calMonth=Math.max(0,Math.min(2,calMonth+ +b.dataset.cm));calSel=null;render()});
  document.querySelectorAll("[data-cday]").forEach(b=>b.onclick=()=>{const d=b.dataset.cday,c=cur(),now=new Date(Date.now()+tzLL(c.lat,c.lon)*36e5);calMonth=(+d.slice(0,4)-now.getUTCFullYear())*12+(+d.slice(5,7)-1-now.getUTCMonth());calSel=d;calOpen=true;render();setTimeout(()=>document.querySelector(".caldet")?.scrollIntoView({behavior:"smooth",block:"nearest"}),60)});
  document.querySelectorAll("[data-crem]").forEach(b=>b.onclick=()=>toggleRem(b.dataset.crem));
  const rx=$("#remX");if(rx)rx.onclick=()=>{remBanner=null;render()};
}
setTimeout(()=>{checkReminders();if(remBanner)render()},2500);

/* ================= v11: RINGKASAN "HARI INI" UNTUK PEMULA + PANDUAN PERTAMA BUKA ================= */
function todayCardHtml(){
  const c=cur();if(!c)return "";loadCalWx();
  const week=[];for(let o=0;o<7;o++)week.push(calDay(o));
  const fw=week.filter(x=>x.wx),avgPen=fw.length?fw.reduce((a,x)=>a+x.pen,0)/fw.length:0;week.forEach(x=>x.score=Math.round(x.raw-(x.wx?x.pen:avgPen)));
  const t=week[0],ok=week.filter(x=>!x.bad).sort((a,b)=>b.score-a.score),best=ok[0],rank=ok.findIndex(x=>x.off===0);
  const v=t.bad?["no","❌",LX("Kurang disarankan","Not recommended"),LX("Angin/ombak/hujan terlalu kuat hari ini.","Wind, waves or rain are too strong today.")]
    :rank===0||rank===1?["good","✅",LX("Bagus untuk mancing","Good day to fish"),""]
    :rank>=0&&rank<=3?["mid","🙂",LX("Lumayan","Fair"),""]:["low","😐",LX("Kurang bagus","Not great"),""];
  const bait=Object.entries(spotData(c).bait||{})[0];
  const w=t.wx;
  return `<div class="card today ${v[0]}">
   <p class="note" style="margin:0">${LX("Hari ini di","Today at")} <b>${esc(c.n)}</b></p>
   <div class="tbig">${v[1]} ${v[2]}</div>${v[3]?`<p class="note" style="margin:2px 0 0">${v[3]}</p>`:""}
   <div class="trow"><div><span>⏰ ${LX("Jam terbaik","Best time")}</span><b>${fmt(t.from)}–${fmt(t.to)}</b></div>
     ${bait?`<div><span>🪱 ${LX("Umpan","Bait")}</span><b>${esc(bait[0])}</b><small>${esc(bait[1].slice(0,2).join(", "))}</small></div>`:""}
     ${w?`<div><span>💨 ${LX("Angin","Wind")}</span><b>${Math.round(w.wind)} ${LX("km/j","km/h")}</b>${w.wave!=null?`<small>🌊 ${(+w.wave).toFixed(1)} m</small>`:""}</div>`:""}</div>
   ${best&&best.off!==0?`<button class="tnext" data-goto-cal="${best.date}">⭐ ${LX("Hari terbaik minggu ini","Best day this week")}: <b>${esc(calName(best.date))}, ${fmt(best.from)}–${fmt(best.to)}</b> ›</button>`:""}
   ${(()=>{const ln=LN(),on=store.get("mm_ln_on",false);return ln?(on?`<p class="note" style="margin:6px 0 0">🔔 ${LX("Notifikasi hari bagus aktif.","Good-day notifications on.")} <a href="#" id="lnOff">${LX("Matikan","Turn off")}</a></p>`:`<button class="btn ghost" id="lnOn" style="width:100%;margin-top:8px">🔔 ${LX("Kabari aku kalau ada hari bagus","Notify me about good days")}</button>`):""})()}
   <button class="linkish" data-goto-cal="" style="margin-top:6px">📅 ${LX("Lihat kalender mancing sebulan","See the monthly fishing calendar")} ›</button>
  </div>`;
}
function bindToday(){document.querySelectorAll("[data-goto-cal]").forEach(b=>b.onclick=()=>{const d=b.dataset.gotoCal;calOpen=true;store.set("mm_cal_open",true);calSel=d||null;calMonth=0;view="prakiraan";document.querySelectorAll(".tabbar button").forEach(x=>x.setAttribute("aria-selected",x.dataset.v==="prakiraan"));$("#main").scrollTop=0;render()})}
// --- panduan pertama buka (sekali saja) ---
let onbStep=0;
const ONB=()=>[["🗺️",LX("Peta","Map"),LX("Lihat “Hari ini” di atas: bagus/tidak untuk mancing, jam terbaik & umpan. Pilih lokasi di kanan atas.","Check “Today” at the top: good day or not, best time & bait. Pick a spot at the top right.")],
  ["🌊",LX("Pasang","Tides"),LX("Kalender sebulan: hijau = hari bagus. Ketuk tanggal untuk jam terbaik & pasang surut, lalu “Ingatkan aku”.","Monthly calendar: green = good day. Tap a date for best times & tides, then “Remind me”.")],
  ["🐟",LX("Ikan & Umpan","Fish & Bait"),LX("Ikan apa yang ada di spot ini dan umpan yang cocok.","Which fish are at this spot and the right bait.")],
  ["📷",LX("Tangkapan & Komunitas","Catches & Community"),LX("Simpan tangkapanmu, pamer foto, tanya-jawab dengan pemancing lain.","Log your catches, share photos and chat with other anglers.")]];
function onboardingHtml(){if(store.get("mm_onb",0))return "";const s=ONB(),k=s[onbStep];
  return `<div class="onb" role="dialog" aria-modal="true"><div class="onbbox"><div class="onbic">${k[0]}</div><h2>${esc(k[1])}</h2><p>${esc(k[2])}</p>
   <div class="onbdots">${s.map((_,i)=>`<i class="${i===onbStep?"on":""}"></i>`).join("")}</div>
   <div class="two"><button class="btn ghost" id="onbSkip">${LX("Lewati","Skip")}</button><button class="btn" id="onbNext">${onbStep<s.length-1?LX("Lanjut","Next"):LX("Mulai mancing 🎣","Start fishing 🎣")}</button></div></div></div>`}
function showOnboarding(){if(store.get("mm_onb",0))return;document.querySelector(".onb")?.remove();document.body.insertAdjacentHTML("beforeend",onboardingHtml());tr(document.querySelector(".onb"));
  const done=()=>{store.set("mm_onb",1);document.querySelector(".onb")?.remove()};
  $("#onbSkip").onclick=done;$("#onbNext").onclick=()=>{if(onbStep<ONB().length-1){onbStep++;showOnboarding()}else done()}}
setTimeout(showOnboarding,1200);

const URLSPOT=(()=>{try{const id=new URLSearchParams(location.search).get("spot");const sp=id&&LOC.find(x=>x.id===id);if(!sp)return null;region=sp.region||regionOf(sp.lat,sp.lon);store.set("mm_region",region);$("#region").value=region;curId=id;store.set("mm_cur",id);history.replaceState(null,"",location.pathname);return id}catch(e){return null}})();
fillPick();render();initCommunity();setTimeout(dailyReminder,3000);
// deteksi lokasi otomatis bila izin sudah pernah diberikan
// setiap aplikasi dibuka: pakai lokasi HP untuk memilih negara & spot terdekat
if(!URLSPOT)detectGPS(true);
// PWA: service worker untuk mode offline & install
if(!window.Capacitor&&"serviceWorker" in navigator&&location.protocol==="https:")navigator.serviceWorker.register("sw.js").catch(()=>{});

// tema terang / gelap
(function(){const k="mm_theme";let t="light";try{t=localStorage.getItem(k)||"light"}catch(e){}
 const apply=v=>{document.documentElement.dataset.mm=v;const b=document.getElementById("thBtn");if(b){b.textContent=v==="dark"?"☀️":"🌙";b.setAttribute("aria-label",v==="dark"?"Ganti ke tema terang":"Ganti ke tema gelap")}const m=document.querySelector('meta[name="theme-color"]');if(m)m.content=v==="dark"?"#050d1e":"#ffffff"};
 apply(t);document.getElementById("thBtn").onclick=()=>{t=t==="dark"?"light":"dark";try{localStorage.setItem(k,t)}catch(e){}apply(t)}})();

// Cegah zoom halaman (cubit & ketuk dua kali) kecuali di peta
(function(){
  const onMap=t=>t&&t.closest&&t.closest(".leaflet-container");
  ["gesturestart","gesturechange","gestureend"].forEach(ev=>document.addEventListener(ev,e=>{if(!onMap(e.target))e.preventDefault()},{passive:false}));
  document.addEventListener("touchmove",e=>{if(e.touches.length>1&&!onMap(e.target))e.preventDefault()},{passive:false});
  document.addEventListener("wheel",e=>{if(e.ctrlKey&&!onMap(e.target))e.preventDefault()},{passive:false});
  document.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&["+","-","=","0"].includes(e.key))e.preventDefault()});
})();

// Layar tetap menyala selama aplikasi terbuka (web: Screen Wake Lock API; APK: diatur di MainActivity)
(function(){let wl=null;const want=()=>store.get("mm_awake",true);
  async function grab(){try{if(!want()||!("wakeLock" in navigator)||document.visibilityState!=="visible"||wl)return;wl=await navigator.wakeLock.request("screen");wl.addEventListener("release",()=>{wl=null})}catch(e){wl=null}}
  document.addEventListener("visibilitychange",grab);["click","touchstart"].forEach(ev=>document.addEventListener(ev,grab,{passive:true}));grab();
  window.setAwake=v=>{store.set("mm_awake",v);if(!v&&wl){wl.release();wl=null}else grab()};})();
