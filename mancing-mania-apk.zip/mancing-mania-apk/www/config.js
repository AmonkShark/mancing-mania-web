/* ============================================================
   KONFIGURASI MANCING MANIA — isi bagian ini sesuai PANDUAN.md
   ============================================================ */
window.MM_CONFIG = {
  // Dari Supabase: Project Settings → API (Data API)
  SUPABASE_URL: "",        // contoh: "https://abcdxyz.supabase.co"
  SUPABASE_ANON_KEY: "",   // kunci "anon" / "publishable" (aman untuk aplikasi)

  // Opsional: video YouTube yang diputar langsung di aplikasi.
  // Kunci = nama ikan / nama rakitan / judul tips persis seperti di aplikasi.
  // Nilai = ID video YouTube (bagian setelah "v=" di link), mis. "dQw4w9WgXcQ".
  VIDEOS: {
    // "GT": "ID_VIDEO",
    // "Running sinker rig": "ID_VIDEO",
    // "Mancing squid": "ID_VIDEO",
  }
};
