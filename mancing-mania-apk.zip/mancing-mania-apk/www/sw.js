/* Service worker KailSpot: aplikasi tetap terbuka saat offline */
const VERSION = "mm-v59";
const SHELL = ["./", "index.html", "style.css", "app.js", "config.js", "i18n-en.js", "manifest.webmanifest",
  "icons/gt.svg", "icons/badge.png", "icons/logo.png", "icons/header-logo.png", "icons/watermark.png", "icons/header-logo-dark.png", "icons/header-marlins.png", "icons/icon-192.png", "icons/icon-512.png", "icons/favicon-64.png",
  "vendor/leaflet/leaflet.css", "vendor/leaflet/leaflet.js", "vendor/supabase/supabase.js", "vendor/supabase/591.supabase.js",
  "fonts/anton-latin-400-normal.woff2", "fonts/bricolage-grotesque-latin-600-normal.woff2", "fonts/bricolage-grotesque-latin-800-normal.woff2",
  "fonts/source-sans-3-latin-400-normal.woff2", "fonts/source-sans-3-latin-600-normal.woff2", "fonts/jetbrains-mono-latin-500-normal.woff2"];
self.addEventListener("install", e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION && k !== "mm-tiles").map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET") return;
  if (u.pathname.endsWith(".apk")) return; // file APK besar: jangan di-cache
  // Data live (cuaca, Supabase, pencarian, peta) selalu dari internet; tidak di-cache di sini
  // Ubin peta: simpan yang pernah dibuka (maks ±600) supaya peta tetap tampil saat offline
  if (/tile\.openstreetmap/.test(u.hostname)) {
    e.respondWith(caches.open("mm-tiles").then(c => c.match(e.request).then(hit => {
      const net = fetch(e.request).then(r => { if (r.ok) { c.put(e.request, r.clone()); c.keys().then(ks => { if (ks.length > 600) ks.slice(0, ks.length - 600).forEach(k => c.delete(k)) }) } return r });
      return hit ? (net.catch(() => hit), hit) : net;
    })));
    return;
  }
  if (/open-meteo\.com|supabase\.co|nominatim/.test(u.hostname)) return;
  // File aplikasi: ambil versi terbaru, pakai cache bila offline
  e.respondWith(fetch(e.request).then(r => {
    if (r.ok && (u.origin === location.origin || /unpkg|jsdelivr|fonts\.(googleapis|gstatic)/.test(u.hostname))) {
      const copy = r.clone(); caches.open(VERSION).then(c => c.put(e.request, copy));
    }
    return r;
  }).catch(() => caches.match(e.request).then(m => m || caches.match("index.html"))));
});
