-- MANCING MANIA v4: titik komunitas (rumpon/karang) & daftar toko pancing / sewa perahu (aman dijalankan ulang)
create table if not exists public.points (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  name text not null check (char_length(trim(name)) between 2 and 50),
  kind text not null default 'rumpon' check (kind in ('rumpon','karang','spot','bahaya')),
  note text check (note is null or char_length(note) <= 200),
  lat double precision not null, lon double precision not null,
  depth_m int check (depth_m is null or depth_m between 0 and 2000),
  public boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind text not null check (kind in ('toko','sewa')),
  name text not null check (char_length(trim(name)) between 2 and 60),
  region text check (region in ('ID','AU')),
  area text check (area is null or char_length(area) <= 80),
  phone text check (phone is null or char_length(phone) <= 25),
  note text check (note is null or char_length(note) <= 300),
  lat double precision, lon double precision,
  status text not null default 'baru' check (status in ('baru','setuju','tolak')),
  created_at timestamptz not null default now()
);
alter table public.points enable row level security;
alter table public.listings enable row level security;

drop policy if exists "titik dibaca" on public.points;
create policy "titik dibaca" on public.points for select using (public or user_id = auth.uid());
drop policy if exists "titik dibuat" on public.points;
create policy "titik dibuat" on public.points for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "titik diubah" on public.points;
create policy "titik diubah" on public.points for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "titik dihapus" on public.points;
create policy "titik dihapus" on public.points for delete to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists "daftar dibaca" on public.listings;
create policy "daftar dibaca" on public.listings for select using (status = 'setuju' or user_id = auth.uid() or public.is_admin());
drop policy if exists "daftar dibuat" on public.listings;
create policy "daftar dibuat" on public.listings for insert to authenticated with check (user_id = auth.uid() and status = 'baru');
drop policy if exists "daftar dinilai admin" on public.listings;
create policy "daftar dinilai admin" on public.listings for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "daftar dihapus" on public.listings;
create policy "daftar dihapus" on public.listings for delete to authenticated using (user_id = auth.uid() or public.is_admin());

grant select on public.points, public.listings to anon, authenticated;
grant insert, update, delete on public.points, public.listings to authenticated;
